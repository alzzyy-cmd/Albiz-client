/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.pipeline.BlendFunction
 *  com.mojang.blaze3d.pipeline.RenderPipeline
 *  com.mojang.blaze3d.pipeline.RenderPipeline$Builder
 *  com.mojang.blaze3d.pipeline.RenderPipeline$Snippet
 *  com.mojang.blaze3d.platform.DepthTestFunction
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.vertex.VertexFormat$class_5596
 *  net.minecraft.class_10799
 *  net.minecraft.class_12245
 *  net.minecraft.class_12246
 *  net.minecraft.class_12247
 *  net.minecraft.class_12250
 *  net.minecraft.class_1921
 *  net.minecraft.class_290
 *  net.minecraft.class_2960
 *  net.minecraft.class_918
 */
package dev.sober.sky;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.sober.SoberClient;
import dev.sober.modules.CustomGlint;
import dev.sober.sky.GlintManager;
import dev.sober.sky.GlintType;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_12250;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_918;

public final class GlintCover {
    private static final int ARMOR = 0;
    private static final int GLINT = 1;
    private static final int TRANSLUCENT = 2;
    private static final int ENTITY = 3;
    private static final int FULL = 4;
    private static class_1921[] cover;
    private static RenderPipeline coverFull;
    private static final Map<GlintType, class_1921[]> SHADERS;
    private static final Map<GlintType, RenderPipeline> PIPELINES;
    private static final Map<GlintType, RenderPipeline> FULL_PIPELINES;
    private static final Map<GlintType, Boolean> VALID;
    private static final Map<RenderPipeline, Boolean> COMPILED;

    private GlintCover() {
    }

    private static CustomGlint module() {
        return SoberClient.MODULES == null ? null : SoberClient.MODULES.get(CustomGlint.class);
    }

    private static boolean active() {
        CustomGlint module = GlintCover.module();
        return module != null && module.isActive() && GlintManager.current() != GlintType.VANILLA;
    }

    private static class_1921[] layers(RenderPipeline pipeline, RenderPipeline full, String name) {
        class_1921[] layers = new class_1921[8];
        GlintCover.fill(layers, 0, pipeline, name);
        GlintCover.fill(layers, 4, full, name + "_full");
        return layers;
    }

    private static void fill(class_1921[] layers, int offset, RenderPipeline pipeline, String name) {
        layers[offset + 2] = class_1921.method_75940((String)(name + "_translucent"), (class_12247)class_12247.method_75927((RenderPipeline)pipeline).method_75934("Sampler0", class_918.field_43087).method_75933(class_12250.field_64069).method_75931(class_12246.field_63983).method_75938());
        layers[offset + 3] = class_1921.method_75940((String)(name + "_entity"), (class_12247)class_12247.method_75927((RenderPipeline)pipeline).method_75934("Sampler0", class_918.field_43087).method_75933(class_12250.field_64070).method_75938());
        layers[offset + 0] = class_1921.method_75940((String)(name + "_armor_entity"), (class_12247)class_12247.method_75927((RenderPipeline)pipeline).method_75934("Sampler0", class_918.field_43086).method_75933(class_12250.field_64071).method_75930(class_12245.field_63976).method_75938());
        layers[offset + 1] = class_1921.method_75940((String)name, (class_12247)class_12247.method_75927((RenderPipeline)pipeline).method_75934("Sampler0", class_918.field_43087).method_75933(class_12250.field_64069).method_75938());
    }

    private static RenderPipeline.Builder base(String location, class_2960 vertex, class_2960 fragment, BlendFunction blend) {
        return RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[]{class_10799.field_60125, class_10799.field_56848, class_10799.field_60126}).withLocation(class_2960.method_60655((String)"sober", (String)location)).withVertexShader(vertex).withFragmentShader(fragment).withSampler("Sampler0").withDepthWrite(false).withCull(false).withDepthTestFunction(DepthTestFunction.EQUAL_DEPTH_TEST).withBlend(blend).withVertexFormat(class_290.field_1585, VertexFormat.class_5596.field_27382);
    }

    private static void create() {
        if (cover != null) {
            return;
        }
        class_2960 glintVertex = class_2960.method_60656((String)"core/glint");
        class_2960 coverFragment = class_2960.method_60655((String)"sober", (String)"core/glint_cover");
        RenderPipeline pipeline = GlintCover.base("pipeline/glint_cover", glintVertex, coverFragment, BlendFunction.TRANSLUCENT).build();
        coverFull = GlintCover.base("pipeline/glint_cover_full", glintVertex, coverFragment, BlendFunction.TRANSLUCENT).withShaderDefine("FULL_COVER").build();
        cover = GlintCover.layers(pipeline, coverFull, "sober_glint");
        for (GlintType type : GlintType.values()) {
            String shader = type.shader();
            if (shader == null) continue;
            class_2960 fxVertex = class_2960.method_60655((String)"sober", (String)"core/glintfx");
            class_2960 fxFragment = class_2960.method_60655((String)"sober", (String)("core/glintfx_" + shader));
            RenderPipeline fx = GlintCover.base("pipeline/glintfx_" + shader, fxVertex, fxFragment, BlendFunction.GLINT).build();
            RenderPipeline fxFull = GlintCover.base("pipeline/glintfx_full_" + shader, fxVertex, fxFragment, BlendFunction.TRANSLUCENT).withShaderDefine("FULL_COVER").build();
            PIPELINES.put(type, fx);
            FULL_PIPELINES.put(type, fxFull);
            SHADERS.put(type, GlintCover.layers(fx, fxFull, "sober_glintfx_" + shader));
        }
    }

    public static List<class_1921> layers() {
        GlintCover.create();
        ArrayList<class_1921> all = new ArrayList<class_1921>(List.of(cover));
        for (class_1921[] set : SHADERS.values()) {
            all.addAll(List.of(set));
        }
        return all;
    }

    private static class_1921 pick(int index, boolean full) {
        if (!GlintCover.active()) {
            return null;
        }
        GlintCover.create();
        GlintType type = GlintManager.current();
        if (type.shader() == null) {
            return full && GlintCover.compiles(coverFull) ? cover[4 + index] : cover[index];
        }
        class_1921[] set = SHADERS.get((Object)type);
        if (set == null || !GlintCover.valid(type)) {
            return null;
        }
        return full && GlintCover.compiles(FULL_PIPELINES.get((Object)type)) ? set[4 + index] : set[index];
    }

    private static boolean fullItems() {
        CustomGlint module = GlintCover.module();
        return module != null && module.fullItemCover.get() != false;
    }

    private static boolean compiles(RenderPipeline pipeline) {
        boolean ok;
        Boolean known = COMPILED.get(pipeline);
        if (known != null) {
            return known;
        }
        try {
            ok = RenderSystem.getDevice().precompilePipeline(pipeline).isValid();
        }
        catch (RuntimeException e) {
            ok = false;
        }
        if (!ok) {
            SoberClient.LOG.error("Full cover glint shader {} failed to compile, using the normal glint", (Object)pipeline.getLocation());
        }
        COMPILED.put(pipeline, ok);
        return ok;
    }

    private static boolean valid(GlintType type) {
        boolean ok;
        Boolean known = VALID.get((Object)type);
        if (known != null) {
            return known;
        }
        try {
            ok = RenderSystem.getDevice().precompilePipeline(PIPELINES.get((Object)type)).isValid();
        }
        catch (RuntimeException e) {
            ok = false;
        }
        if (!ok) {
            SoberClient.LOG.error("Glint shader '{}' failed to compile, falling back to the vanilla glint", (Object)type.shader());
        }
        VALID.put(type, ok);
        return ok;
    }

    public static class_1921 glint() {
        return GlintCover.pick(1, GlintCover.fullItems());
    }

    public static class_1921 translucent() {
        return GlintCover.pick(2, GlintCover.fullItems());
    }

    public static class_1921 entity() {
        return GlintCover.pick(3, GlintCover.fullItems());
    }

    public static class_1921 armor() {
        CustomGlint module = GlintCover.module();
        return GlintCover.pick(0, module != null && module.fullArmorCover.get() != false);
    }

    static {
        SHADERS = new EnumMap<GlintType, class_1921[]>(GlintType.class);
        PIPELINES = new EnumMap<GlintType, RenderPipeline>(GlintType.class);
        FULL_PIPELINES = new EnumMap<GlintType, RenderPipeline>(GlintType.class);
        VALID = new EnumMap<GlintType, Boolean>(GlintType.class);
        COMPILED = new IdentityHashMap<RenderPipeline, Boolean>();
    }
}

