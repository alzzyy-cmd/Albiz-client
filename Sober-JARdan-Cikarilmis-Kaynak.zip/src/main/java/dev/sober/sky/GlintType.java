/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.jspecify.annotations.Nullable
 */
package dev.sober.sky;

import org.jspecify.annotations.Nullable;

public enum GlintType {
    VANILLA(null, 1.0f, null),
    PALM("palm", 6.0f, null),
    GALAXY("galaxy", 3.0f, null),
    RAINBOW("rainbow", 2.5f, null),
    ICE("ice", 3.0f, null),
    SUMMER("summer", 3.0f, null),
    LAGOON("lagoon", 3.0f, null),
    INFERNO("inferno", 3.0f, null),
    VELVET("velvet", 3.0f, null),
    AURUM("aurum", 3.0f, null),
    FIRE(null, 1.0f, "fire"),
    LIGHTNING(null, 1.0f, "lightning"),
    SAKURA(null, 1.0f, "sakura"),
    GOLD(null, 1.0f, "gold"),
    VOID(null, 1.0f, "void"),
    MATRIX(null, 1.0f, "matrix"),
    SYNTHWAVE(null, 1.0f, "synthwave"),
    CHROME(null, 1.0f, "chrome"),
    TOXIC(null, 1.0f, "toxic"),
    HEARTS(null, 1.0f, "hearts");

    private final @Nullable String texture;
    private final float scale;
    private final @Nullable String shader;

    private GlintType(@Nullable String texture, float scale, String shader) {
        this.texture = texture;
        this.scale = scale;
        this.shader = shader;
    }

    public @Nullable String texture() {
        return this.texture;
    }

    public float scale() {
        return this.scale;
    }

    public @Nullable String shader() {
        return this.shader;
    }
}

