/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.buffers.GpuBufferSlice
 *  com.mojang.blaze3d.pipeline.BlendFunction
 *  com.mojang.blaze3d.pipeline.RenderPipeline
 *  com.mojang.blaze3d.pipeline.RenderPipeline$Snippet
 *  com.mojang.blaze3d.platform.DepthTestFunction
 *  com.mojang.blaze3d.systems.CommandEncoder
 *  com.mojang.blaze3d.systems.RenderPass
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.textures.AddressMode
 *  com.mojang.blaze3d.textures.FilterMode
 *  com.mojang.blaze3d.vertex.VertexFormat$class_5596
 *  net.minecraft.class_10789
 *  net.minecraft.class_156
 *  net.minecraft.class_276
 *  net.minecraft.class_290
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_6367
 *  net.minecraft.class_746
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Vector3f
 *  org.joml.Vector3fc
 *  org.joml.Vector4f
 *  org.joml.Vector4fc
 *  org.jspecify.annotations.Nullable
 */
package dev.sober.sky;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.sober.SoberClient;
import dev.sober.modules.CustomGlint;
import dev.sober.modules.FpsBooster;
import java.util.OptionalInt;
import net.minecraft.class_10789;
import net.minecraft.class_156;
import net.minecraft.class_276;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_6367;
import net.minecraft.class_746;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.joml.Vector4f;
import org.joml.Vector4fc;
import org.jspecify.annotations.Nullable;

public final class ItemAuraRenderer {
    private static final RenderPipeline PIPELINE = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"sober", (String)"pipeline/item_aura")).withVertexShader("core/screenquad").withFragmentShader(class_2960.method_60655((String)"sober", (String)"core/item_aura")).withSampler("InSampler").withUniform("DynamicTransforms", class_10789.field_60031).withUniform("Globals", class_10789.field_60031).withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379).build();
    private static final RenderPipeline COMPOSITE = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[0]).withLocation(class_2960.method_60655((String)"sober", (String)"pipeline/item_aura_composite")).withVertexShader("core/screenquad").withFragmentShader("core/blit_screen").withSampler("InSampler").withBlend(BlendFunction.TRANSLUCENT_PREMULTIPLIED_ALPHA).withDepthWrite(false).withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST).withColorWrite(true, false).withVertexFormat(class_290.field_60033, VertexFormat.class_5596.field_27379).build();
    private static boolean handSubmitted;
    private static boolean reportedInvalid;
    private static @Nullable class_6367 half;

    private ItemAuraRenderer() {
    }

    private static boolean shouldRender(@Nullable class_746 player) {
        return SoberClient.MODULES.get(CustomGlint.class).itemAura.get() != false && player != null && (!player.method_6047().method_7960() || !player.method_6079().method_7960());
    }

    public static void onHandSubmitted(@Nullable class_746 player) {
        handSubmitted = !FpsBooster.lowEnd() && ItemAuraRenderer.shouldRender(player);
    }

    public static void afterFeatures() {
        if (!handSubmitted) {
            return;
        }
        handSubmitted = false;
        class_310 mc = class_310.method_1551();
        mc.method_22940().method_23000().method_22993();
        if (!RenderSystem.getDevice().precompilePipeline(PIPELINE).isValid() || !RenderSystem.getDevice().precompilePipeline(COMPOSITE).isValid()) {
            if (!reportedInvalid) {
                reportedInvalid = true;
                SoberClient.LOG.error("Item aura shader failed to compile, item aura disabled");
            }
            return;
        }
        class_276 main = mc.method_1522();
        if (main.method_71640() == null) {
            return;
        }
        float seconds = (float)(class_156.method_658() % 3600000L) / 1000.0f;
        CustomGlint glint = SoberClient.MODULES.get(CustomGlint.class);
        int rgb = glint.itemAuraColor(seconds);
        float scale = Math.max(1.0f, (float)main.field_1481 / 540.0f);
        GpuBufferSlice transforms = RenderSystem.getDynamicUniforms().method_71106((Matrix4fc)new Matrix4f(), (Vector4fc)new Vector4f((float)(rgb >> 16 & 0xFF) / 255.0f, (float)(rgb >> 8 & 0xFF) / 255.0f, (float)(rgb & 0xFF) / 255.0f, 1.0f), (Vector3fc)new Vector3f((float)glint.itemWidth.get().intValue() * scale, (float)glint.itemGlow.get().intValue() * 2.0f * scale, seconds), (Matrix4fc)new Matrix4f());
        int width = Math.max(1, main.field_1482 / 2);
        int height = Math.max(1, main.field_1481 / 2);
        if (half == null) {
            half = new class_6367("Sober item aura", width, height, false);
        } else if (ItemAuraRenderer.half.field_1482 != width || ItemAuraRenderer.half.field_1481 != height) {
            half.method_1234(width, height);
        }
        CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
        try (RenderPass pass = encoder.createRenderPass(() -> "Sober item aura", half.method_71639(), OptionalInt.of(0));){
            pass.setPipeline(PIPELINE);
            RenderSystem.bindDefaultUniforms((RenderPass)pass);
            pass.setUniform("DynamicTransforms", transforms);
            pass.bindTexture("InSampler", main.method_71640(), RenderSystem.getSamplerCache().method_75294(FilterMode.NEAREST));
            pass.draw(0, 3);
        }
        pass = encoder.createRenderPass(() -> "Sober item aura composite", main.method_71639(), OptionalInt.empty());
        try {
            pass.setPipeline(COMPOSITE);
            RenderSystem.bindDefaultUniforms((RenderPass)pass);
            pass.bindTexture("InSampler", half.method_71639(), RenderSystem.getSamplerCache().method_75293(AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE, FilterMode.LINEAR, FilterMode.LINEAR, false));
            pass.draw(0, 3);
        }
        finally {
            if (pass != null) {
                pass.close();
            }
        }
    }
}

