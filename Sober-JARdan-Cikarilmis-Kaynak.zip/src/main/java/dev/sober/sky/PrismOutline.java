/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.pipeline.BlendFunction
 *  com.mojang.blaze3d.pipeline.RenderPipeline
 *  com.mojang.blaze3d.pipeline.RenderPipeline$Snippet
 *  com.mojang.blaze3d.platform.DepthTestFunction
 *  net.minecraft.class_10799
 *  net.minecraft.class_12074
 *  net.minecraft.class_12247
 *  net.minecraft.class_12247$class_12248
 *  net.minecraft.class_1921
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2350$class_2351
 *  net.minecraft.class_238
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_265
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3965
 *  net.minecraft.class_4587
 *  net.minecraft.class_4587$class_4665
 *  net.minecraft.class_4588
 *  net.minecraft.class_4597
 *  net.minecraft.class_4597$class_4598
 */
package dev.sober.sky;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_12074;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;

public final class PrismOutline {
    private static final class_243 X_AXIS = new class_243(1.0, 0.0, 0.0);
    private static final class_243 Y_AXIS = new class_243(0.0, 1.0, 0.0);
    private static final class_243 Z_AXIS = new class_243(0.0, 0.0, 1.0);
    private static final double[] SHADE = new double[]{0.72, 0.96, 1.0, 0.84, 0.57, 0.43, 0.5, 0.63};
    private static final double GLOW = 0.55;
    private static final double OPACITY = 0.95;
    private static final double DETAIL = 1.0;
    private static final double SPACING = 0.04;
    private static final class_1921 MATERIAL = PrismOutline.layer("prism_material", false);
    private static final class_1921 LIGHT = PrismOutline.layer("prism_light", true);
    private static Selection current;
    private static Selection previous;
    private static Object world;
    private static long lastFrame;
    private static double time;

    private PrismOutline() {
    }

    private static class_1921 layer(String name, boolean light) {
        RenderPipeline pipeline = RenderPipeline.builder((RenderPipeline.Snippet[])new RenderPipeline.Snippet[]{class_10799.field_56860}).withLocation(class_2960.method_60655((String)"sober", (String)("pipeline/" + name))).withBlend(light ? BlendFunction.LIGHTNING : BlendFunction.TRANSLUCENT).withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST).withDepthWrite(false).withCull(false).build();
        class_12247.class_12248 setup = class_12247.method_75927((RenderPipeline)pipeline);
        if (!light) {
            setup.method_75937();
        }
        return class_1921.method_75940((String)("sober_" + name), (class_12247)setup.method_75938());
    }

    public static void render(class_4597 consumers, class_4587 matrices, class_12074 outline, class_243 camera, int primary, int accent, double thickness, double speed) {
        class_3965 block;
        class_310 mc = class_310.method_1551();
        class_239 class_2392 = mc.field_1765;
        class_3965 hit = class_2392 instanceof class_3965 && (block = (class_3965)class_2392).method_17783() == class_239.class_240.field_1332 ? block : null;
        PrismOutline.track(outline, hit, mc.field_1687, System.nanoTime(), speed);
        if (current == null && previous == null) {
            return;
        }
        int first = 0xFF000000 | primary;
        int second = 0xFF000000 | accent;
        PrismOutline.draw(consumers, matrices, camera, MATERIAL, false, first, second, thickness);
        PrismOutline.draw(consumers, matrices, camera, LIGHT, true, first, second, thickness);
    }

    private static void track(class_12074 outline, class_3965 hit, Object level, long now, double speed) {
        boolean animate;
        if (world != level) {
            previous = null;
            current = null;
            lastFrame = 0L;
            time = 0.0;
            world = level;
        }
        double dt = lastFrame == 0L ? 0.016666666666666666 : Math.clamp((double)((double)(now - lastFrame) / 1.0E9), (double)0.0, (double)0.1);
        lastFrame = now;
        boolean bl = animate = speed > 0.0;
        if (animate) {
            time += dt * speed;
        }
        if (outline != null && !outline.comp_4935().method_1110()) {
            if (current == null || !PrismOutline.current.pos.equals((Object)outline.comp_4932())) {
                Selection reuse = previous != null && PrismOutline.previous.pos.equals((Object)outline.comp_4932()) ? previous : null;
                previous = current;
                current = reuse == null ? new Selection(outline) : reuse;
            }
            current.update(outline, hit);
            PrismOutline.current.progress = animate ? Math.min(1.0, PrismOutline.current.progress + dt / 0.2) : 1.0;
        } else if (current != null) {
            previous = current;
            current = null;
        }
        if (previous != null) {
            double d = PrismOutline.previous.progress = animate ? Math.max(0.0, PrismOutline.previous.progress - dt / 0.16) : 0.0;
            if (PrismOutline.previous.progress <= 0.0) {
                previous = null;
            }
        }
    }

    private static void draw(class_4597 consumers, class_4587 matrices, class_243 camera, class_1921 layer, boolean light, int first, int second, double thickness) {
        class_4588 buffer = consumers.method_73477(layer);
        PrismOutline.selection(buffer, matrices, camera, previous, light, first, second, thickness);
        PrismOutline.selection(buffer, matrices, camera, current, light, first, second, thickness);
        if (consumers instanceof class_4597.class_4598) {
            class_4597.class_4598 immediate = (class_4597.class_4598)consumers;
            immediate.method_22994(layer);
        }
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private static void selection(class_4588 buffer, class_4587 matrices, class_243 camera, Selection selection, boolean light, int first, int second, double thickness) {
        if (selection == null || selection.progress <= 0.001) {
            return;
        }
        double eased = selection.eased();
        double spacing = 0.04 + (1.0 - eased) * 0.14;
        float alpha = (float)(eased * 0.95 * 0.96);
        if (light) {
            alpha *= 0.55f;
        }
        matrices.method_22903();
        try {
            class_2338 pos = selection.pos;
            matrices.method_22904((double)pos.method_10263() - camera.field_1352, (double)pos.method_10264() - camera.field_1351, (double)pos.method_10260() - camera.field_1350);
            Mesh mesh = new Mesh(buffer, matrices.method_23760(), light, alpha, camera.method_1023((double)pos.method_10263(), (double)pos.method_10264(), (double)pos.method_10260()));
            class_238 box = selection.box;
            double thick = thickness * 0.0075 * 1.0;
            PrismOutline.corners(mesh, box, spacing, thick, 1.0, eased, time, first, second);
            PrismOutline.rings(mesh, box, spacing, thick, 1.0, time, first, second);
            PrismOutline.faceMarker(mesh, selection, spacing, thick, 1.0, eased, time, first, second);
        }
        finally {
            matrices.method_22909();
        }
    }

    private static void corners(Mesh mesh, class_238 box, double spacing, double thick, double scale, double eased, double time, int first, int second) {
        double size = 0.24;
        double lx = Math.min(box.method_17939() * 0.32, size * scale) * (0.55 + eased * 0.45);
        double ly = Math.min(box.method_17940() * 0.32, size * scale) * (0.55 + eased * 0.45);
        double lz = Math.min(box.method_17941() * 0.32, size * scale) * (0.55 + eased * 0.45);
        thick = Math.min(thick, (Math.min(box.method_17939(), Math.min(box.method_17940(), box.method_17941())) + spacing * 2.0) * 0.17);
        for (int i = 0; i < 2; ++i) {
            for (int j = 0; j < 2; ++j) {
                for (int k = 0; k < 2; ++k) {
                    class_243[] ends;
                    int sx = i == 0 ? 1 : -1;
                    int sy = j == 0 ? 1 : -1;
                    int sz = k == 0 ? 1 : -1;
                    class_243 corner = new class_243(i == 0 ? box.field_1323 - spacing : box.field_1320 + spacing, j == 0 ? box.field_1322 - spacing : box.field_1325 + spacing, k == 0 ? box.field_1321 - spacing : box.field_1324 + spacing);
                    int color = PrismOutline.lerp(first, second, (float)(i + j + k) / 4.0f);
                    for (class_243 end : ends = new class_243[]{corner.method_1031((double)sx * lx, 0.0, 0.0), corner.method_1031(0.0, (double)sy * ly, 0.0), corner.method_1031(0.0, 0.0, (double)sz * lz)}) {
                        mesh.beam(corner, end, thick, color, false);
                        class_243 offset = new class_243((double)(-sx), (double)(-sy), (double)(-sz)).method_1029().method_1021(thick * 0.9);
                        mesh.beam(corner.method_35590(end, 0.18).method_1019(offset), corner.method_35590(end, 0.86).method_1019(offset), thick * 0.22, second, true);
                        mesh.beam(corner.method_35590(end, 0.88), end, thick * 1.12, PrismOutline.lighten(second, 0.3f), true);
                    }
                    mesh.crystal(corner, Y_AXIS, X_AXIS, Z_AXIS, thick * 1.9, thick * 3.4, 0.7853981633974483, second);
                }
            }
        }
    }

    private static void rings(Mesh mesh, class_238 box, double spacing, double thick, double scale, double time, int first, int second) {
        int k;
        double rx = (box.method_17939() * 0.5 + spacing) * Math.sqrt(2.0);
        double rz = (box.method_17941() * 0.5 + spacing) * Math.sqrt(2.0);
        class_243 center = box.method_1005().method_1031(0.0, 0.21 * box.method_17940(), 0.0);
        class_243 a = new class_243(1.0, 0.07, 0.0).method_1029();
        class_243 b = a.method_1036(Y_AXIS).method_1029();
        double angle = time * 0.55;
        for (k = 0; k < 4; ++k) {
            double start = angle + (double)k * (Math.PI * 2) / 4.0;
            mesh.arc(center, a, b, rx, rz, thick * 0.7, thick * 0.48, start, 1.1938052083641213, first);
            mesh.arc(center, a, b, rx, rz, thick * 0.23, thick * 0.68, start, 0.2827433388230814, PrismOutline.lighten(second, 0.25f));
        }
        for (k = 0; k < 2; ++k) {
            class_243 spark = PrismOutline.ellipse(center, a, b, rx, rz, angle + (double)k * (Math.PI * 2) / 2.0);
            mesh.crystal(spark, Y_AXIS, X_AXIS, Z_AXIS, 0.023 * scale, 0.056 * scale, -time + (double)k, second);
        }
    }

    private static void faceMarker(Mesh mesh, Selection selection, double spacing, double thick, double scale, double eased, double time, int first, int second) {
        int k;
        class_238 face = selection.faceBox;
        class_2350 side = selection.face;
        class_243 normal = new class_243((double)side.method_10148(), (double)side.method_10164(), (double)side.method_10165());
        class_243 u = side.method_10166() == class_2350.class_2351.field_11052 ? X_AXIS : normal.method_1036(Y_AXIS).method_1029();
        class_243 v = normal.method_1036(u).method_1029();
        double half = PrismOutline.extent(face, normal) * 0.5;
        double width = PrismOutline.extent(face, u);
        double height = PrismOutline.extent(face, v);
        class_243 center = face.method_1005().method_1019(normal.method_1021(half + 0.012 + spacing * 0.18));
        double radius = Math.min(Math.min(width, height) * 0.32, 0.235 * scale) * (1.12 - 0.12 * eased);
        double tube = Math.min(thick * 0.52, radius * 0.13);
        double spin = time * 0.72;
        for (k = 0; k < 3; ++k) {
            mesh.arc(center, u, v, radius, radius, tube, tube * 0.72, spin + (double)k * (Math.PI * 2) / 3.0, 1.5079644737231006, first);
            mesh.arc(center.method_1019(normal.method_1021(0.012)), u, v, radius * 0.74, radius * 0.74, tube * 0.55, tube * 0.45, -spin * 1.3 + (double)k * (Math.PI * 2) / 3.0, 1.0681415022205298, second);
        }
        for (k = 0; k < 12; ++k) {
            double angle = (double)k * (Math.PI * 2) / 12.0;
            class_243 direction = u.method_1021(Math.cos(angle)).method_1019(v.method_1021(Math.sin(angle)));
            double length = radius * (k % 3 == 0 ? 1.24 : 1.14);
            mesh.beam(center.method_1019(direction.method_1021(radius * 1.05)), center.method_1019(direction.method_1021(length)), tube * 0.27, k % 3 == 0 ? second : PrismOutline.darken(first, 0.2f), true);
        }
        double size = radius * 0.14;
        mesh.crystal(center.method_1019(normal.method_1021(0.014)), normal, u, v, size, size * 0.65, 0.7853981633974483, PrismOutline.lighten(second, 0.25f));
    }

    private static double extent(class_238 box, class_243 axis) {
        return Math.abs(axis.field_1352) * box.method_17939() + Math.abs(axis.field_1351) * box.method_17940() + Math.abs(axis.field_1350) * box.method_17941();
    }

    static class_243 ellipse(class_243 center, class_243 a, class_243 b, double ra, double rb, double angle) {
        return center.method_1019(a.method_1021(Math.cos(angle) * ra)).method_1019(b.method_1021(Math.sin(angle) * rb));
    }

    private static int withAlpha(int color, float alpha) {
        return color & 0xFFFFFF | (int)(Math.clamp((float)alpha, (float)0.0f, (float)1.0f) * 255.0f + 0.5f) << 24;
    }

    private static int lerp(int a, int b, float t) {
        t = Math.clamp((float)t, (float)0.0f, (float)1.0f);
        int aa = a >>> 24;
        int ar = a >> 16 & 0xFF;
        int ag = a >> 8 & 0xFF;
        int ab = a & 0xFF;
        int ba = b >>> 24;
        int br = b >> 16 & 0xFF;
        int bg = b >> 8 & 0xFF;
        int bb = b & 0xFF;
        return ((int)((float)aa + (float)(ba - aa) * t) & 0xFF) << 24 | ((int)((float)ar + (float)(br - ar) * t) & 0xFF) << 16 | ((int)((float)ag + (float)(bg - ag) * t) & 0xFF) << 8 | (int)((float)ab + (float)(bb - ab) * t) & 0xFF;
    }

    private static int lighten(int color, float amount) {
        return PrismOutline.lerp(color, color & 0xFF000000 | 0xFFFFFF, amount);
    }

    private static int darken(int color, float amount) {
        return PrismOutline.lerp(color, color & 0xFF000000, amount);
    }

    private static final class Selection {
        final class_2338 pos;
        private class_265 shape;
        private List<class_238> boxes;
        class_238 box;
        class_238 faceBox;
        class_2350 face = class_2350.field_11036;
        double progress;

        Selection(class_12074 outline) {
            this.pos = outline.comp_4932().method_10062();
            this.update(outline, null);
        }

        double eased() {
            return 1.0 - Math.pow(1.0 - this.progress, 3.0);
        }

        void update(class_12074 outline, class_3965 hit) {
            if (this.shape != outline.comp_4935()) {
                this.shape = outline.comp_4935();
                this.boxes = this.shape.method_1090();
                this.faceBox = this.box = this.shape.method_1107();
            }
            if (hit == null || !hit.method_17777().equals((Object)this.pos)) {
                return;
            }
            this.face = hit.method_17780();
            class_243 local = hit.method_17784().method_1023((double)this.pos.method_10263(), (double)this.pos.method_10264(), (double)this.pos.method_10260());
            double best = Double.POSITIVE_INFINITY;
            for (class_238 part : this.boxes) {
                double distance;
                double x = Math.clamp((double)local.field_1352, (double)part.field_1323, (double)part.field_1320);
                double y = Math.clamp((double)local.field_1351, (double)part.field_1322, (double)part.field_1325);
                double z = Math.clamp((double)local.field_1350, (double)part.field_1321, (double)part.field_1324);
                switch (this.face) {
                    case field_11033: {
                        y = part.field_1322;
                        break;
                    }
                    case field_11036: {
                        y = part.field_1325;
                        break;
                    }
                    case field_11043: {
                        z = part.field_1321;
                        break;
                    }
                    case field_11035: {
                        z = part.field_1324;
                        break;
                    }
                    case field_11039: {
                        x = part.field_1323;
                        break;
                    }
                    case field_11034: {
                        x = part.field_1320;
                    }
                }
                if (!((distance = local.method_1028(x, y, z)) < best)) continue;
                best = distance;
                this.faceBox = part;
            }
        }
    }

    private record Mesh(class_4588 buffer, class_4587.class_4665 entry, boolean light, float alpha, class_243 camera) {
        private void vertex(class_243 pos, int color, float a) {
            this.buffer.method_56824(this.entry, (float)pos.field_1352, (float)pos.field_1351, (float)pos.field_1350).method_39415(PrismOutline.withAlpha(color, a * this.alpha));
        }

        private void quad(class_243 a, class_243 b, class_243 c, class_243 d, int color, float alpha) {
            this.vertex(a, color, alpha);
            this.vertex(b, color, alpha);
            this.vertex(c, color, alpha);
            this.vertex(d, color, alpha);
        }

        private void fade(class_243 a, class_243 b, class_243 c, class_243 d, int color, float inner, float outer) {
            this.vertex(a, color, inner);
            this.vertex(b, color, outer);
            this.vertex(c, color, outer);
            this.vertex(d, color, inner);
        }

        void beam(class_243 from, class_243 to, double radius, int color, boolean glows) {
            if (this.light && !glows) {
                return;
            }
            class_243 direction = to.method_1020(from);
            if (direction.method_1027() < 1.0E-10 || radius < 1.0E-4) {
                return;
            }
            direction = direction.method_1029();
            class_243 u = direction.method_1036(Math.abs(direction.field_1351) > 0.9 ? X_AXIS : Y_AXIS).method_1029();
            class_243 v = direction.method_1036(u).method_1029();
            if (this.light) {
                class_243 side = direction.method_1036(this.camera.method_1020(from.method_35590(to, 0.5)));
                side = (side.method_1027() < 1.0E-9 ? u : side.method_1029()).method_1021(radius * 4.0 + 0.005);
                this.fade(from, from.method_1019(side), to.method_1019(side), to, color, 0.22f, 0.0f);
                this.fade(to, to.method_1020(side), from.method_1020(side), from, color, 0.22f, 0.0f);
            } else {
                this.tube(from, to, u, v, radius, color, 1.0f, !glows);
            }
        }

        private void tube(class_243 from, class_243 to, class_243 u, class_243 v, double radius, int color, float alpha, boolean shaded) {
            for (int i = 0; i < 8; ++i) {
                class_243 a = u.method_1021(Math.cos((double)i * (Math.PI * 2) / 8.0) * radius).method_1019(v.method_1021(Math.sin((double)i * (Math.PI * 2) / 8.0) * radius));
                class_243 b = u.method_1021(Math.cos((double)(i + 1) * (Math.PI * 2) / 8.0) * radius).method_1019(v.method_1021(Math.sin((double)(i + 1) * (Math.PI * 2) / 8.0) * radius));
                int shade = shaded ? PrismOutline.darken(color, (float)(1.0 - SHADE[i])) : color;
                this.quad(from.method_1019(a), from.method_1019(b), to.method_1019(b), to.method_1019(a), shade, alpha);
                if (this.light) continue;
                this.quad(from, from, from.method_1019(b), from.method_1019(a), shade, alpha);
                this.quad(to, to, to.method_1019(a), to.method_1019(b), shade, alpha);
            }
        }

        void crystal(class_243 center, class_243 axis, class_243 u, class_243 v, double radius, double height, double angle, int color) {
            if (this.light) {
                for (int i = 0; i < 16; ++i) {
                    class_243 a = PrismOutline.ellipse(center, u, v, radius * 3.0, radius * 3.0, (double)i * (Math.PI * 2) / 16.0);
                    class_243 b = PrismOutline.ellipse(center, u, v, radius * 3.0, radius * 3.0, (double)(i + 1) * (Math.PI * 2) / 16.0);
                    this.fade(center, a, b, center, color, 0.26f, 0.0f);
                }
                return;
            }
            class_243 top = center.method_1019(axis.method_1021(height));
            class_243 bottom = center.method_1020(axis.method_1021(height));
            for (int i = 0; i < 4; ++i) {
                class_243 a = PrismOutline.ellipse(center, u, v, radius, radius, angle + (double)i * (Math.PI * 2) / 4.0);
                class_243 b = PrismOutline.ellipse(center, u, v, radius, radius, angle + (double)(i + 1) * (Math.PI * 2) / 4.0);
                this.quad(top, top, a, b, PrismOutline.lighten(PrismOutline.darken(color, (float)i * 0.12f), 0.12f), 1.0f);
                this.quad(bottom, bottom, b, a, PrismOutline.darken(color, 0.2f + (float)i * 0.1f), 1.0f);
            }
        }

        void arc(class_243 center, class_243 a, class_243 b, double ra, double rb, double tubeWidth, double tubeHeight, double start, double span, int color) {
            class_243 normal = a.method_1036(b).method_1029();
            int segments = Math.max(3, (int)Math.ceil(Math.abs(span) / (Math.PI * 2) * 96.0));
            for (int s = 0; s < segments; ++s) {
                double t0 = start + span * (double)s / (double)segments;
                double t1 = start + span * (double)(s + 1) / (double)segments;
                class_243 p0 = PrismOutline.ellipse(center, a, b, ra, rb, t0);
                class_243 p1 = PrismOutline.ellipse(center, a, b, ra, rb, t1);
                class_243 d0 = a.method_1021(Math.cos(t0)).method_1019(b.method_1021(Math.sin(t0)));
                class_243 d1 = a.method_1021(Math.cos(t1)).method_1019(b.method_1021(Math.sin(t1)));
                if (this.light) {
                    double w = tubeWidth * 5.0 + 0.008;
                    this.fade(p0, p0.method_1019(d0.method_1021(w)), p1.method_1019(d1.method_1021(w)), p1, color, 0.2f, 0.0f);
                    this.fade(p1, p1.method_1020(d1.method_1021(w)), p0.method_1020(d0.method_1021(w)), p0, color, 0.2f, 0.0f);
                    continue;
                }
                for (int i = 0; i < 8; ++i) {
                    double c0 = (double)i * (Math.PI * 2) / 8.0;
                    double c1 = (double)(i + 1) * (Math.PI * 2) / 8.0;
                    class_243 q0 = p0.method_1019(d0.method_1021(Math.cos(c0) * tubeWidth)).method_1019(normal.method_1021(Math.sin(c0) * tubeHeight));
                    class_243 q1 = p0.method_1019(d0.method_1021(Math.cos(c1) * tubeWidth)).method_1019(normal.method_1021(Math.sin(c1) * tubeHeight));
                    class_243 q2 = p1.method_1019(d1.method_1021(Math.cos(c0) * tubeWidth)).method_1019(normal.method_1021(Math.sin(c0) * tubeHeight));
                    class_243 q3 = p1.method_1019(d1.method_1021(Math.cos(c1) * tubeWidth)).method_1019(normal.method_1021(Math.sin(c1) * tubeHeight));
                    int shade = PrismOutline.darken(color, (float)(1.0 - SHADE[i]));
                    this.quad(q0, q1, q3, q2, shade, 1.0f);
                    if (s == 0) {
                        this.quad(p0, p0, q1, q0, shade, 1.0f);
                    }
                    if (s != segments - 1) continue;
                    this.quad(p1, p1, q2, q3, shade, 1.0f);
                }
            }
        }
    }
}

