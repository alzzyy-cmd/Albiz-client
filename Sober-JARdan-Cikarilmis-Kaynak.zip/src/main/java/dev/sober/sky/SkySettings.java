/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.sky;

import dev.sober.sky.SkyType;

public final class SkySettings {
    public static SkyType sky = SkyType.VANILLA;
    public static int speed = 100;
    public static int brightness = 100;
    public static int auroraPalette = 0;
    public static int auroraColor = 4063152;
    public static boolean hideVanillaClouds = true;
    public static boolean matchFog = true;
    public static int quality = 50;

    private SkySettings() {
    }
}

