/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.systems.CommandEncoder
 *  com.mojang.blaze3d.systems.GpuDevice
 *  com.mojang.blaze3d.systems.RenderSystem
 *  com.mojang.blaze3d.textures.AddressMode
 *  com.mojang.blaze3d.textures.FilterMode
 *  com.mojang.blaze3d.textures.GpuTexture
 *  com.mojang.blaze3d.textures.TextureFormat
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_1011
 *  net.minecraft.class_1044
 *  net.minecraft.class_1059
 *  net.minecraft.class_1060
 *  net.minecraft.class_156
 *  net.minecraft.class_310
 *  net.minecraft.class_4588
 *  net.minecraft.class_918
 *  org.joml.Matrix4f
 */
package dev.sober.sky;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.GpuDevice;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.TextureFormat;
import dev.sober.SoberClient;
import dev.sober.mixin.DualConsumerAccessor;
import dev.sober.mixin.OverlayConsumerAccessor;
import dev.sober.sky.GlintFit;
import dev.sober.sky.GlintType;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.Optional;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1011;
import net.minecraft.class_1044;
import net.minecraft.class_1059;
import net.minecraft.class_1060;
import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraft.class_4588;
import net.minecraft.class_918;
import org.joml.Matrix4f;

public final class GlintManager {
    private static final float ITEM_SCALE = 8.0f;
    private static final float ENTITY_SCALE = 0.5f;
    private static final float ARMOR_SCALE = 0.16f;
    private static final float REFERENCE_ATLAS = 1024.0f;
    private static final float SPRITE_PIXELS = 16.0f;
    private static final float ARMOR_WIDTH = 64.0f;
    private static final float ARMOR_HEIGHT = 32.0f;
    private static final float REPEATS_PER_SCALE = 0.6666667f;
    private static GlintType current = GlintType.VANILLA;
    private static boolean fitted;
    private static GpuTexture cachedAtlas;
    private static float cachedWidth;

    private GlintManager() {
    }

    public static GlintType current() {
        return current;
    }

    public static class_4588 fit(class_4588 consumer) {
        if (current == GlintType.VANILLA || !(consumer instanceof DualConsumerAccessor)) {
            return consumer;
        }
        DualConsumerAccessor dual = (DualConsumerAccessor)consumer;
        try {
            class_4588 glint = dual.sober$first();
            if (glint instanceof OverlayConsumerAccessor) {
                OverlayConsumerAccessor overlay = (OverlayConsumerAccessor)glint;
                glint = overlay.sober$delegate();
            }
            class_4588 base = dual.sober$second();
            if (glint == null || base == null) {
                return consumer;
            }
            fitted = true;
            return new GlintFit(glint, base);
        }
        catch (RuntimeException e) {
            return consumer;
        }
    }

    public static Matrix4f transform(float vanilla) {
        if (current == GlintType.VANILLA || current.shader() != null) {
            return null;
        }
        try {
            float u;
            float v;
            float repeats = current.scale() * 0.6666667f;
            if (vanilla == 8.0f) {
                v = fitted ? repeats : repeats * GlintManager.atlasWidth() / 16.0f;
                u = v;
            } else if (vanilla == 0.16f) {
                u = repeats * 64.0f / 16.0f;
                v = repeats * 32.0f / 16.0f;
            } else if (vanilla == 0.5f) {
                u = v = repeats * 64.0f / 16.0f;
            } else {
                return null;
            }
            long time = (long)((double)class_156.method_658() * (Double)class_310.method_1551().field_1690.method_48580().method_41753() * 8.0);
            float x = (float)(time % 110000L) / 110000.0f;
            float y = (float)(time % 30000L) / 30000.0f;
            return new Matrix4f().translation(-x, y, 0.0f).rotateZ(0.17453292f).scale(u, v, 1.0f);
        }
        catch (RuntimeException e) {
            return null;
        }
    }

    public static void ensure() {
        if (current.texture() == null) {
            return;
        }
        class_1060 textures = class_310.method_1551().method_1531();
        if (textures == null) {
            return;
        }
        if (textures.method_4619(class_918.field_43087) instanceof GlintTexture && textures.method_4619(class_918.field_43086) instanceof GlintTexture) {
            return;
        }
        GlintType wanted = current;
        current = GlintType.VANILLA;
        try {
            GlintManager.apply(wanted);
        }
        catch (RuntimeException e) {
            SoberClient.LOG.warn("Could not restore glint {}", (Object)wanted, (Object)e);
        }
    }

    public static float atlasWidth() {
        class_1044 atlas = class_310.method_1551().method_1531().method_4619(class_1059.field_64467);
        try {
            GpuTexture texture = atlas.method_68004();
            if (texture != cachedAtlas) {
                cachedAtlas = texture;
                cachedWidth = texture.getWidth(0);
            }
        }
        catch (IllegalStateException e) {
            cachedAtlas = null;
            cachedWidth = 1024.0f;
        }
        return cachedWidth;
    }

    public static void apply(GlintType wanted) {
        class_310 mc = class_310.method_1551();
        class_1060 textures = mc.method_1531();
        if (textures == null) {
            return;
        }
        if (wanted.texture() == null) {
            if (current.texture() != null) {
                textures.method_4615(class_918.field_43087);
                textures.method_4615(class_918.field_43086);
            }
            current = wanted;
            return;
        }
        class_1011 item = GlintManager.load(wanted);
        class_1011 armor = GlintManager.load(wanted);
        if (item == null || armor == null) {
            if (item != null) {
                item.close();
            }
            if (armor != null) {
                armor.close();
            }
            return;
        }
        textures.method_4616(class_918.field_43087, (class_1044)new GlintTexture(item));
        textures.method_4616(class_918.field_43086, (class_1044)new GlintTexture(armor));
        current = wanted;
    }

    private static class_1011 load(GlintType type) {
        class_1011 class_10112;
        block9: {
            Optional path = FabricLoader.getInstance().getModContainer("soberclient").flatMap(mod -> mod.findPath("assets/sober/textures/glint/" + type.texture() + ".png"));
            if (path.isEmpty()) {
                return null;
            }
            InputStream in = Files.newInputStream((Path)path.get(), new OpenOption[0]);
            try {
                class_10112 = class_1011.method_4309((InputStream)in);
                if (in == null) break block9;
            }
            catch (Throwable throwable) {
                try {
                    if (in != null) {
                        try {
                            in.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (Exception e) {
                    SoberClient.LOG.warn("Could not load glint {}", (Object)type, (Object)e);
                    return null;
                }
            }
            in.close();
        }
        return class_10112;
    }

    static {
        cachedWidth = 1024.0f;
    }

    private static final class GlintTexture
    extends class_1044 {
        GlintTexture(class_1011 image) {
            int levels = Math.max(1, 31 - Integer.numberOfLeadingZeros(Math.min(image.method_4307(), image.method_4323())) - 2);
            GpuDevice device = RenderSystem.getDevice();
            this.field_56974 = device.createTexture(() -> "sober_glint", 5, TextureFormat.RGBA8, image.method_4307(), image.method_4323(), 1, levels);
            this.field_60597 = device.createTextureView(this.field_56974);
            this.field_63613 = RenderSystem.getSamplerCache().method_75293(AddressMode.REPEAT, AddressMode.REPEAT, FilterMode.LINEAR, FilterMode.LINEAR, true);
            CommandEncoder encoder = device.createCommandEncoder();
            class_1011 level = image;
            for (int i = 0; i < levels; ++i) {
                encoder.writeToTexture(this.field_56974, level, i, 0, 0, 0, level.method_4307(), level.method_4323(), 0, 0);
                if (i + 1 >= levels) continue;
                class_1011 next = GlintTexture.half(level);
                level.close();
                level = next;
            }
            level.close();
        }

        private static class_1011 half(class_1011 src) {
            int w = Math.max(1, src.method_4307() / 2);
            int h = Math.max(1, src.method_4323() / 2);
            class_1011 out = new class_1011(w, h, false);
            for (int y = 0; y < h; ++y) {
                for (int x = 0; x < w; ++x) {
                    int a = src.method_61940(x * 2, y * 2);
                    int b = src.method_61940(x * 2 + 1, y * 2);
                    int c = src.method_61940(x * 2, y * 2 + 1);
                    int d = src.method_61940(x * 2 + 1, y * 2 + 1);
                    int color = 0;
                    for (int shift = 0; shift <= 24; shift += 8) {
                        int sum = (a >>> shift & 0xFF) + (b >>> shift & 0xFF) + (c >>> shift & 0xFF) + (d >>> shift & 0xFF);
                        color |= (sum + 2) / 4 << shift;
                    }
                    out.method_61941(x, y, color);
                }
            }
            return out;
        }
    }
}

