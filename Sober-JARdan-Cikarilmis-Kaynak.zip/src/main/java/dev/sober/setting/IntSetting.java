/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 */
package dev.sober.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.sober.setting.Setting;

public class IntSetting
extends Setting<Integer> {
    public final int min;
    public final int max;

    public IntSetting(String name, String description, int defaultValue, int min, int max) {
        super(name, description, defaultValue);
        this.min = min;
        this.max = max;
    }

    @Override
    protected Integer validate(Integer newValue) {
        return Math.max(this.min, Math.min(this.max, newValue));
    }

    @Override
    public String display() {
        return Integer.toString((Integer)this.value);
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive((Number)this.value);
    }

    @Override
    public void load(JsonElement element) {
        if (element.isJsonPrimitive()) {
            this.value = this.validate(element.getAsInt());
        }
    }
}

