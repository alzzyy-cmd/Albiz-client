/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 */
package dev.sober.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.sober.setting.Setting;

public class BoolSetting
extends Setting<Boolean> {
    public BoolSetting(String name, String description, boolean defaultValue) {
        super(name, description, defaultValue);
    }

    public void toggle() {
        this.set((Boolean)this.value == false);
    }

    @Override
    public String display() {
        return (Boolean)this.value != false ? "On" : "Off";
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive((Boolean)this.value);
    }

    @Override
    public void load(JsonElement element) {
        if (element.isJsonPrimitive()) {
            this.value = element.getAsBoolean();
        }
    }
}

