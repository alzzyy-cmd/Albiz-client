/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 */
package dev.sober.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.sober.setting.Setting;

public class EnumSetting<E extends Enum<E>>
extends Setting<E> {
    private final E[] values;

    public EnumSetting(String name, String description, E defaultValue) {
        super(name, description, defaultValue);
        this.values = (Enum[])((Enum)defaultValue).getDeclaringClass().getEnumConstants();
    }

    public void cycle(boolean forward) {
        int index = ((Enum)this.value).ordinal() + (forward ? 1 : -1);
        if (index < 0) {
            index = this.values.length - 1;
        }
        if (index >= this.values.length) {
            index = 0;
        }
        this.set(this.values[index]);
    }

    @Override
    public String display() {
        return ((Enum)this.value).toString();
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive(((Enum)this.value).name());
    }

    @Override
    public void load(JsonElement element) {
        if (!element.isJsonPrimitive()) {
            return;
        }
        String name = element.getAsString();
        for (E e : this.values) {
            if (!((Enum)e).name().equals(name)) continue;
            this.value = e;
        }
    }
}

