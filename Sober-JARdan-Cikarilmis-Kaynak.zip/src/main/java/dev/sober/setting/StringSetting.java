/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonPrimitive
 */
package dev.sober.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import dev.sober.setting.Setting;

public class StringSetting
extends Setting<String> {
    private final boolean hidden;

    public StringSetting(String name, String description, String defaultValue) {
        this(name, description, defaultValue, false);
    }

    public StringSetting(String name, String description, String defaultValue, boolean hidden) {
        super(name, description, defaultValue);
        this.hidden = hidden;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    @Override
    public String display() {
        if (this.hidden && !((String)this.value).isEmpty()) {
            return "*".repeat(Math.min(12, ((String)this.value).length()));
        }
        return (String)this.value;
    }

    @Override
    public JsonElement save() {
        return new JsonPrimitive((String)this.value);
    }

    @Override
    public void load(JsonElement element) {
        if (element.isJsonPrimitive()) {
            this.value = element.getAsString();
        }
    }
}

