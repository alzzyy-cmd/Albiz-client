/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.setting.lite;

import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import dev.sober.setting.lite.LiteSetting;
import java.util.ArrayList;
import java.util.List;

public final class StringListSetting
extends LiteSetting {
    public static final int MAX_ENTRIES = 64;
    private static final String SEPARATOR = " | ";
    private final String initial;
    private StringSetting setting;

    public StringListSetting(String name, String ... defaults) {
        super(name);
        this.initial = String.join((CharSequence)SEPARATOR, defaults);
    }

    @Override
    protected Setting<?> create() {
        this.setting = new StringSetting(this.name(), "Entries separated by |", this.initial);
        this.setting.onChanged(v -> this.notifyChanged());
        return this.setting;
    }

    public List<String> get() {
        String raw = this.setting == null ? this.initial : (String)this.setting.get();
        ArrayList<String> entries = new ArrayList<String>();
        for (String part : raw.split("\\|")) {
            String entry = part.trim();
            if (entry.isEmpty() || entries.size() >= 64) continue;
            entries.add(entry);
        }
        return entries;
    }

    public int size() {
        return this.get().size();
    }

    public StringListSetting itemPicker() {
        return this;
    }

    public boolean isItemPicker() {
        return false;
    }

    public boolean canAdd() {
        return this.size() < 64;
    }

    public boolean addValue(String value) {
        if (value == null || value.isBlank() || !this.canAdd()) {
            return false;
        }
        List<String> entries = this.get();
        entries.add(value.trim());
        this.store(entries);
        return true;
    }

    public boolean removeValue(String value) {
        List<String> entries = this.get();
        for (int i = 0; i < entries.size(); ++i) {
            if (!entries.get(i).equalsIgnoreCase(value)) continue;
            entries.remove(i);
            this.store(entries);
            return true;
        }
        return false;
    }

    public void clear() {
        if (this.size() > 0) {
            this.store(List.of());
        }
    }

    private void store(List<String> entries) {
        if (this.setting != null) {
            this.setting.set(String.join((CharSequence)SEPARATOR, entries));
        }
    }
}

