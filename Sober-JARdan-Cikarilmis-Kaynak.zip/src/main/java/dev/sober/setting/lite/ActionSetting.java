/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.setting.lite;

import dev.sober.setting.BoolSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.lite.LiteSetting;

public final class ActionSetting
extends LiteSetting {
    private final Runnable action;
    private BoolSetting setting;

    public ActionSetting(String name, Runnable action) {
        super(name);
        this.action = action;
    }

    @Override
    protected Setting<?> create() {
        this.setting = new BoolSetting(this.name(), "", false);
        this.setting.onChanged(pressed -> {
            if (!pressed.booleanValue()) {
                return;
            }
            this.setting.set(false);
            this.run();
        });
        return this.setting;
    }

    public void run() {
        this.action.run();
        this.notifyChanged();
    }
}

