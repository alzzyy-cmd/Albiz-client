/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.setting.lite;

import dev.sober.setting.BoolSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.lite.LiteSetting;

public final class BooleanSetting
extends LiteSetting {
    private final boolean initial;
    private BoolSetting setting;

    public BooleanSetting(String name, boolean value) {
        super(name);
        this.initial = value;
    }

    @Override
    protected Setting<?> create() {
        this.setting = new BoolSetting(this.name(), "", this.initial);
        this.setting.onChanged(v -> this.notifyChanged());
        return this.setting;
    }

    public boolean get() {
        return this.setting == null ? this.initial : (Boolean)this.setting.get();
    }

    public void set(boolean value) {
        if (this.setting != null) {
            this.setting.set(value);
        }
    }

    public Value value() {
        return new Value(this);
    }

    public record Value(BooleanSetting setting) {
        public boolean get() {
            return this.setting.get();
        }
    }
}

