/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2248
 *  net.minecraft.class_2960
 *  net.minecraft.class_7923
 */
package dev.sober.setting.lite;

import dev.sober.setting.BlockListSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.lite.LiteSetting;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class BlockColorListSetting
extends LiteSetting {
    private final List<String> defaults;
    private BlockListSetting setting;

    private BlockColorListSetting(String name, List<String> defaults) {
        super(name);
        this.defaults = defaults;
    }

    public static BlockColorListSetting blockList(String name, List<String> defaults) {
        return new BlockColorListSetting(name, List.copyOf(defaults));
    }

    @Override
    protected Setting<?> create() {
        ArrayList<class_2248> blocks = new ArrayList<class_2248>();
        for (String id : this.defaults) {
            class_2960 key = class_2960.method_12829((String)id);
            if (key == null || !class_7923.field_41175.method_10250(key)) continue;
            blocks.add((class_2248)class_7923.field_41175.method_63535(key));
        }
        this.setting = new BlockListSetting(this.name(), "", blocks.toArray(new class_2248[0]));
        this.setting.onChanged(v -> this.notifyChanged());
        return this.setting;
    }

    public Set<class_2248> enabledBlocks() {
        return this.setting == null ? Set.of() : Set.copyOf((Collection)this.setting.get());
    }

    public boolean isEnabled(class_2248 block) {
        return this.setting != null && this.setting.contains(block);
    }

    public boolean hasAnyEnabled() {
        return this.setting != null && !((Set)this.setting.get()).isEmpty();
    }

    public int colorArgb(class_2248 block) {
        Integer rgb = this.setting == null ? null : this.setting.color(block);
        return 0xFF000000 | (rgb == null ? 0xFFFFFF : rgb);
    }

    public static BlockColorListSetting createDefault() {
        return new BlockColorListSetting("Block Colors", List.of());
    }

    public Set<String> enabledIds() {
        if (this.setting == null) {
            return Set.of();
        }
        HashSet<String> ids = new HashSet<String>();
        for (class_2248 block : (Set)this.setting.get()) {
            ids.add(class_7923.field_41175.method_10221((Object)block).toString());
        }
        return Set.copyOf(ids);
    }

    public int tracerColorArgb(class_2248 block) {
        return this.isEnabled(block) ? this.colorArgb(block) : 0;
    }

    public boolean hasAnyTracerEnabled() {
        return this.hasAnyEnabled();
    }
}

