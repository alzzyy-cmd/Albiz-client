/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  net.fabricmc.loader.api.FabricLoader
 */
package dev.sober.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import net.fabricmc.loader.api.FabricLoader;

public final class FriendStore {
    private static final FriendStore INSTANCE = new FriendStore();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Pattern VALID_NAME = Pattern.compile("[.*]?[A-Za-z0-9_]{1,16}");
    private final Map<String, String> friends = new LinkedHashMap<String, String>();
    private boolean loaded;

    private FriendStore() {
    }

    public static FriendStore getInstance() {
        return INSTANCE;
    }

    public synchronized void reset() {
        this.friends.clear();
        this.loaded = false;
    }

    public static boolean isValidName(String name) {
        return name != null && VALID_NAME.matcher(name).matches();
    }

    public synchronized boolean isFriend(String name) {
        this.ensureLoaded();
        return name != null && this.friends.containsKey(name.toLowerCase(Locale.ROOT));
    }

    public synchronized List<String> all() {
        this.ensureLoaded();
        return List.copyOf(this.friends.values());
    }

    public synchronized boolean add(String name) {
        String trimmed;
        this.ensureLoaded();
        String string = trimmed = name == null ? "" : name.trim();
        if (!FriendStore.isValidName(trimmed) || this.friends.putIfAbsent(trimmed.toLowerCase(Locale.ROOT), trimmed) != null) {
            return false;
        }
        this.save();
        return true;
    }

    public synchronized boolean remove(String name) {
        this.ensureLoaded();
        if (name == null || this.friends.remove(name.toLowerCase(Locale.ROOT)) == null) {
            return false;
        }
        this.save();
        return true;
    }

    public synchronized void replaceAll(Collection<String> names) {
        this.ensureLoaded();
        this.friends.clear();
        for (String name : names) {
            String trimmed = name == null ? "" : name.trim();
            if (!FriendStore.isValidName(trimmed)) continue;
            this.friends.putIfAbsent(trimmed.toLowerCase(Locale.ROOT), trimmed);
        }
        this.save();
    }

    private void ensureLoaded() {
        if (this.loaded) {
            return;
        }
        this.loaded = true;
        this.friends.clear();
        Path path = FriendStore.path();
        if (!Files.isRegularFile(path, new LinkOption[0])) {
            return;
        }
        try (BufferedReader reader = Files.newBufferedReader(path);){
            JsonObject root = JsonParser.parseReader((Reader)reader).getAsJsonObject();
            if (!root.has("friends") || !root.get("friends").isJsonArray()) {
                return;
            }
            for (JsonElement element : root.getAsJsonArray("friends")) {
                String name;
                if (!element.isJsonPrimitive() || !FriendStore.isValidName(name = element.getAsString().trim())) continue;
                this.friends.putIfAbsent(name.toLowerCase(Locale.ROOT), name);
            }
        }
        catch (IOException | RuntimeException ignored) {
            this.friends.clear();
        }
    }

    private void save() {
        JsonObject root = new JsonObject();
        root.addProperty("version", (Number)1);
        JsonArray list = new JsonArray();
        for (String name : this.friends.values()) {
            list.add(name);
        }
        root.add("friends", (JsonElement)list);
        Path path = FriendStore.path();
        try {
            Files.createDirectories(path.getParent(), new FileAttribute[0]);
            Path tmp = path.resolveSibling(String.valueOf(path.getFileName()) + ".tmp");
            try (BufferedWriter writer = Files.newBufferedWriter(tmp, new OpenOption[0]);){
                GSON.toJson((JsonElement)root, (Appendable)writer);
            }
            Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING);
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("sober").resolve("friends.json");
    }
}

