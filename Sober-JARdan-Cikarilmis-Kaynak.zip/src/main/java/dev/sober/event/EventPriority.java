/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

public enum EventPriority {
    LOWEST(-100),
    LOW(-50),
    NORMAL(0),
    HIGH(50),
    HIGHEST(100);

    public final int value;

    private EventPriority(int value) {
        this.value = value;
    }

    public static EventPriority fromInt(int v) {
        if (v >= 75) {
            return HIGHEST;
        }
        if (v >= 25) {
            return HIGH;
        }
        if (v >= -25) {
            return NORMAL;
        }
        return v >= -75 ? LOW : LOWEST;
    }
}

