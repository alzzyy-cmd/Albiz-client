/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

import dev.sober.event.Event;
import dev.sober.event.Listener;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaConversionException;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public final class LambdaListenerFactory {
    private static final MethodHandles.Lookup LOOKUP = MethodHandles.lookup();
    private static final MethodType ERASED_INVOKE_TYPE = MethodType.methodType(Void.TYPE, Event.class);

    private LambdaListenerFactory() {
    }

    public static <E extends Event> Listener<E> create(Object instance, Method method) {
        if (instance == null) {
            return LambdaListenerFactory.createStatic(method);
        }
        try {
            return LambdaListenerFactory.createFactory(method).invoke(instance);
        }
        catch (RuntimeException var3) {
            throw var3;
        }
        catch (Throwable var4) {
            throw new RuntimeException("Unexpected error creating listener for method " + String.valueOf(method), var4);
        }
    }

    public static <E extends Event> Listener<E> createStatic(Method method) {
        LambdaListenerFactory.validateMethod(method);
        try {
            MethodHandles.Lookup targetLookup = MethodHandles.privateLookupIn(method.getDeclaringClass(), LOOKUP);
            MethodHandle directHandle = targetLookup.unreflect(method);
            MethodType instantiatedType = MethodType.methodType(Void.TYPE, method.getParameterTypes()[0]);
            CallSite site = LambdaMetafactory.metafactory(targetLookup, "invoke", MethodType.methodType(Listener.class), ERASED_INVOKE_TYPE, directHandle, instantiatedType);
            return site.getTarget().invoke();
        }
        catch (Throwable var5) {
            throw LambdaListenerFactory.wrap(method, var5);
        }
    }

    public static MethodHandle createFactory(Method method) {
        LambdaListenerFactory.validateMethod(method);
        try {
            MethodHandles.Lookup targetLookup = MethodHandles.privateLookupIn(method.getDeclaringClass(), LOOKUP);
            MethodHandle directHandle = targetLookup.unreflect(method);
            MethodType instantiatedType = MethodType.methodType(Void.TYPE, method.getParameterTypes()[0]);
            MethodType factoryType = MethodType.methodType(Listener.class, method.getDeclaringClass());
            CallSite site = LambdaMetafactory.metafactory(targetLookup, "invoke", factoryType, ERASED_INVOKE_TYPE, directHandle, instantiatedType);
            return site.getTarget();
        }
        catch (Throwable var6) {
            throw LambdaListenerFactory.wrap(method, var6);
        }
    }

    private static RuntimeException wrap(Method method, Throwable t) {
        if (t instanceof LambdaConversionException) {
            return new RuntimeException("LambdaMetafactory failed for method " + String.valueOf(method) + ". Ensure the listener method is public and its parameter type is a concrete Event subclass.", t);
        }
        return t instanceof IllegalAccessException ? new RuntimeException("Cannot access method " + String.valueOf(method) + ". Listener methods must be public and their declaring class must be accessible.", t) : new RuntimeException("Unexpected error creating listener for method " + String.valueOf(method), t);
    }

    private static void validateMethod(Method method) {
        if (method.getReturnType() != Void.TYPE) {
            throw new IllegalArgumentException("@EventListener method must return void: " + String.valueOf(method));
        }
        Class<?>[] params = method.getParameterTypes();
        if (params.length != 1) {
            throw new IllegalArgumentException("@EventListener method must have exactly one parameter: " + String.valueOf(method));
        }
        if (!Event.class.isAssignableFrom(params[0])) {
            throw new IllegalArgumentException("@EventListener parameter must be a subclass of Event: " + String.valueOf(method));
        }
    }
}

