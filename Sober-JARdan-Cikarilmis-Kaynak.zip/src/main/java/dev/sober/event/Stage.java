/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

public enum Stage {
    PRE,
    POST;

}

