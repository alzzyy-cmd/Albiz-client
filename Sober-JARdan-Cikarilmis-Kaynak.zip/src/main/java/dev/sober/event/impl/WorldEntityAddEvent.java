/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 */
package dev.sober.event.impl;

import dev.sober.event.Event;
import dev.sober.event.EventType;
import net.minecraft.class_1297;

public final class WorldEntityAddEvent
extends Event {
    public static final EventType<WorldEntityAddEvent> TYPE = new EventType("WorldEntityAddEvent");
    public class_1297 entity;
    private static final WorldEntityAddEvent INSTANCE = new WorldEntityAddEvent();

    private WorldEntityAddEvent() {
    }

    public static void dispatch(class_1297 entity) {
        if (TYPE.hasPreListeners()) {
            WorldEntityAddEvent.INSTANCE.entity = entity;
            TYPE.dispatch(INSTANCE);
            WorldEntityAddEvent.INSTANCE.entity = null;
        }
    }
}

