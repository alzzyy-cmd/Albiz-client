/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 */
package dev.sober.event.impl;

import dev.sober.event.CancellableEvent;
import dev.sober.event.PooledCancellableEventType;
import net.minecraft.class_2596;

public final class PacketReceiveNettyEvent
extends CancellableEvent {
    public static final PooledCancellableEventType<PacketReceiveNettyEvent> TYPE = new PooledCancellableEventType<PacketReceiveNettyEvent>("PacketReceiveNettyEvent", PacketReceiveNettyEvent::new, 1024);
    public class_2596<?> packet;

    private PacketReceiveNettyEvent() {
    }

    public static boolean dispatchSync(class_2596<?> packet) {
        boolean var2;
        if (!TYPE.hasPreListeners()) {
            return false;
        }
        PacketReceiveNettyEvent event = (PacketReceiveNettyEvent)PacketReceiveNettyEvent.TYPE.pool.acquire();
        event.packet = packet;
        event.resetCancellation();
        try {
            TYPE.dispatch(event);
            var2 = event.isCancelled();
        }
        finally {
            event.packet = null;
            PacketReceiveNettyEvent.TYPE.pool.release(event);
        }
        return var2;
    }
}

