/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event.impl;

import dev.sober.event.CancellableEvent;
import dev.sober.event.CancellableEventType;

public final class MouseInputEvent
extends CancellableEvent {
    public static final CancellableEventType<MouseInputEvent> TYPE = new CancellableEventType("MouseInputEvent");
    public long window;
    public int button;
    public int action;
    public int mods;
    private static final MouseInputEvent INSTANCE = new MouseInputEvent();

    private MouseInputEvent() {
    }

    public static boolean dispatch(long window, int button, int action, int mods) {
        if (!TYPE.hasPreListeners()) {
            return false;
        }
        MouseInputEvent.INSTANCE.window = window;
        MouseInputEvent.INSTANCE.button = button;
        MouseInputEvent.INSTANCE.action = action;
        MouseInputEvent.INSTANCE.mods = mods;
        INSTANCE.resetCancellation();
        TYPE.dispatch(INSTANCE);
        return INSTANCE.isCancelled();
    }
}

