/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 */
package dev.sober.event.impl;

import dev.sober.event.CancellableEvent;
import dev.sober.event.CancellableEventType;
import net.minecraft.class_1297;

public final class PlayerAttackEntityEvent
extends CancellableEvent {
    public static final CancellableEventType<PlayerAttackEntityEvent> TYPE = new CancellableEventType("PlayerAttackEntityEvent");
    public class_1297 target;
    private static final PlayerAttackEntityEvent INSTANCE = new PlayerAttackEntityEvent();

    private PlayerAttackEntityEvent() {
    }

    public static boolean dispatch(class_1297 target) {
        if (!TYPE.hasPreListeners()) {
            return false;
        }
        PlayerAttackEntityEvent.INSTANCE.target = target;
        INSTANCE.resetCancellation();
        TYPE.dispatch(INSTANCE);
        boolean cancelled = INSTANCE.isCancelled();
        PlayerAttackEntityEvent.INSTANCE.target = null;
        return cancelled;
    }
}

