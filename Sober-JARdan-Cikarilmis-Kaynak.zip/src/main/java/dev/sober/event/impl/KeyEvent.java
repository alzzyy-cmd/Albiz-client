/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event.impl;

import dev.sober.event.CancellableEvent;
import dev.sober.event.CancellableEventType;

public final class KeyEvent
extends CancellableEvent {
    public static final CancellableEventType<KeyEvent> TYPE = new CancellableEventType("KeyEvent");
    public int key;
    public int scancode;
    public int action;
    public int mods;
    private static final KeyEvent INSTANCE = new KeyEvent();

    private KeyEvent() {
    }

    public static boolean dispatch(int key, int scancode, int action, int mods) {
        if (!TYPE.hasPreListeners()) {
            return false;
        }
        KeyEvent.INSTANCE.key = key;
        KeyEvent.INSTANCE.scancode = scancode;
        KeyEvent.INSTANCE.action = action;
        KeyEvent.INSTANCE.mods = mods;
        INSTANCE.resetCancellation();
        TYPE.dispatch(INSTANCE);
        return INSTANCE.isCancelled();
    }
}

