/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event.impl;

import dev.sober.event.CancellableEvent;
import dev.sober.event.CancellableEventType;

public final class ChatSendEvent
extends CancellableEvent {
    public static final CancellableEventType<ChatSendEvent> TYPE = new CancellableEventType("ChatSendEvent");
    public String message;
    private static final ChatSendEvent INSTANCE = new ChatSendEvent();

    private ChatSendEvent() {
    }

    public static boolean dispatch(String message) {
        if (!TYPE.hasPreListeners()) {
            return false;
        }
        ChatSendEvent.INSTANCE.message = message;
        INSTANCE.resetCancellation();
        TYPE.dispatch(INSTANCE);
        boolean cancelled = INSTANCE.isCancelled();
        ChatSendEvent.INSTANCE.message = null;
        return cancelled;
    }
}

