/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 */
package dev.sober.event.impl;

import dev.sober.event.Event;
import dev.sober.event.EventType;
import net.minecraft.class_1297;

public final class WorldEntityRemoveEvent
extends Event {
    public static final EventType<WorldEntityRemoveEvent> TYPE = new EventType("WorldEntityRemoveEvent");
    public class_1297 entity;
    private static final WorldEntityRemoveEvent INSTANCE = new WorldEntityRemoveEvent();

    private WorldEntityRemoveEvent() {
    }

    public static void dispatch(class_1297 entity) {
        if (TYPE.hasPreListeners()) {
            WorldEntityRemoveEvent.INSTANCE.entity = entity;
            TYPE.dispatch(INSTANCE);
            WorldEntityRemoveEvent.INSTANCE.entity = null;
        }
    }
}

