/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 */
package dev.sober.event.impl;

import dev.sober.event.Event;
import dev.sober.event.EventType;
import net.minecraft.class_2596;

public final class PacketAppliedEvent
extends Event {
    public static final EventType<PacketAppliedEvent> TYPE = new EventType("PacketAppliedEvent");
    public class_2596<?> packet;
    private static final PacketAppliedEvent INSTANCE = new PacketAppliedEvent();

    private PacketAppliedEvent() {
    }

    public static void dispatch(class_2596<?> packet) {
        if (TYPE.hasPreListeners()) {
            PacketAppliedEvent.INSTANCE.packet = packet;
            TYPE.dispatch(INSTANCE);
            PacketAppliedEvent.INSTANCE.packet = null;
        }
    }
}

