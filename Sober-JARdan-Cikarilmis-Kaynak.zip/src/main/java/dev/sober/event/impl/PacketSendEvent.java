/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 */
package dev.sober.event.impl;

import dev.sober.event.CancellableEvent;
import dev.sober.event.PooledCancellableEventType;
import net.minecraft.class_2596;

public final class PacketSendEvent
extends CancellableEvent {
    public static final PooledCancellableEventType<PacketSendEvent> TYPE = new PooledCancellableEventType<PacketSendEvent>("PacketSendEvent", PacketSendEvent::new, 1024);
    public class_2596<?> packet;

    private PacketSendEvent() {
    }

    public static boolean dispatchSync(class_2596<?> packet) {
        boolean var2;
        if (!TYPE.hasPreListeners()) {
            return false;
        }
        PacketSendEvent event = (PacketSendEvent)PacketSendEvent.TYPE.pool.acquire();
        event.packet = packet;
        event.resetCancellation();
        try {
            TYPE.dispatch(event);
            var2 = event.isCancelled();
        }
        finally {
            event.packet = null;
            PacketSendEvent.TYPE.pool.release(event);
        }
        return var2;
    }
}

