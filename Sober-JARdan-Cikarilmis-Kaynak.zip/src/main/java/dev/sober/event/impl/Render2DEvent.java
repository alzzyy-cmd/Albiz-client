/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_332
 */
package dev.sober.event.impl;

import dev.sober.event.Event;
import dev.sober.event.EventType;
import net.minecraft.class_332;

public final class Render2DEvent
extends Event {
    public static final EventType<Render2DEvent> TYPE = new EventType("Render2DEvent");
    public class_332 graphics;
    public float partialTick;
    private static final Render2DEvent INSTANCE = new Render2DEvent();

    private Render2DEvent() {
    }

    public static void dispatch(class_332 graphics, float partialTick) {
        if (TYPE.hasPreListeners()) {
            Render2DEvent.INSTANCE.graphics = graphics;
            Render2DEvent.INSTANCE.partialTick = partialTick;
            TYPE.dispatch(INSTANCE);
            Render2DEvent.INSTANCE.graphics = null;
        }
    }
}

