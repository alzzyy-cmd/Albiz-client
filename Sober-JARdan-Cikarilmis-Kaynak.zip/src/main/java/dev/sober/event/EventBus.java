/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

import dev.sober.event.Event;
import dev.sober.event.EventHandler;
import dev.sober.event.EventListener;
import dev.sober.event.EventPriority;
import dev.sober.event.EventType;
import dev.sober.event.LambdaListenerFactory;
import dev.sober.event.Listener;
import dev.sober.event.ListenerHandle;
import dev.sober.event.Stage;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ArrayBlockingQueue;

public final class EventBus {
    public static final EventBus INSTANCE = new EventBus();
    private final Map<Object, List<RegistrationEntry<?>>> subscriptions = new IdentityHashMap();
    private final ArrayBlockingQueue<Runnable> asyncQueue = new ArrayBlockingQueue(4096);
    private volatile long failedTasks;
    private static final MethodType FACTORY_TYPE = MethodType.methodType(Listener.class, Object.class);
    private static final ClassValue<List<HandlerSpec>> HANDLER_SPECS = new ClassValue<List<HandlerSpec>>(){

        @Override
        protected List<HandlerSpec> computeValue(Class<?> clazz) {
            return EventBus.scan(clazz);
        }
    };
    private static final ClassValue<EventType<?>> TYPE_CACHE = new ClassValue<EventType<?>>(){

        @Override
        protected EventType<?> computeValue(Class<?> eventClass) {
            try {
                Field f = eventClass.getField("TYPE");
                if (!EventType.class.isAssignableFrom(f.getType())) {
                    throw new IllegalArgumentException(eventClass.getName() + ".TYPE must be an EventType instance.");
                }
                return (EventType)f.get(null);
            }
            catch (NoSuchFieldException var3) {
                throw new IllegalArgumentException("Event class " + eventClass.getName() + " must declare 'public static final EventType<...> TYPE'.", var3);
            }
            catch (IllegalAccessException var4) {
                throw new IllegalArgumentException("Cannot access " + eventClass.getName() + ".TYPE", var4);
            }
        }
    };

    public boolean postAsync(Runnable task) {
        return this.asyncQueue.offer(Objects.requireNonNull(task));
    }

    public int drainAsync() {
        return this.drainAsync(512, 2000000L);
    }

    public int drainAsync(int maxTasks, long maxNanos) {
        if (maxTasks > 0 && maxNanos > 0L) {
            Runnable task;
            long started = System.nanoTime();
            int processed = 0;
            while (processed < maxTasks && System.nanoTime() - started < maxNanos && (task = this.asyncQueue.poll()) != null) {
                ++processed;
                try {
                    task.run();
                }
                catch (RuntimeException var11) {
                    long count;
                    if ((count = ++this.failedTasks) > 4L && count % 256L != 0L) continue;
                    System.err.println("[SoberEventBus] Async task failed (#" + count + ")");
                    var11.printStackTrace();
                }
            }
            return processed;
        }
        throw new IllegalArgumentException("Drain limits must be positive");
    }

    public <E extends Event> void off(ListenerHandle<E> handle) {
        handle.unregister();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public int register(Object subscriber) {
        List<HandlerSpec> specs = HANDLER_SPECS.get(subscriber.getClass());
        if (specs.isEmpty()) {
            return 0;
        }
        EventBus eventBus = this;
        synchronized (eventBus) {
            return this.register(subscriber, specs);
        }
    }

    private int register(Object subscriber, List<HandlerSpec> specs) {
        if (this.subscriptions.containsKey(subscriber)) {
            throw new IllegalStateException("Subscriber already registered: " + subscriber.getClass().getName());
        }
        List<RegistrationEntry<?>> entries = EventBus.buildEntries(subscriber, specs);
        try {
            for (RegistrationEntry<?> entry : entries) {
                entry.register();
            }
        }
        catch (Error | RuntimeException failure) {
            for (RegistrationEntry<?> entry : entries) {
                try {
                    entry.unregister();
                }
                catch (Error | RuntimeException cleanup) {
                    if (failure == cleanup) continue;
                    failure.addSuppressed(cleanup);
                }
            }
            throw failure;
        }
        this.subscriptions.put(subscriber, entries);
        return entries.size();
    }

    public synchronized void unregister(Object subscriber) {
        List<RegistrationEntry<?>> entries = this.subscriptions.remove(subscriber);
        if (entries != null) {
            for (RegistrationEntry<?> entry : entries) {
                entry.unregister();
            }
        }
    }

    private static List<RegistrationEntry<?>> buildEntries(Object subscriber, List<HandlerSpec> specs) {
        ArrayList entries = new ArrayList(specs.size());
        for (HandlerSpec spec : specs) {
            Listener<Event> listener = spec.staticListener();
            if (listener == null) {
                try {
                    listener = EventBus.castListener(spec.listenerFactory().invokeExact(subscriber));
                }
                catch (Throwable var7) {
                    throw new RuntimeException("Failed to bind listener for " + subscriber.getClass().getName(), var7);
                }
            }
            ListenerHandle<Event> handle = new ListenerHandle<Event>(spec.type(), spec.stage(), spec.priority(), subscriber, listener::invoke);
            entries.add(new RegistrationEntry<Event>(spec.type(), handle));
        }
        return entries;
    }

    private static Listener<Event> castListener(Listener<?> listener) {
        return listener;
    }

    private static List<HandlerSpec> scan(Class<?> clazz) {
        ArrayList<HandlerSpec> specs = new ArrayList<HandlerSpec>();
        for (Class<?> parent = clazz; parent != null; parent = parent.getSuperclass()) {
            Method[] methodArray = parent.getDeclaredMethods();
            int n = methodArray.length;
            for (int i = 0; i < n; ++i) {
                Method method = methodArray[i];
                if (!EventBus.isHandler(method) || Modifier.isPublic(method.getModifiers())) continue;
                throw new IllegalArgumentException("Event handler must be public: " + String.valueOf(method));
            }
        }
        for (Method methodx : clazz.getMethods()) {
            Stage stage = Stage.PRE;
            EventPriority priority = EventPriority.NORMAL;
            boolean matched = false;
            EventHandler newAnnotation = methodx.getAnnotation(EventHandler.class);
            if (newAnnotation != null) {
                stage = newAnnotation.stage();
                priority = newAnnotation.priority();
                matched = true;
            } else {
                EventListener legacyAnnotation = methodx.getAnnotation(EventListener.class);
                if (legacyAnnotation != null) {
                    stage = Stage.PRE;
                    priority = EventPriority.fromInt(legacyAnnotation.priority());
                    matched = true;
                }
            }
            if (!matched) continue;
            Class<?>[] params = methodx.getParameterTypes();
            if (params.length != 1 || !Event.class.isAssignableFrom(params[0]) || methodx.getReturnType() != Void.TYPE) {
                throw new IllegalArgumentException("Event handler must return void and accept one Event: " + String.valueOf(methodx));
            }
            Class<?> eventClass = params[0];
            EventType<Event> type = EventBus.resolveTypeFor(eventClass);
            if (Modifier.isStatic(methodx.getModifiers())) {
                specs.add(new HandlerSpec(type, stage, priority, null, LambdaListenerFactory.createStatic(methodx)));
                continue;
            }
            specs.add(new HandlerSpec(type, stage, priority, LambdaListenerFactory.createFactory(methodx).asType(FACTORY_TYPE), null));
        }
        return specs.isEmpty() ? List.of() : List.copyOf(specs);
    }

    private static boolean isHandler(Method method) {
        return method.isAnnotationPresent(EventHandler.class) || method.isAnnotationPresent(EventListener.class);
    }

    static <E extends Event> EventType<E> resolveTypeFor(Class<E> eventClass) {
        return TYPE_CACHE.get(eventClass);
    }

    private record RegistrationEntry<E extends Event>(EventType<E> type, ListenerHandle<E> handle) {
        void register() {
            this.type.register(this.handle);
        }

        void unregister() {
            this.type.unregister(this.handle);
        }
    }

    private record HandlerSpec(EventType<Event> type, Stage stage, EventPriority priority, MethodHandle listenerFactory, Listener<Event> staticListener) {
    }
}

