/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

public abstract class Event {
    boolean pooledValid = true;

    public final void checkValid() {
    }
}

