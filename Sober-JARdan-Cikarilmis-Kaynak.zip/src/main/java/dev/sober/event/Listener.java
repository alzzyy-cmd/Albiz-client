/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

import dev.sober.event.Event;

@FunctionalInterface
public interface Listener<E extends Event> {
    public void invoke(E var1);
}

