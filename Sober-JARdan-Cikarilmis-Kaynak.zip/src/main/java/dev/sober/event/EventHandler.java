/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

import dev.sober.event.EventPriority;
import dev.sober.event.Stage;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(value=RetentionPolicy.RUNTIME)
@Target(value={ElementType.METHOD})
public @interface EventHandler {
    public EventPriority priority() default EventPriority.NORMAL;

    public Stage stage() default Stage.PRE;
}

