/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

import dev.sober.event.Event;
import dev.sober.event.EventPriority;
import dev.sober.event.EventType;
import dev.sober.event.Stage;
import java.util.function.Consumer;

public record ListenerHandle<E extends Event>(EventType<E> type, Stage stage, EventPriority priority, Object owner, Consumer<E> callback) {
    public void unregister() {
        this.type.unregister(this);
    }
}

