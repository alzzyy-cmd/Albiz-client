/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

import dev.sober.event.Event;
import dev.sober.event.EventPool;
import dev.sober.event.EventType;
import java.util.function.Supplier;

public class PooledEventType<E extends Event>
extends EventType<E> {
    public final EventPool<E> pool;

    public PooledEventType(Supplier<E> factory, int capacity) {
        this.pool = new EventPool<E>(factory, capacity);
    }

    public PooledEventType(String name, Supplier<E> factory, int capacity) {
        super(name);
        this.pool = new EventPool<E>(factory, capacity);
    }
}

