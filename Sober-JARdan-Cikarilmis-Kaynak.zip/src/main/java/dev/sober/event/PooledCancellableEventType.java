/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

import dev.sober.event.CancellableEvent;
import dev.sober.event.CancellableEventType;
import dev.sober.event.PooledEventType;
import java.util.function.Supplier;

public class PooledCancellableEventType<E extends CancellableEvent>
extends PooledEventType<E> {
    public PooledCancellableEventType(Supplier<E> factory, int capacity) {
        super(factory, capacity);
    }

    public PooledCancellableEventType(String name, Supplier<E> factory, int capacity) {
        super(name, factory, capacity);
    }

    @Override
    public void dispatchPre(E event) {
        CancellableEventType.dispatchPreCancellable(this.list, event);
    }

    @Override
    public void dispatchPost(E event) {
        CancellableEventType.dispatchPostGuarded(this.list, event);
    }
}

