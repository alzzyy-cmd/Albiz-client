/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

import dev.sober.event.Event;
import dev.sober.event.ListenerHandle;
import java.util.IdentityHashMap;
import java.util.Map;

final class ListenerErrorReporter {
    private static final int FULL_TRACE_LIMIT = 4;
    private static final int SUMMARY_INTERVAL = 256;
    private static final Map<ListenerHandle<?>, Integer> failureCounts = new IdentityHashMap();

    private ListenerErrorReporter() {
    }

    static synchronized void report(ListenerHandle<?> handle, Event event, Exception ex) {
        String owner;
        int count = failureCounts.merge(handle, 1, Integer::sum);
        String string = owner = handle.owner() == null ? "<static>" : handle.owner().getClass().getName();
        if (count <= 4) {
            System.err.println("[SoberEventBus] Listener threw (failure #" + count + "): owner=" + owner + " event=" + event.getClass().getSimpleName() + " stage=" + String.valueOf((Object)handle.stage()) + " priority=" + String.valueOf((Object)handle.priority()));
            ex.printStackTrace();
        } else if (count % 256 == 0) {
            System.err.println("[SoberEventBus] Listener still failing (" + count + " total): owner=" + owner + " event=" + event.getClass().getSimpleName() + ": " + String.valueOf(ex));
        }
    }
}

