/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.event;

import dev.sober.event.CancellableEvent;
import dev.sober.event.EventType;
import dev.sober.event.ListenerErrorReporter;
import dev.sober.event.ListenerList;
import dev.sober.event.Stage;
import java.util.function.Consumer;

public class CancellableEventType<E extends CancellableEvent>
extends EventType<E> {
    public CancellableEventType() {
    }

    public CancellableEventType(String name) {
        super(name);
    }

    @Override
    public void dispatchPre(E event) {
        CancellableEventType.dispatchPreCancellable(this.list, event);
    }

    @Override
    public void dispatchPost(E event) {
        CancellableEventType.dispatchPostGuarded(this.list, event);
    }

    static <E extends CancellableEvent> void dispatchPreCancellable(ListenerList<E> list, E event) {
        Consumer<E>[] cbs = list.preCallbacks();
        for (int i = 0; i < cbs.length; ++i) {
            try {
                cbs[i].accept(event);
            }
            catch (Exception var5) {
                ListenerErrorReporter.report(list.handleOf(Stage.PRE, cbs[i]), event, var5);
            }
            if (event.cancelled) break;
        }
    }

    static <E extends CancellableEvent> void dispatchPostGuarded(ListenerList<E> list, E event) {
        event.postStage = true;
        try {
            list.dispatchPost(event);
        }
        finally {
            event.postStage = false;
        }
    }
}

