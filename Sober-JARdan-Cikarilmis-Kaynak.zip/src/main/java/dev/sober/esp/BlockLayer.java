/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap
 *  it.unimi.dsi.fastutil.longs.LongCollection
 *  it.unimi.dsi.fastutil.longs.LongIterator
 *  it.unimi.dsi.fastutil.longs.LongOpenHashSet
 *  net.minecraft.class_12179
 *  net.minecraft.class_12180
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_4604
 */
package dev.sober.esp;

import dev.sober.esp.BlockBoxCache;
import dev.sober.esp.ChunkScanner;
import dev.sober.esp.EspStyle;
import dev.sober.esp.HorizontalCandidates;
import dev.sober.event.impl.Render3DEvent;
import dev.sober.modules.FpsBooster;
import dev.sober.util.BlockBoxHelper;
import dev.sober.util.BlockClusterGeometry;
import dev.sober.util.MobilePerformance;
import dev.sober.util.TracerEngine;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongCollection;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.LongPredicate;
import java.util.function.Supplier;
import net.minecraft.class_12179;
import net.minecraft.class_12180;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4604;

public final class BlockLayer {
    private static final float REVEAL_NANOS = 1.5E8f;
    private static final double FADE_START = 64.0;
    private static final double FADE_END = 256.0;
    private static final float FADE_FLOOR = 0.45f;
    private final Palette palette;
    private final Supplier<Object> dimension;
    private final Map<Object, World> worlds = new HashMap<Object, World>();
    private BlockBoxCache boxCache;

    public BlockLayer(Palette palette, Supplier<Object> dimension) {
        this.palette = palette;
        this.dimension = dimension;
    }

    public void put(long pos, Object kind) {
        Found existing;
        World world = this.world(true);
        if (!(world == null || (existing = (Found)((Object)world.positions.get(pos))) != null && Objects.equals(existing.kind(), kind))) {
            world.positions.put(pos, (Object)new Found(kind, System.nanoTime()));
            ((LongOpenHashSet)world.byChunk.computeIfAbsent(BlockLayer.chunkOf(pos), k -> new LongOpenHashSet())).add(pos);
            BlockLayer.markDirty(world, pos);
        }
    }

    public void remove(long pos) {
        World world = this.world(false);
        if (world != null && world.positions.remove(pos) != null) {
            long chunk = BlockLayer.chunkOf(pos);
            LongOpenHashSet set = (LongOpenHashSet)world.byChunk.get(chunk);
            if (set != null && set.remove(pos) && set.isEmpty()) {
                world.byChunk.remove(chunk);
            }
            BlockLayer.markDirty(world, pos);
        }
    }

    public void clear() {
        this.worlds.clear();
        this.boxCache = null;
    }

    public void retainChunk(long chunkKey, LongPredicate keep) {
        LongOpenHashSet set;
        World world = this.world(false);
        if (world != null && (set = (LongOpenHashSet)world.byChunk.get(chunkKey)) != null) {
            for (long pos : set.toLongArray()) {
                if (keep.test(pos)) continue;
                this.remove(pos);
            }
        }
    }

    public List<Vein> veins() {
        World world = this.world(false);
        if (world == null) {
            return List.of();
        }
        this.rebuildDirty(world);
        if (world.veinsDirty) {
            world.veins = BlockLayer.joinVeins(world);
            world.veinsDirty = false;
        }
        return world.veins;
    }

    private World world(boolean create) {
        Object key = this.dimension.get();
        if (key == null) {
            return null;
        }
        return create ? this.worlds.computeIfAbsent(key, k -> new World()) : this.worlds.get(key);
    }

    private static long chunkKey(int cx, int cz) {
        return (long)cx & 0xFFFFFFFFL | (long)cz << 32;
    }

    private static long chunkOf(long pos) {
        return BlockLayer.chunkKey(class_2338.method_10061((long)pos) >> 4, class_2338.method_10083((long)pos) >> 4);
    }

    private static long regionOf(long chunk) {
        return BlockLayer.chunkKey((int)chunk >> 4, (int)(chunk >> 32) >> 4);
    }

    private static void markDirty(World world, long pos) {
        ChunkScanner.ScanBatch batch = ChunkScanner.deliveryBatch();
        LongOpenHashSet dirty = world.dirty;
        if (batch != null && !batch.finished) {
            if (world.scanBatch != batch) {
                BlockLayer.flushScanDirty(world);
            }
            world.scanBatch = batch;
            dirty = world.scanDirty;
        }
        int x = class_2338.method_10061((long)pos);
        int z = class_2338.method_10083((long)pos);
        int cx = x >> 4;
        int cz = z >> 4;
        dirty.add(BlockLayer.chunkKey(cx, cz));
        if ((x & 0xF) == 0) {
            dirty.add(BlockLayer.chunkKey(cx - 1, cz));
        }
        if ((x & 0xF) == 15) {
            dirty.add(BlockLayer.chunkKey(cx + 1, cz));
        }
        if ((z & 0xF) == 0) {
            dirty.add(BlockLayer.chunkKey(cx, cz - 1));
        }
        if ((z & 0xF) == 15) {
            dirty.add(BlockLayer.chunkKey(cx, cz + 1));
        }
    }

    private static void flushScanDirty(World world) {
        world.dirty.addAll((LongCollection)world.scanDirty);
        world.scanDirty.clear();
        world.scanBatch = null;
    }

    private void rebuildDirty(World world) {
        if (world.scanBatch != null && (world.scanBatch.finished || !FpsBooster.optimizationsEnabled())) {
            BlockLayer.flushScanDirty(world);
        }
        if (!world.dirty.isEmpty()) {
            LongIterator var2 = world.dirty.iterator();
            while (var2.hasNext()) {
                long chunk = var2.next();
                this.rebuildChunk(world, chunk);
            }
            world.dirty.clear();
            world.veinsDirty = true;
        }
    }

    private void rebuildChunk(World world, long chunkKey) {
        LongOpenHashSet set = (LongOpenHashSet)world.byChunk.get(chunkKey);
        if (set == null) {
            if (world.shapes.remove(chunkKey) != null) {
                LongOpenHashSet region = (LongOpenHashSet)world.shapeRegions.get(BlockLayer.regionOf(chunkKey));
                if (region != null && region.remove(chunkKey) && region.isEmpty()) {
                    world.shapeRegions.remove(BlockLayer.regionOf(chunkKey));
                }
                ++world.shapeRevision;
            }
        } else {
            LinkedHashMap<Object, List> byKind = new LinkedHashMap<Object, List>();
            int minX = Integer.MAX_VALUE;
            int minY = Integer.MAX_VALUE;
            int minZ = Integer.MAX_VALUE;
            int maxX = Integer.MIN_VALUE;
            int maxY = Integer.MIN_VALUE;
            int maxZ = Integer.MIN_VALUE;
            LongIterator cx = set.iterator();
            while (cx.hasNext()) {
                long pos = cx.next();
                class_2338 block = class_2338.method_10092((long)pos);
                byKind.computeIfAbsent(((Found)((Object)world.positions.get(pos))).kind(), k -> new ArrayList()).add(block);
                minX = Math.min(minX, block.method_10263());
                maxX = Math.max(maxX, block.method_10263());
                minY = Math.min(minY, block.method_10264());
                maxY = Math.max(maxY, block.method_10264());
                minZ = Math.min(minZ, block.method_10260());
                maxZ = Math.max(maxZ, block.method_10260());
            }
            int cxx = (int)chunkKey;
            int cz = (int)(chunkKey >> 32);
            ArrayList<Cluster> clusters = new ArrayList<Cluster>();
            for (Map.Entry entry : byKind.entrySet()) {
                Object kind = entry.getKey();
                BlockClusterGeometry.Membership same = (x, y, z) -> {
                    Found found = (Found)((Object)((Object)world.positions.get(class_2338.method_10064((int)x, (int)y, (int)z))));
                    return found != null && Objects.equals(found.kind(), kind);
                };
                for (List<class_2338> component : BlockClusterGeometry.connectedComponents((Collection)entry.getValue())) {
                    clusters.add(BlockLayer.buildCluster(world, kind, component, same, cxx, cz));
                }
            }
            world.shapes.put(chunkKey, (Object)new Shapes(clusters, new class_238((double)(minX - 1), (double)(minY - 1), (double)(minZ - 1), (double)(maxX + 2), (double)(maxY + 2), (double)(maxZ + 2))));
            ((LongOpenHashSet)world.shapeRegions.computeIfAbsent(BlockLayer.regionOf(chunkKey), k -> new LongOpenHashSet())).add(chunkKey);
            ++world.shapeRevision;
        }
    }

    private static Iterable<Shapes> nearbyShapes(World world, class_243 eye, double range) {
        if (!FpsBooster.optimizationsEnabled()) {
            return world.shapes.values();
        }
        int cx = (int)Math.floor(eye.field_1352) >> 4;
        int cz = (int)Math.floor(eye.field_1350) >> 4;
        if (world.candidateRevision == world.shapeRevision && world.candidateX == cx && world.candidateZ == cz && world.candidateRange == range) {
            return world.candidates;
        }
        world.candidates.clear();
        int radius = (int)Math.ceil(range / 16.0) + 1;
        for (int rx = cx - radius >> 4; rx <= cx + radius >> 4; ++rx) {
            for (int rz = cz - radius >> 4; rz <= cz + radius >> 4; ++rz) {
                LongOpenHashSet region = (LongOpenHashSet)world.shapeRegions.get(BlockLayer.chunkKey(rx, rz));
                if (region == null) continue;
                LongIterator var10 = region.iterator();
                while (var10.hasNext()) {
                    Shapes shape;
                    long key = var10.next();
                    if (Math.abs((long)((int)key) - (long)cx) > (long)radius || Math.abs((long)((int)(key >> 32)) - (long)cz) > (long)radius || (shape = (Shapes)((Object)world.shapes.get(key))) == null) continue;
                    world.candidates.add(shape);
                }
            }
        }
        world.candidateRevision = world.shapeRevision;
        world.candidateX = cx;
        world.candidateZ = cz;
        world.candidateRange = range;
        return world.candidates;
    }

    private static Cluster buildCluster(World world, Object kind, List<class_2338> component, BlockClusterGeometry.Membership same, int cx, int cz) {
        long[] positions = new long[component.size()];
        ArrayList<Long> links = new ArrayList<Long>();
        double sx = 0.0;
        double sy = 0.0;
        double sz = 0.0;
        long bornAt = Long.MAX_VALUE;
        for (int i = 0; i < positions.length; ++i) {
            class_2338 pos = component.get(i);
            positions[i] = pos.method_10063();
            sx += (double)pos.method_10263() + 0.5;
            sy += (double)pos.method_10264() + 0.5;
            sz += (double)pos.method_10260() + 0.5;
            bornAt = Math.min(bornAt, ((Found)((Object)world.positions.get(positions[i]))).bornAt());
            for (class_2338 next : new class_2338[]{pos.method_10078(), pos.method_10067(), pos.method_10072(), pos.method_10095()}) {
                if (next.method_10263() >> 4 == cx && next.method_10260() >> 4 == cz || !same.contains(next.method_10263(), next.method_10264(), next.method_10260())) continue;
                links.add(next.method_10063());
            }
        }
        int n = positions.length;
        return new Cluster(kind, positions, new class_243(sx / (double)n, sy / (double)n, sz / (double)n), bornAt, BlockClusterGeometry.build(component, same), links.stream().mapToLong(Long::longValue).toArray());
    }

    private static List<Vein> joinVeins(World world) {
        ArrayList<Cluster> all = new ArrayList<Cluster>();
        Long2ObjectOpenHashMap owner = new Long2ObjectOpenHashMap();
        for (Shapes shapes : world.shapes.values()) {
            for (Cluster cluster : shapes.clusters()) {
                all.add(cluster);
                if (cluster.links().length == 0) continue;
                for (long pos : cluster.positions()) {
                    int lx = class_2338.method_10061((long)pos) & 0xF;
                    int lz = class_2338.method_10083((long)pos) & 0xF;
                    if (lx != 0 && lx != 15 && lz != 0 && lz != 15) continue;
                    owner.put(pos, (Object)cluster);
                }
            }
        }
        IdentityHashMap<Cluster, Cluster> parentx = new IdentityHashMap<Cluster, Cluster>();
        for (Cluster cluster : all) {
            parentx.put(cluster, cluster);
        }
        for (Cluster cluster : all) {
            for (long link : cluster.links()) {
                Cluster other = (Cluster)((Object)owner.get(link));
                if (other == null) continue;
                parentx.put(BlockLayer.find(parentx, cluster), BlockLayer.find(parentx, other));
            }
        }
        IdentityHashMap<Cluster, double[]> sums = new IdentityHashMap<Cluster, double[]>();
        for (Cluster clusterx : all) {
            double[] sum = sums.computeIfAbsent(BlockLayer.find(parentx, clusterx), r -> new double[4]);
            int n = clusterx.positions().length;
            sum[0] = sum[0] + clusterx.center().field_1352 * (double)n;
            sum[1] = sum[1] + clusterx.center().field_1351 * (double)n;
            sum[2] = sum[2] + clusterx.center().field_1350 * (double)n;
            sum[3] = sum[3] + (double)n;
        }
        ArrayList<Vein> arrayList = new ArrayList<Vein>(sums.size());
        Object object = sums.entrySet().iterator();
        while (object.hasNext()) {
            Map.Entry entry = (Map.Entry)object.next();
            double[] s = (double[])entry.getValue();
            arrayList.add(new Vein(((Cluster)((Object)entry.getKey())).kind(), new class_243(s[0] / s[3], s[1] / s[3], s[2] / s[3])));
        }
        return arrayList;
    }

    private static Cluster find(Map<Cluster, Cluster> parent, Cluster cluster) {
        Cluster root = cluster;
        while (parent.get((Object)root) != root) {
            root = parent.get((Object)root);
        }
        while (parent.get((Object)cluster) != root) {
            Cluster next = parent.get((Object)cluster);
            parent.put(cluster, root);
            cluster = next;
        }
        return root;
    }

    public void render(Render3DEvent event, EspStyle style) {
        class_310 mc = class_310.method_1551();
        World world = this.world(false);
        if (mc.field_1724 != null && world != null) {
            this.rebuildDirty(world);
            class_4604 frustum = FpsBooster.frustumCulling() ? event.frustum : null;
            long now = System.nanoTime();
            class_243 eye = mc.field_1724.method_5836(event.partialTick);
            boolean outline = style.outline();
            boolean glow = style.glow.get();
            boolean fade = style.fade.get();
            boolean reveal = style.reveal.get();
            float baseWidth = style.lineWidth.get();
            float fillAlpha = style.fillAlpha.get();
            float boxSize = style.boxSize.get();
            double range = style.range.get();
            boolean mobile = MobilePerformance.active();
            BlockBoxCache boxes = null;
            if (mobile && !outline) {
                if (this.boxCache == null) {
                    this.boxCache = new BlockBoxCache(4096);
                }
                this.boxCache.beginFrame(boxSize);
                boxes = this.boxCache;
            } else if (!mobile) {
                this.boxCache = null;
            }
            for (Shapes shapes : BlockLayer.nearbyShapes(world, eye, range)) {
                if (frustum != null && !frustum.method_23093(shapes.bounds())) continue;
                for (Cluster cluster : shapes.clusters()) {
                    int fill;
                    double dist = eye.method_1022(cluster.center());
                    if (dist > range) continue;
                    float alpha = fade ? BlockLayer.distanceFade(dist) : 1.0f;
                    float t = reveal ? Math.min(1.0f, (float)(now - cluster.bornAt()) / 1.5E8f) : 1.0f;
                    if ((alpha *= BlockLayer.easeOutCubic(t)) < 0.02f) continue;
                    float width = fade ? baseWidth * (1.0f - 0.3f * (float)Math.min(1.0, dist / 256.0)) : baseWidth;
                    int color = this.palette.color(cluster.kind());
                    int stroke = BlockLayer.scaleAlpha(color, alpha);
                    int n = fill = fillAlpha > 0.0f ? BlockLayer.withAlpha(color, fillAlpha * alpha) : 0;
                    if (outline) {
                        BlockLayer.drawOutline(cluster, stroke, fill, width, glow);
                        continue;
                    }
                    BlockLayer.drawBoxes(cluster, stroke, fill, width, boxSize, boxes);
                }
            }
        }
    }

    private static void drawOutline(Cluster cluster, int stroke, int fill, float width, boolean glow) {
        BlockClusterGeometry.Mesh mesh = cluster.mesh();
        if (fill >>> 24 > 0) {
            class_12179 style = class_12179.method_75539((int)fill);
            for (BlockClusterGeometry.Face face : mesh.faces()) {
                class_12180.method_75547((class_243)face.a(), (class_243)face.b(), (class_243)face.c(), (class_243)face.d(), (class_12179)style).method_75533();
            }
        }
        int halo = glow ? BlockLayer.scaleAlpha(stroke, 0.18f) : 0;
        for (BlockClusterGeometry.Segment edge : mesh.edges()) {
            class_243 a = edge.a();
            class_243 b = edge.b();
            if (glow) {
                class_12180.method_75546((class_243)a, (class_243)b, (int)halo, (float)(width * 3.0f)).method_75533();
            }
            class_12180.method_75546((class_243)a, (class_243)b, (int)stroke, (float)width).method_75533();
        }
    }

    private static void drawBoxes(Cluster cluster, int stroke, int fill, float width, float size, BlockBoxCache cache) {
        class_12179 style = fill >>> 24 > 0 ? class_12179.method_75537((int)stroke, (float)width, (int)fill) : class_12179.method_75536((int)stroke, (float)width);
        for (long pos : cluster.positions()) {
            class_238 bounds = cache == null ? BlockBoxHelper.scaledBlockBox(class_2338.method_10092((long)pos), size) : cache.box(pos);
            class_12180.method_75541((class_238)bounds, (class_12179)style).method_75533();
        }
    }

    private static float distanceFade(double dist) {
        if (dist <= 64.0) {
            return 1.0f;
        }
        float t = (float)Math.min(1.0, (dist - 64.0) / 192.0);
        return 1.0f - 0.55f * t * t;
    }

    public void renderTracers(EspStyle style) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            class_243 eye = mc.field_1724.method_5836(1.0f);
            double rangeSq = (double)style.range.get() * (double)style.range.get();
            List<Vein> visible = this.veins();
            World world = this.world(false);
            if (MobilePerformance.active() && world != null) {
                if (world.tracerCandidates == null) {
                    world.tracerCandidates = new HorizontalCandidates<Vein>(veinx -> veinx.center().field_1352, veinx -> veinx.center().field_1350);
                }
                visible = world.tracerCandidates.select(visible, eye.field_1352, eye.field_1350, style.range.get());
            } else if (world != null) {
                world.tracerCandidates = null;
            }
            for (Vein vein : visible) {
                int color;
                if (eye.method_1025(vein.center()) > rangeSq || (color = this.palette.tracerColor(vein.kind())) >>> 24 == 0) continue;
                TracerEngine.draw(vein.center(), color);
            }
        }
    }

    private static int withAlpha(int argb, float alpha) {
        return Math.round(255.0f * Math.max(0.0f, Math.min(1.0f, alpha))) << 24 | argb & 0xFFFFFF;
    }

    private static int scaleAlpha(int argb, float mul) {
        int alpha = Math.round((float)(argb >>> 24) * Math.max(0.0f, Math.min(1.0f, mul)));
        return alpha << 24 | argb & 0xFFFFFF;
    }

    private static float easeOutCubic(float t) {
        float inv = 1.0f - t;
        return 1.0f - inv * inv * inv;
    }

    public static interface Palette {
        public int color(Object var1);

        public int tracerColor(Object var1);
    }

    private static final class World {
        final Long2ObjectOpenHashMap<Found> positions = new Long2ObjectOpenHashMap();
        final Long2ObjectOpenHashMap<LongOpenHashSet> byChunk = new Long2ObjectOpenHashMap();
        final Long2ObjectOpenHashMap<Shapes> shapes = new Long2ObjectOpenHashMap();
        final Long2ObjectOpenHashMap<LongOpenHashSet> shapeRegions = new Long2ObjectOpenHashMap();
        final LongOpenHashSet dirty = new LongOpenHashSet();
        final LongOpenHashSet scanDirty = new LongOpenHashSet();
        ChunkScanner.ScanBatch scanBatch;
        List<Vein> veins = List.of();
        boolean veinsDirty;
        long shapeRevision;
        long candidateRevision = -1L;
        int candidateX;
        int candidateZ;
        double candidateRange;
        final List<Shapes> candidates = new ArrayList<Shapes>();
        HorizontalCandidates<Vein> tracerCandidates;

        private World() {
        }
    }

    private record Found(Object kind, long bornAt) {
    }

    private record Cluster(Object kind, long[] positions, class_243 center, long bornAt, BlockClusterGeometry.Mesh mesh, long[] links) {
    }

    private record Shapes(List<Cluster> clusters, class_238 bounds) {
    }

    public record Vein(Object kind, class_243 center) {
    }
}

