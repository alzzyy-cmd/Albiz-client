/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.skin;

import dev.sober.skin.SkinMesh;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class SkinRig {
    public static final int BODY = 0;
    public static final int HEAD = 1;
    public static final int RIGHT_ARM = 2;
    public static final int LEFT_ARM = 3;
    public static final int RIGHT_LEG = 4;
    public static final int LEFT_LEG = 5;
    private static final int H = 160;
    private static final float CELL = 0.00625f;
    public final SkinMesh mesh;
    public final int turn;
    public final float[][] positions;
    public final float[][] normals;
    public final byte[][] bones;
    public final float[][] weights;
    public final float[][] upper;
    public final float[] hip = new float[3];
    public final float[] neck = new float[3];
    public final float[][] armPivot = new float[2][3];
    public final float[][] legPivot = new float[2][3];
    public final float[] armRest = new float[2];
    public final boolean[] arms = new boolean[2];
    public boolean legs;
    public float headStrength = 1.0f;
    public float halfWidth;
    public float wingY;
    public float backZ;
    private float x0;
    private int width;
    private boolean[] grid;
    private int centerCol;

    private SkinRig(SkinMesh mesh, int turn) {
        this.mesh = mesh;
        this.turn = turn;
        int count = mesh.parts.size();
        this.positions = new float[count][];
        this.normals = new float[count][];
        this.bones = new byte[count][];
        this.weights = new float[count][];
        this.upper = new float[count][];
    }

    public static SkinRig build(SkinMesh mesh, int turn, boolean relax) {
        SkinRig rig = new SkinRig(mesh, turn);
        rig.rotate();
        rig.analyze(relax);
        return rig;
    }

    private void rotate() {
        double a = Math.toRadians(this.turn);
        float c = (float)Math.cos(a);
        float s = (float)Math.sin(a);
        for (int i = 0; i < this.mesh.parts.size(); ++i) {
            SkinMesh.Part part = this.mesh.parts.get(i);
            float[] p = (float[])part.positions.clone();
            float[] n = (float[])part.normals.clone();
            for (int v = 0; v < p.length; v += 3) {
                float x = p[v];
                float z = p[v + 2];
                p[v] = c * x + s * z;
                p[v + 2] = -s * x + c * z;
                x = n[v];
                z = n[v + 2];
                n[v] = c * x + s * z;
                n[v + 2] = -s * x + c * z;
                this.halfWidth = Math.max(this.halfWidth, Math.abs(p[v]));
            }
            this.positions[i] = p;
            this.normals[i] = n;
            int vertices = p.length / 3;
            this.bones[i] = new byte[vertices];
            this.weights[i] = new float[vertices];
            this.upper[i] = new float[vertices];
        }
    }

    private static float smooth(float t) {
        t = Math.max(0.0f, Math.min(1.0f, t));
        return t * t * (3.0f - 2.0f * t);
    }

    private int col(float x) {
        return Math.max(0, Math.min(this.width - 1, (int)Math.floor((x - this.x0) / 0.00625f)));
    }

    private static int row(float y) {
        return Math.max(0, Math.min(159, (int)Math.floor(y / 0.00625f)));
    }

    private float colX(int c) {
        return this.x0 + ((float)c + 0.5f) * 0.00625f;
    }

    private void mark(float x, float y) {
        this.grid[SkinRig.row((float)y) * this.width + this.col((float)x)] = true;
    }

    private void rasterize() {
        float minX = Float.MAX_VALUE;
        float maxX = -3.4028235E38f;
        for (float[] p : this.positions) {
            for (int v = 0; v < p.length; v += 3) {
                minX = Math.min(minX, p[v]);
                maxX = Math.max(maxX, p[v]);
            }
        }
        this.x0 = minX - 0.00625f;
        this.width = Math.max(3, Math.min(800, (int)Math.ceil((maxX - minX) / 0.00625f) + 3));
        this.grid = new boolean[this.width * 160];
        for (int i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            int[] t = this.mesh.parts.get((int)i).triangles;
            int k = 0;
            while (k + 2 < t.length) {
                int a = t[k] * 3;
                int b = t[k + 1] * 3;
                int c = t[k + 2] * 3;
                this.triangle(p[a], p[a + 1], p[b], p[b + 1], p[c], p[c + 1]);
                k += 3;
            }
        }
    }

    private void edge(float ax, float ay, float bx, float by) {
        float length = (float)Math.sqrt((bx - ax) * (bx - ax) + (by - ay) * (by - ay));
        int steps = Math.max(1, (int)Math.ceil(length / 0.003125f));
        for (int i = 0; i <= steps; ++i) {
            float t = (float)i / (float)steps;
            this.mark(ax + (bx - ax) * t, ay + (by - ay) * t);
        }
    }

    private void triangle(float ax, float ay, float bx, float by, float cx, float cy) {
        this.edge(ax, ay, bx, by);
        this.edge(bx, by, cx, cy);
        this.edge(cx, cy, ax, ay);
        float area = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax);
        if (Math.abs(area) < 1.0E-9f) {
            return;
        }
        int c0 = this.col(Math.min(ax, Math.min(bx, cx)));
        int c1 = this.col(Math.max(ax, Math.max(bx, cx)));
        int r0 = SkinRig.row(Math.min(ay, Math.min(by, cy)));
        int r1 = SkinRig.row(Math.max(ay, Math.max(by, cy)));
        for (int r = r0; r <= r1; ++r) {
            float py = ((float)r + 0.5f) * 0.00625f;
            for (int c = c0; c <= c1; ++c) {
                float px = this.colX(c);
                float w0 = ((bx - px) * (cy - py) - (by - py) * (cx - px)) / area;
                float w1 = ((cx - px) * (ay - py) - (cy - py) * (ax - px)) / area;
                float w2 = 1.0f - w0 - w1;
                if (!(w0 >= 0.0f) || !(w1 >= 0.0f) || !(w2 >= 0.0f)) continue;
                this.grid[r * this.width + c] = true;
            }
        }
    }

    private List<int[]> runs(int r) {
        ArrayList<int[]> list = new ArrayList<int[]>();
        int start = -1;
        int last = -10;
        for (int c = 0; c < this.width; ++c) {
            if (!this.grid[r * this.width + c]) continue;
            if (start >= 0 && c - last <= 2) {
                last = c;
                continue;
            }
            if (start >= 0) {
                list.add(new int[]{start, last});
            }
            start = c;
            last = c;
        }
        if (start >= 0) {
            list.add(new int[]{start, last});
        }
        return list;
    }

    private void analyze(boolean relax) {
        int v;
        int i;
        int bottom;
        this.rasterize();
        float sum = 0.0f;
        int filled = 0;
        for (int r = SkinRig.row(0.35f); r <= SkinRig.row(0.85f); ++r) {
            for (int c = 0; c < this.width; ++c) {
                if (!this.grid[r * this.width + c]) continue;
                sum += this.colX(c);
                ++filled;
            }
        }
        float cx = filled > 0 ? sum / (float)filled : 0.0f;
        this.centerCol = this.col(cx);
        ArrayList<List<int[]>> rows = new ArrayList<List<int[]>>();
        for (int r = 0; r < 160; ++r) {
            rows.add(this.runs(r));
        }
        for (bottom = 0; bottom < 160 && ((List)rows.get(bottom)).isEmpty(); ++bottom) {
        }
        int firstGap = -1;
        int lastGap = -1;
        int misses = 0;
        int r = bottom;
        while ((float)r < 112.0f) {
            if (this.gapAt((List)rows.get(r))) {
                if (firstGap < 0) {
                    firstGap = r;
                }
                lastGap = r;
                misses = 0;
            } else if (firstGap >= 0 ? ++misses > 2 : (float)(r - bottom) > 24.0f) break;
            ++r;
        }
        this.legs = firstGap >= 0 && (float)(lastGap - firstGap) >= 12.799999f && (float)(firstGap - bottom) <= 24.0f;
        int crotchRow = this.legs ? lastGap : -1;
        float crotchY = this.legs ? (float)(lastGap + 1) * 0.00625f : 0.45f;
        int[][] inner = new int[2][160];
        int[][] outer = new int[2][160];
        int[][] core = new int[2][160];
        for (int[] a : inner) {
            Arrays.fill(a, -1);
        }
        for (int r2 = 0; r2 < 160; ++r2) {
            int coreRight;
            int coreLeft;
            List list = (List)rows.get(r2);
            if (list.isEmpty()) continue;
            if (this.legs && r2 <= crotchRow) {
                int gap = this.gapIndex(list);
                if (gap < 0) continue;
                coreLeft = ((int[])list.get(gap))[0];
                coreRight = ((int[])list.get(gap + 1))[1];
            } else {
                int[] best = null;
                int bestDistance = Integer.MAX_VALUE;
                for (int[] run : list) {
                    int distance = run[0] <= this.centerCol && run[1] >= this.centerCol ? 0 : Math.min(Math.abs(run[0] - this.centerCol), Math.abs(run[1] - this.centerCol));
                    if (distance >= bestDistance) continue;
                    bestDistance = distance;
                    best = run;
                }
                coreLeft = best[0];
                coreRight = best[1];
            }
            core[0][r2] = coreLeft;
            core[1][r2] = coreRight;
            float y = ((float)r2 + 0.5f) * 0.00625f;
            if (y < 0.12f || y > 0.92f) continue;
            for (int[] run : list) {
                if (run[1] < coreLeft && (inner[0][r2] < 0 || run[0] < outer[0][r2])) {
                    inner[0][r2] = run[1];
                    outer[0][r2] = run[0];
                }
                if (run[0] <= coreRight || inner[1][r2] >= 0 && run[1] <= outer[1][r2]) continue;
                inner[1][r2] = run[0];
                outer[1][r2] = run[1];
            }
        }
        float minArmTop = this.legs ? crotchY + 0.1f : 0.35f;
        for (int s = 0; s < 2; ++s) {
            int sign = s == 0 ? -1 : 1;
            int bestTop = -1;
            int bestBottom = -1;
            int r3 = 159;
            while (r3 >= 0) {
                if (inner[s][r3] < 0) {
                    --r3;
                    continue;
                }
                int top = r3;
                int low = r3;
                int gap = 0;
                while (r3 >= 0) {
                    if (inner[s][r3] >= 0) {
                        low = r3;
                        gap = 0;
                    } else if (++gap > 2) break;
                    --r3;
                }
                if (!((float)(top + 1) * 0.00625f >= minArmTop) || low <= SkinRig.row(0.13f) + 1 || top - low <= bestTop - bestBottom) continue;
                bestTop = top;
                bestBottom = low;
            }
            if (bestTop >= 0 && (float)(bestTop - bestBottom) >= 9.599999f) {
                this.separatedArm(s, sign, bestTop, bestBottom, inner, outer, core);
                continue;
            }
            this.horizontalArm(s, sign, cx, crotchY, rows, core);
        }
        if (this.legs) {
            this.legs(cx, crotchRow, crotchY, rows);
        }
        float hipY = this.legs ? crotchY + 0.02f : 0.45f;
        this.hip[0] = cx;
        this.hip[1] = hipY;
        this.hip[2] = this.meanZ(hipY - 0.05f, hipY + 0.05f, -1);
        float shoulderY = 0.7f;
        if (this.arms[0] || this.arms[1]) {
            shoulderY = Math.max(this.arms[0] ? this.armPivot[0][1] : 0.0f, this.arms[1] ? this.armPivot[1][1] : 0.0f);
        }
        this.head(cx, shoulderY, core);
        for (i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            v = 0;
            int k = 0;
            while (v < p.length) {
                if (this.bones[i][k] != 4 && this.bones[i][k] != 5) {
                    this.upper[i][k] = SkinRig.smooth((p[v + 1] - (hipY - 0.03f)) / 0.08f);
                }
                v += 3;
                ++k;
            }
        }
        if (relax) {
            for (int s = 0; s < 2; ++s) {
                if (!this.arms[s]) continue;
                this.armRest[s] = this.rest(s);
            }
        }
        this.wingY = this.arms[0] || this.arms[1] ? Math.max(this.arms[0] ? this.armPivot[0][1] : 0.0f, this.arms[1] ? this.armPivot[1][1] : 0.0f) : Math.max(0.5f, this.neck[1] - 0.04f);
        this.backZ = 0.0f;
        for (i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            v = 0;
            int k = 0;
            while (v < p.length) {
                if (!(p[v + 1] < this.wingY - 0.1f) && !(p[v + 1] > this.wingY + 0.05f) && this.bones[i][k] != 2 && this.bones[i][k] != 3) {
                    this.backZ = Math.min(this.backZ, p[v + 2]);
                }
                v += 3;
                ++k;
            }
        }
        this.grid = null;
    }

    private boolean gapAt(List<int[]> list) {
        return this.gapIndex(list) >= 0;
    }

    private int gapIndex(List<int[]> list) {
        int tolerance = Math.max(2, Math.round(6.3999996f));
        int best = -1;
        int bestDistance = Integer.MAX_VALUE;
        int i = 0;
        while (i + 1 < list.size()) {
            int distance;
            int start = list.get(i)[1] + 1;
            int end = list.get(i + 1)[0] - 1;
            int n = this.centerCol < start ? start - this.centerCol : (distance = this.centerCol > end ? this.centerCol - end : 0);
            if (distance <= tolerance && distance < bestDistance) {
                bestDistance = distance;
                best = i;
            }
            ++i;
        }
        return best;
    }

    private void separatedArm(int s, int sign, int top, int bottom, int[][] inner, int[][] outer, int[][] core) {
        float[] sep = new float[160];
        float last = Float.NaN;
        for (int r = bottom; r <= top; ++r) {
            if (inner[s][r] >= 0) {
                last = (this.colX(inner[s][r]) + this.colX(sign < 0 ? core[0][r] : core[1][r])) / 2.0f;
            }
            sep[r] = last;
        }
        float armWidth = 0.0f;
        float centerX = 0.0f;
        int samples = 0;
        for (int r = top; r >= Math.max(bottom, top - 4); --r) {
            if (inner[s][r] < 0) continue;
            armWidth += (float)(Math.abs(outer[s][r] - inner[s][r]) + 1) * 0.00625f;
            centerX += (this.colX(outer[s][r]) + this.colX(inner[s][r])) / 2.0f;
            ++samples;
        }
        if (samples == 0) {
            return;
        }
        armWidth /= (float)samples;
        centerX /= (float)samples;
        float armpitY = (float)(top + 1) * 0.00625f;
        float handY = (float)bottom * 0.00625f - 0.01f;
        int columnFrom = Math.min(inner[s][top], outer[s][top]);
        int columnTo = Math.max(inner[s][top], outer[s][top]);
        int topRow = top;
        int limit = Math.min(159, top + Math.round(armWidth * 2.5f / 0.00625f));
        int r = top + 1;
        while (r <= limit) {
            boolean any = false;
            for (int c = columnFrom; c <= columnTo && !any; ++c) {
                any = this.grid[r * this.width + c];
            }
            if (!any) break;
            topRow = r++;
        }
        float shoulderTop = (float)(topRow + 1) * 0.00625f;
        float pivotY = shoulderTop - armWidth * 0.5f;
        float sepTop = sep[top];
        byte bone = s == 0 ? (byte)2 : 3;
        for (int i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            int v = 0;
            int k = 0;
            while (v < p.length) {
                float x = p[v];
                float y = p[v + 1];
                float w = 0.0f;
                if (y >= handY && y <= armpitY) {
                    float line = sep[Math.max(bottom, Math.min(top, SkinRig.row(y)))];
                    if (!Float.isNaN(line) && (float)sign * (x - line) > 0.0f) {
                        w = 1.0f;
                    }
                } else if (y > armpitY && y < shoulderTop + 0.01f) {
                    float d = (float)sign * (x - sepTop);
                    float fade = y <= pivotY ? 1.0f : 1.0f - SkinRig.smooth((y - pivotY) / Math.max(0.005f, shoulderTop + 0.01f - pivotY));
                    w = SkinRig.smooth(d / Math.max(0.005f, armWidth * 0.35f)) * fade;
                }
                if (w > this.weights[i][k]) {
                    this.bones[i][k] = bone;
                    this.weights[i][k] = w;
                }
                v += 3;
                ++k;
            }
        }
        float sy = 0.0f;
        float sx = 0.0f;
        float syy = 0.0f;
        float sxy = 0.0f;
        int fit = 0;
        for (int r2 = Math.max(bottom, top - (top - bottom) / 2); r2 <= top; ++r2) {
            if (inner[s][r2] < 0) continue;
            float y = ((float)r2 + 0.5f) * 0.00625f;
            float x = (this.colX(outer[s][r2]) + this.colX(inner[s][r2])) / 2.0f;
            sy += y;
            sx += x;
            syy += y * y;
            sxy += x * y;
            ++fit;
        }
        float slope = 0.0f;
        float offset = centerX;
        if (fit >= 3) {
            float denominator = (float)fit * syy - sy * sy;
            if (Math.abs(denominator) > 1.0E-9f) {
                slope = Math.max(-3.0f, Math.min(3.0f, ((float)fit * sxy - sx * sy) / denominator));
                offset = (sx - slope * sy) / (float)fit;
            } else {
                offset = sx / (float)fit;
            }
        } else {
            offset = centerX - slope * armpitY;
        }
        float armZ = this.meanZ(armpitY - 0.06f, armpitY + 0.005f, bone);
        for (int i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            int v = 0;
            int k = 0;
            while (v < p.length) {
                float y = p[v + 1];
                if (!(y <= armpitY || y > shoulderTop + 0.01f || (float)sign * (p[v] - centerX) < -armWidth * 1.5f)) {
                    float fade;
                    float depth;
                    float distance = Math.abs(p[v] - (offset + slope * y));
                    float along = 1.0f - SkinRig.smooth((distance - armWidth * 0.5f) / Math.max(0.004f, armWidth * 0.5f));
                    float w = along * (depth = 1.0f - SkinRig.smooth((Math.abs(p[v + 2] - armZ) - armWidth * 0.6f) / Math.max(0.004f, armWidth * 0.6f))) * (fade = y <= pivotY ? 1.0f : 1.0f - SkinRig.smooth((y - pivotY) / Math.max(0.005f, shoulderTop + 0.01f - pivotY)));
                    if (w > this.weights[i][k] && (this.bones[i][k] == 0 || this.bones[i][k] == bone)) {
                        this.bones[i][k] = bone;
                        this.weights[i][k] = w;
                    }
                }
                v += 3;
                ++k;
            }
        }
        this.arms[s] = true;
        this.armPivot[s][0] = offset + slope * pivotY;
        this.armPivot[s][1] = pivotY;
        this.armPivot[s][2] = armZ;
    }

    private void horizontalArm(int s, int sign, float cx, float crotchY, List<List<int[]>> rows, int[][] core) {
        int from = SkinRig.row(crotchY + 0.05f);
        int to = SkinRig.row(crotchY + 0.2f);
        ArrayList<Float> halves = new ArrayList<Float>();
        for (int r = from; r <= to; ++r) {
            if (rows.get(r).isEmpty()) continue;
            halves.add(Float.valueOf((float)sign * (this.colX(s == 0 ? core[0][r] : core[1][r]) - cx)));
        }
        if (halves.isEmpty()) {
            return;
        }
        halves.sort(Float::compare);
        float torsoHalf = Math.max(0.03f, ((Float)halves.get(halves.size() / 2)).floatValue());
        int wideLow = -1;
        int wideHigh = -1;
        float reach = 0.0f;
        for (int r = to + 1; r < SkinRig.row(0.95f); ++r) {
            if (rows.get(r).isEmpty()) continue;
            float extent = (float)sign * (this.colX(s == 0 ? core[0][r] : core[1][r]) - cx);
            if (!(extent > torsoHalf * 1.7f)) continue;
            if (wideLow < 0) {
                wideLow = r;
            }
            wideHigh = r;
            reach = Math.max(reach, extent);
        }
        if (wideLow < 0 || wideHigh - wideLow < 1 || reach < torsoHalf * 2.2f) {
            return;
        }
        float shoulderX = cx + (float)sign * torsoHalf * 1.1f;
        float low = (float)wideLow * 0.00625f - 0.06f;
        float high = (float)(wideHigh + 1) * 0.00625f + 0.06f;
        int bone = s == 0 ? 2 : 3;
        for (int i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            int v = 0;
            int k = 0;
            while (v < p.length) {
                float w;
                float y = p[v + 1];
                if (!(y < low) && !(y > high) && (w = SkinRig.smooth((float)sign * (p[v] - shoulderX) / 0.04f)) > this.weights[i][k]) {
                    this.bones[i][k] = (byte)bone;
                    this.weights[i][k] = w;
                }
                v += 3;
                ++k;
            }
        }
        this.arms[s] = true;
        this.armPivot[s][0] = shoulderX;
        this.armPivot[s][1] = (float)(wideLow + wideHigh + 1) * 0.5f * 0.00625f;
        this.armPivot[s][2] = this.meanZ(low, high, bone);
    }

    private void legs(float cx, int crotchRow, float crotchY, List<List<int[]>> rows) {
        int sampleRow = Math.max(0, crotchRow - 3);
        float[] half = new float[]{0.04f, 0.04f};
        for (int[] run : rows.get(sampleRow)) {
            if (run[1] < this.centerCol) {
                half[0] = Math.max(half[0], (float)(run[1] - run[0] + 1) * 0.00625f / 2.0f);
            }
            if (run[0] <= this.centerCol) continue;
            half[1] = Math.max(half[1], (float)(run[1] - run[0] + 1) * 0.00625f / 2.0f);
        }
        float[] sumX = new float[2];
        float[] sumZ = new float[2];
        int[] count = new int[2];
        for (float[] p : this.positions) {
            for (int v = 0; v < p.length; v += 3) {
                int s;
                float y = p[v + 1];
                if (y < crotchY - 0.1f || y > crotchY) continue;
                int n = s = p[v] < cx ? 0 : 1;
                sumX[n] = sumX[n] + p[v];
                int n2 = s;
                sumZ[n2] = sumZ[n2] + p[v + 2];
                int n3 = s;
                count[n3] = count[n3] + 1;
            }
        }
        for (int s = 0; s < 2; ++s) {
            int sign = s == 0 ? -1 : 1;
            this.legPivot[s][0] = count[s] > 0 ? sumX[s] / (float)count[s] : cx + (float)sign * half[s];
            this.legPivot[s][1] = crotchY + 0.02f;
            this.legPivot[s][2] = count[s] > 0 ? sumZ[s] / (float)count[s] : 0.0f;
        }
        float band = 0.06f;
        for (int i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            int v = 0;
            int k = 0;
            while (v < p.length) {
                if (!(this.weights[i][k] > 0.5f)) {
                    float x = p[v];
                    float y = p[v + 1];
                    if (!(y > crotchY + band)) {
                        int s;
                        int n = s = x < cx ? 0 : 1;
                        if (!(Math.abs(x - this.legPivot[s][0]) > half[s] * 2.4f + 0.02f)) {
                            float w;
                            float f = w = y <= crotchY ? 1.0f : 1.0f - SkinRig.smooth((y - crotchY) / band);
                            if (y > crotchY - 0.02f) {
                                w *= Math.min(1.0f, Math.abs(x - cx) / Math.max(0.01f, half[s]));
                            }
                            if (!(w <= 0.0f)) {
                                this.bones[i][k] = (byte)(s == 0 ? 4 : 5);
                                this.weights[i][k] = w;
                            }
                        }
                    }
                }
                v += 3;
                ++k;
            }
        }
    }

    private void head(float cx, float shoulderY, int[][] core) {
        float neckY;
        int from = SkinRig.row(shoulderY);
        int to = SkinRig.row(0.94f);
        int shoulderWidth = 0;
        for (int r = Math.max(0, from - 8); r <= from; ++r) {
            shoulderWidth = Math.max(shoulderWidth, core[1][r] - core[0][r]);
        }
        int narrow = -1;
        int narrowWidth = Integer.MAX_VALUE;
        for (int r = from; r <= to; ++r) {
            int w = core[1][r] - core[0][r];
            if (w <= 0 || w >= narrowWidth) continue;
            narrowWidth = w;
            narrow = r;
        }
        float band = 0.05f;
        if (!Float.isNaN(this.mesh.neckHint)) {
            neckY = this.mesh.neckHint;
            this.headStrength = Float.isNaN(this.mesh.headHint) ? 1.0f : this.mesh.headHint;
            band = 0.14f;
        } else if (narrow >= 0 && shoulderWidth > 0 && (float)narrowWidth < (float)shoulderWidth * 0.8f && narrow < to - 2) {
            neckY = (float)narrow * 0.00625f;
            this.headStrength = 1.0f;
        } else {
            neckY = 0.78f;
            this.headStrength = 0.5f;
        }
        this.neck[0] = cx;
        this.neck[1] = neckY;
        this.neck[2] = this.meanZ(neckY - 0.03f, neckY + 0.03f, -1);
        for (int i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            int v = 0;
            int k = 0;
            while (v < p.length) {
                block11: {
                    float w;
                    block12: {
                        w = SkinRig.smooth((p[v + 1] - (neckY - 0.02f)) / band);
                        if (w <= 0.0f) break block11;
                        if (this.bones[i][k] == 0) break block12;
                        if (this.weights[i][k] >= 0.5f) break block11;
                        w *= 1.0f - this.weights[i][k];
                    }
                    this.bones[i][k] = 1;
                    this.weights[i][k] = w;
                }
                v += 3;
                ++k;
            }
        }
    }

    private float meanZ(float low, float high, int bone) {
        float sum = 0.0f;
        int count = 0;
        for (int i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            int v = 0;
            int k = 0;
            while (v < p.length) {
                float y = p[v + 1];
                if (!(y < low || y > high || bone >= 0 && (this.bones[i][k] != bone || this.weights[i][k] < 0.8f))) {
                    sum += p[v + 2];
                    ++count;
                }
                v += 3;
                ++k;
            }
        }
        return count > 0 ? sum / (float)count : 0.0f;
    }

    private float rest(int s) {
        double angle;
        byte bone = s == 0 ? (byte)2 : 3;
        float[] pivot = this.armPivot[s];
        ArrayList<float[]> points = new ArrayList<float[]>();
        for (int i = 0; i < this.positions.length; ++i) {
            float[] p = this.positions[i];
            int v = 0;
            int k = 0;
            while (v < p.length) {
                if (this.bones[i][k] == bone && !(this.weights[i][k] < 0.9f)) {
                    float dx = p[v] - pivot[0];
                    float dy = p[v + 1] - pivot[1];
                    points.add(new float[]{dx, dy, dx * dx + dy * dy});
                }
                v += 3;
                ++k;
            }
        }
        if (points.size() < 3) {
            return 0.0f;
        }
        points.sort((a, b) -> Float.compare(b[2], a[2]));
        int take = Math.min(points.size(), Math.max(3, points.size() / 7));
        float dx = 0.0f;
        float dy = 0.0f;
        for (int i = 0; i < take; ++i) {
            dx += ((float[])points.get(i))[0];
            dy += ((float[])points.get(i))[1];
        }
        int sign = s == 0 ? -1 : 1;
        double outward = Math.atan2((float)sign * dx, -dy);
        if (outward < 0.45) {
            return 0.0f;
        }
        double target = 0.17;
        double tx = (double)sign * Math.sin(target);
        double ty = -Math.cos(target);
        for (angle = Math.atan2(ty, tx) - Math.atan2(dy, dx); angle > Math.PI; angle -= Math.PI * 2) {
        }
        while (angle < -Math.PI) {
            angle += Math.PI * 2;
        }
        return (float)angle;
    }
}

