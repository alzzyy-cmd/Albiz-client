/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  net.minecraft.class_1011
 *  org.joml.Matrix3f
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionf
 *  org.joml.Quaternionfc
 *  org.joml.Vector3f
 */
package dev.sober.skin;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.sober.skin.SkinMesh;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_1011;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;

public final class SkinLoader {
    private static final int MAX_TEXTURE = 2048;

    private SkinLoader() {
    }

    public static SkinMesh load(Path file, int budget) throws IOException {
        List<Raw> raw;
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        float[] hints = new float[]{Float.NaN, Float.NaN};
        if (name.endsWith(".glb")) {
            raw = SkinLoader.glb(Files.readAllBytes(file), file.getParent(), hints);
        } else if (name.endsWith(".gltf")) {
            raw = SkinLoader.gltf(JsonParser.parseString((String)Files.readString(file)).getAsJsonObject(), null, file.getParent(), hints);
        } else if (name.endsWith(".obj")) {
            raw = SkinLoader.obj(file);
        } else if (name.endsWith(".stl")) {
            raw = SkinLoader.stl(Files.readAllBytes(file));
        } else {
            throw new IOException("Unsupported format");
        }
        return SkinLoader.finish(raw, budget, hints);
    }

    public static SkinMesh loadGlb(byte[] bytes, int budget) throws IOException {
        float[] hints = new float[]{Float.NaN, Float.NaN};
        return SkinLoader.finish(SkinLoader.glb(bytes, null, hints), budget, hints);
    }

    private static SkinMesh finish(List<Raw> raw, int budget, float[] hints) throws IOException {
        if (raw.isEmpty()) {
            throw new IOException("The model has no triangles");
        }
        for (Raw raw2 : raw) {
            if (raw2.normals != null) continue;
            SkinLoader.smoothNormals(raw2);
        }
        raw = SkinLoader.decimate(raw, Math.max(1000, budget));
        SkinLoader.normalize(raw);
        ArrayList<SkinMesh.Part> parts = new ArrayList<SkinMesh.Part>();
        for (Raw part : raw) {
            if (part.triangles.length == 0) {
                if (part.image == null) continue;
                part.image.close();
                continue;
            }
            parts.add(new SkinMesh.Part(part.positions, part.uvs, part.normals, part.colors, part.triangles, part.image));
        }
        SkinMesh skinMesh = new SkinMesh(parts);
        skinMesh.neckHint = hints[0];
        skinMesh.headHint = hints[1];
        return skinMesh;
    }

    private static List<Raw> glb(byte[] bytes, Path folder, float[] hints) throws IOException {
        ByteBuffer b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        if (bytes.length < 20 || b.getInt(0) != 1179937895) {
            throw new IOException("Not a GLB file");
        }
        int length = Math.min(b.getInt(8), bytes.length);
        int offset = 12;
        JsonObject json = null;
        ByteBuffer bin = null;
        while (offset + 8 <= length) {
            int chunk = b.getInt(offset);
            int type = b.getInt(offset + 4);
            int start = offset + 8;
            if (start + chunk > bytes.length) break;
            if (type == 1313821514) {
                json = JsonParser.parseString((String)new String(bytes, start, chunk, StandardCharsets.UTF_8)).getAsJsonObject();
            } else if (type == 5130562) {
                bin = ByteBuffer.wrap(bytes, start, chunk).slice().order(ByteOrder.LITTLE_ENDIAN);
            }
            offset = start + chunk;
        }
        if (json == null) {
            throw new IOException("GLB without JSON");
        }
        return SkinLoader.gltf(json, bin, folder, hints);
    }

    private static void hints(JsonObject json, float[] hints) {
        try {
            JsonObject data = json.getAsJsonObject("asset").getAsJsonObject("extras").getAsJsonObject("sober");
            if (data.has("neck")) {
                hints[0] = data.get("neck").getAsFloat();
            }
            if (data.has("headStrength")) {
                hints[1] = data.get("headStrength").getAsFloat();
            }
        }
        catch (RuntimeException runtimeException) {
            // empty catch block
        }
    }

    private static List<ByteBuffer> buffers(JsonObject json, ByteBuffer bin, Path folder) throws IOException {
        ArrayList<ByteBuffer> list = new ArrayList<ByteBuffer>();
        JsonArray array = json.has("buffers") ? json.getAsJsonArray("buffers") : new JsonArray();
        for (int i = 0; i < array.size(); ++i) {
            JsonObject buffer = array.get(i).getAsJsonObject();
            if (!buffer.has("uri")) {
                list.add(bin != null ? bin : ByteBuffer.allocate(0));
                continue;
            }
            list.add(ByteBuffer.wrap(SkinLoader.uri(buffer.get("uri").getAsString(), folder)).order(ByteOrder.LITTLE_ENDIAN));
        }
        return list;
    }

    private static byte[] uri(String uri, Path folder) throws IOException {
        if (uri.startsWith("data:")) {
            return Base64.getDecoder().decode(uri.substring(uri.indexOf(44) + 1));
        }
        if (folder == null) {
            throw new IOException("External file without folder: " + uri);
        }
        return Files.readAllBytes(folder.resolve(URLDecoder.decode(uri, StandardCharsets.UTF_8)));
    }

    private static int componentSize(int type) {
        return switch (type) {
            case 5120, 5121 -> 1;
            case 5122, 5123 -> 2;
            default -> 4;
        };
    }

    private static int components(String type) {
        return switch (type) {
            case "SCALAR" -> 1;
            case "VEC2" -> 2;
            case "VEC3" -> 3;
            case "VEC4" -> 4;
            case "MAT4" -> 16;
            default -> 1;
        };
    }

    private static float[] floats(JsonObject json, List<ByteBuffer> buffers, int index) {
        JsonObject accessor = json.getAsJsonArray("accessors").get(index).getAsJsonObject();
        int count = accessor.get("count").getAsInt();
        int comps = SkinLoader.components(accessor.get("type").getAsString());
        float[] out = new float[count * comps];
        if (!accessor.has("bufferView")) {
            return out;
        }
        int type = accessor.get("componentType").getAsInt();
        boolean normalized = accessor.has("normalized") && accessor.get("normalized").getAsBoolean();
        JsonObject view = json.getAsJsonArray("bufferViews").get(accessor.get("bufferView").getAsInt()).getAsJsonObject();
        ByteBuffer buf = buffers.get(view.get("buffer").getAsInt());
        int size = SkinLoader.componentSize(type);
        int base = (view.has("byteOffset") ? view.get("byteOffset").getAsInt() : 0) + (accessor.has("byteOffset") ? accessor.get("byteOffset").getAsInt() : 0);
        int stride = view.has("byteStride") ? view.get("byteStride").getAsInt() : size * comps;
        for (int e = 0; e < count; ++e) {
            for (int c = 0; c < comps; ++c) {
                float value;
                int p = base + e * stride + c * size;
                out[e * comps + c] = value = (switch (type) {
                    case 5126 -> buf.getFloat(p);
                    case 5121 -> {
                        if (normalized) {
                            yield (float)(buf.get(p) & 0xFF) / 255.0f;
                        }
                        yield buf.get(p) & 0xFF;
                    }
                    case 5123 -> {
                        if (normalized) {
                            yield (float)(buf.getShort(p) & 0xFFFF) / 65535.0f;
                        }
                        yield buf.getShort(p) & 0xFFFF;
                    }
                    case 5120 -> {
                        if (normalized) {
                            yield Math.max((float)buf.get(p) / 127.0f, -1.0f);
                        }
                        yield buf.get(p);
                    }
                    case 5122 -> {
                        if (normalized) {
                            yield Math.max((float)buf.getShort(p) / 32767.0f, -1.0f);
                        }
                        yield buf.getShort(p);
                    }
                    default -> (long)buf.getInt(p) & 0xFFFFFFFFL;
                });
            }
        }
        return out;
    }

    private static int[] ints(JsonObject json, List<ByteBuffer> buffers, int index) {
        JsonObject accessor = json.getAsJsonArray("accessors").get(index).getAsJsonObject();
        int count = accessor.get("count").getAsInt();
        int[] out = new int[count];
        if (!accessor.has("bufferView")) {
            return out;
        }
        int type = accessor.get("componentType").getAsInt();
        JsonObject view = json.getAsJsonArray("bufferViews").get(accessor.get("bufferView").getAsInt()).getAsJsonObject();
        ByteBuffer buf = buffers.get(view.get("buffer").getAsInt());
        int size = SkinLoader.componentSize(type);
        int base = (view.has("byteOffset") ? view.get("byteOffset").getAsInt() : 0) + (accessor.has("byteOffset") ? accessor.get("byteOffset").getAsInt() : 0);
        int stride = view.has("byteStride") ? view.get("byteStride").getAsInt() : size;
        for (int e = 0; e < count; ++e) {
            int p = base + e * stride;
            out[e] = switch (type) {
                case 5121 -> buf.get(p) & 0xFF;
                case 5123 -> buf.getShort(p) & 0xFFFF;
                default -> buf.getInt(p);
            };
        }
        return out;
    }

    private static Matrix4f local(JsonObject node) {
        Matrix4f m = new Matrix4f();
        if (node.has("matrix")) {
            JsonArray a = node.getAsJsonArray("matrix");
            float[] values = new float[16];
            for (int i = 0; i < 16; ++i) {
                values[i] = a.get(i).getAsFloat();
            }
            m.set(values);
            return m;
        }
        if (node.has("translation")) {
            JsonArray t = node.getAsJsonArray("translation");
            m.translate(t.get(0).getAsFloat(), t.get(1).getAsFloat(), t.get(2).getAsFloat());
        }
        if (node.has("rotation")) {
            JsonArray r = node.getAsJsonArray("rotation");
            m.rotate((Quaternionfc)new Quaternionf(r.get(0).getAsFloat(), r.get(1).getAsFloat(), r.get(2).getAsFloat(), r.get(3).getAsFloat()));
        }
        if (node.has("scale")) {
            JsonArray s = node.getAsJsonArray("scale");
            m.scale(s.get(0).getAsFloat(), s.get(1).getAsFloat(), s.get(2).getAsFloat());
        }
        return m;
    }

    private static List<Raw> gltf(JsonObject json, ByteBuffer bin, Path folder, float[] hints) throws IOException {
        SkinLoader.hints(json, hints);
        List<ByteBuffer> buffers = SkinLoader.buffers(json, bin, folder);
        LinkedHashMap<Integer, Builder> builders = new LinkedHashMap<Integer, Builder>();
        HashMap<Integer, class_1011> images = new HashMap<Integer, class_1011>();
        JsonArray nodes = json.has("nodes") ? json.getAsJsonArray("nodes") : new JsonArray();
        ArrayList<Integer> roots = new ArrayList<Integer>();
        if (json.has("scenes") && json.getAsJsonArray("scenes").size() > 0) {
            int scene = json.has("scene") ? json.get("scene").getAsInt() : 0;
            Iterator sceneObject = json.getAsJsonArray("scenes").get(scene).getAsJsonObject();
            if (sceneObject.has("nodes")) {
                for (JsonElement e : sceneObject.getAsJsonArray("nodes")) {
                    roots.add(e.getAsInt());
                }
            }
        }
        if (roots.isEmpty()) {
            boolean[] child = new boolean[nodes.size()];
            for (JsonElement e : nodes) {
                JsonObject node = e.getAsJsonObject();
                if (!node.has("children")) continue;
                for (JsonElement c : node.getAsJsonArray("children")) {
                    child[c.getAsInt()] = true;
                }
            }
            for (int i = 0; i < nodes.size(); ++i) {
                if (child[i]) continue;
                roots.add(i);
            }
        }
        if (nodes.isEmpty() && json.has("meshes")) {
            for (int m = 0; m < json.getAsJsonArray("meshes").size(); ++m) {
                SkinLoader.mesh(json, buffers, folder, m, new Matrix4f(), null, builders, images);
            }
        }
        Matrix4f[] worlds = new Matrix4f[nodes.size()];
        Iterator i = roots.iterator();
        while (i.hasNext()) {
            int root = (Integer)i.next();
            SkinLoader.worldOf(nodes, root, new Matrix4f(), worlds, 0);
        }
        for (int i2 = 0; i2 < nodes.size(); ++i2) {
            JsonObject node;
            if (worlds[i2] == null || !(node = nodes.get(i2).getAsJsonObject()).has("mesh")) continue;
            Matrix4f[] joints = node.has("skin") ? SkinLoader.joints(json, buffers, node.get("skin").getAsInt(), worlds) : null;
            SkinLoader.mesh(json, buffers, folder, node.get("mesh").getAsInt(), worlds[i2], joints, builders, images);
        }
        ArrayList<Raw> result = new ArrayList<Raw>();
        for (Builder builder : builders.values()) {
            result.add(SkinLoader.toRaw(builder));
        }
        return result;
    }

    private static void worldOf(JsonArray nodes, int index, Matrix4f parent, Matrix4f[] worlds, int depth) {
        Matrix4f world;
        if (depth > 128 || index < 0 || index >= nodes.size() || worlds[index] != null) {
            return;
        }
        JsonObject node = nodes.get(index).getAsJsonObject();
        worlds[index] = world = new Matrix4f((Matrix4fc)parent).mul((Matrix4fc)SkinLoader.local(node));
        if (node.has("children")) {
            for (JsonElement child : node.getAsJsonArray("children")) {
                SkinLoader.worldOf(nodes, child.getAsInt(), world, worlds, depth + 1);
            }
        }
    }

    private static Matrix4f[] joints(JsonObject json, List<ByteBuffer> buffers, int skinIndex, Matrix4f[] worlds) {
        if (!json.has("skins") || skinIndex < 0 || skinIndex >= json.getAsJsonArray("skins").size()) {
            return null;
        }
        JsonObject skin = json.getAsJsonArray("skins").get(skinIndex).getAsJsonObject();
        if (!skin.has("joints")) {
            return null;
        }
        JsonArray list = skin.getAsJsonArray("joints");
        float[] inverse = skin.has("inverseBindMatrices") ? SkinLoader.floats(json, buffers, skin.get("inverseBindMatrices").getAsInt()) : null;
        Matrix4f[] result = new Matrix4f[list.size()];
        for (int k = 0; k < list.size(); ++k) {
            int joint = list.get(k).getAsInt();
            Matrix4f world = joint >= 0 && joint < worlds.length && worlds[joint] != null ? worlds[joint] : new Matrix4f();
            Matrix4f bind = new Matrix4f();
            if (inverse != null && inverse.length >= (k + 1) * 16) {
                float[] values = new float[16];
                System.arraycopy(inverse, k * 16, values, 0, 16);
                bind.set(values);
            }
            result[k] = new Matrix4f((Matrix4fc)world).mul((Matrix4fc)bind);
        }
        return result;
    }

    private static JsonObject specGloss(JsonObject material) {
        if (material == null || !material.has("extensions")) {
            return null;
        }
        JsonObject extensions = material.getAsJsonObject("extensions");
        return extensions.has("KHR_materials_pbrSpecularGlossiness") ? extensions.getAsJsonObject("KHR_materials_pbrSpecularGlossiness") : null;
    }

    private static int imageOf(JsonObject json, JsonObject material) {
        if (material == null) {
            return -1;
        }
        JsonObject textureRef = null;
        if (material.has("pbrMetallicRoughness") && material.getAsJsonObject("pbrMetallicRoughness").has("baseColorTexture")) {
            textureRef = material.getAsJsonObject("pbrMetallicRoughness").getAsJsonObject("baseColorTexture");
        } else {
            JsonObject gloss = SkinLoader.specGloss(material);
            if (gloss != null && gloss.has("diffuseTexture")) {
                textureRef = gloss.getAsJsonObject("diffuseTexture");
            }
        }
        if (textureRef == null || !textureRef.has("index")) {
            return -1;
        }
        int texture = textureRef.get("index").getAsInt();
        if (!json.has("textures")) {
            return -1;
        }
        JsonObject tex = json.getAsJsonArray("textures").get(texture).getAsJsonObject();
        if (tex.has("source")) {
            return tex.get("source").getAsInt();
        }
        if (tex.has("extensions")) {
            for (Map.Entry ext : tex.getAsJsonObject("extensions").entrySet()) {
                JsonObject value = ((JsonElement)ext.getValue()).getAsJsonObject();
                if (!value.has("source")) continue;
                return value.get("source").getAsInt();
            }
        }
        return -1;
    }

    private static class_1011 image(JsonObject json, List<ByteBuffer> buffers, Path folder, int index) throws IOException {
        byte[] data;
        JsonObject image = json.getAsJsonArray("images").get(index).getAsJsonObject();
        if (image.has("bufferView")) {
            JsonObject view = json.getAsJsonArray("bufferViews").get(image.get("bufferView").getAsInt()).getAsJsonObject();
            ByteBuffer buf = buffers.get(view.get("buffer").getAsInt());
            int offset = view.has("byteOffset") ? view.get("byteOffset").getAsInt() : 0;
            data = new byte[view.get("byteLength").getAsInt()];
            for (int i = 0; i < data.length; ++i) {
                data[i] = buf.get(offset + i);
            }
        } else if (image.has("uri")) {
            data = SkinLoader.uri(image.get("uri").getAsString(), folder);
        } else {
            return null;
        }
        return SkinLoader.decode(data);
    }

    private static void mesh(JsonObject json, List<ByteBuffer> buffers, Path folder, int meshIndex, Matrix4f world, Matrix4f[] joints, Map<Integer, Builder> builders, Map<Integer, class_1011> images) throws IOException {
        JsonObject mesh = json.getAsJsonArray("meshes").get(meshIndex).getAsJsonObject();
        Matrix3f normalMatrix = new Matrix3f((Matrix4fc)world).invert().transpose();
        for (JsonElement element : mesh.getAsJsonArray("primitives")) {
            boolean flip;
            int[] indices;
            JsonObject attributes;
            int mode;
            JsonObject primitive = element.getAsJsonObject();
            if (primitive.has("extensions") && (primitive.getAsJsonObject("extensions").has("KHR_draco_mesh_compression") || primitive.getAsJsonObject("extensions").has("EXT_meshopt_compression"))) {
                throw new IOException("Compressed GLB (Draco) is not supported. Export it without compression.");
            }
            int n = mode = primitive.has("mode") ? primitive.get("mode").getAsInt() : 4;
            if (mode != 4 && mode != 5 && mode != 6 || !(attributes = primitive.getAsJsonObject("attributes")).has("POSITION")) continue;
            float[] pos = SkinLoader.floats(json, buffers, attributes.get("POSITION").getAsInt());
            int count = pos.length / 3;
            float[] nrm = attributes.has("NORMAL") ? SkinLoader.floats(json, buffers, attributes.get("NORMAL").getAsInt()) : null;
            float[] uv = attributes.has("TEXCOORD_0") ? SkinLoader.floats(json, buffers, attributes.get("TEXCOORD_0").getAsInt()) : null;
            float[] col = null;
            int colComps = 0;
            if (attributes.has("COLOR_0")) {
                int accessor = attributes.get("COLOR_0").getAsInt();
                colComps = SkinLoader.components(json.getAsJsonArray("accessors").get(accessor).getAsJsonObject().get("type").getAsString());
                col = SkinLoader.floats(json, buffers, accessor);
            }
            JsonObject material = primitive.has("material") && json.has("materials") ? json.getAsJsonArray("materials").get(primitive.get("material").getAsInt()).getAsJsonObject() : null;
            float[] factor = new float[]{1.0f, 1.0f, 1.0f, 1.0f};
            JsonArray factorArray = null;
            if (material != null && material.has("pbrMetallicRoughness") && material.getAsJsonObject("pbrMetallicRoughness").has("baseColorFactor")) {
                factorArray = material.getAsJsonObject("pbrMetallicRoughness").getAsJsonArray("baseColorFactor");
            } else if (SkinLoader.specGloss(material) != null && SkinLoader.specGloss(material).has("diffuseFactor")) {
                factorArray = SkinLoader.specGloss(material).getAsJsonArray("diffuseFactor");
            }
            if (factorArray != null) {
                for (int i = 0; i < 4 && i < factorArray.size(); ++i) {
                    factor[i] = factorArray.get(i).getAsFloat();
                }
            }
            float[] jointIndex = null;
            float[] jointWeight = null;
            if (joints != null && attributes.has("JOINTS_0") && attributes.has("WEIGHTS_0")) {
                jointIndex = SkinLoader.floats(json, buffers, attributes.get("JOINTS_0").getAsInt());
                jointWeight = SkinLoader.floats(json, buffers, attributes.get("WEIGHTS_0").getAsInt());
                if (jointIndex.length < count * 4 || jointWeight.length < count * 4) {
                    jointWeight = null;
                    jointIndex = null;
                }
            }
            Matrix4f skinned = new Matrix4f();
            Matrix3f skinnedNormal = new Matrix3f();
            int imageIndex = uv != null ? SkinLoader.imageOf(json, material) : -1;
            Builder builder = builders.get(imageIndex);
            if (builder == null) {
                builder = new Builder();
                if (imageIndex >= 0) {
                    class_1011 img = images.get(imageIndex);
                    if (img == null && !images.containsKey(imageIndex)) {
                        img = SkinLoader.image(json, buffers, folder, imageIndex);
                        images.put(imageIndex, img);
                    }
                    builder.image = img;
                }
                builders.put(imageIndex, builder);
            }
            int first = builder.vertices();
            Vector3f p = new Vector3f();
            Vector3f n2 = new Vector3f();
            for (int v2 = 0; v2 < count; ++v2) {
                Matrix4f transform = world;
                Matrix3f normalTransform = normalMatrix;
                if (jointIndex != null) {
                    skinned.zero();
                    float total = 0.0f;
                    for (int k = 0; k < 4; ++k) {
                        float w = jointWeight[v2 * 4 + k];
                        int j = (int)jointIndex[v2 * 4 + k];
                        if (w <= 0.0f || j < 0 || j >= joints.length) continue;
                        Matrix4f m = joints[j];
                        skinned.m00(skinned.m00() + m.m00() * w).m01(skinned.m01() + m.m01() * w).m02(skinned.m02() + m.m02() * w).m03(skinned.m03() + m.m03() * w);
                        skinned.m10(skinned.m10() + m.m10() * w).m11(skinned.m11() + m.m11() * w).m12(skinned.m12() + m.m12() * w).m13(skinned.m13() + m.m13() * w);
                        skinned.m20(skinned.m20() + m.m20() * w).m21(skinned.m21() + m.m21() * w).m22(skinned.m22() + m.m22() * w).m23(skinned.m23() + m.m23() * w);
                        skinned.m30(skinned.m30() + m.m30() * w).m31(skinned.m31() + m.m31() * w).m32(skinned.m32() + m.m32() * w).m33(skinned.m33() + m.m33() * w);
                        total += w;
                    }
                    if (total > 1.0E-6f) {
                        transform = skinned;
                        normalTransform = skinnedNormal.set((Matrix4fc)skinned);
                    }
                }
                transform.transformPosition(pos[v2 * 3], pos[v2 * 3 + 1], pos[v2 * 3 + 2], p);
                if (nrm != null) {
                    normalTransform.transform(nrm[v2 * 3], nrm[v2 * 3 + 1], nrm[v2 * 3 + 2], n2);
                    if (n2.lengthSquared() > 1.0E-12f) {
                        n2.normalize();
                    }
                } else {
                    n2.set(0.0f, 1.0f, 0.0f);
                }
                float r = factor[0];
                float g = factor[1];
                float bl = factor[2];
                float a = factor[3];
                if (col != null) {
                    r *= col[v2 * colComps];
                    g *= col[v2 * colComps + 1];
                    bl *= col[v2 * colComps + 2];
                    if (colComps > 3) {
                        a *= col[v2 * colComps + 3];
                    }
                }
                int color = SkinLoader.clamp(a) << 24 | SkinLoader.clamp(r) << 16 | SkinLoader.clamp(g) << 8 | SkinLoader.clamp(bl);
                builder.vertex(p.x, p.y, p.z, uv != null ? uv[v2 * 2] : 0.0f, uv != null ? uv[v2 * 2 + 1] : 0.0f, n2.x, n2.y, n2.z, color);
            }
            if (primitive.has("indices")) {
                indices = SkinLoader.ints(json, buffers, primitive.get("indices").getAsInt());
            } else {
                indices = new int[count];
                for (int i = 0; i < count; ++i) {
                    indices[i] = i;
                }
            }
            boolean bl = flip = world.determinant() < 0.0f;
            if (mode == 4) {
                i = 0;
                while (i + 2 < indices.length) {
                    SkinLoader.triangle(builder, first, indices[i], indices[i + 1], indices[i + 2], flip, count);
                    i += 3;
                }
            } else if (mode == 5) {
                i = 0;
                while (i + 2 < indices.length) {
                    if ((i & 1) == 0) {
                        SkinLoader.triangle(builder, first, indices[i], indices[i + 1], indices[i + 2], flip, count);
                    } else {
                        SkinLoader.triangle(builder, first, indices[i + 1], indices[i], indices[i + 2], flip, count);
                    }
                    ++i;
                }
            } else {
                i = 1;
                while (i + 1 < indices.length) {
                    SkinLoader.triangle(builder, first, indices[0], indices[i], indices[i + 1], flip, count);
                    ++i;
                }
            }
            if (nrm != null) continue;
            builder.normals.replaceAll(v -> Float.valueOf(Float.NaN));
        }
    }

    private static void triangle(Builder builder, int first, int a, int b, int c, boolean flip, int count) {
        if (a < 0 || b < 0 || c < 0 || a >= count || b >= count || c >= count) {
            return;
        }
        builder.triangles.add(first + a);
        builder.triangles.add(first + (flip ? c : b));
        builder.triangles.add(first + (flip ? b : c));
    }

    private static int clamp(float v) {
        return Math.max(0, Math.min(255, Math.round(v * 255.0f)));
    }

    private static Raw toRaw(Builder builder) {
        float[] positions = new float[builder.positions.size()];
        for (int i = 0; i < positions.length; ++i) {
            positions[i] = builder.positions.get(i).floatValue();
        }
        float[] uvs = new float[builder.uvs.size()];
        for (int i = 0; i < uvs.length; ++i) {
            uvs[i] = builder.uvs.get(i).floatValue();
        }
        boolean missing = false;
        float[] normals = new float[builder.normals.size()];
        for (int i = 0; i < normals.length; ++i) {
            normals[i] = builder.normals.get(i).floatValue();
            if (!Float.isNaN(normals[i])) continue;
            missing = true;
        }
        int[] colors = builder.colors.stream().mapToInt(Integer::intValue).toArray();
        int[] triangles = builder.triangles.stream().mapToInt(Integer::intValue).toArray();
        return new Raw(positions, uvs, missing ? null : normals, colors, triangles, builder.image);
    }

    public static class_1011 decode(byte[] data) throws IOException {
        return SkinLoader.decode(data, 2048);
    }

    /*
     * Exception decompiling
     */
    public static class_1011 decode(byte[] data, int maxSize) throws IOException {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.getStartingBlocks(Op04StructuredStatement.java:412)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op04StructuredStatement.buildNestedBlocks(Op04StructuredStatement.java:487)
         *     at org.benf.cfr.reader.bytecode.analysis.opgraph.Op03SimpleStatement.createInitialStructuredBlock(Op03SimpleStatement.java:736)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisInner(CodeAnalyser.java:850)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysisOrWrapFail(CodeAnalyser.java:278)
         *     at org.benf.cfr.reader.bytecode.CodeAnalyser.getAnalysis(CodeAnalyser.java:201)
         *     at org.benf.cfr.reader.entities.attributes.AttributeCode.analyse(AttributeCode.java:94)
         *     at org.benf.cfr.reader.entities.Method.analyse(Method.java:531)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseMid(ClassFile.java:1055)
         *     at org.benf.cfr.reader.entities.ClassFile.analyseTop(ClassFile.java:942)
         *     at org.benf.cfr.reader.Driver.doJarVersionTypes(Driver.java:257)
         *     at org.benf.cfr.reader.Driver.doJar(Driver.java:139)
         *     at org.benf.cfr.reader.CfrDriverImpl.analyse(CfrDriverImpl.java:76)
         *     at org.benf.cfr.reader.Main.main(Main.java:54)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    private static List<Raw> obj(Path file) throws IOException {
        ArrayList<float[]> v = new ArrayList<float[]>();
        ArrayList<float[]> vt = new ArrayList<float[]>();
        ArrayList<float[]> vn = new ArrayList<float[]>();
        HashMap<String, String[]> materials = new HashMap<String, String[]>();
        LinkedHashMap<String, Builder> builders = new LinkedHashMap<String, Builder>();
        HashMap<String, class_1011> textures = new HashMap<String, class_1011>();
        String current = "";
        block16: for (String line : Files.readAllLines(file)) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) continue;
            String[] parts = trimmed.split("\\s+");
            switch (parts[0]) {
                case "mtllib": {
                    Path mtl = file.resolveSibling(trimmed.substring(7).trim());
                    if (!Files.exists(mtl, new LinkOption[0])) continue block16;
                    materials.putAll(SkinLoader.mtl(mtl));
                    break;
                }
                case "usemtl": {
                    current = parts.length > 1 ? parts[1] : "";
                    break;
                }
                case "v": {
                    v.add(new float[]{Float.parseFloat(parts[1]), Float.parseFloat(parts[2]), Float.parseFloat(parts[3])});
                    break;
                }
                case "vt": {
                    vt.add(new float[]{Float.parseFloat(parts[1]), parts.length > 2 ? Float.parseFloat(parts[2]) : 0.0f});
                    break;
                }
                case "vn": {
                    vn.add(new float[]{Float.parseFloat(parts[1]), Float.parseFloat(parts[2]), Float.parseFloat(parts[3])});
                    break;
                }
                case "f": {
                    int i;
                    String[] material;
                    String key = current;
                    Builder builder = (Builder)builders.get(key);
                    if (builder == null) {
                        builder = new Builder();
                        material = (String[])materials.get(key);
                        if (material != null && material[1] != null) {
                            String texName = material[1];
                            if (!textures.containsKey(texName)) {
                                Path texFile = file.resolveSibling(texName);
                                textures.put(texName, Files.exists(texFile, new LinkOption[0]) ? SkinLoader.decode(Files.readAllBytes(texFile)) : null);
                            }
                            builder.image = (class_1011)textures.get(texName);
                        }
                        builders.put(key, builder);
                    }
                    int color = (material = (String[])materials.get(key)) != null && material[0] != null ? (int)Long.parseLong(material[0], 16) : -1;
                    int[] corner = new int[parts.length - 1];
                    for (i = 1; i < parts.length; ++i) {
                        String[] refs = parts[i].split("/");
                        int pi = SkinLoader.index(refs[0], v.size());
                        float[] p = (float[])v.get(pi);
                        float u = 0.0f;
                        float w = 0.0f;
                        if (refs.length > 1 && !refs[1].isEmpty()) {
                            float[] t = (float[])vt.get(SkinLoader.index(refs[1], vt.size()));
                            u = t[0];
                            w = 1.0f - t[1];
                        }
                        float nx = Float.NaN;
                        float ny = Float.NaN;
                        float nz = Float.NaN;
                        if (refs.length > 2 && !refs[2].isEmpty()) {
                            float[] n = (float[])vn.get(SkinLoader.index(refs[2], vn.size()));
                            nx = n[0];
                            ny = n[1];
                            nz = n[2];
                        }
                        corner[i - 1] = builder.vertices();
                        builder.vertex(p[0], p[1], p[2], u, w, nx, ny, nz, color);
                    }
                    i = 1;
                    while (i + 1 < corner.length) {
                        builder.triangles.add(corner[0]);
                        builder.triangles.add(corner[i]);
                        builder.triangles.add(corner[i + 1]);
                        ++i;
                    }
                    continue block16;
                }
            }
        }
        ArrayList<Raw> result = new ArrayList<Raw>();
        for (Builder builder : builders.values()) {
            result.add(SkinLoader.toRaw(builder));
        }
        return result;
    }

    private static int index(String ref, int size) {
        int i = Integer.parseInt(ref);
        return i < 0 ? size + i : i - 1;
    }

    private static Map<String, String[]> mtl(Path file) throws IOException {
        HashMap<String, String[]> result = new HashMap<String, String[]>();
        String name = null;
        for (String line : Files.readAllLines(file)) {
            String trimmed = line.trim();
            String[] parts = trimmed.split("\\s+");
            if (parts.length == 0) continue;
            if (parts[0].equals("newmtl") && parts.length > 1) {
                name = parts[1];
                result.put(name, new String[2]);
                continue;
            }
            if (name != null && parts[0].equals("Kd") && parts.length > 3) {
                int r = SkinLoader.clamp(Float.parseFloat(parts[1]));
                int g = SkinLoader.clamp(Float.parseFloat(parts[2]));
                int b = SkinLoader.clamp(Float.parseFloat(parts[3]));
                ((String[])result.get((Object)name))[0] = Integer.toHexString(0xFF000000 | r << 16 | g << 8 | b);
                continue;
            }
            if (name == null || !parts[0].equals("map_Kd") || parts.length <= 1) continue;
            ((String[])result.get((Object)name))[1] = parts[parts.length - 1];
        }
        return result;
    }

    private static List<Raw> stl(byte[] bytes) throws IOException {
        Builder builder = new Builder();
        ByteBuffer buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        if (bytes.length >= 84 && 84L + ((long)buf.getInt(80) & 0xFFFFFFFFL) * 50L == (long)bytes.length) {
            int count = buf.getInt(80);
            for (int t = 0; t < count; ++t) {
                int base = 84 + t * 50 + 12;
                for (int k = 0; k < 3; ++k) {
                    builder.triangles.add(builder.vertices());
                    builder.vertex(buf.getFloat(base + k * 12), buf.getFloat(base + k * 12 + 4), buf.getFloat(base + k * 12 + 8), 0.0f, 0.0f, Float.NaN, Float.NaN, Float.NaN, -3617582);
                }
            }
        } else {
            for (String line : new String(bytes, StandardCharsets.US_ASCII).split("\\R")) {
                String[] parts;
                String trimmed = line.trim();
                if (!trimmed.startsWith("vertex") || (parts = trimmed.split("\\s+")).length < 4) continue;
                builder.triangles.add(builder.vertices());
                builder.vertex(Float.parseFloat(parts[1]), Float.parseFloat(parts[2]), Float.parseFloat(parts[3]), 0.0f, 0.0f, Float.NaN, Float.NaN, Float.NaN, -3617582);
            }
        }
        if (builder.triangles.size() < 3) {
            throw new IOException("Empty model");
        }
        Raw raw = SkinLoader.toRaw(builder);
        Raw zUp = SkinLoader.rotateZUp(raw);
        return List.of(zUp);
    }

    private static Raw rotateZUp(Raw raw) {
        float[] p = raw.positions;
        float[] out = new float[p.length];
        for (int i = 0; i < p.length; i += 3) {
            out[i] = p[i];
            out[i + 1] = p[i + 2];
            out[i + 2] = -p[i + 1];
        }
        return new Raw(out, raw.uvs, null, raw.colors, raw.triangles, raw.image);
    }

    private static void smoothNormals(Raw raw) {
        float[] p = raw.positions;
        float[] n = new float[p.length];
        int[] t = raw.triangles;
        int i = 0;
        while (i + 2 < t.length) {
            int a = t[i] * 3;
            int b = t[i + 1] * 3;
            int c = t[i + 2] * 3;
            float ux = p[b] - p[a];
            float uy = p[b + 1] - p[a + 1];
            float uz = p[b + 2] - p[a + 2];
            float vx = p[c] - p[a];
            float vy = p[c + 1] - p[a + 1];
            float vz = p[c + 2] - p[a + 2];
            float nx = uy * vz - uz * vy;
            float ny = uz * vx - ux * vz;
            float nz = ux * vy - uy * vx;
            int[] nArray = new int[]{a, b, c};
            int n2 = nArray.length;
            for (int j = 0; j < n2; ++j) {
                int k;
                int n3 = k = nArray[j];
                n[n3] = n[n3] + nx;
                int n4 = k + 1;
                n[n4] = n[n4] + ny;
                int n5 = k + 2;
                n[n5] = n[n5] + nz;
            }
            i += 3;
        }
        for (i = 0; i < n.length; i += 3) {
            float len = (float)Math.sqrt(n[i] * n[i] + n[i + 1] * n[i + 1] + n[i + 2] * n[i + 2]);
            if (len > 1.0E-12f) {
                int n6 = i;
                n[n6] = n[n6] / len;
                int n7 = i + 1;
                n[n7] = n[n7] / len;
                int n8 = i + 2;
                n[n8] = n[n8] / len;
                continue;
            }
            n[i + 1] = 1.0f;
        }
        raw.normals = n;
    }

    private static List<Raw> decimate(List<Raw> parts, int budget) {
        int total = 0;
        float[] min = new float[]{Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE};
        float[] max = new float[]{-3.4028235E38f, -3.4028235E38f, -3.4028235E38f};
        for (Raw part : parts) {
            total += part.triangles.length / 3;
            for (int i = 0; i < part.positions.length; ++i) {
                min[i % 3] = Math.min(min[i % 3], part.positions[i]);
                max[i % 3] = Math.max(max[i % 3], part.positions[i]);
            }
        }
        List<Raw> current = parts;
        if (total <= budget) {
            return current;
        }
        float extent = Math.max(max[0] - min[0], Math.max(max[1] - min[1], max[2] - min[2]));
        if (extent <= 0.0f) {
            return current;
        }
        List<Raw> best = current;
        float cells = 220.0f;
        for (int attempt = 0; attempt < 14; ++attempt) {
            float cell = extent / cells;
            ArrayList<Raw> result = new ArrayList<Raw>();
            int count = 0;
            for (Raw part : current) {
                Raw reduced = SkinLoader.cluster(part, cell, min, Math.max(12.0f, cells * 0.35f));
                result.add(reduced);
                count += reduced.triangles.length / 3;
            }
            best = result;
            if (count <= budget) break;
            cells *= 0.78f;
        }
        return best;
    }

    private static Raw cluster(Raw part, float cell, float[] min, float uvGrid) {
        int vertices = part.colors.length;
        HashMap<Key, Integer> clusters = new HashMap<Key, Integer>();
        int[] map = new int[vertices];
        ArrayList<double[]> sums = new ArrayList<double[]>();
        for (int v = 0; v < vertices; ++v) {
            int vv;
            long ix = (long)((part.positions[v * 3] - min[0]) / cell) & 0x1FFFFFL;
            long iy = (long)((part.positions[v * 3 + 1] - min[1]) / cell) & 0x1FFFFFL;
            long iz = (long)((part.positions[v * 3 + 2] - min[2]) / cell) & 0x1FFFFFL;
            int uu = (int)Math.floor(part.uvs[v * 2] * uvGrid) & 0xFFFF;
            Key key = new Key(ix | iy << 21 | iz << 42, uu | (vv = (int)Math.floor(part.uvs[v * 2 + 1] * uvGrid) & 0xFFFF) << 16);
            Integer id = (Integer)clusters.get((Object)key);
            if (id == null) {
                id = sums.size();
                clusters.put(key, id);
                sums.add(new double[13]);
            }
            map[v] = id;
            double[] s = (double[])sums.get(id);
            s[0] = s[0] + (double)part.positions[v * 3];
            s[1] = s[1] + (double)part.positions[v * 3 + 1];
            s[2] = s[2] + (double)part.positions[v * 3 + 2];
            s[3] = s[3] + (double)part.uvs[v * 2];
            s[4] = s[4] + (double)part.uvs[v * 2 + 1];
            s[5] = s[5] + (double)part.normals[v * 3];
            s[6] = s[6] + (double)part.normals[v * 3 + 1];
            s[7] = s[7] + (double)part.normals[v * 3 + 2];
            int c = part.colors[v];
            s[8] = s[8] + (double)(c >>> 24);
            s[9] = s[9] + (double)(c >> 16 & 0xFF);
            s[10] = s[10] + (double)(c >> 8 & 0xFF);
            s[11] = s[11] + (double)(c & 0xFF);
            s[12] = s[12] + 1.0;
        }
        int n = sums.size();
        float[] positions = new float[n * 3];
        float[] uvs = new float[n * 2];
        float[] normals = new float[n * 3];
        int[] colors = new int[n];
        for (int i = 0; i < n; ++i) {
            double[] s = (double[])sums.get(i);
            double k = s[12];
            positions[i * 3] = (float)(s[0] / k);
            positions[i * 3 + 1] = (float)(s[1] / k);
            positions[i * 3 + 2] = (float)(s[2] / k);
            uvs[i * 2] = (float)(s[3] / k);
            uvs[i * 2 + 1] = (float)(s[4] / k);
            double nx = s[5];
            double ny = s[6];
            double nz = s[7];
            double len = Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (len < 1.0E-9) {
                len = 1.0;
                ny = 1.0;
            }
            normals[i * 3] = (float)(nx / len);
            normals[i * 3 + 1] = (float)(ny / len);
            normals[i * 3 + 2] = (float)(nz / len);
            colors[i] = (int)Math.round(s[8] / k) << 24 | (int)Math.round(s[9] / k) << 16 | (int)Math.round(s[10] / k) << 8 | (int)Math.round(s[11] / k);
        }
        ArrayList<Integer> triangles = new ArrayList<Integer>();
        HashSet<Long> seen = new HashSet<Long>();
        int i = 0;
        while (i + 2 < part.triangles.length) {
            int a = map[part.triangles[i]];
            int b = map[part.triangles[i + 1]];
            int c = map[part.triangles[i + 2]];
            if (a != b && b != c && a != c) {
                int lo = Math.min(a, Math.min(b, c));
                int hi = Math.max(a, Math.max(b, c));
                int mid = a + b + c - lo - hi;
                long id = (long)lo * 2654435761L ^ (long)mid << 21 ^ (long)hi << 42 ^ (long)(a == lo ? (b == mid ? 0 : 1) : 2);
                if (seen.add(id)) {
                    triangles.add(a);
                    triangles.add(b);
                    triangles.add(c);
                }
            }
            i += 3;
        }
        return new Raw(positions, uvs, normals, colors, triangles.stream().mapToInt(Integer::intValue).toArray(), part.image);
    }

    private static void normalize(List<Raw> parts) {
        float[] min = new float[]{Float.MAX_VALUE, Float.MAX_VALUE, Float.MAX_VALUE};
        float[] max = new float[]{-3.4028235E38f, -3.4028235E38f, -3.4028235E38f};
        for (Raw part : parts) {
            for (int i = 0; i < part.positions.length; ++i) {
                min[i % 3] = Math.min(min[i % 3], part.positions[i]);
                max[i % 3] = Math.max(max[i % 3], part.positions[i]);
            }
        }
        float height = max[1] - min[1];
        if (height <= 1.0E-6f) {
            height = Math.max(1.0E-6f, Math.max(max[0] - min[0], max[2] - min[2]));
        }
        float cx = (min[0] + max[0]) / 2.0f;
        float cz = (min[2] + max[2]) / 2.0f;
        for (Raw part : parts) {
            float[] p = part.positions;
            for (int i = 0; i < p.length; i += 3) {
                p[i] = (p[i] - cx) / height;
                p[i + 1] = (p[i + 1] - min[1]) / height;
                p[i + 2] = (p[i + 2] - cz) / height;
            }
        }
    }

    private static final class Raw {
        final float[] positions;
        final float[] uvs;
        float[] normals;
        final int[] colors;
        final int[] triangles;
        final class_1011 image;

        Raw(float[] positions, float[] uvs, float[] normals, int[] colors, int[] triangles, class_1011 image) {
            this.positions = positions;
            this.uvs = uvs;
            this.normals = normals;
            this.colors = colors;
            this.triangles = triangles;
            this.image = image;
        }
    }

    private static final class Builder {
        final List<Float> positions = new ArrayList<Float>();
        final List<Float> uvs = new ArrayList<Float>();
        final List<Float> normals = new ArrayList<Float>();
        final List<Integer> colors = new ArrayList<Integer>();
        final List<Integer> triangles = new ArrayList<Integer>();
        class_1011 image;

        private Builder() {
        }

        int vertices() {
            return this.colors.size();
        }

        void vertex(float x, float y, float z, float u, float v, float nx, float ny, float nz, int color) {
            this.positions.add(Float.valueOf(x));
            this.positions.add(Float.valueOf(y));
            this.positions.add(Float.valueOf(z));
            this.uvs.add(Float.valueOf(u));
            this.uvs.add(Float.valueOf(v));
            this.normals.add(Float.valueOf(nx));
            this.normals.add(Float.valueOf(ny));
            this.normals.add(Float.valueOf(nz));
            this.colors.add(color);
        }
    }

    private record Key(long position, int uv) {
    }
}

