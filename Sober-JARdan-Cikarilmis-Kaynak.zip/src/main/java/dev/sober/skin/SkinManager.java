/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.loader.api.FabricLoader
 */
package dev.sober.skin;

import dev.sober.SoberClient;
import dev.sober.gui.Notifications;
import dev.sober.skin.SkinLoader;
import dev.sober.skin.SkinMesh;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;

public final class SkinManager {
    public static final String CAT = "builtin/sober_cat.glb";
    public static final String BOT = "builtin/sober_bot.glb";
    public static final String BANANA = "builtin/sober_banana.glb";
    private static final Map<String, String> BUILTIN = SkinManager.builtin();
    private static final Map<String, String> FAILED = new HashMap<String, String>();
    private static volatile List<String> files = List.copyOf(BUILTIN.keySet());
    private static volatile long lastScan;
    private static volatile boolean scanning;
    private static Path folder;
    private static String currentKey;
    private static SkinMesh current;
    private static CompletableFuture<SkinMesh> pending;
    private static String pendingKey;

    private SkinManager() {
    }

    private static Map<String, String> builtin() {
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
        map.put(CAT, "Sober Cat");
        map.put(BOT, "Sober Bot");
        map.put(BANANA, "Banana Buddy");
        return Collections.unmodifiableMap(map);
    }

    public static Path folder() {
        if (folder != null) {
            return folder;
        }
        Path path = FabricLoader.getInstance().getConfigDir().resolve("sober").resolve("skins");
        try {
            Files.createDirectories(path, new FileAttribute[0]);
        }
        catch (IOException iOException) {
            // empty catch block
        }
        folder = path;
        return path;
    }

    public static List<String> files() {
        long now = System.currentTimeMillis();
        if (now - lastScan > 5000L && !scanning) {
            lastScan = now;
            scanning = true;
            CompletableFuture.runAsync(() -> {
                try {
                    SkinManager.rescan();
                }
                finally {
                    scanning = false;
                }
            });
        }
        return files;
    }

    public static void rescan() {
        lastScan = System.currentTimeMillis();
        ArrayList<String> found = new ArrayList<String>(BUILTIN.keySet());
        try (Stream<Path> stream = Files.list(SkinManager.folder());){
            stream.filter(x$0 -> Files.isRegularFile(x$0, new LinkOption[0])).map(p -> p.getFileName().toString()).filter(SkinManager::supported).filter(name -> !BUILTIN.containsKey("builtin/" + name)).sorted(String.CASE_INSENSITIVE_ORDER).forEach(found::add);
        }
        catch (IOException iOException) {
            // empty catch block
        }
        files = List.copyOf(found);
    }

    public static void reload() {
        FAILED.clear();
        if (current != null) {
            current.release();
        }
        current = null;
        currentKey = null;
        pending = null;
        pendingKey = null;
        SkinManager.rescan();
    }

    private static boolean supported(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".glb") || lower.endsWith(".gltf") || lower.endsWith(".obj") || lower.endsWith(".stl");
    }

    private static String alias(String name) {
        if (!name.startsWith("builtin/") || BUILTIN.containsKey(name)) {
            return name;
        }
        String tail = name.substring(name.lastIndexOf(95) + 1);
        for (String key : BUILTIN.keySet()) {
            if (!key.endsWith("_" + tail)) continue;
            return key;
        }
        return name;
    }

    public static String title(String file) {
        if (BUILTIN.containsKey(file = SkinManager.alias(file))) {
            return BUILTIN.get(file);
        }
        int dot = file.lastIndexOf(46);
        String base = dot > 0 ? file.substring(0, dot) : file;
        return base.replace('_', ' ').replace('-', ' ');
    }

    public static String error(String name) {
        return FAILED.get(name);
    }

    public static boolean loading() {
        return pending != null;
    }

    public static SkinMesh get(String requested, int budget) {
        String key;
        String name;
        block11: {
            if (requested == null || requested.isEmpty()) {
                return null;
            }
            name = SkinManager.alias(requested);
            key = name + "#" + budget;
            if (key.equals(currentKey) && current != null) {
                current.upload();
                return current;
            }
            if (FAILED.containsKey(name)) {
                return current;
            }
            if (pending != null && pending.isDone()) {
                String doneKey = pendingKey;
                CompletableFuture<SkinMesh> done = pending;
                pending = null;
                pendingKey = null;
                try {
                    SkinMesh mesh = done.join();
                    if (key.equals(doneKey)) {
                        if (current != null) {
                            current.release();
                        }
                        current = mesh;
                        currentKey = key;
                        mesh.upload();
                        Notifications.push("Custom Skin", SkinManager.title(name) + " loaded with " + mesh.triangleCount() + " triangles.", Notifications.Type.SUCCESS);
                        return mesh;
                    }
                    mesh.release();
                }
                catch (RuntimeException e) {
                    Throwable cause = e.getCause() != null ? e.getCause() : e;
                    String skin = doneKey.substring(0, doneKey.lastIndexOf(35));
                    FAILED.put(skin, String.valueOf(cause.getMessage()));
                    SoberClient.LOG.error("Could not load skin {}", (Object)skin, (Object)cause);
                    Notifications.push("Custom Skin", "Could not load " + skin + ": " + cause.getMessage(), Notifications.Type.ERROR);
                    if (!skin.equals(name)) break block11;
                    return null;
                }
            }
        }
        if (pending == null && BUILTIN.containsKey(name)) {
            pendingKey = key;
            pending = CompletableFuture.supplyAsync(() -> {
                SkinMesh skinMesh;
                block9: {
                    InputStream stream = SkinManager.class.getResourceAsStream("/assets/sober/skins/" + name.substring(name.indexOf(47) + 1));
                    try {
                        if (stream == null) {
                            throw new IOException("built in skin is missing");
                        }
                        skinMesh = SkinLoader.loadGlb(stream.readAllBytes(), budget);
                        if (stream == null) break block9;
                    }
                    catch (Throwable t$) {
                        try {
                            if (stream != null) {
                                try {
                                    stream.close();
                                }
                                catch (Throwable x2) {
                                    t$.addSuppressed(x2);
                                }
                            }
                            throw t$;
                        }
                        catch (IOException e) {
                            throw new RuntimeException(e.getMessage(), e);
                        }
                    }
                    stream.close();
                }
                return skinMesh;
            });
        }
        if (pending == null) {
            Path file = SkinManager.folder().resolve(name);
            if (!Files.isRegularFile(file, new LinkOption[0])) {
                FAILED.put(name, "file not found");
                return null;
            }
            pendingKey = key;
            pending = CompletableFuture.supplyAsync(() -> {
                try {
                    return SkinLoader.load(file, budget);
                }
                catch (IOException e) {
                    throw new RuntimeException(e.getMessage(), e);
                }
            });
        }
        return current != null && currentKey != null && currentKey.startsWith(name + "#") ? current : null;
    }
}

