/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1011
 *  net.minecraft.class_1043
 *  net.minecraft.class_1044
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 */
package dev.sober.skin;

import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class SkinMesh {
    private static final class_2960 WHITE = class_2960.method_60655((String)"sober", (String)"skin/white");
    private static boolean whiteReady;
    private static int counter;
    public final List<Part> parts;
    float neckHint = Float.NaN;
    float headHint = Float.NaN;
    private boolean uploaded;

    SkinMesh(List<Part> parts) {
        this.parts = parts;
    }

    public int triangleCount() {
        int sum = 0;
        for (Part part : this.parts) {
            sum += part.triangleCount();
        }
        return sum;
    }

    public void upload() {
        if (this.uploaded) {
            return;
        }
        this.uploaded = true;
        class_310 mc = class_310.method_1551();
        for (Part part : this.parts) {
            if (part.image == null) {
                if (!whiteReady) {
                    class_1011 white = new class_1011(1, 1, false);
                    white.method_61941(0, 0, -1);
                    mc.method_1531().method_4616(WHITE, (class_1044)new class_1043(() -> "sober skin white", white));
                    whiteReady = true;
                }
                part.texture = WHITE;
                continue;
            }
            class_2960 id = class_2960.method_60655((String)"sober", (String)("skin/texture_" + counter++));
            class_1011 image = part.image;
            part.image = null;
            mc.method_1531().method_4616(id, (class_1044)new class_1043(() -> "sober skin " + String.valueOf(id), image));
            part.texture = id;
        }
    }

    public void release() {
        class_310 mc = class_310.method_1551();
        for (Part part : this.parts) {
            if (part.image != null) {
                part.image.close();
                part.image = null;
            }
            if (part.texture == null || part.texture.equals((Object)WHITE)) continue;
            mc.method_1531().method_4615(part.texture);
        }
    }

    public static final class Part {
        public final float[] positions;
        public final float[] uvs;
        public final float[] normals;
        public final int[] colors;
        public final int[] triangles;
        private class_1011 image;
        private class_2960 texture;

        Part(float[] positions, float[] uvs, float[] normals, int[] colors, int[] triangles, class_1011 image) {
            this.positions = positions;
            this.uvs = uvs;
            this.normals = normals;
            this.colors = colors;
            this.triangles = triangles;
            this.image = image;
        }

        public class_2960 texture() {
            return this.texture;
        }

        public int triangleCount() {
            return this.triangles.length / 3;
        }
    }
}

