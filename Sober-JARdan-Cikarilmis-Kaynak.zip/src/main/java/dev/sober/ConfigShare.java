/*
 * Decompiled with CFR 0.152.
 */
package dev.sober;

import dev.sober.ConfigSlots;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ConfigShare {
    public static final String PREFIX = "SC-";
    public static final int NAME_MIN = 3;
    public static final int NAME_MAX = 16;
    private static final String BASE = "https://textdb.online/";
    private static final String KEY = "soberclient-cfg-";
    private static final Pattern SHORT = Pattern.compile("(?i)^[SY]C-?([A-Za-z0-9_]{3,16})$");
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8L)).followRedirects(HttpClient.Redirect.NORMAL).build();

    private ConfigShare() {
    }

    public static String shortCode(String text) {
        if (text == null) {
            return null;
        }
        Matcher matcher = SHORT.matcher(text.replaceAll("\\s+", ""));
        return matcher.matches() ? matcher.group(1).toUpperCase(Locale.ROOT) : null;
    }

    public static String cleanName(String text) {
        if (text == null) {
            return "";
        }
        String name = text.strip();
        if (name.regionMatches(true, 0, PREFIX, 0, PREFIX.length())) {
            name = name.substring(PREFIX.length());
        }
        return (name = name.replaceAll("[^A-Za-z0-9_]", "").toUpperCase(Locale.ROOT)).length() > 16 ? name.substring(0, 16) : name;
    }

    public static CompletableFuture<String> upload(String json, String name, Set<String> mine) {
        return CompletableFuture.supplyAsync(() -> {
            String payload = ConfigSlots.pack(json);
            if (name != null && !name.isEmpty()) {
                if (name.length() < 3) {
                    throw new IllegalArgumentException("A share name needs at least 3 letters or numbers.");
                }
                if (!ConfigShare.read(name).isEmpty() && !mine.contains(name)) {
                    throw new IllegalArgumentException(PREFIX + name + " is already taken. Pick another share name.");
                }
                ConfigShare.write(name, payload);
                return PREFIX + name;
            }
            for (int attempt = 0; attempt < 6; ++attempt) {
                String digits = Integer.toString(100000 + RANDOM.nextInt(900000));
                if (!ConfigShare.read(digits).isEmpty()) continue;
                ConfigShare.write(digits, payload);
                return PREFIX + digits;
            }
            throw new IllegalStateException("No free code found.");
        });
    }

    public static CompletableFuture<String> download(String code) {
        return CompletableFuture.supplyAsync(() -> {
            String payload = ConfigShare.read(code);
            if (payload.isEmpty()) {
                throw new IllegalArgumentException("There is no config with the code SC-" + code + ".");
            }
            return ConfigSlots.unpack(payload);
        });
    }

    private static void write(String code, String payload) {
        String body = "value=" + URLEncoder.encode(payload, StandardCharsets.UTF_8);
        HttpRequest request = HttpRequest.newBuilder(URI.create("https://textdb.online/update/?key=" + ConfigShare.key(code))).timeout(Duration.ofSeconds(20L)).header("Content-Type", "application/x-www-form-urlencoded").POST(HttpRequest.BodyPublishers.ofString(body)).build();
        String answer = ConfigShare.send(request);
        if (!answer.replace(" ", "").contains("\"status\":1")) {
            throw new IllegalStateException("The upload was refused.");
        }
        if (!ConfigShare.read(code).equals(payload)) {
            throw new IllegalStateException("The upload could not be checked.");
        }
    }

    private static String read(String code) {
        HttpRequest request = HttpRequest.newBuilder(URI.create(BASE + ConfigShare.key(code))).timeout(Duration.ofSeconds(15L)).GET().build();
        return ConfigShare.send(request).strip();
    }

    private static String key(String code) {
        return KEY + code.toLowerCase(Locale.ROOT);
    }

    private static String send(HttpRequest request) {
        try {
            HttpResponse<String> response = HTTP.send(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
            if (response.statusCode() / 100 != 2) {
                throw new IllegalStateException("The config server answered " + response.statusCode() + ".");
            }
            return response.body();
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("The connection was interrupted.");
        }
        catch (IOException e) {
            throw new IllegalStateException("The config server could not be reached.");
        }
    }
}

