/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1041
 *  net.minecraft.class_3675
 */
package dev.sober.input;

import net.minecraft.class_1041;
import net.minecraft.class_3675;

public final class SoberKeyPolling {
    private SoberKeyPolling() {
    }

    public static boolean isKeyDown(class_1041 window, int key) {
        return class_3675.method_15987((class_1041)window, (int)key);
    }
}

