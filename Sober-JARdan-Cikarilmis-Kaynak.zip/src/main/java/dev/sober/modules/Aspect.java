/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;
import dev.sober.setting.lite.NumberSetting;

public final class Aspect
extends BusModule {
    private static volatile float ratio;
    private final NumberSetting setting = this.addSetting("ratio", new NumberSetting("Ratio", 1.6f, 0.5f, 8.0f).step(0.1f));

    public Aspect() {
        super("aspect", "Aspect", "Changes the aspect ratio of the gameplay only. Lower ratios stretch the world wider, higher ratios squeeze it. Your hands, menus, the HUD and the ClickGUI stay normal.", ModuleCategory.VISUALS);
        this.setting.onChange(this::update);
    }

    @Override
    public void onEnable() {
        this.update();
    }

    @Override
    public void onDisable() {
        ratio = 0.0f;
    }

    private void update() {
        ratio = this.isEnabled() ? Math.max(0.1f, this.setting.get()) : 0.0f;
    }

    public static float aspect(float original) {
        float value = ratio;
        return value > 0.0f ? value : original;
    }
}

