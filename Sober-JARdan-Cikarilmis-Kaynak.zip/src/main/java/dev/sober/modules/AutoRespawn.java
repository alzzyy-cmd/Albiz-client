/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_2338
 *  net.minecraft.class_2561
 *  net.minecraft.class_418
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_124;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_418;

public class AutoRespawn
extends Module {
    private final Setting<Integer> delay = this.add(new IntSetting("Delay", "Ticks to wait on the death screen before respawning.", 0, 0, 60));
    private final Setting<Boolean> coords = this.add(new BoolSetting("Death Coords", "Writes where you died into your chat.", true));
    private int waited;
    private boolean dead;

    public AutoRespawn() {
        super("Auto Respawn", "Respawns you right away when you die.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (AutoRespawn.mc.field_1724 == null) {
            return;
        }
        if (!(AutoRespawn.mc.field_1755 instanceof class_418)) {
            this.waited = 0;
            this.dead = false;
            return;
        }
        if (!this.dead) {
            this.dead = true;
            if (this.coords.get().booleanValue()) {
                class_2338 pos = AutoRespawn.mc.field_1724.method_24515();
                AutoRespawn.mc.field_1705.method_1743().method_1812((class_2561)class_2561.method_43470((String)"[Auto Respawn] ").method_27692(class_124.field_1080).method_10852((class_2561)class_2561.method_43470((String)("You died at " + pos.method_10263() + ", " + pos.method_10264() + ", " + pos.method_10260())).method_27692(class_124.field_1068)));
            }
        }
        if (this.waited++ < this.delay.get()) {
            return;
        }
        AutoRespawn.mc.field_1724.method_7331();
        mc.method_1507(null);
    }
}

