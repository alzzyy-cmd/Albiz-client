/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  net.minecraft.class_124
 *  net.minecraft.class_2558
 *  net.minecraft.class_2558$class_10608
 *  net.minecraft.class_2561
 *  net.minecraft.class_2568
 *  net.minecraft.class_2568$class_10613
 *  net.minecraft.class_5250
 */
package dev.sober.modules;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.sober.gui.Notifications;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.module.Status;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.ProxySelector;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;

public class StaffLive
extends Module
implements Status {
    private static final Pattern LIVE_STATUS = Pattern.compile("\"liveRoom(?:UserInfo)?\"\\s*:\\s*\\{.{0,4000}?\"status\"\\s*:\\s*(\\d)", 32);
    private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36";
    private final Setting<Boolean> pasta = this.add(new BoolSetting("Pastagamer08", "Notifies when Pastagamer08 goes live on TikTok or YouTube.", true));
    private final Setting<Boolean> wizox = this.add(new BoolSetting("W1zox_", "Notifies when W1zox_ goes live on YouTube.", true));
    private final Setting<Boolean> munkerlich = this.add(new BoolSetting("Munkerlich", "Notifies when Munkerlich goes live on YouTube.", true));
    private final Setting<Integer> interval = this.add(new IntSetting("Interval", "Minutes between two checks.", 2, 1, 15));
    private final Setting<Boolean> chatLink = this.add(new BoolSetting("Chat Link", "Also writes a clickable link to the stream into your chat.", true));
    public final Setting<Boolean> hud = this.add(new BoolSetting("HUD", "Shows who is live as a card in your HUD. Move and resize it in the HUD editor while the chat is open.", true));
    private final List<Stream> streams = List.of(new Stream("Pastagamer08", Platform.TikTok, "pastagamer08", "https://www.tiktok.com/@pastagamer08/live", this.pasta::get), new Stream("Pastagamer08", Platform.YouTube, "pastagamer08", "https://www.youtube.com/@pastagamer08/streams", this.pasta::get), new Stream("W1zox_", Platform.YouTube, "wizoxlol", "https://www.youtube.com/@wizoxlol/streams", this.wizox::get), new Stream("Munkerlich", Platform.YouTube, "Munkerlich", "https://www.youtube.com/@Munkerlich/streams", this.munkerlich::get));
    private final Map<Stream, Boolean> live = new ConcurrentHashMap<Stream, Boolean>();
    private final Set<Stream> failed = ConcurrentHashMap.newKeySet();
    private HttpClient http;
    private ScheduledExecutorService executor;
    private long nextCheck;

    public StaffLive() {
        super("Staff Live", "Notifies you when Pastagamer08, W1zox_ or Munkerlich goes live on TikTok or YouTube.", Category.DONUT);
    }

    @Override
    public void onEnable() {
        this.live.clear();
        this.failed.clear();
        this.nextCheck = 0L;
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10L)).followRedirects(HttpClient.Redirect.NORMAL).cookieHandler(new CookieManager(null, CookiePolicy.ACCEPT_ALL)).proxy(ProxySelector.getDefault()).build();
        this.executor = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread thread = new Thread(runnable, "Sober Staff Live");
            thread.setDaemon(true);
            return thread;
        });
        this.executor.scheduleWithFixedDelay(this::poll, 0L, 15L, TimeUnit.SECONDS);
    }

    @Override
    public void onDisable() {
        if (this.executor != null) {
            this.executor.shutdownNow();
        }
        this.executor = null;
        this.live.clear();
        this.failed.clear();
    }

    private void poll() {
        long now = System.currentTimeMillis();
        if (now < this.nextCheck) {
            return;
        }
        this.nextCheck = now + (long)this.interval.get().intValue() * 60000L;
        for (Stream stream : this.streams) {
            if (!stream.enabled().get().booleanValue()) {
                this.live.remove((Object)stream);
                this.failed.remove((Object)stream);
                continue;
            }
            Boolean result = this.check(stream);
            if (result == null) {
                this.failed.add(stream);
                continue;
            }
            this.failed.remove((Object)stream);
            Boolean before = this.live.put(stream, result);
            if (!result.booleanValue() || Boolean.TRUE.equals(before)) continue;
            this.announce(stream);
        }
    }

    @Override
    public String statusTitle() {
        long count = this.live.values().stream().filter(Boolean::booleanValue).count();
        return count > 0L ? "STATUS  /  " + count + " LIVE" : "STATUS";
    }

    public List<Entry> entries() {
        ArrayList<Entry> entries = new ArrayList<Entry>();
        for (Stream stream : this.streams) {
            int color;
            String badge;
            boolean enabled;
            Boolean state = this.live.get((Object)stream);
            boolean bl = enabled = this.isActive() && stream.enabled().get() != false;
            if (!enabled) {
                badge = "OFF";
                color = -11907241;
            } else if (Boolean.TRUE.equals(state)) {
                badge = "LIVE";
                color = -1750963;
            } else if (this.failed.contains((Object)stream) && state == null) {
                badge = "NO DATA";
                color = -9741778;
            } else if (state == null) {
                badge = "CHECKING";
                color = -12959929;
            } else {
                badge = "OFFLINE";
                color = -12959929;
            }
            entries.add(new Entry(stream.name(), stream.platform().title, badge, color, enabled && Boolean.TRUE.equals(state), enabled, stream.link()));
        }
        return entries;
    }

    @Override
    public List<Status.Row> statusRows() {
        ArrayList<Status.Row> rows = new ArrayList<Status.Row>();
        for (Entry entry : this.entries()) {
            String detail = entry.link().replace("https://", "").replace("www.", "");
            rows.add(new Status.Row(entry.name() + "  /  " + entry.platform(), detail, entry.badge(), entry.color(), entry.link()));
        }
        return rows;
    }

    @Override
    public String statusDescription() {
        return "Who is live and where. Click a row to open the stream in your browser.";
    }

    private Boolean check(Stream stream) {
        try {
            return stream.platform() == Platform.YouTube ? this.youtube(stream.handle()) : this.tiktok(stream.handle());
        }
        catch (Exception e) {
            return null;
        }
    }

    private boolean youtube(String handle) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(URI.create("https://www.youtube.com/@" + handle + "/live")).timeout(Duration.ofSeconds(20L)).header("User-Agent", USER_AGENT).header("Accept-Language", "en-US,en;q=0.9").header("Cookie", "SOCS=CAI").GET().build();
        HttpResponse<String> response = this.http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new IllegalStateException("status " + response.statusCode());
        }
        String body = response.body();
        if (body.contains("consent.youtube.com/m")) {
            throw new IllegalStateException("consent page");
        }
        return body.contains("\"isLiveNow\":true");
    }

    private boolean tiktok(String handle) throws Exception {
        try {
            return this.tiktokApi(handle);
        }
        catch (Exception e) {
            return this.tiktokPage(handle);
        }
    }

    private boolean tiktokPage(String handle) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(URI.create("https://www.tiktok.com/@" + handle + "/live")).timeout(Duration.ofSeconds(20L)).header("User-Agent", USER_AGENT).header("Accept-Language", "en-US,en;q=0.9").GET().build();
        HttpResponse<String> response = this.http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new IllegalStateException("status " + response.statusCode());
        }
        Matcher room = LIVE_STATUS.matcher(response.body());
        if (room.find()) {
            return room.group(1).equals("2");
        }
        throw new IllegalStateException("no status");
    }

    private boolean tiktokApi(String handle) throws Exception {
        JsonElement status;
        HttpRequest request = HttpRequest.newBuilder(URI.create("https://www.tiktok.com/api-live/user/room/?aid=1988&sourceType=54&uniqueId=" + handle)).timeout(Duration.ofSeconds(20L)).header("User-Agent", USER_AGENT).header("Accept", "application/json").GET().build();
        HttpResponse<String> response = this.http.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            throw new IllegalStateException("status " + response.statusCode());
        }
        JsonObject data = JsonParser.parseString((String)response.body()).getAsJsonObject().getAsJsonObject("data");
        if (data == null) {
            throw new IllegalStateException("no data");
        }
        JsonObject room = data.has("liveRoom") && data.get("liveRoom").isJsonObject() ? data.getAsJsonObject("liveRoom") : null;
        JsonElement jsonElement = status = room != null ? room.get("status") : null;
        if (status == null && data.has("user") && data.get("user").isJsonObject()) {
            status = data.getAsJsonObject("user").get("status");
        }
        if (status == null || !status.isJsonPrimitive()) {
            throw new IllegalStateException("no status");
        }
        return status.getAsInt() == 2;
    }

    private void announce(Stream stream) {
        String platform = stream.platform().title;
        Notifications.push("Staff Live", stream.name() + " is live on " + platform + "!", Notifications.Type.WARNING);
        if (!this.chatLink.get().booleanValue()) {
            return;
        }
        mc.execute(() -> {
            if (StaffLive.mc.field_1724 == null) {
                return;
            }
            class_5250 link = class_2561.method_43470((String)("[Open " + platform + "]")).method_27694(style -> style.method_10977(class_124.field_1075).method_30938(Boolean.valueOf(true)).method_10958((class_2558)new class_2558.class_10608(URI.create(stream.link()))).method_10949((class_2568)new class_2568.class_10613((class_2561)class_2561.method_43470((String)stream.link()))));
            class_5250 message = class_2561.method_43470((String)"[Staff Live] ").method_27692(class_124.field_1076).method_10852((class_2561)class_2561.method_43470((String)(stream.name() + " is live on " + platform + " ")).method_27692(class_124.field_1068)).method_10852((class_2561)link);
            StaffLive.mc.field_1705.method_1743().method_1812((class_2561)message);
        });
    }

    @Override
    public String getInfoString() {
        long count = this.live.values().stream().filter(Boolean::booleanValue).count();
        return count > 0L ? count + " live" : null;
    }

    private record Stream(String name, Platform platform, String handle, String link, Supplier<Boolean> enabled) {
    }

    private static enum Platform {
        YouTube("YouTube"),
        TikTok("TikTok");

        final String title;

        private Platform(String title) {
            this.title = title;
        }
    }

    public record Entry(String name, String platform, String badge, int color, boolean live, boolean enabled, String link) {
    }
}

