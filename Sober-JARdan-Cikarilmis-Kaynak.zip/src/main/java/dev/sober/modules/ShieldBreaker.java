/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_239
 *  net.minecraft.class_3489
 *  net.minecraft.class_3966
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.CombatItems;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_3489;
import net.minecraft.class_3966;

public class ShieldBreaker
extends Module {
    private final Setting<Integer> delay = this.add(new IntSetting("Delay", "Ticks between two shield breaks.", 4, 0, 20));
    private final Setting<Boolean> switchBack = this.add(new BoolSetting("Switch Back", "Goes back to your weapon right after the hit.", true));
    private final Setting<Boolean> clicking = this.add(new BoolSetting("Only While Clicking", "Only breaks shields while you hold the attack key.", false));
    private int timer;
    private int previous = -1;

    public ShieldBreaker() {
        super("Shield Breaker", "Hits a player who blocks with a shield using an axe from your hotbar, which disables the shield.", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        this.restore();
    }

    @Override
    public void onTick() {
        class_3966 hit;
        if (ShieldBreaker.mc.field_1724 == null || ShieldBreaker.mc.field_1761 == null || ShieldBreaker.mc.field_1755 != null || ShieldBreaker.mc.field_1724.method_7325()) {
            return;
        }
        if (this.previous >= 0) {
            this.restore();
            return;
        }
        if (this.timer > 0) {
            --this.timer;
            return;
        }
        if (this.clicking.get().booleanValue() && !ShieldBreaker.mc.field_1690.field_1886.method_1434()) {
            return;
        }
        class_239 class_2392 = ShieldBreaker.mc.field_1765;
        if (!(class_2392 instanceof class_3966) || !((class_2392 = (hit = (class_3966)class_2392).method_17782()) instanceof class_1657)) {
            return;
        }
        class_1657 target = (class_1657)class_2392;
        if (!target.method_6039() || !target.method_5805()) {
            return;
        }
        int axe = CombatItems.hotbarSlot(stack -> stack.method_31573(class_3489.field_42612));
        if (axe < 0) {
            return;
        }
        int held = ShieldBreaker.mc.field_1724.method_31548().method_67532();
        ShieldBreaker.mc.field_1724.method_31548().method_61496(axe);
        ShieldBreaker.mc.field_1761.method_2918((class_1657)ShieldBreaker.mc.field_1724, (class_1297)target);
        ShieldBreaker.mc.field_1724.method_6104(class_1268.field_5808);
        if (held != axe) {
            this.previous = held;
        }
        this.timer = this.delay.get();
    }

    private void restore() {
        if (this.previous >= 0 && this.switchBack.get().booleanValue() && ShieldBreaker.mc.field_1724 != null) {
            ShieldBreaker.mc.field_1724.method_31548().method_61496(this.previous);
        }
        this.previous = -1;
    }
}

