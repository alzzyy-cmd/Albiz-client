/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_746
 */
package dev.sober.modules;

import dev.sober.event.Stage;
import dev.sober.event.impl.TickEvent;
import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;
import dev.sober.setting.lite.NumberSetting;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class Spider
extends BusModule {
    private static final double CLIMB_VELOCITY_THRESHOLD = 0.2;
    private final NumberSetting climbSpeed = this.addSetting("climb-speed", new NumberSetting("Climb Speed", 0.2f, 0.0f, 10.0f).step(0.1f));

    public Spider() {
        super("spider", "Spider", "Allows you to climb walls like a spider.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEnable() {
        this.on(TickEvent.TYPE, Stage.POST, this::onPostTick);
    }

    private void onPostTick(TickEvent event) {
        class_746 player = class_310.method_1551().field_1724;
        if (player != null && player.field_5976) {
            class_243 velocity = player.method_18798();
            if (!(velocity.field_1351 >= 0.2)) {
                player.method_18800(velocity.field_1352, (double)this.climbSpeed.get(), velocity.field_1350);
            }
        }
    }
}

