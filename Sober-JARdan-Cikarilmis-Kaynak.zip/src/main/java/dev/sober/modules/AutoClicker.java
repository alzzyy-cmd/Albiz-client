/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 */
package dev.sober.modules;

import dev.sober.mixin.MinecraftClientAccessor;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.CombatItems;
import dev.sober.render.Render3D;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_239;

public class AutoClicker
extends Module {
    private final Setting<Integer> minCps = this.add(new IntSetting("Min CPS", "Fewest clicks per second.", 9, 1, 20));
    private final Setting<Integer> maxCps = this.add(new IntSetting("Max CPS", "Most clicks per second. Every click waits a random time between the two.", 13, 1, 20));
    private final Setting<Boolean> cooldown = this.add(new BoolSetting("Respect Cooldown", "Waits until your weapon is fully charged instead of clicking at the CPS. Best for 1.9+ combat.", false));
    private final Setting<Boolean> entitiesOnly = this.add(new BoolSetting("Entities Only", "Only clicks while your crosshair is on a player or mob.", false));
    private final Setting<Boolean> weaponOnly = this.add(new BoolSetting("Weapons Only", "Only clicks while you hold a sword, axe, mace or trident.", false));
    private long nextClick;

    public AutoClicker() {
        super("Auto Clicker", "Keeps clicking while you hold the attack key. Never clicks on blocks, so mining stays normal.", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        this.nextClick = 0L;
    }

    @Override
    public void onRender(Render3D renderer) {
        if (AutoClicker.mc.field_1724 == null || AutoClicker.mc.field_1755 != null || AutoClicker.mc.field_1724.method_6115() || !AutoClicker.mc.field_1690.field_1886.method_1434()) {
            this.nextClick = 0L;
            return;
        }
        long now = System.nanoTime();
        if (this.nextClick == 0L) {
            this.nextClick = now + this.interval();
            return;
        }
        class_239 hit = AutoClicker.mc.field_1765;
        if (hit != null && hit.method_17783() == class_239.class_240.field_1332) {
            return;
        }
        if (this.entitiesOnly.get().booleanValue() && (hit == null || hit.method_17783() != class_239.class_240.field_1331)) {
            return;
        }
        if (this.weaponOnly.get().booleanValue() && !CombatItems.isWeapon(AutoClicker.mc.field_1724.method_6047())) {
            return;
        }
        if (this.cooldown.get() != false ? AutoClicker.mc.field_1724.method_7261(0.5f) < 0.95f : now < this.nextClick) {
            return;
        }
        ((MinecraftClientAccessor)mc).sober$doAttack();
        this.nextClick = now + this.interval();
    }

    private long interval() {
        int high;
        int low = Math.min(this.minCps.get(), this.maxCps.get());
        double cps = low == (high = Math.max(this.minCps.get(), this.maxCps.get())) ? (double)low : ThreadLocalRandom.current().nextDouble(low, (double)high + 1.0E-9);
        return (long)(1.0E9 / cps);
    }

    @Override
    public String getInfoString() {
        return this.cooldown.get() != false ? "Cooldown" : (this.minCps.get().equals(this.maxCps.get()) ? String.valueOf(this.minCps.get()) + " CPS" : String.valueOf(this.minCps.get()) + "-" + String.valueOf(this.maxCps.get()) + " CPS");
    }
}

