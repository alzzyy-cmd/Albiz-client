/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1511
 *  net.minecraft.class_1657
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_238
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_2680
 *  net.minecraft.class_3965
 *  net.minecraft.class_3966
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.CombatItems;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class AutoHitCrystal
extends Module {
    private final Setting<Boolean> obsidian = this.add(new BoolSetting("Place Obsidian", "Also places obsidian first when you look at another block.", true));
    private final Setting<Integer> placeDelay = this.add(new IntSetting("Place Delay", "Ticks between placing obsidian and the crystal.", 1, 0, 10));
    private final Setting<Integer> breakDelay = this.add(new IntSetting("Break Delay", "Ticks between placing the crystal and hitting it.", 1, 0, 10));
    private final Setting<Boolean> switchBack = this.add(new BoolSetting("Switch Back", "Goes back to the slot you held before when you let go.", true));
    private int timer;
    private int previous = -1;

    public AutoHitCrystal() {
        super("Auto Hit Crystal", "Hold right click: places obsidian, puts an end crystal on it and hits the crystal, again and again.", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        this.restore();
    }

    @Override
    public void onTick() {
        class_3965 blockHit;
        block12: {
            block11: {
                class_3966 entityHit;
                class_1297 class_12972;
                if (AutoHitCrystal.mc.field_1724 == null || AutoHitCrystal.mc.field_1687 == null || AutoHitCrystal.mc.field_1761 == null || AutoHitCrystal.mc.field_1724.method_7325()) {
                    return;
                }
                if (AutoHitCrystal.mc.field_1755 != null || !AutoHitCrystal.mc.field_1690.field_1904.method_1434()) {
                    this.restore();
                    return;
                }
                if (this.timer > 0) {
                    --this.timer;
                    return;
                }
                class_239 hit = AutoHitCrystal.mc.field_1765;
                if (hit instanceof class_3966 && (class_12972 = (entityHit = (class_3966)hit).method_17782()) instanceof class_1511) {
                    class_1511 crystal = (class_1511)class_12972;
                    AutoHitCrystal.mc.field_1761.method_2918((class_1657)AutoHitCrystal.mc.field_1724, (class_1297)crystal);
                    AutoHitCrystal.mc.field_1724.method_6104(class_1268.field_5808);
                    this.timer = this.placeDelay.get();
                    return;
                }
                if (!(hit instanceof class_3965)) break block11;
                blockHit = (class_3965)hit;
                if (hit.method_17783() == class_239.class_240.field_1332) break block12;
            }
            return;
        }
        class_2338 pos = blockHit.method_17777();
        class_2680 state = AutoHitCrystal.mc.field_1687.method_8320(pos);
        if (state.method_27852(class_2246.field_10540) || state.method_27852(class_2246.field_9987)) {
            if (!this.freeAbove(pos)) {
                return;
            }
            if (this.use(stack -> stack.method_31574(class_1802.field_8301), blockHit)) {
                this.timer = this.breakDelay.get();
            }
            return;
        }
        if (this.obsidian.get().booleanValue() && this.use(stack -> stack.method_31574(class_1802.field_8281), blockHit)) {
            this.timer = this.placeDelay.get();
        }
    }

    private boolean freeAbove(class_2338 pos) {
        class_2338 above = pos.method_10084();
        if (!AutoHitCrystal.mc.field_1687.method_22347(above)) {
            return false;
        }
        class_238 space = new class_238((double)above.method_10263(), (double)above.method_10264(), (double)above.method_10260(), (double)(above.method_10263() + 1), (double)(above.method_10264() + 2), (double)(above.method_10260() + 1));
        return AutoHitCrystal.mc.field_1687.method_8335(null, space).isEmpty();
    }

    private boolean use(Predicate<class_1799> item, class_3965 hit) {
        int slot = CombatItems.hotbarSlot(item);
        if (slot < 0) {
            return false;
        }
        if (this.previous < 0) {
            this.previous = AutoHitCrystal.mc.field_1724.method_31548().method_67532();
        }
        AutoHitCrystal.mc.field_1724.method_31548().method_61496(slot);
        AutoHitCrystal.mc.field_1761.method_2896(AutoHitCrystal.mc.field_1724, class_1268.field_5808, hit);
        AutoHitCrystal.mc.field_1724.method_6104(class_1268.field_5808);
        return true;
    }

    private void restore() {
        if (this.previous >= 0 && this.switchBack.get().booleanValue() && AutoHitCrystal.mc.field_1724 != null) {
            AutoHitCrystal.mc.field_1724.method_31548().method_61496(this.previous);
        }
        this.previous = -1;
    }
}

