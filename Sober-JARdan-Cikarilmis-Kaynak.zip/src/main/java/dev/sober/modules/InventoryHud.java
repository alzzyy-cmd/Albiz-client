/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.Setting;

public final class InventoryHud
extends Module {
    public final Setting<Boolean> emptySlots = this.add(new BoolSetting("Empty Slots", "Show subtle cells for empty slots.", true));

    public InventoryHud() {
        super("Inventory HUD", "Movable inventory grid for the HUD editor.", Category.CLIENT);
    }

    @Override
    public boolean showInHud() {
        return false;
    }
}

