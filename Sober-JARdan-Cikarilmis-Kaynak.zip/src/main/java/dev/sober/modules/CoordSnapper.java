/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_746
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_746;

public class CoordSnapper
extends Module {
    private boolean reported;

    public CoordSnapper() {
        super("Coord Snapper", "Writes the coordinates where you died into your chat.", Category.CLIENT);
    }

    @Override
    public void onDisable() {
        this.reported = false;
    }

    @Override
    public void onGameLeft() {
        this.reported = false;
    }

    @Override
    public void onTick() {
        class_746 player = CoordSnapper.mc.field_1724;
        if (player == null || CoordSnapper.mc.field_1687 == null) {
            return;
        }
        if (!player.method_29504() && player.method_6032() > 0.0f) {
            this.reported = false;
            return;
        }
        if (this.reported) {
            return;
        }
        this.reported = true;
        class_2338 pos = player.method_24515();
        this.info("You died at %d %d %d in the %s.", pos.method_10263(), pos.method_10264(), pos.method_10260(), this.dimension());
    }

    private String dimension() {
        if (CoordSnapper.mc.field_1687.method_27983() == class_1937.field_25180) {
            return "Nether";
        }
        if (CoordSnapper.mc.field_1687.method_27983() == class_1937.field_25181) {
            return "End";
        }
        if (CoordSnapper.mc.field_1687.method_27983() == class_1937.field_25179) {
            return "Overworld";
        }
        return CoordSnapper.mc.field_1687.method_27983().method_29177().method_12832();
    }
}

