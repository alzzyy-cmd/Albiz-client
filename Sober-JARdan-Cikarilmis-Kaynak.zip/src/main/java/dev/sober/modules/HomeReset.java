/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import dev.sober.util.DonutUtils;

public class HomeReset
extends Module {
    private final Setting<String> home = this.add(new StringSetting("Home", "Name or number of the home that gets reset.", "1"));
    private final Setting<Integer> delay = this.add(new IntSetting("Delay", "Ticks between /delhome and /sethome.", 10, 0, 60));
    private int timer;

    public HomeReset() {
        super("Home Reset", "Deletes a home and sets it again where you stand, with one key press.", Category.DONUT);
    }

    @Override
    public void onEnable() {
        if (HomeReset.mc.field_1724 == null || this.name().isEmpty()) {
            if (this.name().isEmpty()) {
                this.warning("Set a home name first.", new Object[0]);
            }
            this.setEnabled(false);
            return;
        }
        DonutUtils.command("delhome " + this.name());
        this.timer = this.delay.get();
    }

    @Override
    public void onTick() {
        if (HomeReset.mc.field_1724 == null) {
            this.setEnabled(false);
            return;
        }
        if (this.timer-- > 0) {
            return;
        }
        DonutUtils.command("sethome " + this.name());
        this.info("Home %s was reset here.", this.name());
        this.setEnabled(false);
    }

    private String name() {
        String text = this.home.get().trim();
        return text.startsWith("/") ? text.substring(1).trim() : text;
    }
}

