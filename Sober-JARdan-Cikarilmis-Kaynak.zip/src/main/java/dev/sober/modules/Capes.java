/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10055
 *  net.minecraft.class_11890
 *  net.minecraft.class_12079$class_10726
 *  net.minecraft.class_12079$class_12081
 *  net.minecraft.class_2960
 *  net.minecraft.class_8685
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.CapeTexture;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_10055;
import net.minecraft.class_11890;
import net.minecraft.class_12079;
import net.minecraft.class_2960;
import net.minecraft.class_8685;

public class Capes
extends Module {
    private static final class_12079.class_12081 ELYTRA = new class_12079.class_10726(class_2960.method_60656((String)"entity/equipment/wings/elytra"));
    public final Setting<Style> style = this.add(new EnumSetting<Style>("Style", "Sober is the glowing SC logo on dark charcoal. Sober Shine has a light that sweeps over it. Neon Logo draws the logo as flickering white neon. Drip shows the SOBER CLIENT lettering with silver drops running down. Badge shows the round Sober badge turning slowly. Wordmark shows the SOBER CLIENT lettering with the SC logo. Lightning flashes white bolts behind the logo. Night Sky has twinkling stars and a glowing logo. Smoke has slowly rising silver smoke. Chrome shimmers like polished metal.", Style.SoberShine));
    public final Setting<Boolean> effects = this.add(new BoolSetting("Effects", "Plays the moving effect of the style. Off keeps the cape still.", true));
    public final Setting<Boolean> alwaysShow = this.add(new BoolSetting("Always Show", "Shows the cape even when capes are turned off in your skin settings.", true));

    public Capes() {
        super("Capes", "A SoberClient cape with the logo in different styles and effects. Only you can see it.", Category.VISUALS);
    }

    public static void apply(class_11890 entity, class_10055 state) {
        if (entity != Capes.mc.field_1724) {
            return;
        }
        Capes module = SoberClient.MODULES.get(Capes.class);
        if (module == null || !module.isActive()) {
            return;
        }
        class_12079.class_12081 cape = CapeTexture.asset(module.style.get(), module.effects.get());
        class_8685 skin = state.field_53520;
        state.field_53520 = new class_8685(skin.comp_1626(), cape, skin.comp_1628() != null ? skin.comp_1628() : ELYTRA, skin.comp_1629(), skin.comp_1630());
        if (module.alwaysShow.get().booleanValue()) {
            state.field_53532 = true;
        }
    }

    public static enum Style {
        Sober("Sober"),
        SoberShine("Sober Shine"),
        NeonBottle("Neon Logo"),
        Drip("Drip"),
        Badge("Badge"),
        Wordmark("Wordmark"),
        Lightning("Lightning"),
        NightSky("Night Sky"),
        Smoke("Smoke"),
        Chrome("Chrome");

        private final String label;

        private Style(String label) {
            this.label = label;
        }

        public String toString() {
            return this.label;
        }
    }
}

