/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_332
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.gui.CrosshairRenderer;
import dev.sober.gui.Theme;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.Freecam;
import dev.sober.modules.Freelook;
import dev.sober.render.Color;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_332;

public class CustomCrosshair
extends Module {
    private final Setting<Style> style = this.add(new EnumSetting<Style>("Style", "Sober Bottle is the SoberClient bottle, Island Sun a dot with rays, Wave a wavy ring, SoberClient Y three arms, plus classic Cross, Ring, Brackets and Dot.", Style.Bottle));
    private final Setting<Tint> tint = this.add(new EnumSetting<Tint>("Color Mode", "Theme uses your GUI accent color, also rainbow and galaxy. Custom uses your own color.", Tint.Theme));
    private final Setting<Color> color = this.add(new ColorSetting("Color", "Color of the crosshair.", new Color(95, 227, 238, 255))).visible(() -> this.tint.get() == Tint.Custom);
    private final Setting<Integer> size = this.add(new IntSetting("Size", "Size of the crosshair in screen pixels.", 9, 3, 30));
    private final Setting<Integer> thickness = this.add(new IntSetting("Thickness", "Line thickness in screen pixels.", 2, 1, 6));
    private final Setting<Integer> gap = this.add(new IntSetting("Gap", "Space between the center and the lines.", 3, 0, 15)).visible(() -> this.style.get() != Style.Bottle && this.style.get() != Style.Dot);
    private final Setting<Integer> opacity = this.add(new IntSetting("Opacity", "How visible the crosshair is in percent.", 100, 20, 100));
    private final Setting<Boolean> outline = this.add(new BoolSetting("Outline", "Thin dark border so the crosshair is visible on any background.", true));
    private final Setting<Boolean> glow = this.add(new BoolSetting("Glow", "Soft glow in the crosshair color.", true));
    private final Setting<Boolean> dynamic = this.add(new BoolSetting("Dynamic", "The lines spread a little while you move and right after you attack.", false)).visible(() -> this.style.get() != Style.Bottle && this.style.get() != Style.Dot);
    private final Setting<Indicator> indicator = this.add(new EnumSetting<Indicator>("Attack Indicator", "Animated draws a small clean bar under the crosshair that fills up while your sword or axe recharges and glows when a full hit is ready. Vanilla keeps the Minecraft bar.", Indicator.Animated));
    private final Setting<Boolean> hitAnimation = this.add(new BoolSetting("Hit Animation", "The crosshair pops and an X flies outwards when you hit a player or mob.", true));
    private final Setting<Boolean> freeCamera = this.add(new BoolSetting("Freecam & Freelook", "Also shows the crosshair while Freecam or Freelook is on.", true));
    private float spread;
    private float lastCooldown = 1.0f;
    private long hitAt;
    private long readyAt;
    private boolean wasCharging;
    private float barProgress = 1.0f;
    private float barShown;
    private long lastFrame = System.nanoTime();

    public CustomCrosshair() {
        super("Custom Crosshair", "Replaces the Minecraft crosshair with SoberClient designs in your theme color, with an animated attack indicator.", Category.VISUALS);
    }

    private static CustomCrosshair instance() {
        return SoberClient.MODULES.get(CustomCrosshair.class);
    }

    public static boolean render(class_332 context) {
        CustomCrosshair crosshair = CustomCrosshair.instance();
        if (crosshair == null || !crosshair.isActive() || CustomCrosshair.mc.field_1724 == null) {
            return false;
        }
        crosshair.draw(context);
        return true;
    }

    public static boolean showsInFreeCamera() {
        CustomCrosshair crosshair = CustomCrosshair.instance();
        if (crosshair == null || !crosshair.isActive() || !crosshair.freeCamera.get().booleanValue()) {
            return false;
        }
        Freecam freecam = SoberClient.MODULES.get(Freecam.class);
        Freelook freelook = SoberClient.MODULES.get(Freelook.class);
        return freecam != null && freecam.isActive() || freelook != null && freelook.isActive();
    }

    public static boolean hidesVanillaIndicator() {
        CustomCrosshair crosshair = CustomCrosshair.instance();
        return crosshair != null && crosshair.isActive() && crosshair.indicator.get() != Indicator.Vanilla;
    }

    private int baseColor() {
        return switch (this.tint.get().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> Theme.accent();
            case 1 -> 0xFF000000 | this.color.get().packed();
            case 2 -> -1;
        };
    }

    private void draw(class_332 context) {
        float t;
        long now = System.nanoTime();
        float delta = Math.min(0.1f, (float)(now - this.lastFrame) / 1.0E9f);
        this.lastFrame = now;
        float cooldown = CustomCrosshair.mc.field_1724.method_7261(mc.method_61966().method_60637(true));
        float target = 0.0f;
        if (this.dynamic.get().booleanValue()) {
            double speed = Math.hypot(CustomCrosshair.mc.field_1724.method_18798().field_1352, CustomCrosshair.mc.field_1724.method_18798().field_1350) * 20.0;
            target += (float)Math.min(4.0, speed * 0.6);
            target += (1.0f - cooldown) * 4.0f;
            if (!CustomCrosshair.mc.field_1724.method_24828()) {
                target += 2.0f;
            }
        }
        this.spread += (target - this.spread) * (1.0f - (float)Math.exp(-delta * 14.0f));
        int color = this.baseColor();
        float visible = (float)this.opacity.get().intValue() / 100.0f;
        long millis = System.currentTimeMillis();
        long sinceHit = millis - this.hitAt;
        int shown = this.size.get();
        if (this.hitAnimation.get().booleanValue() && sinceHit < 220L) {
            t = 1.0f - (float)sinceHit / 220.0f;
            shown = Math.round((float)this.size.get().intValue() * (1.0f + 0.35f * t * t));
        }
        CrosshairRenderer.draw(context, this.style.get().shape, shown, this.thickness.get(), this.gap.get() + Math.round(this.spread), this.outline.get(), this.glow.get(), color, visible);
        if (this.indicator.get() == Indicator.Animated) {
            this.drawIndicator(context, cooldown, color, visible, millis, delta);
        }
        if (this.hitAnimation.get().booleanValue() && sinceHit < 300L) {
            t = (float)sinceHit / 300.0f;
            float ease = 1.0f - (1.0f - t) * (1.0f - t) * (1.0f - t);
            CrosshairRenderer.draw(context, CrosshairRenderer.Shape.HIT, this.size.get() + 3 + Math.round(ease * 7.0f), Math.max(1, this.thickness.get()), 0, this.outline.get(), false, -1, visible * (1.0f - t));
        }
    }

    private void drawIndicator(class_332 context, float cooldown, int color, float visible, long millis, float delta) {
        class_1309 living;
        class_1297 class_12972;
        boolean charging;
        int offset = Math.max(9, Math.round((float)this.size.get().intValue() * 0.9f + (float)this.gap.get().intValue() + (float)this.thickness.get().intValue() + 5.0f));
        int width = Math.max(16, Math.round((float)this.size.get().intValue() * 2.2f + (float)this.gap.get().intValue() * 2.0f + 4.0f));
        int height = Math.max(2, Math.min(4, this.thickness.get() + 1));
        boolean bl = charging = cooldown < 1.0f;
        if (charging && !this.wasCharging) {
            this.barProgress = cooldown;
        }
        this.barProgress += (cooldown - this.barProgress) * (1.0f - (float)Math.exp(-delta * 30.0f));
        if (cooldown < this.barProgress) {
            this.barProgress = cooldown;
        }
        boolean target = (class_12972 = CustomCrosshair.mc.field_1692) instanceof class_1309 && (living = (class_1309)class_12972).method_5805();
        float show = charging || target ? 1.0f : 0.0f;
        this.barShown += (show - this.barShown) * (1.0f - (float)Math.exp(-delta * (show > this.barShown ? 22.0f : 9.0f)));
        if (charging) {
            this.wasCharging = true;
        } else if (this.wasCharging) {
            this.wasCharging = false;
            this.readyAt = millis;
        }
        long sinceReady = millis - this.readyAt;
        float flash = sinceReady < 320L ? 1.0f - (float)sinceReady / 320.0f : 0.0f;
        float shown = Math.max(this.barShown, flash);
        if (shown <= 0.01f) {
            return;
        }
        float halo = charging ? 0.0f : Math.max(flash, target ? 0.45f + 0.3f * (float)Math.sin((double)millis / 160.0) : 0.0f);
        CrosshairRenderer.bar(context, offset, width, height, charging ? this.barProgress : 1.0f, color, this.outline.get(), visible * shown, halo);
    }

    @Override
    public void onTick() {
        if (CustomCrosshair.mc.field_1724 == null) {
            return;
        }
        float cooldown = CustomCrosshair.mc.field_1724.method_7261(0.0f);
        if (this.lastCooldown > 0.85f && cooldown < 0.3f && CustomCrosshair.mc.field_1692 != null) {
            this.hitAt = System.currentTimeMillis();
        }
        this.lastCooldown = cooldown;
    }

    @Override
    public String getInfoString() {
        return this.style.get().toString();
    }

    @Override
    public boolean showInHud() {
        return false;
    }

    public static enum Style {
        Bottle("Sober Bottle", CrosshairRenderer.Shape.BOTTLE),
        Sun("Island Sun", CrosshairRenderer.Shape.SUN),
        Wave("Wave", CrosshairRenderer.Shape.WAVE),
        Y("SoberClient Y", CrosshairRenderer.Shape.Y),
        Cross("Cross", CrosshairRenderer.Shape.CROSS),
        Ring("Ring", CrosshairRenderer.Shape.RING),
        Brackets("Brackets", CrosshairRenderer.Shape.BRACKETS),
        Dot("Dot", CrosshairRenderer.Shape.DOT);

        private final String title;
        private final CrosshairRenderer.Shape shape;

        private Style(String title, CrosshairRenderer.Shape shape) {
            this.title = title;
            this.shape = shape;
        }

        public String toString() {
            return this.title;
        }
    }

    public static enum Tint {
        Theme,
        Custom,
        White;

    }

    public static enum Indicator {
        Animated,
        Vanilla,
        Off;

    }
}

