/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;
import dev.sober.module.ModuleRegistry;

public final class Hotkeys
extends BusModule {
    public Hotkeys() {
        super("hotkeys", "Hotkeys", "Lists the modules you have bound to a key, and their keys.", ModuleCategory.CLIENT);
    }

    public static Hotkeys get() {
        return ModuleRegistry.get(Hotkeys.class);
    }

    public static boolean shouldShowHud() {
        Hotkeys module = Hotkeys.get();
        return module != null && module.isEnabled();
    }
}

