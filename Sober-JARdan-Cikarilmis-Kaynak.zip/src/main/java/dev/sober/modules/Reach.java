/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1657
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.util.Locale;
import net.minecraft.class_1657;

public class Reach
extends Module {
    private static volatile Reach instance;
    private final Setting<Integer> entity = this.add(new IntSetting("Entity Reach", "Extra reach for hitting players and mobs, in tenths of a block.", 5, 0, 30));
    private final Setting<Integer> block = this.add(new IntSetting("Block Reach", "Extra reach for breaking and placing blocks, in tenths of a block.", 5, 0, 30));

    public Reach() {
        super("Reach", "Lets you hit players and reach blocks from further away.", Category.MOVEMENT);
        instance = this;
    }

    private static Reach active(class_1657 player) {
        Reach module = instance;
        return module != null && module.isActive() && player == Reach.mc.field_1724 ? module : null;
    }

    public static double entityExtra(class_1657 player) {
        Reach module = Reach.active(player);
        return module == null ? 0.0 : (double)module.entity.get().intValue() / 10.0;
    }

    public static double blockExtra(class_1657 player) {
        Reach module = Reach.active(player);
        return module == null ? 0.0 : (double)module.block.get().intValue() / 10.0;
    }

    @Override
    public String getInfoString() {
        return String.format(Locale.ROOT, "+%.1f", (double)this.entity.get().intValue() / 10.0);
    }
}

