/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_5911
 *  net.minecraft.class_746
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_746;

public class NoFall
extends Module {
    public NoFall() {
        super("No Fall", "You take no fall damage.", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        class_746 player = NoFall.mc.field_1724;
        if (player == null || player.method_31549().field_7477 || player.method_7325() || player.method_6128() || player.method_24828()) {
            return;
        }
        if (player.field_6017 > 2.0 && player.method_18798().field_1351 < 0.0) {
            player.field_3944.method_52787((class_2596)new class_2828.class_5911(true, player.field_5976));
        }
    }
}

