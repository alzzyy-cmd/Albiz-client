/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.gui.Theme;

final class CosmeticAccent {
    private CosmeticAccent() {
    }

    static int argb() {
        return 0xFF000000 | Theme.accent();
    }
}

