/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;

public final class Sprint
extends BusModule {
    private static volatile Sprint active;

    public Sprint() {
        super("sprint", "Sprint", "Keeps you sprinting while you move forward, like vanilla Toggle Sprint.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEnable() {
        active = this;
    }

    @Override
    public void onDisable() {
        active = null;
    }

    public static boolean holding() {
        return active != null;
    }
}

