/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.ints.Int2DoubleOpenHashMap
 *  it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap
 *  java.lang.MatchException
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 */
package dev.sober.modules;

import dev.sober.gui.Theme;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.Color;
import dev.sober.render.Render3D;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import it.unimi.dsi.fastutil.ints.Int2DoubleOpenHashMap;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class JumpCircles
extends Module {
    private final Setting<Style> style = this.add(new EnumSetting<Style>("Style", "Sober Badge is a dark disc with the SC logo in a chrome ring. Chrome Drip is only the chrome ring with liquid drops. SC Logo is the glowing SC logo. Glow Ring is a plain glowing ring.", Style.Badge));
    private final Setting<Integer> size = this.add(new IntSetting("Size", "Size of the circle at its biggest, in tenths of a block.", 24, 6, 60));
    private final Setting<Integer> duration = this.add(new IntSetting("Duration", "How long a circle stays in milliseconds.", 1100, 300, 4000));
    private final Setting<Boolean> spin = this.add(new BoolSetting("Spin", "The circle turns while it grows.", true));
    private final Setting<ColorMode> colorMode = this.add(new EnumSetting<ColorMode>("Color Mode", "Original keeps the colors of the logo. Custom, Theme and Rainbow tint it.", ColorMode.Original));
    private final Setting<Color> color = this.add(new ColorSetting("Color", "Tint of the circles.", new Color(230, 230, 236, 255))).visible(() -> this.colorMode.get() == ColorMode.Custom);
    private final Setting<Boolean> ring = this.add(new BoolSetting("Outer Ring", "A glowing double ring spreads out around the circle, always centered on it.", true));
    private final Setting<Color> ringColor = this.add(new ColorSetting("Ring Color", "Color of the outer ring. With Theme or Rainbow it follows the circle.", new Color(236, 76, 200, 255))).visible(() -> this.ring.get() != false && (this.colorMode.get() == ColorMode.Original || this.colorMode.get() == ColorMode.Custom));
    private final Setting<Boolean> landing = this.add(new BoolSetting("On Landing", "Also shows a circle when you land after a jump or a fall.", false));
    private final Setting<Boolean> others = this.add(new BoolSetting("Others", "Shows circles for other players near you too.", false));
    private final List<Circle> circles = new ArrayList<Circle>();
    private final Int2IntOpenHashMap air = new Int2IntOpenHashMap();
    private final Int2DoubleOpenHashMap groundY = new Int2DoubleOpenHashMap();
    private double hue;
    private int turn = 1;

    public JumpCircles() {
        super("Jump Circles", "A glowing SoberClient circle spreads out on the ground under you every time you jump.", Category.VISUALS);
    }

    @Override
    public void onDisable() {
        this.circles.clear();
        this.air.clear();
        this.groundY.clear();
    }

    @Override
    public void onTick() {
        if (JumpCircles.mc.field_1687 == null || JumpCircles.mc.field_1724 == null) {
            return;
        }
        long now = System.currentTimeMillis();
        for (class_1657 player : JumpCircles.mc.field_1687.method_18456()) {
            if (player != JumpCircles.mc.field_1724 && (!this.others.get().booleanValue() || player.method_5858((class_1297)JumpCircles.mc.field_1724) > 2304.0)) continue;
            if (player.method_7325() || player.method_31549().field_7479 || player.method_5765()) {
                this.air.put(player.method_5628(), 0);
                continue;
            }
            int id = player.method_5628();
            boolean ground = player.method_24828();
            int ticksInAir = this.air.getOrDefault(id, 0);
            if (ground) {
                if (ticksInAir > 3 && this.landing.get().booleanValue()) {
                    this.spawn(player.method_23317(), player.method_23318(), player.method_23321(), now);
                }
                this.air.put(id, 0);
                this.groundY.put(id, player.method_23318());
                continue;
            }
            if (ticksInAir == 0 && this.groundY.containsKey(id) && player.method_23318() > this.groundY.get(id) + 0.05 && player.method_18798().field_1351 > 0.1) {
                this.spawn(player.field_6014, this.groundY.get(id), player.field_5969, now);
            }
            this.air.put(id, ticksInAir + 1);
        }
        if (this.air.size() > 128) {
            this.air.clear();
            this.groundY.clear();
        }
    }

    private void spawn(double x, double y, double z, long now) {
        if (this.circles.size() >= 48) {
            this.circles.remove(0);
        }
        this.hue += 0.09;
        this.turn = -this.turn;
        this.circles.add(new Circle(x, y, z, now, this.hue, this.turn));
    }

    private Color colorFor(Circle circle) {
        return switch (this.colorMode.get().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> {
                if (this.style.get() == Style.Ring) {
                    yield new Color(232, 232, 238, 255);
                }
                yield Color.WHITE;
            }
            case 1 -> this.color.get().withAlpha(255);
            case 2 -> Color.fromPacked(Theme.accent(circle.hue())).withAlpha(255);
            case 3 -> Color.fromHsv((float)(circle.hue() % 1.0), 0.6f, 1.0f, 255);
        };
    }

    private Color ringColorFor(Circle circle) {
        return switch (this.colorMode.get().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0, 1 -> this.ringColor.get().withAlpha(255);
            case 2, 3 -> this.colorFor(circle);
        };
    }

    @Override
    public void onRender(Render3D renderer) {
        if (this.circles.isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        double life = Math.max(1, this.duration.get());
        double max = (double)this.size.get().intValue() / 10.0;
        String texture = this.style.get().texture;
        renderer.setDepthTest(true);
        Iterator<Circle> iterator = this.circles.iterator();
        while (iterator.hasNext()) {
            Circle circle = iterator.next();
            double t = (double)(now - circle.start()) / life;
            if (t >= 1.0) {
                iterator.remove();
                continue;
            }
            double grow = 1.0 - Math.pow(1.0 - t, 3.0);
            double fade = t < 0.12 ? t / 0.12 : Math.pow(1.0 - (t - 0.12) / 0.88, 1.6);
            double scale = max * (0.3 + 0.7 * grow);
            double rotation = this.spin.get() != false ? (double)circle.turn() * grow * 2.4 : 0.0;
            renderer.decal(texture, circle.x(), circle.y() + 0.015, circle.z(), scale, rotation, this.colorFor(circle).scaleAlpha(fade));
            if (!this.ring.get().booleanValue()) continue;
            this.wave(renderer, circle, t, max);
        }
        renderer.setDepthTest(false);
    }

    private void wave(Render3D renderer, Circle circle, double t, double max) {
        double spread = 1.0 - Math.pow(1.0 - t, 4.0);
        double fade = Math.min(1.0, t / 0.06) * Math.pow(1.0 - t, 1.7);
        Color base = this.ringColorFor(circle);
        Color light = base.lerp(Color.WHITE, 0.3);
        double x = circle.x();
        double y = circle.y() + 0.02;
        double z = circle.z();
        double outer = max * (0.17 + 0.55 * spread);
        double inner = max * (0.15 + 0.45 * spread);
        double width = max * 0.006 * (1.0 - 0.35 * t);
        if (outer - inner > width * 3.0) {
            renderer.disc(x, y, z, inner + width, outer - width * 1.4, base.scaleAlpha(0.1 * fade), base.scaleAlpha(0.1 * fade), 64);
        }
        JumpCircles.line(renderer, x, y, z, inner, width, max * 0.035, light.scaleAlpha(0.95 * fade));
        JumpCircles.line(renderer, x, y, z, outer, width * 1.4, max * 0.05, base.scaleAlpha(0.8 * fade));
    }

    private static void line(Render3D renderer, double x, double y, double z, double radius, double width, double glow, Color color) {
        Color halo = color.scaleAlpha(0.3);
        renderer.disc(x, y, z, Math.max(0.0, radius - glow), radius, halo.withAlpha(0), halo, 64);
        renderer.disc(x, y, z, radius, radius + glow, halo, halo.withAlpha(0), 64);
        renderer.disc(x, y, z, radius - width, radius + width, color, color, 64);
    }

    public static enum Style {
        Badge("Sober Badge", "effects/jump_badge"),
        Drip("Chrome Drip", "effects/jump_drip"),
        Bottle("SC Logo", "effects/jump_bottle"),
        Ring("Glow Ring", "effects/jump_ring");

        private final String title;
        final String texture;

        private Style(String title, String texture) {
            this.title = title;
            this.texture = texture;
        }

        public String toString() {
            return this.title;
        }
    }

    public static enum ColorMode {
        Original,
        Custom,
        Theme,
        Rainbow;

    }

    private record Circle(double x, double y, double z, long start, double hue, int turn) {
    }
}

