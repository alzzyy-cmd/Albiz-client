/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1531
 *  net.minecraft.class_1657
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.util.Locale;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;

public class Hitbox
extends Module {
    private static volatile Hitbox instance;
    private final Setting<Integer> expand = this.add(new IntSetting("Expand", "Extra size around every hitbox, in hundredths of a block.", 20, 1, 100));
    private final Setting<Targets> targets = this.add(new EnumSetting<Targets>("Targets", "Whose hitboxes get bigger.", Targets.Players));

    public Hitbox() {
        super("Hitbox", "Makes the hitboxes of players and mobs bigger, so they are easier to hit.", Category.COMBAT);
        instance = this;
    }

    public static float extra(class_1297 entity) {
        Hitbox module = instance;
        if (module == null || !module.isActive() || entity == Hitbox.mc.field_1724 || !(entity instanceof class_1309) || entity instanceof class_1531) {
            return 0.0f;
        }
        boolean player = entity instanceof class_1657;
        boolean wanted = switch (module.targets.get().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> player;
            case 1 -> {
                if (!player) {
                    yield true;
                }
                yield false;
            }
            case 2 -> true;
        };
        return wanted ? (float)module.expand.get().intValue() / 100.0f : 0.0f;
    }

    @Override
    public String getInfoString() {
        return String.format(Locale.ROOT, "%.2f", Float.valueOf((float)this.expand.get().intValue() / 100.0f));
    }

    public static enum Targets {
        Players,
        Mobs,
        All;

    }
}

