/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.util.concurrent.ThreadLocalRandom;

public class AutoJumpReset
extends Module {
    private final Setting<Integer> chance = this.add(new IntSetting("Chance", "How often it jumps when you get hit, in percent.", 100, 1, 100));
    private final Setting<Integer> delay = this.add(new IntSetting("Delay", "Ticks to wait after the hit before jumping.", 0, 0, 3));
    private boolean holding;

    public AutoJumpReset() {
        super("Auto Jump Reset", "Jumps right when you take a hit, so you take less knockback.", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        this.release();
    }

    @Override
    public void onTick() {
        if (AutoJumpReset.mc.field_1724 == null || AutoJumpReset.mc.field_1755 != null) {
            this.release();
            return;
        }
        if (this.holding) {
            this.release();
            return;
        }
        if (AutoJumpReset.mc.field_1724.field_6235 == 0 || AutoJumpReset.mc.field_1724.field_6235 != AutoJumpReset.mc.field_1724.field_6254 - 1 - this.delay.get()) {
            return;
        }
        if (!AutoJumpReset.mc.field_1724.method_24828() || AutoJumpReset.mc.field_1724.method_5799() || AutoJumpReset.mc.field_1724.method_5771()) {
            return;
        }
        if (ThreadLocalRandom.current().nextInt(100) >= this.chance.get()) {
            return;
        }
        AutoJumpReset.mc.field_1690.field_1903.method_23481(true);
        this.holding = true;
    }

    private void release() {
        if (!this.holding) {
            return;
        }
        this.holding = false;
        AutoJumpReset.mc.field_1690.field_1903.method_23481(false);
    }
}

