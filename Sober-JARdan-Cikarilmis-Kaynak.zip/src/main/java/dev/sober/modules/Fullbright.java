/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;

public class Fullbright
extends Module {
    public final Setting<Mode> mode = this.add(new EnumSetting<Mode>("Mode", "Gamma turns the brightness far above the normal maximum. Night Vision looks like the night vision potion.", Mode.Gamma));
    public final Setting<Integer> brightness = this.add(new IntSetting("Brightness", "How bright the game gets, in percent.", 100, 10, 100)).visible(() -> this.mode.get() == Mode.Gamma);

    public Fullbright() {
        super("Fullbright", "Makes the whole game bright, even in caves and at night.", Category.VISUALS);
    }

    private static Fullbright instance() {
        Fullbright module = SoberClient.MODULES.get(Fullbright.class);
        return module != null && module.isActive() ? module : null;
    }

    public static float gamma(float value) {
        Fullbright module = Fullbright.instance();
        if (module == null || module.mode.get() != Mode.Gamma) {
            return value;
        }
        return Math.max(value, 1.0f + 15.0f * (float)module.brightness.get().intValue() / 100.0f);
    }

    public static float nightVision(float value) {
        Fullbright module = Fullbright.instance();
        return module != null && module.mode.get() == Mode.NightVision ? 1.0f : value;
    }

    public static enum Mode {
        Gamma,
        NightVision;

    }
}

