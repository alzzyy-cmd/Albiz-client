/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_2338
 */
package dev.sober.modules;

import dev.sober.mixin.InteractionManagerAccessor;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_2338;

public class SpeedMine
extends Module {
    private final Setting<Mode> mode = this.add(new EnumSetting<Mode>("Mode", "Damage mines every block faster by the speed below. Early Finish breaks the block as soon as it reaches the progress below. Haste gives you a Haste effect that only you can see.", Mode.Damage));
    private final Setting<Integer> speed = this.add(new IntSetting("Speed", "How much faster you mine in percent. 100 is normal speed.", 140, 100, 300)).visible(() -> this.mode.get() == Mode.Damage);
    private final Setting<Integer> finishAt = this.add(new IntSetting("Finish At", "Progress in percent at which the block breaks.", 75, 40, 100)).visible(() -> this.mode.get() == Mode.Finish);
    private final Setting<Integer> haste = this.add(new IntSetting("Haste Level", "Level of the Haste effect.", 2, 1, 4)).visible(() -> this.mode.get() == Mode.Haste);
    private final Setting<Boolean> noDelay = this.add(new BoolSetting("No Break Delay", "Removes the short pause before you can start on the next block.", true));
    private class_2338 lastPos;
    private float lastProgress;
    private boolean gaveHaste;

    public SpeedMine() {
        super("Speed Mine", "Mines blocks faster. Servers with an anticheat can flag it, so keep the speed low there.", Category.MOVEMENT);
    }

    @Override
    public void onDisable() {
        this.removeHaste();
        this.lastPos = null;
    }

    @Override
    public void onTick() {
        if (SpeedMine.mc.field_1724 == null || SpeedMine.mc.field_1761 == null) {
            return;
        }
        InteractionManagerAccessor manager = (InteractionManagerAccessor)SpeedMine.mc.field_1761;
        if (this.noDelay.get().booleanValue()) {
            manager.sober$setBreakingCooldown(0);
        }
        if (this.mode.get() == Mode.Haste) {
            class_1293 current = SpeedMine.mc.field_1724.method_6112(class_1294.field_5917);
            if (current == null || current.method_5584() < 40 && this.gaveHaste) {
                SpeedMine.mc.field_1724.method_6092(new class_1293(class_1294.field_5917, 200, this.haste.get() - 1, false, false, false));
                this.gaveHaste = true;
            }
            return;
        }
        this.removeHaste();
        if (!manager.sober$breaking()) {
            this.lastPos = null;
            return;
        }
        class_2338 pos = manager.sober$breakingPos();
        float progress = manager.sober$breakingProgress();
        if (this.mode.get() == Mode.Finish) {
            if (progress >= (float)this.finishAt.get().intValue() / 100.0f && progress < 1.0f) {
                manager.sober$setBreakingProgress(1.0f);
            }
        } else if (pos != null && pos.equals((Object)this.lastPos) && progress > this.lastProgress) {
            float boosted = progress + (progress - this.lastProgress) * ((float)this.speed.get().intValue() / 100.0f - 1.0f);
            manager.sober$setBreakingProgress(Math.min(1.0f, boosted));
            progress = Math.min(1.0f, boosted);
        }
        this.lastPos = pos == null ? null : pos.method_10062();
        this.lastProgress = progress;
    }

    private void removeHaste() {
        if (!this.gaveHaste || SpeedMine.mc.field_1724 == null) {
            return;
        }
        SpeedMine.mc.field_1724.method_6016(class_1294.field_5917);
        this.gaveHaste = false;
    }

    @Override
    public String getInfoString() {
        return switch (this.mode.get().ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> String.valueOf(this.speed.get()) + "%";
            case 1 -> String.valueOf(this.finishAt.get()) + "%";
            case 2 -> "Haste " + String.valueOf(this.haste.get());
        };
    }

    public static enum Mode {
        Damage("Damage"),
        Finish("Early Finish"),
        Haste("Haste");

        private final String title;

        private Mode(String title) {
            this.title = title;
        }

        public String toString() {
            return this.title;
        }
    }
}

