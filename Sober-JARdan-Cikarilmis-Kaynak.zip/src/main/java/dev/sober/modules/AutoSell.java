/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1703
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.ItemSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import dev.sober.util.DonutUtils;
import dev.sober.util.InvUtil;
import java.util.ArrayList;
import java.util.Iterator;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class AutoSell
extends Module {
    private final Setting<Mode> mode = this.add(new EnumSetting<Mode>("Mode", "Sell: /sell GUI. Order: deliver to the best paying /order.", Mode.Sell));
    private final Setting<class_1792> item = this.add(new ItemSetting("Item", "Item to sell (item id, e.g. sea_pickle).", class_1802.field_17498));
    private final Setting<String> targetPlayer = this.add(new StringSetting("Order Player", "Only deliver to orders of this player (empty = anyone).", "")).visible(() -> this.mode.get() == Mode.Order);
    private final Setting<Integer> delay = this.add(new IntSetting("Delay", "Delay in ticks between moving stacks.", 2, 0, 20));
    private final Setting<Boolean> quickDeliver = this.add(new BoolSetting("Quick Deliver", "Move all matching stacks in a single tick.", true));
    private int wait;

    public AutoSell() {
        super("Auto Sell", "Automatically sells the chosen item via /sell or /order.", Category.DONUT);
    }

    @Override
    public void onEnable() {
        this.wait = 0;
    }

    @Override
    public void onTick() {
        if (this.wait > 0) {
            --this.wait;
            return;
        }
        class_1703 class_17032 = AutoSell.mc.field_1724.field_7512;
        if (!(class_17032 instanceof class_1707)) {
            this.openGui();
            return;
        }
        class_1707 container = (class_1707)class_17032;
        switch (container.method_17388()) {
            case 4: {
                this.depositItems(container);
                break;
            }
            case 6: {
                if (this.mode.get() != Mode.Order) break;
                this.pickOrder(container);
                break;
            }
            case 3: {
                if (this.mode.get() != Mode.Order) break;
                DonutUtils.click(container.field_7763, 15, 1, class_1713.field_7794);
                this.wait = 10;
                break;
            }
        }
    }

    private void openGui() {
        if (!InvUtil.has(this.item.get())) {
            this.wait = 20;
            return;
        }
        if (this.mode.get() == Mode.Sell) {
            DonutUtils.command("sell");
        } else {
            Object name;
            Object object = name = this.item.get() == class_1802.field_8606 ? "Bones" : this.item.get().method_63680().getString();
            if (!this.targetPlayer.get().isBlank()) {
                name = (String)name + " " + this.targetPlayer.get().trim();
            }
            DonutUtils.command("order " + (String)name);
        }
        this.wait = 20;
    }

    private void depositItems(class_1707 container) {
        int containerSize = container.method_17388() * 9;
        ArrayList slots = new ArrayList();
        class_1799 reference = class_1799.field_8037;
        for (int slot = containerSize; slot < container.field_7761.size(); ++slot) {
            class_1799 stack = container.method_7611(slot).method_7677();
            if (stack.method_7960() || stack.method_7909() != this.item.get()) continue;
            if (reference.method_7960()) {
                reference = stack;
            }
            if (!class_1799.method_31577((class_1799)reference, (class_1799)stack)) continue;
            slots.add(slot);
        }
        if (slots.isEmpty()) {
            AutoSell.mc.field_1724.method_7346();
            this.wait = 10;
            return;
        }
        if (this.quickDeliver.get().booleanValue() || this.delay.get() == 0) {
            Iterator iterator = slots.iterator();
            while (iterator.hasNext()) {
                int slot = (Integer)iterator.next();
                DonutUtils.click(container.field_7763, slot, 0, class_1713.field_7794);
            }
            this.wait = 5;
        } else {
            DonutUtils.click(container.field_7763, (Integer)slots.getFirst(), 0, class_1713.field_7794);
            this.wait = this.delay.get();
        }
    }

    private void pickOrder(class_1707 container) {
        class_1799 sortButton = container.method_7611(47).method_7677();
        if (sortButton.method_7960()) {
            this.wait = 2;
            return;
        }
        if (!DonutUtils.isSortActive(sortButton, "Most Money Per Item")) {
            DonutUtils.click(container.field_7763, 47, 1, class_1713.field_7794);
            this.wait = 5;
            return;
        }
        for (int slot = 0; slot < 45; ++slot) {
            if (!container.method_7611(slot).method_7677().method_31574(this.item.get())) continue;
            DonutUtils.click(container.field_7763, slot, 1, class_1713.field_7794);
            this.wait = 10;
            return;
        }
        AutoSell.mc.field_1724.method_7346();
        this.wait = 40;
    }

    public static enum Mode {
        Sell,
        Order;

    }
}

