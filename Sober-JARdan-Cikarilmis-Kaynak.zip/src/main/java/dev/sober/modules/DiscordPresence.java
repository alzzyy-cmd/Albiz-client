/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_2535
 *  net.minecraft.class_310
 *  net.minecraft.class_634
 *  net.minecraft.class_642
 *  net.minecraft.class_8732
 *  org.slf4j.Logger
 *  org.slf4j.LoggerFactory
 */
package dev.sober.modules;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.sober.event.impl.TickEvent;
import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;
import dev.sober.setting.lite.BooleanSetting;
import dev.sober.setting.lite.StringSetting;
import dev.sober.util.discord.DiscordIpc;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.LockSupport;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2535;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_642;
import net.minecraft.class_8732;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DiscordPresence
extends BusModule {
    private static final Logger LOGGER = LoggerFactory.getLogger((String)"SoberClient");
    private static final String DEFAULT_APPLICATION_ID = "1559646375757615134";
    private static final String DEFAULT_LOGO = "https://cdn.discordapp.com/app-icons/1559646375757615134/0bcb337998c0af0a201594fa884e71b3.png?size=512";
    private static volatile String logo = "https://cdn.discordapp.com/app-icons/1559646375757615134/0bcb337998c0af0a201594fa884e71b3.png?size=512";
    private static volatile boolean logoChecked;
    private static final String LOGO_TEXT = "SoberClient";
    private static final String CLIENT_LINE;
    private static final String BUTTON_LABEL = "Discord";
    private static final String BUTTON_URL = "https://discord.gg/soberclient";
    private static final String IN_MENU = "In Main Menu";
    private static final String SINGLEPLAYER = "Singleplayer";
    private static final String MULTIPLAYER = "Multiplayer";
    private static final String LAN_WORLD = "LAN World";
    private static final String REALMS = "Realms";
    private static final long GAME_STARTED;
    private static final long RETRY_MIN_MS = 5000L;
    private static final long RETRY_MAX_MS = 30000L;
    private static final long IDLE_POLL_MS = 1000L;
    private static final long MIN_UPDATE_GAP_MS = 4000L;
    private static final long KEEP_ALIVE_MS = 60000L;
    private final BooleanSetting showServerIp = this.addSetting("show-server-ip", new BooleanSetting("Show Server IP", true));
    private final StringSetting applicationId = this.addSetting("application-id", new StringSetting("Application ID", "1559646375757615134"));
    private volatile Card card;
    private Link link;
    private class_2535 session;
    private long joinedAt;
    private boolean loggedIdle;

    private String applicationId() {
        String id = this.applicationId.get().trim();
        return id.isEmpty() ? DEFAULT_APPLICATION_ID : id;
    }

    public DiscordPresence() {
        super("discord-presence", "Discord Presence", "Shows SoberClient and the server you are on in your Discord status.", ModuleCategory.CLIENT);
    }

    @Override
    public void onEnable() {
        if (this.applicationId().isBlank()) {
            if (!this.loggedIdle) {
                this.loggedIdle = true;
                LOGGER.info("[Sober] Discord Presence: no Discord application id set; idle");
            }
        } else {
            this.session = null;
            this.card = new Card(IN_MENU, GAME_STARTED);
            this.link = new Link(this.link);
            this.refresh();
            this.on(TickEvent.TYPE, event -> this.refresh());
            this.link.start();
        }
    }

    @Override
    public void onDisable() {
        if (this.link != null) {
            this.link.stop();
        }
        this.session = null;
    }

    private void refresh() {
        long startedAt;
        String details;
        class_310 mc = class_310.method_1551();
        class_634 listener = mc.method_1562();
        if (listener != null) {
            if (listener.method_48296() != this.session) {
                this.session = listener.method_48296();
                this.joinedAt = System.currentTimeMillis() / 1000L;
            }
            details = this.place(mc, listener.method_45734());
            startedAt = this.joinedAt;
        } else {
            if (this.session != null && this.session.method_10758() && this.session.method_10744() instanceof class_8732) {
                return;
            }
            this.session = null;
            details = IN_MENU;
            startedAt = GAME_STARTED;
        }
        Card shown = this.card;
        if (startedAt != shown.startedAt() || !details.equals(shown.details())) {
            this.card = new Card(details, startedAt);
            this.link.wake();
        }
    }

    private String place(class_310 mc, class_642 server) {
        if (mc.method_1542()) {
            return SINGLEPLAYER;
        }
        if (server == null) {
            return MULTIPLAYER;
        }
        if (server.method_52811()) {
            return REALMS;
        }
        if (server.method_2994()) {
            return LAN_WORLD;
        }
        return this.showServerIp.get() ? server.field_3761 : MULTIPLAYER;
    }

    private static void refreshLogo(String applicationId) {
        if (logoChecked) {
            return;
        }
        logoChecked = true;
        try (HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).build();){
            HttpRequest request = HttpRequest.newBuilder(URI.create("https://discord.com/api/v10/applications/" + applicationId + "/rpc")).timeout(Duration.ofSeconds(8L)).GET().build();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() != 200) {
                return;
            }
            JsonObject body = JsonParser.parseString((String)response.body()).getAsJsonObject();
            if (body.has("icon") && body.get("icon").isJsonPrimitive()) {
                logo = "https://cdn.discordapp.com/app-icons/" + applicationId + "/" + body.get("icon").getAsString() + ".png?size=512";
            }
        }
        catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        catch (IOException | RuntimeException e) {
            LOGGER.debug("[Sober] Discord Presence: could not look up the app icon", (Throwable)e);
        }
    }

    private static JsonObject activity(Card card) {
        JsonObject activity = new JsonObject();
        activity.addProperty("details", card.details());
        activity.addProperty("state", CLIENT_LINE.strip());
        JsonObject timestamps = new JsonObject();
        timestamps.addProperty("start", (Number)card.startedAt());
        activity.add("timestamps", (JsonElement)timestamps);
        JsonObject assets = new JsonObject();
        assets.addProperty("large_image", logo);
        assets.addProperty("large_text", LOGO_TEXT);
        activity.add("assets", (JsonElement)assets);
        if (!BUTTON_URL.isEmpty()) {
            JsonObject button = new JsonObject();
            button.addProperty("label", BUTTON_LABEL);
            button.addProperty("url", BUTTON_URL);
            JsonArray buttons = new JsonArray();
            buttons.add((JsonElement)button);
            activity.add("buttons", (JsonElement)buttons);
        }
        return activity;
    }

    static {
        CLIENT_LINE = "SoberClient " + FabricLoader.getInstance().getModContainer("soberclient").map(mod -> mod.getMetadata().getVersion().getFriendlyString()).orElse("");
        GAME_STARTED = ProcessHandle.current().info().startInstant().orElseGet(Instant::now).getEpochSecond();
    }

    private record Card(String details, long startedAt) {
    }

    private final class Link
    implements Runnable {
        private final Thread thread = new Thread((Runnable)this, "Sober Discord Presence");
        private volatile boolean running = true;
        private Thread previous;
        private DiscordIpc ipc;
        private Card sent;
        private long sentAt;
        private long retryMs = 5000L;
        private String lastProblem;

        Link(Link previous) {
            this.previous = previous != null ? previous.thread : null;
            this.thread.setDaemon(true);
        }

        void start() {
            this.thread.start();
        }

        void wake() {
            LockSupport.unpark(this.thread);
        }

        void stop() {
            this.running = false;
            LockSupport.unpark(this.thread);
        }

        @Override
        public void run() {
            this.awaitPrevious();
            while (this.running) {
                block5: {
                    if (this.ipc == null && !this.connect()) {
                        this.pause(this.retryMs);
                        this.retryMs = Math.min(this.retryMs * 2L, 30000L);
                        continue;
                    }
                    try {
                        this.ipc.poll();
                        Card next = DiscordPresence.this.card;
                        long since = System.currentTimeMillis() - this.sentAt;
                        if (this.sent != null && since < (next.equals((Object)this.sent) ? 60000L : 4000L)) break block5;
                        this.send(next);
                    }
                    catch (IOException var4) {
                        this.report("lost Discord", var4);
                        this.hangUp();
                        continue;
                    }
                }
                this.pause(1000L);
            }
            if (this.ipc != null) {
                this.clear();
            }
        }

        private void awaitPrevious() {
            if (this.previous != null) {
                try {
                    this.previous.join();
                }
                catch (InterruptedException var2) {
                    this.running = false;
                }
                this.previous = null;
            }
        }

        private boolean connect() {
            try {
                this.ipc = DiscordIpc.connect(DiscordPresence.this.applicationId());
            }
            catch (IOException var2) {
                this.report("could not connect", var2);
                return false;
            }
            if (this.ipc == null) {
                return false;
            }
            LOGGER.info("[Sober] Discord Presence: connected to Discord");
            DiscordPresence.refreshLogo(DiscordPresence.this.applicationId());
            this.retryMs = 5000L;
            this.lastProblem = null;
            this.sent = null;
            return true;
        }

        private void send(Card next) throws IOException {
            try {
                this.ipc.setActivity(DiscordPresence.activity(next));
            }
            catch (DiscordIpc.RefusedException var3) {
                this.report("Discord refused the card", var3);
            }
            this.sent = next;
            this.sentAt = System.currentTimeMillis();
        }

        private void clear() {
            try {
                this.ipc.setActivity(null);
            }
            catch (DiscordIpc.RefusedException | IOException exception) {
                // empty catch block
            }
            this.hangUp();
        }

        private void hangUp() {
            this.ipc.close();
            this.ipc = null;
            this.sent = null;
        }

        private void pause(long millis) {
            LockSupport.parkNanos(TimeUnit.MILLISECONDS.toNanos(millis));
        }

        private void report(String what, Exception problem) {
            String line = what + " (" + String.valueOf(problem) + ")";
            if (!line.equals(this.lastProblem)) {
                this.lastProblem = line;
                LOGGER.warn("[Sober] Discord Presence: {}", (Object)line);
            }
        }
    }
}

