/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2ObjectMap
 *  net.minecraft.class_1944
 *  net.minecraft.class_2804
 *  net.minecraft.class_3556
 *  net.minecraft.class_3558
 *  net.minecraft.class_3562
 *  net.minecraft.class_4076
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.mixin.ChunkLightProviderAccessor;
import dev.sober.mixin.ChunkToNibbleArrayMapAccessor;
import dev.sober.mixin.LightStorageAccessor;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.Color;
import dev.sober.render.Render3D;
import dev.sober.render.ShapeMode;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1944;
import net.minecraft.class_2804;
import net.minecraft.class_3556;
import net.minecraft.class_3558;
import net.minecraft.class_3562;
import net.minecraft.class_4076;

public class LightFinder
extends Module {
    private final Setting<Integer> maxY = this.add(new IntSetting("Max Y", "Only show light below this Y level.", 0, -64, 320));
    private final Setting<Integer> minLight = this.add(new IntSetting("Min Light", "Minimum block light level to show.", 1, 1, 15));
    private final Setting<Integer> range = this.add(new IntSetting("Range", "Horizontal range in chunks.", 8, 1, 32));
    private final Setting<Integer> maxBlocks = this.add(new IntSetting("Max Blocks", "Limit of rendered blocks to keep the framerate up.", 20000, 100, 100000));
    private final Setting<Integer> updateInterval = this.add(new IntSetting("Update Interval", "Ticks between light scans.", 20, 1, 200));
    private final Setting<ShapeMode> shapeMode;
    private final Setting<Color> dimColor;
    private final Setting<Color> brightColor;
    private volatile List<LitBlock> litBlocks;
    private int timer;
    private long[] pendingKeys;
    private int pendingIndex;
    private int perTick;
    private List<LitBlock> building;
    private boolean first;

    public LightFinder() {
        super("Light Finder", "Renders block light sections for base finding.", Category.BASE_FINDING);
        this.group("Render");
        this.shapeMode = this.add(new EnumSetting<ShapeMode>("Shape Mode", "How lit blocks are drawn.", ShapeMode.Lines));
        this.dimColor = this.add(new ColorSetting("Dim Color", "Color for light level 1.", new Color(40, 40, 50, 80)));
        this.brightColor = this.add(new ColorSetting("Bright Color", "Color for light level 15.", new Color(255, 255, 50, 120)));
        this.litBlocks = List.of();
        this.perTick = 1;
    }

    @Override
    public void onEnable() {
        this.timer = 0;
        this.litBlocks = List.of();
        this.pendingKeys = null;
        this.building = null;
        this.first = true;
    }

    @Override
    public void onDisable() {
        this.litBlocks = List.of();
        this.pendingKeys = null;
        this.building = null;
    }

    @Override
    public void onTick() {
        try {
            if (this.pendingKeys == null) {
                long[] keys;
                if (this.timer-- > 0) {
                    return;
                }
                long[] lArray = keys = this.arrays() == null ? new long[]{} : this.arrays().keySet().toLongArray();
                if (this.first) {
                    this.first = false;
                    this.pendingKeys = keys;
                    this.pendingIndex = 0;
                    this.building = new ArrayList<LitBlock>();
                    this.collectStep(keys.length);
                    return;
                }
                this.pendingKeys = keys;
                this.pendingIndex = 0;
                this.building = new ArrayList<LitBlock>();
                this.perTick = Math.max(1, (keys.length + this.updateInterval.get() - 1) / Math.max(1, this.updateInterval.get()));
            }
            this.collectStep(this.perTick);
        }
        catch (Exception e) {
            SoberClient.LOG.error("LightFinder failed to read light data", (Throwable)e);
            this.litBlocks = List.of();
            this.pendingKeys = null;
            this.timer = this.updateInterval.get();
        }
    }

    private Long2ObjectMap<class_2804> arrays() {
        class_3562 view = LightFinder.mc.field_1687.method_22336().method_15562(class_1944.field_9282);
        if (!(view instanceof class_3558)) {
            return null;
        }
        class_3558 provider = (class_3558)view;
        class_3556<?> storage = ((LightStorageAccessor)((ChunkLightProviderAccessor)provider).sober$getLightStorage()).sober$getStorage();
        return ((ChunkToNibbleArrayMapAccessor)storage).sober$getArrays();
    }

    private void collectStep(int count) {
        Long2ObjectMap<class_2804> arrays = this.arrays();
        int playerChunkX = LightFinder.mc.field_1724.method_31476().field_9181;
        int playerChunkZ = LightFinder.mc.field_1724.method_31476().field_9180;
        int chunkRange = this.range.get();
        int yLimit = this.maxY.get();
        int min = this.minLight.get();
        int limit = this.maxBlocks.get();
        List<LitBlock> result = this.building;
        int end = Math.min(this.pendingKeys.length, this.pendingIndex + count);
        boolean full = false;
        block0: while (this.pendingIndex < end && !full && arrays != null) {
            class_4076 section;
            long key;
            class_2804 array;
            if ((array = (class_2804)arrays.get(key = this.pendingKeys[this.pendingIndex++])) == null || array.method_51380() || (section = class_4076.method_18677((long)key)).method_19528() >= yLimit || Math.abs(section.method_18674() - playerChunkX) > chunkRange || Math.abs(section.method_18687() - playerChunkZ) > chunkRange) continue;
            for (int x = 0; x < 16; ++x) {
                int worldY;
                for (int y = 0; y < 16 && (worldY = section.method_19528() + y) < yLimit; ++y) {
                    for (int z = 0; z < 16; ++z) {
                        int level = array.method_12139(x, y, z);
                        if (level < min) continue;
                        result.add(new LitBlock(section.method_19527() + x, worldY, section.method_19529() + z, level));
                        if (result.size() < limit) continue;
                        full = true;
                        continue block0;
                    }
                }
            }
        }
        if (full || arrays == null || this.pendingIndex >= this.pendingKeys.length) {
            this.litBlocks = result;
            this.pendingKeys = null;
            this.building = null;
            this.timer = 0;
        }
    }

    @Override
    public void onRender(Render3D renderer) {
        Color dim = this.dimColor.get();
        Color bright = this.brightColor.get();
        Color[] palette = new Color[16];
        for (int level = 1; level < 16; ++level) {
            palette[level] = dim.lerp(bright, (double)(level - 1) / 14.0);
        }
        for (LitBlock block : this.litBlocks) {
            Color color = palette[Math.max(1, Math.min(15, block.level))];
            renderer.box(block.x, block.y, block.z, block.x + 1, block.y + 1, block.z + 1, color, color, this.shapeMode.get());
        }
    }

    private record LitBlock(int x, int y, int z, int level) {
    }
}

