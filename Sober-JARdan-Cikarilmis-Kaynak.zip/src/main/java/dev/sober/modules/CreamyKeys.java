/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_304
 *  net.minecraft.class_3675
 */
package dev.sober.modules;

import dev.sober.gui.KeySynth;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_304;
import net.minecraft.class_3675;

public class CreamyKeys
extends Module {
    private final Setting<Sound> sound = this.add(new EnumSetting<Sound>("Key Sound", "Aula F75, FB67, 60he v2 and Frosted 65 play the real keyboard sounds cut from your recordings, unchanged.", Sound.AulaF75));
    private final Setting<Boolean> inGame = this.add(new BoolSetting("In Game", "Also clicks while playing, not only in chat and menus.", true));
    private final Setting<Boolean> movement = this.add(new BoolSetting("Movement Keys", "Walking, jumping, sneaking and sprinting keys also click while playing. Turn off for clicks only while typing and on other keys.", true)).visible(this.inGame::get);
    private final Setting<Boolean> release = this.add(new BoolSetting("Release Sound", "Plays a second, softer click when a key is let go, like a real keyboard. Doubles the amount of clicks.", false));
    private final Setting<Integer> cooldown = this.add(new IntSetting("Cooldown", "Minimum time between two clicks in milliseconds, so many keys at once do not rattle.", 70, 0, 300));
    private final Setting<Boolean> stereo = this.add(new BoolSetting("Stereo", "Keys on the left of the keyboard sound from the left, keys on the right from the right.", true));
    private final Setting<Integer> volume = this.add(new IntSetting("Volume", "Loudness of the key clicks in percent.", 100, 10, 250));
    private final Setting<Boolean> mouse = this.add(new BoolSetting("Mouse", "Mouse buttons play the mouse click from your clip when pressed.", true));
    private final Set<Integer> down = new HashSet<Integer>();
    private final Set<Integer> buttons = new HashSet<Integer>();
    private long lastSound;
    private long lastMouse;

    public CreamyKeys() {
        super("Creamy Keys", "Every key press sounds like a real creamy mechanical keyboard.", Category.CLIENT);
    }

    @Override
    public void onDisable() {
        this.down.clear();
        this.buttons.clear();
    }

    public void onMouse(int button, int action) {
        if (action == 0) {
            this.buttons.remove(button);
            return;
        }
        if (action != 1 || !this.buttons.add(button)) {
            return;
        }
        if (!this.mouse.get().booleanValue() || CreamyKeys.mc.field_1755 == null && !this.inGame.get().booleanValue()) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastMouse < 20L) {
            return;
        }
        this.lastMouse = now;
        KeySynth.playMouse((float)this.volume.get().intValue() / 100.0f);
    }

    private boolean movementKey(int key) {
        for (class_304 binding : new class_304[]{CreamyKeys.mc.field_1690.field_1894, CreamyKeys.mc.field_1690.field_1881, CreamyKeys.mc.field_1690.field_1913, CreamyKeys.mc.field_1690.field_1849, CreamyKeys.mc.field_1690.field_1903, CreamyKeys.mc.field_1690.field_1832, CreamyKeys.mc.field_1690.field_1867}) {
            if (class_3675.method_15981((String)binding.method_1428()).method_1444() != key) continue;
            return true;
        }
        return false;
    }

    public void onKey(int key, int action) {
        boolean playing;
        if (key == -1 || action == 2) {
            return;
        }
        if (action == 0) {
            if (this.down.remove(key) && this.release.get().booleanValue()) {
                this.play(key, true);
            }
            return;
        }
        if (!this.down.add(key)) {
            return;
        }
        boolean bl = playing = CreamyKeys.mc.field_1755 == null;
        if (playing && (!this.inGame.get().booleanValue() || !this.movement.get().booleanValue() && this.movementKey(key))) {
            return;
        }
        this.play(key, false);
    }

    private void play(int key, boolean up) {
        long now = System.currentTimeMillis();
        if (now - this.lastSound < (long)this.cooldown.get().intValue()) {
            return;
        }
        this.lastSound = now;
        float level = (float)this.volume.get().intValue() / 100.0f;
        KeySynth.play(this.sound.get().profile, key, up, level, this.stereo.get());
    }

    @Override
    public boolean showInHud() {
        return false;
    }

    public static enum Sound {
        AulaF75("Aula F75", KeySynth.Profile.Recorded),
        FB67("FB67", KeySynth.Profile.Fb67),
        He60v2("60he v2", KeySynth.Profile.He60v2),
        Frost65("Frosted 65", KeySynth.Profile.Frost65);

        private final String title;
        private final KeySynth.Profile profile;

        private Sound(String title, KeySynth.Profile profile) {
            this.title = title;
            this.profile = profile;
        }

        public String toString() {
            return this.title;
        }
    }
}

