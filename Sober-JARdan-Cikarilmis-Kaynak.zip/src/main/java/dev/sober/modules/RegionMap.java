/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;
import dev.sober.setting.lite.BooleanSetting;
import dev.sober.setting.lite.ColorSetting;
import dev.sober.setting.lite.NumberSetting;

public final class RegionMap
extends BusModule {
    private final NumberSetting cellSize = this.addSetting("cell-size", new NumberSetting("Cell Size", 22.0f, 10.0f, 50.0f).step(1.0f));
    private final NumberSetting cellGap = this.addSetting("cell-gap", new NumberSetting("Cell Gap", 2.0f, 0.0f, 10.0f).step(1.0f));
    private final NumberSetting playerScale = this.addSetting("player-scale", new NumberSetting("Player Scale", 1.0f, 0.5f, 3.0f).step(0.1f));
    private final NumberSetting textScale = this.addSetting("text-scale", new NumberSetting("Text Scale", 1.0f, 0.1f, 2.0f).step(0.1f));
    private final NumberSetting opacity = this.addSetting("opacity", new NumberSetting("Opacity", 1.0f, 0.1f, 1.0f).step(0.05f));
    private final BooleanSetting shadow = this.addSetting("shadow", new BooleanSetting("Shadow", true));
    private final BooleanSetting showRegionIds = this.addSetting("show-region-ids", new BooleanSetting("Show Region IDs", true));
    private final BooleanSetting showLegend = this.addSetting("show-legend", new BooleanSetting("Show Legend", true));
    private final BooleanSetting showCoordinates = this.addSetting("show-coordinates", new BooleanSetting("Show Coordinates", true));
    private final ColorSetting playerIndicatorColor = this.addSetting(new ColorSetting("Player Indicator", -52686));

    public RegionMap() {
        super("region-map", "Region Map", "DonutSMP region map with directional indicator.", ModuleCategory.CLIENT);
    }

    public float cellSize() {
        return this.cellSize.get();
    }

    public float cellGap() {
        return this.cellGap.get();
    }

    public float playerScale() {
        return this.playerScale.get();
    }

    public float textScale() {
        return this.textScale.get();
    }

    public float opacity() {
        return this.opacity.get();
    }

    public boolean shadow() {
        return this.shadow.get();
    }

    public boolean showRegionIds() {
        return this.showRegionIds.get();
    }

    public boolean showLegend() {
        return this.showLegend.get();
    }

    public boolean showCoordinates() {
        return this.showCoordinates.get();
    }

    public ColorSetting playerIndicatorColor() {
        return this.playerIndicatorColor;
    }
}

