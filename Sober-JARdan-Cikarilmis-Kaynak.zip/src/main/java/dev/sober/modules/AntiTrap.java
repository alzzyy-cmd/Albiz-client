/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1297$class_5529
 *  net.minecraft.class_1299
 *  net.minecraft.class_2604
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import java.util.ArrayList;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2604;

public class AntiTrap
extends Module {
    public AntiTrap() {
        super("Anti Trap", "Removes armor stands and chest minecarts client side to escape Polish traps.", Category.COMBAT);
    }

    @Override
    public void onEnable() {
        if (AntiTrap.mc.field_1687 == null) {
            return;
        }
        ArrayList<class_1297> traps = new ArrayList<class_1297>();
        for (class_1297 entity : AntiTrap.mc.field_1687.method_18112()) {
            if (!AntiTrap.isTrap(entity.method_5864())) continue;
            traps.add(entity);
        }
        for (class_1297 entity : traps) {
            AntiTrap.mc.field_1687.method_2945(entity.method_5628(), class_1297.class_5529.field_26999);
        }
    }

    @Override
    public boolean onEntitySpawn(class_2604 packet) {
        return AntiTrap.isTrap(packet.method_11169());
    }

    private static boolean isTrap(class_1299<?> type) {
        return type == class_1299.field_6131 || type == class_1299.field_6126;
    }
}

