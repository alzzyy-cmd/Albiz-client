/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_2561
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.AutoReconnect;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;

public class AutoLog
extends Module {
    private final Setting<Integer> range = this.add(new IntSetting(this, "Range", "Logs out when another player comes within this many blocks. 0 turns it off.", 32, 0, 128){

        @Override
        public String display() {
            return (Integer)this.value == 0 ? "Off" : String.valueOf(this.value) + " blocks";
        }
    });
    private final Setting<Integer> health = this.add(new IntSetting(this, "Health", "Also logs out at or below this many hearts. 0 turns it off.", 0, 0, 20){

        @Override
        public String display() {
            return (Integer)this.value == 0 ? "Off" : String.valueOf(this.value) + " hearts";
        }
    });
    private final Setting<Boolean> autoOff = this.add(new BoolSetting("Auto Off", "Turns Auto Log off after it logged you out, so you can join again.", true));

    public AutoLog() {
        super("Auto Log", "Leaves the server when a player comes near you or your health gets low.", Category.DONUT);
    }

    @Override
    public void onTick() {
        class_1657 near;
        if (AutoLog.mc.field_1724 == null || AutoLog.mc.field_1687 == null || mc.method_1562() == null || mc.method_1542() || AutoLog.mc.field_1724.field_6012 < 40) {
            return;
        }
        String reason = null;
        if (this.health.get() > 0 && AutoLog.mc.field_1724.method_6032() + AutoLog.mc.field_1724.method_6067() <= (float)this.health.get().intValue() * 2.0f) {
            reason = "Your health went down to " + Math.round(AutoLog.mc.field_1724.method_6032() / 2.0f) + " hearts.";
        } else if (this.range.get() > 0 && (near = this.nearest()) != null) {
            reason = near.method_7334().name() + " came within " + Math.round(near.method_5739((class_1297)AutoLog.mc.field_1724)) + " blocks.";
        }
        if (reason == null) {
            return;
        }
        if (this.autoOff.get().booleanValue()) {
            this.setEnabledSilently(false);
            SoberClient.CONFIG.save();
        }
        AutoReconnect.skipNext();
        mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_43470((String)("[Auto Log] " + reason)));
    }

    private class_1657 nearest() {
        class_1657 best = null;
        double bestDistance = this.range.get() * this.range.get();
        for (class_1657 player : AutoLog.mc.field_1687.method_18456()) {
            double distance;
            if (player == AutoLog.mc.field_1724 || player.method_7325() || mc.method_1562().method_2871(player.method_5667()) == null || !((distance = player.method_5858((class_1297)AutoLog.mc.field_1724)) <= bestDistance)) continue;
            bestDistance = distance;
            best = player;
        }
        return best;
    }

    @Override
    public String getInfoString() {
        return this.range.get() > 0 ? String.valueOf(this.range.get()) + "m" : null;
    }
}

