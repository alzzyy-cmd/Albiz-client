/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1802
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.CombatItems;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1802;

public class AutoDoubleHand
extends Module {
    private final Setting<Integer> health = this.add(new IntSetting(this, "Health", "Holds a totem in your main hand at or below this many hearts. 0 only reacts to pops.", 4, 0, 20){

        @Override
        public String display() {
            return (Integer)this.value == 0 ? "Off" : String.valueOf(this.value) + " hearts";
        }
    });
    private final Setting<Boolean> onPop = this.add(new BoolSetting("On Pop", "Grabs a totem from your hotbar right after your offhand totem pops.", true));
    private final Setting<Boolean> switchBack = this.add(new BoolSetting("Switch Back", "Goes back to the slot you held once you are above the health again.", true));
    private boolean hadOffhandTotem;
    private int previous = -1;

    public AutoDoubleHand() {
        super("Auto Double Hand", "Puts a totem in your main hand too when you are low or your offhand totem just popped.", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        this.previous = -1;
    }

    @Override
    public void onTick() {
        boolean low;
        if (AutoDoubleHand.mc.field_1724 == null || AutoDoubleHand.mc.field_1724.method_68878() || AutoDoubleHand.mc.field_1724.method_7325() || AutoDoubleHand.mc.field_1755 != null) {
            return;
        }
        boolean offhandTotem = AutoDoubleHand.mc.field_1724.method_6079().method_31574(class_1802.field_8288);
        boolean popped = this.hadOffhandTotem && !offhandTotem && AutoDoubleHand.mc.field_1724.field_6235 > 0;
        this.hadOffhandTotem = offhandTotem;
        float hp = AutoDoubleHand.mc.field_1724.method_6032() + AutoDoubleHand.mc.field_1724.method_6067();
        boolean bl = low = this.health.get() > 0 && hp <= (float)this.health.get().intValue() * 2.0f;
        if ((low || this.onPop.get().booleanValue() && popped) && !AutoDoubleHand.mc.field_1724.method_6047().method_31574(class_1802.field_8288)) {
            int slot = CombatItems.hotbarSlot(stack -> stack.method_31574(class_1802.field_8288));
            if (slot < 0) {
                return;
            }
            if (this.previous < 0) {
                this.previous = AutoDoubleHand.mc.field_1724.method_31548().method_67532();
            }
            AutoDoubleHand.mc.field_1724.method_31548().method_61496(slot);
            return;
        }
        if (!low && !popped && this.previous >= 0 && AutoDoubleHand.mc.field_1724.field_6235 == 0) {
            if (this.switchBack.get().booleanValue()) {
                AutoDoubleHand.mc.field_1724.method_31548().method_61496(this.previous);
            }
            this.previous = -1;
        }
    }
}

