/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 */
package dev.sober.modules;

import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;
import dev.sober.modules.entitycontrol.EntityControlVehicleHook;
import dev.sober.setting.lite.BooleanSetting;
import dev.sober.setting.lite.NumberSetting;
import net.minecraft.class_1297;

public final class EntitySpeed
extends BusModule {
    public static volatile EntitySpeed active;
    private final NumberSetting horizontalSpeed = this.addSetting("horizontal-speed", new NumberSetting("Horizontal Speed", 10.0f, 0.0f, 50.0f).step(0.5f));
    private final BooleanSetting onlyOnGround = this.addSetting("only-on-ground", new BooleanSetting("Only On Ground", false));
    private final BooleanSetting inWater = this.addSetting("in-water", new BooleanSetting("In Water", true));

    public EntitySpeed() {
        super("entity-speed", "Entity Speed", "Makes you go faster horizontally when riding entities.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEnable() {
        active = this;
        EntityControlVehicleHook.refresh();
    }

    @Override
    public void onDisable() {
        active = null;
        EntityControlVehicleHook.refresh();
    }

    public boolean appliesTo(class_1297 vehicle) {
        return !(this.onlyOnGround.get() && !vehicle.method_24828() && !vehicle.method_70987() || !this.inWater.get() && vehicle.method_5799());
    }

    public double horizontalSpeed() {
        return this.horizontalSpeed.get();
    }
}

