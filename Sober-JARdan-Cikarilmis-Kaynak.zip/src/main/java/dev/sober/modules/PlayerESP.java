/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_640
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.Color;
import dev.sober.render.Render3D;
import dev.sober.render.ShapeMode;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_640;

public class PlayerESP
extends Module {
    private final Setting<ShapeMode> shapeMode;
    private final Setting<Color> color;
    private final Setting<Boolean> distanceColor;
    private final Setting<Boolean> tracers;
    private final Setting<Boolean> throughWalls;
    private final Setting<Boolean> invisible;
    private final Setting<Boolean> notify;
    private final Setting<Boolean> notifyLeave;
    private final Setting<Integer> cooldown;
    private final Set<UUID> present;
    private final Map<UUID, Long> lastAlert;

    public PlayerESP() {
        super("Player ESP", "Highlights other players and notifies you when someone shows up.", Category.BASE_FINDING);
        this.group("Render");
        this.shapeMode = this.add(new EnumSetting<ShapeMode>("Shape Mode", "How players are drawn.", ShapeMode.Both));
        this.color = this.add(new ColorSetting("Color", "Color of the player boxes.", new Color(176, 140, 240, 255)));
        this.distanceColor = this.add(new BoolSetting("Distance Color", "Close players turn red, far ones stay in your color.", true));
        this.tracers = this.add(new BoolSetting("Tracers", "Line from your crosshair to every player.", false));
        this.throughWalls = this.add(new BoolSetting("Through Walls", "Boxes are visible through blocks.", true));
        this.invisible = this.add(new BoolSetting("Invisible Players", "Also shows players with an invisibility effect or potion.", true));
        this.group("Alerts");
        this.notify = this.add(new BoolSetting("Notify", "Notification when a player comes into render distance.", true));
        this.notifyLeave = this.add(new BoolSetting("Notify Leave", "Notification when a player leaves render distance.", false));
        this.cooldown = this.add(new IntSetting("Cooldown", "Seconds before the same player can notify again.", 30, 0, 300));
        this.present = new HashSet<UUID>();
        this.lastAlert = new HashMap<UUID, Long>();
    }

    @Override
    public void onEnable() {
        this.present.clear();
        if (PlayerESP.mc.field_1687 == null) {
            return;
        }
        for (class_1657 player : PlayerESP.mc.field_1687.method_18456()) {
            if (player == PlayerESP.mc.field_1724) continue;
            this.present.add(player.method_5667());
        }
    }

    @Override
    public void onGameLeft() {
        this.present.clear();
    }

    @Override
    public void onTick() {
        HashSet<UUID> now = new HashSet<UUID>();
        long time = System.currentTimeMillis();
        for (class_1657 player : PlayerESP.mc.field_1687.method_18456()) {
            if (player == PlayerESP.mc.field_1724) continue;
            UUID id = player.method_5667();
            now.add(id);
            if (this.present.contains(id) || !this.notify.get().booleanValue() || time - this.lastAlert.getOrDefault(id, 0L) < (long)this.cooldown.get().intValue() * 1000L) continue;
            this.lastAlert.put(id, time);
            this.info("%s spotted, %d blocks away.", player.method_5477().getString(), Math.round(Math.sqrt(player.method_5858((class_1297)PlayerESP.mc.field_1724))));
        }
        if (this.notifyLeave.get().booleanValue()) {
            for (UUID id : this.present) {
                if (now.contains(id)) continue;
                class_640 entry = mc.method_1562() == null ? null : mc.method_1562().method_2871(id);
                this.info("%s left your render distance.", entry != null ? entry.method_2966().name() : "A player");
            }
        }
        this.present.clear();
        this.present.addAll(now);
    }

    @Override
    public void onRender(Render3D renderer) {
        float delta = mc.method_61966().method_60637(true);
        renderer.setDepthTest(this.throughWalls.get() == false);
        for (class_1657 player : PlayerESP.mc.field_1687.method_18456()) {
            if (player == PlayerESP.mc.field_1724 || player.method_5767() && !player.method_5851() && !this.invisible.get().booleanValue()) continue;
            class_243 offset = player.method_30950(delta).method_1020(player.method_73189());
            class_238 box = player.method_5829().method_997(offset).method_1014(0.05);
            Color c = this.color.get();
            if (this.distanceColor.get().booleanValue()) {
                double t = Math.min(1.0, Math.sqrt(player.method_5858((class_1297)PlayerESP.mc.field_1724)) / 48.0);
                c = new Color(255, 70, 90, c.a()).lerp(c, t);
            }
            renderer.box(box, c, c, this.shapeMode.get());
            if (!this.tracers.get().booleanValue()) continue;
            class_243 center = box.method_1005();
            renderer.tracer(center.field_1352, center.field_1351, center.field_1350, c.scaleAlpha(0.8));
        }
        renderer.setDepthTest(false);
    }

    @Override
    public String getInfoString() {
        return this.present.isEmpty() ? null : String.valueOf(this.present.size());
    }
}

