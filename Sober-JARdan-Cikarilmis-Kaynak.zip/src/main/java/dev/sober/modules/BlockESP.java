/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2248
 *  net.minecraft.class_2680
 *  net.minecraft.class_310
 */
package dev.sober.modules;

import dev.sober.esp.BlockLayer;
import dev.sober.esp.ChunkScanner;
import dev.sober.esp.EspStyle;
import dev.sober.event.EventHandler;
import dev.sober.event.impl.Render3DEvent;
import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;
import dev.sober.setting.lite.BlockColorListSetting;
import dev.sober.setting.lite.BooleanSetting;
import java.util.Set;
import java.util.function.LongPredicate;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class BlockESP
extends BusModule
implements ChunkScanner.Consumer {
    private final EspStyle style;
    private final BooleanSetting sTracers;
    private final BlockColorListSetting sBlockColors;
    private final BlockLayer layer;
    private Set<String> scannedIds;

    public BlockESP() {
        super("block-esp", "Block ESP", "Highlights chosen blocks; touching blocks merge into one shape.", ModuleCategory.RENDER);
        BlockESP blockESP = this;
        this.style = new EspStyle((x$0, x$1) -> blockESP.addSetting(x$0, x$1), "Outline", 0.2f, 2048.0f);
        this.sTracers = this.addSetting("tracers", new BooleanSetting("Tracers", false));
        this.sBlockColors = this.addSetting(BlockColorListSetting.createDefault());
        this.layer = new BlockLayer(new BlockLayer.Palette(){

            @Override
            public int color(Object kind) {
                return BlockESP.this.sBlockColors.colorArgb((class_2248)kind);
            }

            @Override
            public int tracerColor(Object kind) {
                return BlockESP.this.sBlockColors.tracerColorArgb((class_2248)kind);
            }
        }, () -> class_310.method_1551().field_1687 == null ? null : class_310.method_1551().field_1687.method_27983());
        this.scannedIds = Set.of();
        this.sBlockColors.onChange(this::rescan);
    }

    private void rescan() {
        Set<String> ids;
        if (this.isEnabled() && !(ids = this.sBlockColors.enabledIds()).equals(this.scannedIds)) {
            boolean removed = !ids.containsAll(this.scannedIds);
            this.scannedIds = ids;
            if (removed) {
                this.layer.clear();
            }
            ChunkScanner.rescan();
        }
    }

    @Override
    public void onEnable() {
        this.scannedIds = this.sBlockColors.enabledIds();
        ChunkScanner.register(this);
    }

    @Override
    public void onDisable() {
        ChunkScanner.unregister(this);
        this.layer.clear();
    }

    @Override
    public boolean wants(class_2680 state) {
        return this.sBlockColors.isEnabled(state.method_26204());
    }

    @Override
    public void found(long pos, class_2680 state) {
        this.layer.put(pos, state.method_26204());
    }

    @Override
    public void removed(long pos) {
        this.layer.remove(pos);
    }

    @Override
    public void reset() {
        this.layer.clear();
    }

    @Override
    public void chunkScanned(long chunkKey, LongPredicate stillThere) {
        this.layer.retainChunk(chunkKey, stillThere);
    }

    @EventHandler
    public void onRender3D(Render3DEvent event) {
        this.layer.render(event, this.style);
        if (this.sTracers.get() && this.sBlockColors.hasAnyTracerEnabled()) {
            this.layer.renderTracers(this.style);
        }
    }
}

