/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1799
 *  net.minecraft.class_1890
 *  net.minecraft.class_1893
 *  net.minecraft.class_2378
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_2680
 *  net.minecraft.class_3965
 *  net.minecraft.class_6880
 *  net.minecraft.class_7924
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2378;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public class AutoTool
extends Module {
    private final Setting<Boolean> switchBack = this.add(new BoolSetting("Switch Back", "Goes back to your old slot when you stop mining.", true));
    private final Setting<Boolean> antiBreak = this.add(new BoolSetting("Anti Break", "Never uses tools that are about to break.", true));
    private final Setting<Integer> minDurability = this.add(new IntSetting("Min Durability", "Durability a tool needs to still be used.", 10, 1, 100)).visible(this.antiBreak::get);
    private final Setting<Boolean> preferSilk = this.add(new BoolSetting("Prefer Silk Touch", "Takes silk touch tools when they mine just as fast.", false));
    private int previousSlot = -1;

    public AutoTool() {
        super("Auto Tool", "Switches to the best tool in your hotbar while mining.", Category.DONUT);
    }

    @Override
    public void onDisable() {
        this.restore();
    }

    @Override
    public void onGameLeft() {
        this.previousSlot = -1;
    }

    @Override
    public void onTick() {
        int current;
        boolean mining;
        if (AutoTool.mc.field_1724 == null || AutoTool.mc.field_1687 == null || AutoTool.mc.field_1761 == null) {
            return;
        }
        boolean bl = mining = AutoTool.mc.field_1690.field_1886.method_1434() && AutoTool.mc.field_1755 == null && AutoTool.mc.field_1765 != null && AutoTool.mc.field_1765.method_17783() == class_239.class_240.field_1332;
        if (!mining || AutoTool.mc.field_1724.method_68878()) {
            this.restore();
            return;
        }
        class_2680 state = AutoTool.mc.field_1687.method_8320(((class_3965)AutoTool.mc.field_1765).method_17777());
        if (state.method_26215()) {
            return;
        }
        int best = current = AutoTool.mc.field_1724.method_31548().method_67532();
        double bestScore = this.score(AutoTool.mc.field_1724.method_31548().method_5438(current), state);
        for (int i = 0; i < 9; ++i) {
            double score = this.score(AutoTool.mc.field_1724.method_31548().method_5438(i), state);
            if (!(score > bestScore + 0.001)) continue;
            bestScore = score;
            best = i;
        }
        if (best != current) {
            if (this.previousSlot == -1) {
                this.previousSlot = current;
            }
            AutoTool.mc.field_1724.method_31548().method_61496(best);
        }
    }

    private double score(class_1799 stack, class_2680 state) {
        class_2378 registry;
        int efficiency;
        if (this.antiBreak.get().booleanValue() && stack.method_7963() && stack.method_7936() - stack.method_7919() <= this.minDurability.get()) {
            return -1.0;
        }
        double score = stack.method_7924(state);
        if (score <= 1.0) {
            return stack.method_7963() ? 0.5 : 1.0;
        }
        if (stack.method_7951(state)) {
            score += 1000.0;
        }
        if ((efficiency = class_1890.method_8225((class_6880)(registry = AutoTool.mc.field_1687.method_30349().method_30530(class_7924.field_41265)).method_46747(class_1893.field_9131), (class_1799)stack)) > 0) {
            score += (double)(efficiency * efficiency + 1);
        }
        if (this.preferSilk.get().booleanValue() && class_1890.method_8225((class_6880)registry.method_46747(class_1893.field_9099), (class_1799)stack) > 0) {
            score += 0.5;
        }
        return score;
    }

    private void restore() {
        if (this.previousSlot != -1 && this.switchBack.get().booleanValue() && AutoTool.mc.field_1724 != null) {
            AutoTool.mc.field_1724.method_31548().method_61496(this.previousSlot);
        }
        this.previousSlot = -1;
    }
}

