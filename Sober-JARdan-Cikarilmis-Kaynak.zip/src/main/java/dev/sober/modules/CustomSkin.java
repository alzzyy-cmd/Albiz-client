/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10055
 *  net.minecraft.class_11659
 *  net.minecraft.class_12122
 *  net.minecraft.class_12249
 *  net.minecraft.class_1306
 *  net.minecraft.class_156
 *  net.minecraft.class_2960
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_7833
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Quaternionfc
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.gui.Notifications;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.module.Presets;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import dev.sober.skin.SkinManager;
import dev.sober.skin.SkinMesh;
import dev.sober.skin.SkinRig;
import java.util.Arrays;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12122;
import net.minecraft.class_12249;
import net.minecraft.class_1306;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;

public class CustomSkin
extends Module
implements Presets {
    private static final float PI = (float)Math.PI;
    private static final float PLAYER_SCALE = 0.9375f;
    private static final float SKIN_HEIGHT = 2.0f;
    private static final float SKIN_WIDTH = 1.0f;
    private static final int[] PART_COLORS = new int[]{0, -1522361, -1552305, -11563032, -11943297, -5870616};
    public final Setting<String> skin;
    public final Setting<Integer> size;
    public final Setting<Boolean> fitSkin;
    public final Setting<Integer> turn;
    public final Setting<Integer> height;
    public final Setting<Integer> detail;
    public final Setting<Boolean> showElytra;
    public final Setting<Boolean> animate;
    public final Setting<Boolean> animateArms;
    public final Setting<Boolean> animateLegs;
    public final Setting<Boolean> animateHead;
    public final Setting<Boolean> relaxArms;
    public final Setting<Integer> swing;
    public final Setting<Boolean> showParts;
    public final Setting<Boolean> openFolder;
    public final Setting<Boolean> reload;
    private static final int RING = 6;
    private SkinRig rig;
    private boolean rigRelaxed;
    private Object drawnState;
    private SkinRig poseRig;
    private float[][][] posePositions;
    private float[][][] poseNormals;
    private int[][] tinted;
    private final Map<int[], int[]> quadCache;
    private SkinMesh quadMesh;
    private int ring;
    private float elytraDy;
    private float elytraDz;

    public CustomSkin() {
        super("Custom Skin", "Shows your own 3D model instead of your player, with moving arms and legs. Only you can see it.", Category.VISUALS);
        this.group("Skin");
        this.skin = this.add(new StringSetting("Skin Model", "", "builtin/sober_cat.glb", true)).visible(() -> false);
        this.size = this.add(new IntSetting("Size", "Size in percent. 100 is exactly the size of a normal Minecraft skin.", 100, 30, 300));
        this.fitSkin = this.add(new BoolSetting("Fit Skin Size", "Keeps the model inside the space of a normal Minecraft skin: as tall as a player and never wider than one with arms.", true));
        this.turn = this.add(new IntSetting("Turn", "Turns the model in degrees if it looks the wrong way.", 0, 0, 359));
        this.height = this.add(new IntSetting("Height Offset", "Moves the model up or down in hundredths of a block.", 0, -100, 100));
        this.detail = this.add(new IntSetting("Detail", "Maximum triangles in thousands. Lower values load faster and run smoother.", 25, 5, 120));
        this.showElytra = this.add(new BoolSetting("Show Elytra", "Shows your elytra wings on the back of the model.", true));
        this.group("Animation");
        this.animate = this.add(new BoolSetting("Animate", "Moves arms, legs and head like a normal player: walking, hitting, sneaking, looking around and riding. The model gets split into parts automatically.", true));
        this.animateArms = this.add(new BoolSetting("Arms", "Swings the arms.", true)).visible(this.animate::get);
        this.animateLegs = this.add(new BoolSetting("Legs", "Moves the legs.", true)).visible(this.animate::get);
        this.animateHead = this.add(new BoolSetting("Head", "Turns the head where you look.", true)).visible(this.animate::get);
        this.relaxArms = this.add(new BoolSetting("Relax Arms", "Lowers arms that stick out to the side (T-pose) so they hang down and can swing.", true)).visible(this.animate::get);
        this.swing = this.add(new IntSetting("Swing Strength", "How far arms and legs swing while walking, in percent.", 100, 0, 200)).visible(this.animate::get);
        this.showParts = this.add(new BoolSetting("Show Parts", "Colors the detected parts: head yellow, right arm red, left arm blue, right leg green, left leg purple. Helps to check the split.", false)).visible(this.animate::get);
        this.group("Files");
        this.openFolder = this.add(new BoolSetting("Open Folder", "Opens config/sober/skins. Put .glb, .gltf, .obj or .stl files there.", false)).onChanged(v -> {
            if (!v.booleanValue()) {
                return;
            }
            class_156.method_668().method_672(SkinManager.folder().toFile());
            this.openFolder.set(false);
        });
        this.reload = this.add(new BoolSetting("Reload Skins", "Loads the skin files again.", false)).onChanged(v -> {
            if (!v.booleanValue()) {
                return;
            }
            SkinManager.reload();
            this.rig = null;
            Notifications.push("Custom Skin", SkinManager.files().size() + " skins found.", Notifications.Type.SUCCESS);
            this.reload.set(false);
        });
        this.quadCache = new IdentityHashMap<int[], int[]>();
    }

    public static boolean render(class_10055 state, class_4587 matrices, class_11659 queue, int overlay) {
        CustomSkin module = SoberClient.MODULES.get(CustomSkin.class);
        if (module == null) {
            return false;
        }
        module.drawnState = null;
        if (!module.isActive() || module.skin.get().isEmpty()) {
            return false;
        }
        if (CustomSkin.mc.field_1724 == null || state.field_53528 != CustomSkin.mc.field_1724.method_5628() || state.field_53333 || state.field_53542) {
            return false;
        }
        SkinMesh mesh = SkinManager.get(module.skin.get(), module.detail.get() * 1000);
        if (mesh == null) {
            return false;
        }
        module.draw(mesh, state, matrices, queue, overlay);
        module.drawnState = state;
        return true;
    }

    public static boolean hidesFeatures(Object state) {
        CustomSkin module = SoberClient.MODULES.get(CustomSkin.class);
        return module != null && state != null && module.drawnState == state;
    }

    public static boolean showsElytra() {
        CustomSkin module = SoberClient.MODULES.get(CustomSkin.class);
        return module != null && module.showElytra.get() != false;
    }

    public static void elytraOffset(class_4587 matrices) {
        CustomSkin module = SoberClient.MODULES.get(CustomSkin.class);
        if (module != null) {
            matrices.method_46416(0.0f, module.elytraDy, module.elytraDz);
        }
    }

    private SkinRig rig(SkinMesh mesh) {
        boolean relax = this.relaxArms.get();
        if (this.rig == null || this.rig.mesh != mesh || this.rig.turn != this.turn.get() || this.rigRelaxed != relax) {
            this.rig = SkinRig.build(mesh, this.turn.get(), relax);
            this.rigRelaxed = relax;
        }
        return this.rig;
    }

    private void draw(SkinMesh mesh, class_10055 state, class_4587 matrices, class_11659 queue, int overlay) {
        int i;
        SkinRig rig = this.rig(mesh);
        Matrix4f[] bones = this.animate.get() != false ? this.bones(rig, state) : null;
        boolean tint = this.animate.get() != false && this.showParts.get() != false;
        int light = state.field_61820;
        float s = 2.0f;
        if (this.fitSkin.get().booleanValue() && rig.halfWidth * 2.0f * s > 1.0f) {
            s = 1.0f / Math.max(0.01f, rig.halfWidth * 2.0f);
        }
        float offsetY = (float)this.height.get().intValue() / 100.0f / 0.9375f;
        this.elytraDy = 1.501f - (offsetY + (s *= (float)this.size.get().intValue() / 100.0f) * rig.wingY);
        this.elytraDz = -(s * rig.backZ + 0.125f);
        matrices.method_22903();
        matrices.method_46416(0.0f, 1.501f, 0.0f);
        matrices.method_22905(-1.0f, -1.0f, 1.0f);
        matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees(180.0f));
        matrices.method_46416(0.0f, (float)this.height.get().intValue() / 100.0f / 0.9375f, 0.0f);
        matrices.method_22905(s, s, s);
        float[][] affine = null;
        int slot = 0;
        if (bones != null) {
            affine = new float[bones.length][];
            for (int b = 0; b < bones.length; ++b) {
                affine[b] = CustomSkin.affine(bones[b]);
            }
            if (this.poseRig != rig) {
                this.poseRig = rig;
                this.posePositions = new float[6][mesh.parts.size()][];
                this.poseNormals = new float[6][mesh.parts.size()][];
                this.tinted = null;
            }
            slot = this.ring;
            this.ring = (this.ring + 1) % 6;
        }
        if (tint && this.tinted == null) {
            this.tinted = new int[mesh.parts.size()][];
            for (i = 0; i < this.tinted.length; ++i) {
                this.tinted[i] = CustomSkin.tint(rig, i, mesh.parts.get((int)i).colors);
            }
        }
        for (i = 0; i < mesh.parts.size(); ++i) {
            SkinMesh.Part part = mesh.parts.get(i);
            if (part.texture() == null) continue;
            float[] uv = part.uvs;
            if (affine != null) {
                if (this.posePositions[slot][i] == null) {
                    this.posePositions[slot][i] = new float[rig.positions[i].length];
                    this.poseNormals[slot][i] = new float[rig.normals[i].length];
                }
                CustomSkin.pose(rig, i, affine, this.posePositions[slot][i], this.poseNormals[slot][i]);
            }
            float[] p = affine != null ? this.posePositions[slot][i] : rig.positions[i];
            float[] n = affine != null ? this.poseNormals[slot][i] : rig.normals[i];
            int[] c = tint ? this.tinted[i] : part.colors;
            int[] q = this.quads(mesh, part.triangles);
            queue.method_73483(matrices, class_12249.method_75994((class_2960)part.texture()), (entry, consumer) -> {
                for (int v : q) {
                    consumer.method_56824(entry, p[v * 3], p[v * 3 + 1], p[v * 3 + 2]).method_39415(c[v]).method_22913(uv[v * 2], uv[v * 2 + 1]).method_22922(overlay).method_60803(light).method_60831(entry, n[v * 3], n[v * 3 + 1], n[v * 3 + 2]);
                }
            });
        }
        matrices.method_22909();
    }

    private int[] quads(SkinMesh mesh, int[] triangles) {
        if (this.quadMesh != mesh) {
            this.quadCache.clear();
            this.quadMesh = mesh;
        }
        return this.quadCache.computeIfAbsent(triangles, CustomSkin::pair);
    }

    private static long edge(int a, int b) {
        return (long)Math.min(a, b) << 32 | (long)Math.max(a, b);
    }

    private static int[] pair(int[] t) {
        int count = t.length / 3;
        int[] partner = new int[count];
        Arrays.fill(partner, -1);
        HashMap<Long, Integer> open = new HashMap<Long, Integer>();
        for (int i = 0; i < count; ++i) {
            int e;
            for (e = 0; e < 3 && partner[i] < 0; ++e) {
                Integer other = (Integer)open.get(CustomSkin.edge(t[i * 3 + e], t[i * 3 + (e + 1) % 3]));
                if (other == null || partner[other] >= 0) continue;
                partner[i] = other;
                partner[other.intValue()] = i;
            }
            if (partner[i] >= 0) continue;
            for (e = 0; e < 3; ++e) {
                open.put(CustomSkin.edge(t[i * 3 + e], t[i * 3 + (e + 1) % 3]), i);
            }
        }
        int quads = 0;
        for (int i = 0; i < count; ++i) {
            if (partner[i] >= 0 && partner[i] <= i) continue;
            ++quads;
        }
        int[] out = new int[quads * 4];
        int o = 0;
        block4: for (int i = 0; i < count; ++i) {
            int j = partner[i];
            if (j >= 0 && j < i) continue;
            if (j < 0) {
                out[o++] = t[i * 3];
                out[o++] = t[i * 3 + 1];
                out[o++] = t[i * 3 + 2];
                out[o++] = t[i * 3 + 2];
                continue;
            }
            for (int r = 0; r < 3; ++r) {
                int x = t[i * 3 + r];
                int y = t[i * 3 + (r + 1) % 3];
                int z = t[i * 3 + (r + 2) % 3];
                int d = -1;
                int shared = 0;
                for (int k = 0; k < 3; ++k) {
                    int v = t[j * 3 + k];
                    if (v == x || v == y) {
                        ++shared;
                        continue;
                    }
                    d = v;
                }
                if (shared != 2 || d < 0) continue;
                out[o++] = x;
                out[o++] = d;
                out[o++] = y;
                out[o++] = z;
                continue block4;
            }
        }
        return o == out.length ? out : Arrays.copyOf(out, o);
    }

    private static int[] tint(SkinRig rig, int part, int[] colors) {
        int[] out = new int[colors.length];
        byte[] bones = rig.bones[part];
        float[] weights = rig.weights[part];
        for (int v = 0; v < out.length; ++v) {
            byte bone = bones[v];
            out[v] = bone == 0 ? colors[v] : CustomSkin.mix(colors[v], PART_COLORS[bone], 0.75f * weights[v]);
        }
        return out;
    }

    private static int mix(int a, int b, float t) {
        int ar = a >> 16 & 0xFF;
        int ag = a >> 8 & 0xFF;
        int ab = a & 0xFF;
        int br = b >> 16 & 0xFF;
        int bg = b >> 8 & 0xFF;
        int bb = b & 0xFF;
        return a & 0xFF000000 | (int)((float)ar + (float)(br - ar) * t) << 16 | (int)((float)ag + (float)(bg - ag) * t) << 8 | (int)((float)ab + (float)(bb - ab) * t);
    }

    private static Matrix4f around(float[] pivot, Matrix4f rotation) {
        return new Matrix4f().translate(pivot[0], pivot[1], pivot[2]).mul((Matrix4fc)rotation).translate(-pivot[0], -pivot[1], -pivot[2]);
    }

    private static Matrix4f limb(float pitch, float yaw, float roll) {
        return new Matrix4f().rotateZ(-roll).rotateY(-yaw).rotateX(pitch);
    }

    private Matrix4f[] bones(SkinRig rig, class_10055 state) {
        float leaning;
        float glide;
        float strength = (float)this.swing.get().intValue() / 100.0f;
        float g = state.field_53450;
        float h = state.field_53451 / Math.max(0.01f, state.field_53405);
        float headPitch = state.field_53448 * (float)Math.PI / 180.0f;
        float headYaw = state.field_53447 * (float)Math.PI / 180.0f;
        float f = glide = state.field_53411 ? class_3532.method_15363((float)state.method_64259(), (float)0.0f, (float)1.0f) : 0.0f;
        if (state.field_53411) {
            headPitch = rig.headStrength >= 1.0f ? -0.7853982f : class_3532.method_16439((float)glide, (float)headPitch, (float)-0.15f);
            headYaw *= 1.0f - 0.6f * glide;
        } else if (state.field_53403 > 0.0f) {
            headPitch = class_3532.method_61345((float)state.field_53403, (float)headPitch, (float)-0.7853982f);
        }
        float rArmP = class_3532.method_15362((double)(g * 0.6662f + (float)Math.PI)) * h * strength;
        float lArmP = class_3532.method_15362((double)(g * 0.6662f)) * h * strength;
        float rArmY = 0.0f;
        float lArmY = 0.0f;
        float rArmR = 0.0f;
        float lArmR = 0.0f;
        float rLegP = class_3532.method_15362((double)(g * 0.6662f)) * 1.4f * h * strength;
        float lLegP = class_3532.method_15362((double)(g * 0.6662f + (float)Math.PI)) * 1.4f * h * strength;
        float rLegY = 0.0f;
        float lLegY = 0.0f;
        float rLegR = 0.0f;
        float lLegR = 0.0f;
        if (state.field_53413) {
            rArmP -= 0.62831855f;
            lArmP -= 0.62831855f;
            rLegP = -1.4137167f;
            rLegY = 0.31415927f;
            rLegR = 0.07853982f;
            lLegP = -1.4137167f;
            lLegY = -0.31415927f;
            lLegR = -0.07853982f;
        }
        String right = state.field_55304.name();
        String left = state.field_55306.name();
        boolean twoHanded = false;
        if (right.equals("BOW_AND_ARROW") || left.equals("BOW_AND_ARROW") || right.startsWith("CROSSBOW") || left.startsWith("CROSSBOW")) {
            boolean mirror = left.equals("BOW_AND_ARROW") || left.startsWith("CROSSBOW");
            rArmY = mirror ? -0.1f + headYaw - 0.4f : -0.1f + headYaw;
            lArmY = mirror ? 0.1f + headYaw : 0.1f + headYaw + 0.4f;
            rArmP = -1.5707964f + headPitch;
            lArmP = -1.5707964f + headPitch;
            twoHanded = true;
        }
        if (!twoHanded) {
            float[] r = CustomSkin.armPose(right, rArmP, rArmY, headPitch, headYaw, state.field_53410, true);
            rArmP = r[0];
            rArmY = r[1];
            float[] l = CustomSkin.armPose(left, lArmP, lArmY, headPitch, headYaw, state.field_53410, false);
            lArmP = l[0];
            lArmY = l[1];
        }
        if (glide > 0.0f) {
            float flutter = class_3532.method_15374((double)(state.field_53328 * 0.35f)) * 0.05f;
            float kick = class_3532.method_15374((double)(state.field_53328 * 0.22f)) * 0.08f;
            rArmP = class_3532.method_16439((float)glide, (float)rArmP, (float)(0.18f + flutter));
            lArmP = class_3532.method_16439((float)glide, (float)lArmP, (float)(0.18f - flutter));
            rArmY = class_3532.method_16439((float)glide, (float)rArmY, (float)0.0f);
            lArmY = class_3532.method_16439((float)glide, (float)lArmY, (float)0.0f);
            rArmR = class_3532.method_16439((float)glide, (float)rArmR, (float)(0.62f + flutter));
            lArmR = class_3532.method_16439((float)glide, (float)lArmR, (float)(-0.62f - flutter));
            rLegP = class_3532.method_16439((float)glide, (float)rLegP, (float)(0.1f + kick));
            lLegP = class_3532.method_16439((float)glide, (float)lLegP, (float)(0.1f - kick));
            rLegY = class_3532.method_16439((float)glide, (float)rLegY, (float)0.0f);
            lLegY = class_3532.method_16439((float)glide, (float)lLegY, (float)0.0f);
            rLegR = class_3532.method_16439((float)glide, (float)rLegR, (float)0.09f);
            lLegR = class_3532.method_16439((float)glide, (float)lLegR, (float)-0.09f);
        }
        float bodyYaw = 0.0f;
        float f2 = state.field_63604;
        if (f2 > 0.0f) {
            bodyYaw = class_3532.method_15374((double)(class_3532.method_15355((float)f2) * (float)Math.PI * 2.0f)) * 0.2f;
            if (state.field_53408 == class_1306.field_6182) {
                bodyYaw = -bodyYaw;
            }
            rArmY += bodyYaw;
            lArmY += bodyYaw;
            lArmP += bodyYaw;
            if (state.field_63603 == class_12122.field_63399) {
                float eased = 1.0f - (1.0f - f2) * (1.0f - f2) * (1.0f - f2) * (1.0f - f2);
                float i = class_3532.method_15374((double)(eased * (float)Math.PI));
                float j = class_3532.method_15374((double)(f2 * (float)Math.PI)) * -(headPitch - 0.7f) * 0.75f;
                if (state.field_53408 == class_1306.field_6182) {
                    lArmP -= i * 1.2f + j;
                    lArmY += bodyYaw * 2.0f;
                    lArmR += class_3532.method_15374((double)(f2 * (float)Math.PI)) * -0.4f;
                } else {
                    rArmP -= i * 1.2f + j;
                    rArmY += bodyYaw * 2.0f;
                    rArmR += class_3532.method_15374((double)(f2 * (float)Math.PI)) * -0.4f;
                }
            }
        }
        float sway = 1.0f - glide;
        if (!right.equals("SPYGLASS")) {
            rArmR += (class_3532.method_15362((double)(state.field_53328 * 0.09f)) * 0.05f + 0.05f) * sway;
            rArmP += class_3532.method_15374((double)(state.field_53328 * 0.067f)) * 0.05f * sway;
        }
        if (!left.equals("SPYGLASS")) {
            lArmR -= (class_3532.method_15362((double)(state.field_53328 * 0.09f)) * 0.05f + 0.05f) * sway;
            lArmP -= class_3532.method_15374((double)(state.field_53328 * 0.067f)) * 0.05f * sway;
        }
        if ((leaning = state.field_53403) > 0.0f) {
            lLegP = class_3532.method_16439((float)leaning, (float)lLegP, (float)(0.3f * class_3532.method_15362((double)(g * 0.33333334f + (float)Math.PI))));
            rLegP = class_3532.method_16439((float)leaning, (float)rLegP, (float)(0.3f * class_3532.method_15362((double)(g * 0.33333334f))));
        }
        if (!this.animateArms.get().booleanValue()) {
            lArmR = 0.0f;
            rArmR = 0.0f;
            lArmY = 0.0f;
            rArmY = 0.0f;
            lArmP = 0.0f;
            rArmP = 0.0f;
        }
        if (!this.animateLegs.get().booleanValue()) {
            lLegR = 0.0f;
            rLegR = 0.0f;
            lLegY = 0.0f;
            rLegY = 0.0f;
            lLegP = 0.0f;
            rLegP = 0.0f;
        }
        float headScale = this.animateHead.get() != false ? rig.headStrength : 0.0f;
        float lean = state.field_53410 ? 0.45f : 0.0f;
        Matrix4f body = CustomSkin.around(rig.hip, new Matrix4f().rotateY(-bodyYaw).rotateX(lean));
        Matrix4f[] bones = new Matrix4f[]{body, new Matrix4f((Matrix4fc)body).mul((Matrix4fc)CustomSkin.around(rig.neck, new Matrix4f().rotateY(-headYaw * headScale).rotateX(headPitch * headScale))), new Matrix4f((Matrix4fc)body).mul((Matrix4fc)CustomSkin.around(rig.armPivot[0], CustomSkin.limb(rArmP, rArmY, rArmR).rotateZ(rig.armRest[0]))), new Matrix4f((Matrix4fc)body).mul((Matrix4fc)CustomSkin.around(rig.armPivot[1], CustomSkin.limb(lArmP, lArmY, lArmR).rotateZ(rig.armRest[1]))), CustomSkin.around(rig.legPivot[0], CustomSkin.limb(rLegP, rLegY, rLegR)), CustomSkin.around(rig.legPivot[1], CustomSkin.limb(lLegP, lLegY, lLegR))};
        return bones;
    }

    private static float[] armPose(String pose, float pitch, float yaw, float headPitch, float headYaw, boolean sneaking, boolean right) {
        float[] fArray;
        switch (pose) {
            case "ITEM": {
                float[] fArray2 = new float[2];
                fArray2[0] = pitch * 0.5f - 0.31415927f;
                fArray = fArray2;
                fArray2[1] = 0.0f;
                break;
            }
            case "BLOCK": {
                float[] fArray3 = new float[2];
                fArray3[0] = pitch * 0.5f - 0.9424779f;
                fArray = fArray3;
                fArray3[1] = right ? -0.5235988f : 0.5235988f;
                break;
            }
            case "THROW_TRIDENT": 
            case "SPEAR": {
                float[] fArray4 = new float[2];
                fArray4[0] = pitch * 0.5f - (float)Math.PI;
                fArray = fArray4;
                fArray4[1] = 0.0f;
                break;
            }
            case "SPYGLASS": {
                float[] fArray5 = new float[2];
                fArray5[0] = class_3532.method_15363((float)(headPitch - 1.9198622f - (sneaking ? 0.2617994f : 0.0f)), (float)-2.4f, (float)3.3f);
                fArray = fArray5;
                fArray5[1] = headYaw + (right ? -0.2617994f : 0.2617994f);
                break;
            }
            case "TOOT_HORN": {
                float[] fArray6 = new float[2];
                fArray6[0] = class_3532.method_15363((float)headPitch, (float)-1.2f, (float)1.2f) - 1.4835298f;
                fArray = fArray6;
                fArray6[1] = headYaw + (right ? -0.5235988f : 0.5235988f);
                break;
            }
            case "BRUSH": {
                float[] fArray7 = new float[2];
                fArray7[0] = pitch * 0.5f - 0.62831855f;
                fArray = fArray7;
                fArray7[1] = 0.0f;
                break;
            }
            default: {
                float[] fArray8 = new float[2];
                fArray8[0] = pitch;
                fArray = fArray8;
                fArray8[1] = yaw;
            }
        }
        return fArray;
    }

    private static void pose(SkinRig rig, int part, float[][] m, float[] out, float[] outN) {
        float[] src = rig.positions[part];
        float[] srcN = rig.normals[part];
        byte[] boneOf = rig.bones[part];
        float[] weight = rig.weights[part];
        float[] upper = rig.upper[part];
        float[] body = m[0];
        int v = 0;
        int k = 0;
        while (v < src.length) {
            float length;
            float x = src[v];
            float y = src[v + 1];
            float z = src[v + 2];
            float nx = srcN[v];
            float ny = srcN[v + 1];
            float nz = srcN[v + 2];
            float px = x;
            float py = y;
            float pz = z;
            float qx = nx;
            float qy = ny;
            float qz = nz;
            float u = upper[k];
            if (u > 0.0f) {
                px += (CustomSkin.tx(body, x, y, z) - x) * u;
                py += (CustomSkin.ty(body, x, y, z) - y) * u;
                pz += (CustomSkin.tz(body, x, y, z) - z) * u;
                qx += (CustomSkin.rx(body, nx, ny, nz) - nx) * u;
                qy += (CustomSkin.ry(body, nx, ny, nz) - ny) * u;
                qz += (CustomSkin.rz(body, nx, ny, nz) - nz) * u;
            }
            byte bone = boneOf[k];
            float w = weight[k];
            if (bone != 0 && w > 0.0f) {
                float[] a = m[bone];
                px += (CustomSkin.tx(a, x, y, z) - px) * w;
                py += (CustomSkin.ty(a, x, y, z) - py) * w;
                pz += (CustomSkin.tz(a, x, y, z) - pz) * w;
                qx += (CustomSkin.rx(a, nx, ny, nz) - qx) * w;
                qy += (CustomSkin.ry(a, nx, ny, nz) - qy) * w;
                qz += (CustomSkin.rz(a, nx, ny, nz) - qz) * w;
            }
            if ((length = (float)Math.sqrt(qx * qx + qy * qy + qz * qz)) > 1.0E-6f) {
                qx /= length;
                qy /= length;
                qz /= length;
            }
            out[v] = px;
            out[v + 1] = py;
            out[v + 2] = pz;
            outN[v] = qx;
            outN[v + 1] = qy;
            outN[v + 2] = qz;
            v += 3;
            ++k;
        }
    }

    private static float[] affine(Matrix4f m) {
        return new float[]{m.m00(), m.m01(), m.m02(), m.m10(), m.m11(), m.m12(), m.m20(), m.m21(), m.m22(), m.m30(), m.m31(), m.m32()};
    }

    private static float tx(float[] m, float x, float y, float z) {
        return m[0] * x + m[3] * y + m[6] * z + m[9];
    }

    private static float ty(float[] m, float x, float y, float z) {
        return m[1] * x + m[4] * y + m[7] * z + m[10];
    }

    private static float tz(float[] m, float x, float y, float z) {
        return m[2] * x + m[5] * y + m[8] * z + m[11];
    }

    private static float rx(float[] m, float x, float y, float z) {
        return m[0] * x + m[3] * y + m[6] * z;
    }

    private static float ry(float[] m, float x, float y, float z) {
        return m[1] * x + m[4] * y + m[7] * z;
    }

    private static float rz(float[] m, float x, float y, float z) {
        return m[2] * x + m[5] * y + m[8] * z;
    }

    @Override
    public int presetCount() {
        return 1 + SkinManager.files().size();
    }

    @Override
    public String presetName(int index) {
        if (index == 0) {
            return "None";
        }
        List<String> files = SkinManager.files();
        return index - 1 < files.size() ? SkinManager.title(files.get(index - 1)) : "";
    }

    @Override
    public int presetColor(int index) {
        return index == 0 ? -9801856 : -2762274;
    }

    @Override
    public boolean presetActive(int index) {
        if (index == 0) {
            return this.skin.get().isEmpty();
        }
        List<String> files = SkinManager.files();
        return index - 1 < files.size() && files.get(index - 1).equals(this.skin.get());
    }

    @Override
    public void selectPreset(int index) {
        if (index == 0) {
            this.skin.set("");
            return;
        }
        List<String> files = SkinManager.files();
        if (index - 1 >= files.size()) {
            return;
        }
        this.skin.set(files.get(index - 1));
        if (!this.isActive()) {
            this.setEnabled(true);
        }
        Notifications.push("Custom Skin", "Loading " + SkinManager.title(files.get(index - 1)) + "...", Notifications.Type.INFO);
    }

    @Override
    public String presetDescription() {
        return "Sober Cat, Sober Bot and Banana Buddy are built in. Your own 3D models go into config/sober/skins (.glb, .gltf, .obj or .stl). Use Open Folder below.";
    }

    @Override
    public boolean showInHud() {
        return false;
    }
}

