/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.brigadier.CommandDispatcher
 *  com.mojang.brigadier.arguments.ArgumentType
 *  com.mojang.brigadier.arguments.StringArgumentType
 *  com.mojang.brigadier.builder.LiteralArgumentBuilder
 *  com.mojang.brigadier.context.CommandContext
 *  com.mojang.brigadier.suggestion.SuggestionProvider
 *  com.mojang.brigadier.suggestion.SuggestionsBuilder
 *  net.fabricmc.fabric.api.client.command.v2.ClientCommandManager
 *  net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback
 *  net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource
 *  net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents
 *  net.minecraft.class_124
 *  net.minecraft.class_2172
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 *  net.minecraft.class_5250
 *  net.minecraft.class_5251
 */
package dev.sober.modules;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import dev.sober.SoberClient;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;
import net.minecraft.class_5251;

public class FakePay
extends Module {
    private final Setting<String> icon = this.add(new StringSetting("Icon", "Text put in front of the player name where %icon% is used, for example a rank.", ""));
    private final Setting<String> chatPaid;
    private final Setting<String> actionbarPaid;
    private final Setting<String> chatReceived;
    private final Setting<String> actionbarReceived;
    private final Setting<String> amounts;

    public FakePay() {
        super("Fake Pay", "While it is on, /pay <player> <amount> is not sent to the server and only shows the pay message in your own chat and action bar. /fakepay send and /fakepay receive show a message without paying. Nothing is sent and nobody else sees it.", Category.DONUT);
        this.group("Messages");
        this.chatPaid = this.add(new StringSetting("Chat Paid", "Chat line after /pay. Use %player%, %amount%, %amount_grouped% and %icon%, & color codes and &#RRGGBB. Empty shows nothing.", "&fYou paid %icon%%player% &a$ %amount%"));
        this.actionbarPaid = this.add(new StringSetting("Action Bar Paid", "Action bar text after /pay. Empty shows nothing.", "&fYou paid %player% &a$ %amount%"));
        this.chatReceived = this.add(new StringSetting("Chat Received", "Chat line for /fakepay receive. Empty shows nothing.", "&f%icon%%player% paid you &a$ %amount%"));
        this.actionbarReceived = this.add(new StringSetting("Action Bar Received", "Action bar text for /fakepay receive. Empty shows nothing.", "&f%player% paid you &a$ %amount%"));
        this.amounts = this.add(new StringSetting("Amounts", "Amounts suggested when you press Tab in /fakepay, separated by commas.", "100, 1000, 10000, 100000, 1000000"));
        ClientSendMessageEvents.ALLOW_COMMAND.register(this::allowCommand);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> this.register((CommandDispatcher<FabricClientCommandSource>)dispatcher));
    }

    private boolean allowCommand(String command) {
        if (!this.isActive()) {
            return true;
        }
        String[] parts = command.trim().split("\\s+", 3);
        if (parts.length < 3 || !parts[0].equalsIgnoreCase("pay")) {
            return true;
        }
        mc.execute(() -> this.showPaid(parts[1], parts[2].trim()));
        return false;
    }

    private void register(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        SuggestionProvider players = (context, builder) -> class_2172.method_9265((Iterable)((FabricClientCommandSource)context.getSource()).method_9262(), (SuggestionsBuilder)builder);
        SuggestionProvider money = (context, builder) -> class_2172.method_9265(this.amountList(), (SuggestionsBuilder)builder);
        dispatcher.register((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)((LiteralArgumentBuilder)ClientCommandManager.literal((String)"fakepay").executes(context -> this.status((FabricClientCommandSource)context.getSource()))).then(ClientCommandManager.literal((String)"on").executes(context -> this.intercept((FabricClientCommandSource)context.getSource(), true)))).then(ClientCommandManager.literal((String)"off").executes(context -> this.intercept((FabricClientCommandSource)context.getSource(), false)))).then(ClientCommandManager.literal((String)"toggle").executes(context -> this.intercept((FabricClientCommandSource)context.getSource(), !this.isActive())))).then(ClientCommandManager.literal((String)"send").then(ClientCommandManager.argument((String)"player", (ArgumentType)StringArgumentType.word()).suggests(players).then(ClientCommandManager.argument((String)"amount", (ArgumentType)StringArgumentType.greedyString()).suggests(money).executes(context -> this.run((CommandContext<FabricClientCommandSource>)context, true)))))).then(ClientCommandManager.literal((String)"receive").then(ClientCommandManager.argument((String)"player", (ArgumentType)StringArgumentType.word()).suggests(players).then(ClientCommandManager.argument((String)"amount", (ArgumentType)StringArgumentType.greedyString()).suggests(money).executes(context -> this.run((CommandContext<FabricClientCommandSource>)context, false))))));
    }

    private int run(CommandContext<FabricClientCommandSource> context, boolean paid) {
        String player = StringArgumentType.getString(context, (String)"player");
        String amount = StringArgumentType.getString(context, (String)"amount").trim();
        if (paid) {
            this.showPaid(player, amount);
        } else {
            this.showReceived(player, amount);
        }
        return 1;
    }

    private int intercept(FabricClientCommandSource source, boolean on) {
        this.setEnabled(on);
        SoberClient.CONFIG.save();
        return this.status(source);
    }

    private int status(FabricClientCommandSource source) {
        source.sendFeedback((class_2561)FakePay.parse(this.isActive() ? "&7Fake Pay: /pay is &ablocked&7 and only shows the message." : "&7Fake Pay: /pay is &csent to the server&7 as normal."));
        return 1;
    }

    private List<String> amountList() {
        ArrayList<String> list = new ArrayList<String>();
        for (String part : this.amounts.get().split(",")) {
            String value = part.trim();
            if (value.isEmpty()) continue;
            list.add(value);
        }
        return list;
    }

    private void showPaid(String player, String amount) {
        this.show(this.chatPaid.get(), this.actionbarPaid.get(), player, amount);
    }

    private void showReceived(String player, String amount) {
        this.show(this.chatReceived.get(), this.actionbarReceived.get(), player, amount);
    }

    private void show(String chat, String actionbar, String player, String amount) {
        if (FakePay.mc.field_1705 == null) {
            return;
        }
        String chatLine = this.fill(chat, player, amount);
        String barLine = this.fill(actionbar, player, amount);
        if (!chatLine.isBlank()) {
            FakePay.mc.field_1705.method_1743().method_1812((class_2561)FakePay.parse(chatLine));
        }
        if (!barLine.isBlank()) {
            FakePay.mc.field_1705.method_1758((class_2561)FakePay.parse(barLine), false);
        }
    }

    private String fill(String template, String player, String amount) {
        if (template == null) {
            return "";
        }
        return template.replace("%icon%", this.icon.get()).replace("%player%", player).replace("%amount_grouped%", FakePay.grouped(amount)).replace("%amount%", amount);
    }

    static String grouped(String amount) {
        try {
            String plain = amount.replace(",", "").replace("_", "").trim();
            if (plain.contains(".")) {
                NumberFormat format = NumberFormat.getNumberInstance(Locale.US);
                format.setMaximumFractionDigits(2);
                return format.format(Double.parseDouble(plain));
            }
            return NumberFormat.getIntegerInstance(Locale.US).format(Long.parseLong(plain));
        }
        catch (NumberFormatException e) {
            return amount;
        }
    }

    static class_5250 parse(String input) {
        class_5250 out = class_2561.method_43473();
        if (input == null || input.isEmpty()) {
            return out;
        }
        class_2583 style = class_2583.field_24360;
        StringBuilder pending = new StringBuilder();
        for (int i = 0; i < input.length(); ++i) {
            char c = input.charAt(i);
            if ((c == '&' || c == '\u00a7') && i + 1 < input.length()) {
                class_124 formatting;
                char code = Character.toLowerCase(input.charAt(i + 1));
                if (code == '#' && i + 7 < input.length()) {
                    try {
                        int rgb = Integer.parseInt(input.substring(i + 2, i + 8), 16);
                        FakePay.flush(out, pending, style);
                        style = class_2583.field_24360.method_27703(class_5251.method_27717((int)rgb));
                        i += 7;
                        continue;
                    }
                    catch (NumberFormatException rgb) {
                        // empty catch block
                    }
                }
                if ((formatting = class_124.method_544((char)code)) != null) {
                    FakePay.flush(out, pending, style);
                    style = formatting == class_124.field_1070 ? class_2583.field_24360 : (formatting.method_543() ? class_2583.field_24360.method_27706(formatting) : style.method_27706(formatting));
                    ++i;
                    continue;
                }
            }
            pending.append(c);
        }
        FakePay.flush(out, pending, style);
        return out;
    }

    private static void flush(class_5250 out, StringBuilder pending, class_2583 style) {
        if (pending.isEmpty()) {
            return;
        }
        out.method_10852((class_2561)class_2561.method_43470((String)pending.toString()).method_10862(style));
        pending.setLength(0);
    }

    @Override
    public boolean showInHud() {
        return false;
    }
}

