/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1531
 *  net.minecraft.class_1657
 *  net.minecraft.class_239
 *  net.minecraft.class_3966
 *  net.minecraft.class_746
 */
package dev.sober.modules;

import dev.sober.config.FriendStore;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.CombatItems;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import net.minecraft.class_746;

public class TriggerBot
extends Module {
    private final Setting<Targets> targets = this.add(new EnumSetting<Targets>("Targets", "What gets hit when it is under your crosshair.", Targets.Players));
    private final Setting<Integer> charge = this.add(new IntSetting("Charge", "Hits once your attack is charged this many percent. 100 gives full damage.", 100, 10, 100));
    private final Setting<Integer> delay = this.add(new IntSetting("Random Delay", "Waits up to this many milliseconds more before a hit, so the timing is never the same.", 60, 0, 300));
    private final Setting<Boolean> friends = this.add(new BoolSetting("Ignore Friends", "Never hits players on your friend list.", true));
    private final Setting<Boolean> weaponOnly = this.add(new BoolSetting("Weapons Only", "Only hits while you hold a sword, axe, mace or trident.", true));
    private final Random random = new Random();
    private long hitAt = -1L;

    public TriggerBot() {
        super("Trigger Bot", "Hits the player or mob under your crosshair as soon as your attack is charged.", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        this.hitAt = -1L;
    }

    @Override
    public void onTick() {
        class_746 player = TriggerBot.mc.field_1724;
        class_1309 target = this.target();
        if (target == null || player == null || TriggerBot.mc.field_1761 == null || TriggerBot.mc.field_1755 != null || player.method_6115() || this.weaponOnly.get().booleanValue() && !CombatItems.isWeapon(player.method_6047()) || player.method_7261(0.5f) * 100.0f < (float)this.charge.get().intValue()) {
            this.hitAt = -1L;
            return;
        }
        long now = System.currentTimeMillis();
        if (this.hitAt < 0L) {
            this.hitAt = now + (long)(this.delay.get() > 0 ? this.random.nextInt(this.delay.get() + 1) : 0);
        }
        if (now < this.hitAt) {
            return;
        }
        this.hitAt = -1L;
        TriggerBot.mc.field_1761.method_2918((class_1657)player, (class_1297)target);
        player.method_6104(class_1268.field_5808);
    }

    private class_1309 target() {
        class_3966 hit;
        class_239 class_2392 = TriggerBot.mc.field_1765;
        if (!(class_2392 instanceof class_3966) || !((class_2392 = (hit = (class_3966)class_2392).method_17782()) instanceof class_1309)) {
            return null;
        }
        class_1309 living = (class_1309)class_2392;
        if (!living.method_5805() || living instanceof class_1531) {
            return null;
        }
        if (living instanceof class_1657) {
            class_1657 other = (class_1657)living;
            if (this.targets.get() == Targets.Mobs) {
                return null;
            }
            return this.friends.get() != false && FriendStore.getInstance().isFriend(other.method_7334().name()) ? null : living;
        }
        return this.targets.get() == Targets.Players ? null : living;
    }

    public static enum Targets {
        Players,
        Mobs,
        All;

    }
}

