/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1661
 *  net.minecraft.class_1747
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_1937
 *  net.minecraft.class_2246
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_2680
 *  net.minecraft.class_2769
 *  net.minecraft.class_3965
 *  net.minecraft.class_4969
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3965;
import net.minecraft.class_4969;

public class AnchorMacro
extends Module {
    private final Setting<Boolean> useKey = this.add(new BoolSetting("Use Key", "Only works while you hold right click on the anchor.", true));
    private final Setting<Integer> explodeSlot = this.add(new IntSetting(this, "Explode Slot", "Hotbar slot used to blow up the anchor. Auto takes an empty slot, a totem or another safe item.", 0, 0, 9){

        @Override
        public String display() {
            return (Integer)this.value == 0 ? "Auto" : String.valueOf(this.value);
        }
    });
    private final Setting<Boolean> switchBack = this.add(new BoolSetting("Switch Back", "Goes back to the slot you held before.", true));
    private final Setting<Integer> delay = this.add(new IntSetting("Delay", "Ticks between charging and blowing up.", 2, 0, 10));
    private int previous = -1;
    private int timer;

    public AnchorMacro() {
        super("Anchor Macro", "Charges the respawn anchor you look at with glowstone and blows it up right after.", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        this.restore();
    }

    @Override
    public void onTick() {
        class_3965 hit;
        if (AnchorMacro.mc.field_1724 == null || AnchorMacro.mc.field_1687 == null || AnchorMacro.mc.field_1761 == null) {
            return;
        }
        if (this.useKey.get().booleanValue() && !AnchorMacro.mc.field_1690.field_1904.method_1434()) {
            this.restore();
            return;
        }
        if (this.timer > 0) {
            --this.timer;
            return;
        }
        class_239 class_2392 = AnchorMacro.mc.field_1765;
        if (!(class_2392 instanceof class_3965) || (hit = (class_3965)class_2392).method_17783() != class_239.class_240.field_1332) {
            this.restore();
            return;
        }
        class_2680 state = AnchorMacro.mc.field_1687.method_8320(hit.method_17777());
        if (!state.method_27852(class_2246.field_23152)) {
            this.restore();
            return;
        }
        class_1661 inventory = AnchorMacro.mc.field_1724.method_31548();
        if ((Integer)state.method_11654((class_2769)class_4969.field_23153) == 0) {
            for (int i = 0; i < 9; ++i) {
                if (!inventory.method_5438(i).method_31574(class_1802.field_8801)) continue;
                this.use(i, hit);
                return;
            }
            return;
        }
        if (AnchorMacro.mc.field_1687.method_27983() == class_1937.field_25180) {
            return;
        }
        int slot = this.explodeSlot(inventory);
        if (slot >= 0) {
            this.use(slot, hit);
        }
    }

    private void use(int slot, class_3965 hit) {
        class_1661 inventory = AnchorMacro.mc.field_1724.method_31548();
        if (this.previous < 0) {
            this.previous = inventory.method_67532();
        }
        inventory.method_61496(slot);
        AnchorMacro.mc.field_1761.method_2896(AnchorMacro.mc.field_1724, class_1268.field_5808, hit);
        AnchorMacro.mc.field_1724.method_6104(class_1268.field_5808);
        this.timer = this.delay.get();
    }

    private int explodeSlot(class_1661 inventory) {
        int i;
        int chosen = this.explodeSlot.get() - 1;
        if (chosen >= 0) {
            return inventory.method_5438(chosen).method_31574(class_1802.field_8801) ? -1 : chosen;
        }
        for (i = 0; i < 9; ++i) {
            if (!inventory.method_5438(i).method_7960()) continue;
            return i;
        }
        for (i = 0; i < 9; ++i) {
            if (!inventory.method_5438(i).method_31574(class_1802.field_8288)) continue;
            return i;
        }
        for (i = 0; i < 9; ++i) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_31574(class_1802.field_8801) || stack.method_7909() instanceof class_1747) continue;
            return i;
        }
        return -1;
    }

    private void restore() {
        if (this.previous >= 0 && this.switchBack.get().booleanValue() && AnchorMacro.mc.field_1724 != null) {
            AnchorMacro.mc.field_1724.method_31548().method_61496(this.previous);
        }
        this.previous = -1;
    }
}

