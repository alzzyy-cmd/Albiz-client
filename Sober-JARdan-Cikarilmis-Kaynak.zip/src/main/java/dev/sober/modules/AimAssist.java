/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1531
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_3532
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.config.FriendStore;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.CombatItems;
import dev.sober.modules.Freecam;
import dev.sober.modules.Freelook;
import dev.sober.render.Render3D;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class AimAssist
extends Module {
    private final Setting<Integer> range = this.add(new IntSetting("Range", "Targets within this many blocks are aimed at.", 5, 2, 8));
    private final Setting<Integer> fov = this.add(new IntSetting("FOV", "Only targets inside this angle around your crosshair, in degrees.", 60, 10, 180));
    private final Setting<Integer> speed = this.add(new IntSetting("Speed", "How fast your view is pulled to the target. Low feels like a soft nudge.", 30, 1, 100));
    private final Setting<Targets> targets = this.add(new EnumSetting<Targets>("Targets", "Aims at players, at mobs or at both.", Targets.Players));
    private final Setting<AimAt> aimAt = this.add(new EnumSetting<AimAt>("Aim At", "Closest aims at the nearest point of the hitbox, Head at the head, Body at the middle.", AimAt.Closest));
    private final Setting<Boolean> clicking = this.add(new BoolSetting("Only While Clicking", "Only aims while you hold the attack key.", true));
    private final Setting<Boolean> vertical = this.add(new BoolSetting("Vertical", "Also moves your view up and down, not only sideways.", true));
    private final Setting<Boolean> walls = this.add(new BoolSetting("Through Walls", "Also aims at targets you cannot see.", false));
    private final Setting<Boolean> friends = this.add(new BoolSetting("Ignore Friends", "Never aims at players on your friend list.", true));
    private final Setting<Boolean> weaponOnly = this.add(new BoolSetting("Weapons Only", "Only aims while you hold a sword, axe, mace or trident.", false));
    private long lastFrame;
    private class_1309 target;

    public AimAssist() {
        super("Aim Assist", "Smoothly pulls your view onto the closest player or mob in front of you.", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        this.target = null;
        this.lastFrame = 0L;
    }

    @Override
    public void onRender(Render3D renderer) {
        long now = System.nanoTime();
        float dt = this.lastFrame == 0L ? 0.0f : Math.min(0.05f, (float)(now - this.lastFrame) / 1.0E9f);
        this.lastFrame = now;
        this.target = null;
        if (AimAssist.mc.field_1724 == null || AimAssist.mc.field_1687 == null || AimAssist.mc.field_1755 != null || AimAssist.mc.field_1724.method_7325()) {
            return;
        }
        if (SoberClient.MODULES.get(Freecam.class).isActive() || SoberClient.MODULES.get(Freelook.class).isActive()) {
            return;
        }
        if (this.clicking.get().booleanValue() && !AimAssist.mc.field_1690.field_1886.method_1434()) {
            return;
        }
        if (this.weaponOnly.get().booleanValue() && !CombatItems.isWeapon(AimAssist.mc.field_1724.method_6047())) {
            return;
        }
        this.target = this.findTarget();
        if (this.target == null || dt <= 0.0f) {
            return;
        }
        class_243 eye = AimAssist.mc.field_1724.method_33571();
        class_243 aim = this.aimPoint(this.target.method_5829(), eye);
        double dx = aim.field_1352 - eye.field_1352;
        double dy = aim.field_1351 - eye.field_1351;
        double dz = aim.field_1350 - eye.field_1350;
        float wantYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float wantPitch = (float)(-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
        float pull = 1.0f - (float)Math.exp((float)(-this.speed.get().intValue()) * 0.25f * dt);
        float yawStep = class_3532.method_15393((float)(wantYaw - AimAssist.mc.field_1724.method_36454())) * pull;
        float pitchStep = this.vertical.get() != false ? (wantPitch - AimAssist.mc.field_1724.method_36455()) * pull : 0.0f;
        AimAssist.mc.field_1724.method_5872((double)yawStep / 0.15, (double)pitchStep / 0.15);
    }

    private class_1309 findTarget() {
        class_1309 best = null;
        double bestAngle = (double)this.fov.get().intValue() / 2.0;
        double max = this.range.get() * this.range.get();
        class_243 eye = AimAssist.mc.field_1724.method_33571();
        for (class_1297 entity : AimAssist.mc.field_1687.method_18112()) {
            class_1309 living;
            if (!(entity instanceof class_1309) || !this.wanted(living = (class_1309)entity) || living.method_5858((class_1297)AimAssist.mc.field_1724) > max || !this.walls.get().booleanValue() && !AimAssist.mc.field_1724.method_6057((class_1297)living)) continue;
            class_243 aim = this.aimPoint(living.method_5829(), eye);
            float yaw = (float)Math.toDegrees(Math.atan2(aim.field_1350 - eye.field_1350, aim.field_1352 - eye.field_1352)) - 90.0f;
            double angle = Math.abs(class_3532.method_15393((float)(yaw - AimAssist.mc.field_1724.method_36454())));
            if (!(angle < bestAngle)) continue;
            bestAngle = angle;
            best = living;
        }
        return best;
    }

    private boolean wanted(class_1309 entity) {
        if (entity == AimAssist.mc.field_1724 || !entity.method_5805() || entity.method_7325() || entity.method_5767() || entity instanceof class_1531) {
            return false;
        }
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (this.targets.get() == Targets.Mobs) {
                return false;
            }
            return this.friends.get() == false || !FriendStore.getInstance().isFriend(player.method_7334().name());
        }
        return this.targets.get() != Targets.Players;
    }

    private class_243 aimPoint(class_238 box, class_243 eye) {
        class_243 center = box.method_1005();
        return switch (this.aimAt.get().ordinal()) {
            default -> throw new MatchException(null, null);
            case 1 -> new class_243(center.field_1352, box.field_1325 - box.method_17940() * 0.12, center.field_1350);
            case 2 -> center;
            case 0 -> {
                class_238 inner = box.method_35580(box.method_17939() * 0.2, box.method_17940() * 0.15, box.method_17941() * 0.2);
                yield new class_243(class_3532.method_15350((double)eye.field_1352, (double)inner.field_1323, (double)inner.field_1320), class_3532.method_15350((double)eye.field_1351, (double)inner.field_1322, (double)inner.field_1325), class_3532.method_15350((double)eye.field_1350, (double)inner.field_1321, (double)inner.field_1324));
            }
        };
    }

    @Override
    public String getInfoString() {
        return this.target == null ? null : this.target.method_5477().getString();
    }

    public static enum Targets {
        Players,
        Mobs,
        All;

    }

    public static enum AimAt {
        Closest,
        Head,
        Body;

    }
}

