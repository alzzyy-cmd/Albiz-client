/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2338
 *  net.minecraft.class_2382
 *  net.minecraft.class_2680
 *  net.minecraft.class_2818
 *  net.minecraft.class_2826
 */
package dev.sober.modules;

import dev.sober.gui.Notifications;
import dev.sober.gui.RegionMap;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BlockListSetting;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import dev.sober.util.ChunkScanner;
import dev.sober.util.DonutUtils;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2826;

public class BlockNotifier
extends Module {
    private final BlockListSetting blocks = (BlockListSetting)this.add(new BlockListSetting("Blocks", "Click to pick the blocks that trigger a notification.", class_2246.field_10260, class_2246.field_22109, class_2246.field_10442, class_2246.field_29029)).onChanged(v -> {
        this.targets = v;
    });
    private final Setting<Integer> minCount = this.add(new IntSetting("Min Count", "Blocks of one type needed in a chunk before you get notified.", 1, 1, 64));
    private final Setting<Boolean> placed = this.add(new BoolSetting("Placed Blocks", "Also notify when a picked block gets placed near you.", true));
    private final Setting<Boolean> chat = this.add(new BoolSetting("Chat Message", "Also writes the find into the chat.", false));
    private final Set<class_2338> known = ConcurrentHashMap.newKeySet();
    private final Map<class_2248, Long> lastNotify = new ConcurrentHashMap<class_2248, Long>();
    private final ChunkScanner scanner = new ChunkScanner("BlockNotifier", this::scan);
    private volatile Set<class_2248> targets = Set.of();
    private volatile int regionRow = -1;
    private volatile int regionCol = -1;
    private int rescanIn = -1;

    public BlockNotifier() {
        super("Block Notifier", "Notifies you when blocks you picked show up.", Category.BASE_FINDING);
    }

    @Override
    public void onEnable() {
        this.targets = (Set)this.blocks.get();
        this.known.clear();
        this.updateRegion();
        this.rescanIn = -1;
        this.scanner.start();
    }

    @Override
    public void onTick() {
        int row = this.regionRow;
        int col = this.regionCol;
        this.updateRegion();
        if (row >= 0 && (row != this.regionRow || col != this.regionCol)) {
            this.rescanIn = 60;
        }
        if (this.rescanIn > 0 && --this.rescanIn == 0) {
            this.rescanIn = -1;
            this.scanner.submitLoaded();
        }
    }

    private void updateRegion() {
        RegionMap.Region region = DonutUtils.onDonut() ? RegionMap.current(mc) : null;
        this.regionRow = region == null ? -1 : region.row();
        this.regionCol = region == null ? -1 : region.col();
    }

    private boolean otherRegion(class_2338 pos) {
        int row = this.regionRow;
        int col = this.regionCol;
        if (row < 0) {
            return false;
        }
        RegionMap.Region region = RegionMap.at((double)pos.method_10263() + 0.5, (double)pos.method_10260() + 0.5);
        return region.row() != row || region.col() != col;
    }

    @Override
    public void onDisable() {
        this.scanner.stop();
        this.known.clear();
    }

    @Override
    public void onGameLeft() {
        this.known.clear();
    }

    @Override
    public void onChunkLoad(class_2818 chunk) {
        this.scanner.submit(chunk);
    }

    private void scan(class_2818 chunk) {
        Set<class_2248> wanted = this.targets;
        if (wanted.isEmpty()) {
            return;
        }
        if (this.known.size() > 100000) {
            this.known.clear();
        }
        HashMap<class_2248, Integer> counts = new HashMap<class_2248, Integer>();
        HashMap<class_2248, class_2338> first = new HashMap<class_2248, class_2338>();
        class_2826[] sections = chunk.method_12006();
        int bottom = chunk.method_31607();
        for (int i = 0; i < sections.length; ++i) {
            class_2826 section = sections[i];
            if (section == null || section.method_38292() || !section.method_19523(state -> wanted.contains(state.method_26204()))) continue;
            int baseY = bottom + i * 16;
            for (int x = 0; x < 16; ++x) {
                for (int y = 0; y < 16; ++y) {
                    for (int z = 0; z < 16; ++z) {
                        class_2338 pos;
                        class_2248 block = section.method_12254(x, y, z).method_26204();
                        if (!wanted.contains(block) || this.otherRegion(pos = new class_2338(chunk.method_12004().method_8326() + x, baseY + y, chunk.method_12004().method_8328() + z)) || !this.known.add(pos)) continue;
                        counts.merge(block, 1, Integer::sum);
                        first.putIfAbsent(block, pos);
                    }
                }
            }
        }
        for (Map.Entry entry : counts.entrySet()) {
            if ((Integer)entry.getValue() < this.minCount.get()) continue;
            this.notifyFound((class_2248)entry.getKey(), (Integer)entry.getValue(), (class_2338)first.get(entry.getKey()));
        }
    }

    private void notifyFound(class_2248 block, int count, class_2338 pos) {
        long now = System.currentTimeMillis();
        Long last = this.lastNotify.get(block);
        if (last != null && now - last < 1500L) {
            return;
        }
        this.lastNotify.put(block, now);
        mc.execute(() -> {
            if (!this.isActive() || BlockNotifier.mc.field_1724 == null || BlockNotifier.mc.field_1687 == null) {
                return;
            }
            if (this.otherRegion(pos) || !BlockNotifier.mc.field_1687.method_8320(pos).method_27852(block)) {
                this.known.remove(pos);
                return;
            }
            int distance = (int)Math.round(Math.sqrt(BlockNotifier.mc.field_1724.method_24515().method_10262((class_2382)pos)));
            String name = block.method_9518().getString();
            String message = (String)(count > 1 ? count + "x " : "") + name + " at " + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260() + " (" + distance + "m)";
            Notifications.push("Block Found", message, Notifications.Type.SUCCESS);
            if (this.chat.get().booleanValue()) {
                this.info(message, new Object[0]);
            }
        });
    }

    @Override
    public void onBlockUpdate(class_2338 pos, class_2680 oldState, class_2680 newState) {
        if (!this.placed.get().booleanValue() || !this.targets.contains(newState.method_26204()) || oldState.method_26204() == newState.method_26204()) {
            return;
        }
        class_2338 immutable = pos.method_10062();
        if (!this.otherRegion(immutable) && this.known.add(immutable)) {
            this.notifyFound(newState.method_26204(), 1, immutable);
        }
    }

    @Override
    public String getInfoString() {
        return String.valueOf(((Set)this.blocks.get()).size());
    }
}

