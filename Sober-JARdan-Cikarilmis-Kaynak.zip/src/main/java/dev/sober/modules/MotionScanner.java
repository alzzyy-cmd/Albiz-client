/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap
 *  it.unimi.dsi.fastutil.longs.Long2ObjectMap$Entry
 *  it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap
 *  net.minecraft.class_1299
 *  net.minecraft.class_1923
 *  net.minecraft.class_2211
 *  net.minecraft.class_2246
 *  net.minecraft.class_2248
 *  net.minecraft.class_2258
 *  net.minecraft.class_2261
 *  net.minecraft.class_2266
 *  net.minecraft.class_2279
 *  net.minecraft.class_2281
 *  net.minecraft.class_2282
 *  net.minecraft.class_2283
 *  net.minecraft.class_2309
 *  net.minecraft.class_2336
 *  net.minecraft.class_2338
 *  net.minecraft.class_2344
 *  net.minecraft.class_2360
 *  net.minecraft.class_2363
 *  net.minecraft.class_2386
 *  net.minecraft.class_2397
 *  net.minecraft.class_2404
 *  net.minecraft.class_243
 *  net.minecraft.class_2449
 *  net.minecraft.class_2480
 *  net.minecraft.class_2488
 *  net.minecraft.class_2500
 *  net.minecraft.class_2523
 *  net.minecraft.class_2541
 *  net.minecraft.class_2542
 *  net.minecraft.class_2596
 *  net.minecraft.class_2604
 *  net.minecraft.class_2623
 *  net.minecraft.class_2665
 *  net.minecraft.class_2680
 *  net.minecraft.class_2741
 *  net.minecraft.class_2767
 *  net.minecraft.class_2769
 *  net.minecraft.class_3419
 *  net.minecraft.class_3708
 *  net.minecraft.class_4481
 *  net.minecraft.class_4770
 *  net.minecraft.class_4863
 *  net.minecraft.class_5542
 *  net.minecraft.class_5635
 *  net.minecraft.class_5689
 *  net.minecraft.class_5801
 *  net.minecraft.class_5955
 *  net.minecraft.class_7124
 *  net.minecraft.class_8042
 */
package dev.sober.modules;

import dev.sober.event.ListenerHandle;
import dev.sober.event.impl.PacketReceiveNettyEvent;
import dev.sober.gui.Notifications;
import dev.sober.gui.OverlayCanvas;
import dev.sober.gui.WorldLabel;
import dev.sober.module.Category;
import dev.sober.module.HudOverlayProvider;
import dev.sober.module.Module;
import dev.sober.render.ChunkHighlight;
import dev.sober.render.Color;
import dev.sober.render.Render3D;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.class_1299;
import net.minecraft.class_1923;
import net.minecraft.class_2211;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2258;
import net.minecraft.class_2261;
import net.minecraft.class_2266;
import net.minecraft.class_2279;
import net.minecraft.class_2281;
import net.minecraft.class_2282;
import net.minecraft.class_2283;
import net.minecraft.class_2309;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2360;
import net.minecraft.class_2363;
import net.minecraft.class_2386;
import net.minecraft.class_2397;
import net.minecraft.class_2404;
import net.minecraft.class_243;
import net.minecraft.class_2449;
import net.minecraft.class_2480;
import net.minecraft.class_2488;
import net.minecraft.class_2500;
import net.minecraft.class_2523;
import net.minecraft.class_2541;
import net.minecraft.class_2542;
import net.minecraft.class_2596;
import net.minecraft.class_2604;
import net.minecraft.class_2623;
import net.minecraft.class_2665;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2767;
import net.minecraft.class_2769;
import net.minecraft.class_3419;
import net.minecraft.class_3708;
import net.minecraft.class_4481;
import net.minecraft.class_4770;
import net.minecraft.class_4863;
import net.minecraft.class_5542;
import net.minecraft.class_5635;
import net.minecraft.class_5689;
import net.minecraft.class_5801;
import net.minecraft.class_5955;
import net.minecraft.class_7124;
import net.minecraft.class_8042;

public class MotionScanner
extends Module
implements HudOverlayProvider {
    private final Setting<Integer> threshold;
    private final Setting<Integer> memory;
    private final Setting<Integer> ignoreNear;
    private final Setting<Boolean> containers;
    private final Setting<Boolean> doors;
    private final Setting<Boolean> furnaces;
    private final Setting<Boolean> building;
    private final Setting<Boolean> redstone;
    private final Setting<Boolean> entities;
    private final Setting<Boolean> sounds;
    private final Setting<Boolean> notify;
    private final Setting<Integer> cooldown;
    private final Setting<Boolean> chat;
    private final Setting<Color> color;
    private final Setting<Color> hotColor;
    private final Setting<Boolean> labels;
    private final Setting<Boolean> beams;
    private final Setting<Boolean> tracers;
    private final ConcurrentLinkedQueue<class_2596<?>> incoming;
    private final ConcurrentLinkedQueue<Event> events;
    private final Long2ObjectOpenHashMap<Spot> spots;
    private final Long2LongOpenHashMap notified;
    private final List<Label> shown;
    private ListenerHandle<PacketReceiveNettyEvent> listener;
    private long lastDecay;

    public MotionScanner() {
        super("Motion Scanner", "Lights up chunks where something is happening right now: chests and doors opening, furnaces running, blocks being placed or broken, items, carts and block sounds.", Category.BASE_FINDING);
        this.group("Find");
        this.threshold = this.add(new IntSetting("Sensitivity", "Activity points a chunk needs before it lights up. Lower finds more, higher only shows busy chunks.", 12, 2, 80));
        this.memory = this.add(new IntSetting("Memory", "Seconds until old activity has faded away.", 60, 10, 600));
        this.ignoreNear = this.add(new IntSetting("Ignore Near Me", "Activity closer to you than this many blocks is ignored, so your own building does not count.", 24, 0, 96));
        this.containers = this.add(new BoolSetting("Containers", "Chests, barrels and shulker boxes opening.", true));
        this.doors = this.add(new BoolSetting("Doors", "Doors, trapdoors and fence gates opening and closing.", true));
        this.furnaces = this.add(new BoolSetting("Furnaces", "Furnaces, smokers and blast furnaces turning on.", true));
        this.building = this.add(new BoolSetting("Building", "Blocks placed or broken. Growing plants, water, lava, fire and leaves are ignored.", true));
        this.redstone = this.add(new BoolSetting("Redstone", "Pistons, lamps, repeaters and other redstone parts switching.", true));
        this.entities = this.add(new BoolSetting("Items & Carts", "Dropped items, experience, minecarts and TNT showing up.", true));
        this.sounds = this.add(new BoolSetting("Sounds", "Block sounds the server sends you, for example someone mining out of sight.", true));
        this.group("Alerts");
        this.notify = this.add(new BoolSetting("Notify", "Notification when a chunk lights up.", true));
        this.cooldown = this.add(new IntSetting("Cooldown", "Seconds before the same chunk can notify again.", 120, 10, 900)).visible(this.notify::get);
        this.chat = this.add(new BoolSetting("Chat Message", "Also writes the find into the chat.", false)).visible(this.notify::get);
        this.group("Look");
        this.color = this.add(new ColorSetting("Color", "Color of chunks with some activity. Pick any color on the wheel.", new Color(120, 200, 255, 200)));
        this.hotColor = this.add(new ColorSetting("Busy Color", "Color of chunks with a lot of activity.", new Color(255, 80, 120, 230)));
        this.labels = this.add(new BoolSetting("Labels", "Shows what happened above every chunk.", true));
        this.beams = this.add(new BoolSetting("Beams", "A beam above every active chunk.", true));
        this.tracers = this.add(new BoolSetting("Tracers", "Lines to every active chunk.", false));
        this.incoming = new ConcurrentLinkedQueue();
        this.events = new ConcurrentLinkedQueue();
        this.spots = new Long2ObjectOpenHashMap();
        this.notified = new Long2LongOpenHashMap();
        this.shown = new ArrayList<Label>();
    }

    @Override
    public void onEnable() {
        this.spots.clear();
        this.notified.clear();
        this.incoming.clear();
        this.events.clear();
        this.lastDecay = System.currentTimeMillis();
        this.listener = PacketReceiveNettyEvent.TYPE.listen(this, event -> {
            class_2596<?> packet = event.packet;
            if (packet instanceof class_2623 || packet instanceof class_2604 || packet instanceof class_2767 || packet instanceof class_8042) {
                this.incoming.add(packet);
            }
        });
    }

    @Override
    public void onDisable() {
        if (this.listener != null) {
            PacketReceiveNettyEvent.TYPE.unregister(this.listener);
        }
        this.listener = null;
        this.spots.clear();
        this.shown.clear();
        this.incoming.clear();
        this.events.clear();
    }

    @Override
    public void onGameLeft() {
        this.spots.clear();
        this.notified.clear();
    }

    @Override
    public void onBlockUpdate(class_2338 pos, class_2680 oldState, class_2680 newState) {
        if (oldState == newState) {
            return;
        }
        Reason reason = this.classify(oldState, newState);
        if (reason != null) {
            this.events.add(new Event(reason, (double)pos.method_10263() + 0.5, pos.method_10264(), (double)pos.method_10260() + 0.5));
        }
    }

    private Reason classify(class_2680 oldState, class_2680 newState) {
        class_2248 oldBlock = oldState.method_26204();
        class_2248 newBlock = newState.method_26204();
        if (MotionScanner.natural(oldBlock) || MotionScanner.natural(newBlock)) {
            return null;
        }
        if (oldBlock == newBlock) {
            if (newState.method_28498((class_2769)class_2741.field_12537) && oldState.method_11654((class_2769)class_2741.field_12537) != newState.method_11654((class_2769)class_2741.field_12537)) {
                return newBlock instanceof class_3708 ? (this.containers.get().booleanValue() ? Reason.CONTAINER : null) : (this.doors.get() != false ? Reason.DOOR : null);
            }
            if (newBlock instanceof class_2363 && newState.method_28498((class_2769)class_2741.field_12548)) {
                return this.furnaces.get() != false && (Boolean)newState.method_11654((class_2769)class_2741.field_12548) != false ? Reason.FURNACE : null;
            }
            if (newState.method_28498((class_2769)class_2741.field_12484) || newState.method_28498((class_2769)class_2741.field_12548) || newState.method_28498((class_2769)class_2741.field_12511) || newState.method_28498((class_2769)class_2741.field_12552)) {
                return this.redstone.get() != false ? Reason.REDSTONE : null;
            }
            return null;
        }
        return this.building.get() != false ? Reason.BUILD : null;
    }

    private static boolean natural(class_2248 block) {
        return block instanceof class_2404 || block instanceof class_4770 || block instanceof class_2397 || block instanceof class_2261 || block instanceof class_4863 || block instanceof class_2500 || block instanceof class_2344 || block instanceof class_2488 || block instanceof class_2386 || block instanceof class_2360 || block instanceof class_2541 || block instanceof class_2523 || block instanceof class_2266 || block instanceof class_2211 || block instanceof class_5542 || block instanceof class_5955 || block instanceof class_2282 || block instanceof class_2279 || block instanceof class_2283 || block instanceof class_5689 || block instanceof class_2309 || block instanceof class_2542 || block instanceof class_7124 || block instanceof class_4481 || block instanceof class_2258 || block instanceof class_5635 || block == class_2246.field_10566 || block instanceof class_2449 || block instanceof class_5801;
    }

    /*
     * Enabled aggressive block sorting
     */
    private void handle(class_2596<?> packet) {
        if (packet instanceof class_8042) {
            class_8042 bundle = (class_8042)packet;
            Iterator iterator = bundle.method_48324().iterator();
            while (iterator.hasNext()) {
                class_2596 inner = (class_2596)iterator.next();
                this.handle(inner);
            }
            return;
        }
        if (packet instanceof class_2623) {
            class_2623 blockEvent = (class_2623)packet;
            class_2248 block = blockEvent.method_11295();
            class_2338 pos = blockEvent.method_11298();
            if (!(block instanceof class_2281 || block instanceof class_2336 || block instanceof class_2480)) {
                if (!(block instanceof class_2665)) return;
                if (this.redstone.get() == false) return;
                this.events.add(new Event(Reason.REDSTONE, (double)pos.method_10263() + 0.5, pos.method_10264(), (double)pos.method_10260() + 0.5));
                return;
            }
            if (this.containers.get() == false) return;
            if (blockEvent.method_11294() != 1) return;
            if (blockEvent.method_11296() <= 0) return;
            this.events.add(new Event(Reason.CONTAINER, (double)pos.method_10263() + 0.5, pos.method_10264(), (double)pos.method_10260() + 0.5));
            return;
        }
        if (packet instanceof class_2604) {
            class_2604 spawn = (class_2604)packet;
            if (this.entities.get().booleanValue()) {
                class_1299 type = spawn.method_11169();
                Reason reason = type == class_1299.field_6052 || type == class_1299.field_6044 ? Reason.ITEMS : (type == class_1299.field_6063 || type == class_1299.field_6089 || type == class_1299.field_6096 || type == class_1299.field_6126 || type == class_1299.field_6058 || type == class_1299.field_6053 || type == class_1299.field_6080 ? Reason.VEHICLE : null);
                if (reason == null) return;
                this.events.add(new Event(reason, spawn.method_11175(), spawn.method_11174(), spawn.method_11176()));
                return;
            }
        }
        if (!(packet instanceof class_2767)) return;
        class_2767 sound = (class_2767)packet;
        if (this.sounds.get() == false) return;
        if (sound.method_11888() != class_3419.field_15245) return;
        this.events.add(new Event(Reason.SOUND, sound.method_11890(), sound.method_11889(), sound.method_11893()));
    }

    @Override
    public void onTick() {
        Event event;
        class_2596<?> packet;
        if (MotionScanner.mc.field_1724 == null) {
            return;
        }
        while ((packet = this.incoming.poll()) != null) {
            this.handle(packet);
        }
        long now = System.currentTimeMillis();
        double near = (double)this.ignoreNear.get().intValue() * (double)this.ignoreNear.get().intValue();
        while ((event = this.events.poll()) != null) {
            if (MotionScanner.mc.field_1724.method_5649(event.x(), MotionScanner.mc.field_1724.method_23318(), event.z()) < near) continue;
            long key = class_1923.method_8331((int)((int)Math.floor(event.x()) >> 4), (int)((int)Math.floor(event.z()) >> 4));
            Spot spot2 = (Spot)this.spots.computeIfAbsent(key, k -> new Spot());
            spot2.score += event.reason().weight;
            spot2.ySum += event.y() * event.reason().weight;
            spot2.yWeight += event.reason().weight;
            spot2.last = now;
            spot2.reasons.merge(event.reason(), 1, Integer::sum);
            if (!this.notify.get().booleanValue() || !(spot2.score >= (double)this.threshold.get().intValue()) || now - this.notified.getOrDefault(key, 0L) <= (long)this.cooldown.get().intValue() * 1000L) continue;
            this.notified.put(key, now);
            this.announce(key, spot2);
        }
        double factor = Math.exp((double)(-(now - this.lastDecay)) / ((double)this.memory.get().intValue() * 1000.0 / 3.0));
        this.lastDecay = now;
        this.spots.values().removeIf(spot -> {
            spot.score *= factor;
            return spot.score < 0.3;
        });
    }

    private void announce(long key, Spot spot) {
        class_1923 pos = new class_1923(key);
        int x = pos.method_8326() + 8;
        int z = pos.method_8328() + 8;
        int distance = (int)Math.round(Math.sqrt(MotionScanner.mc.field_1724.method_5649((double)x, MotionScanner.mc.field_1724.method_23318(), (double)z)));
        String message = "Activity at " + x + " " + Math.round(spot.ySum / Math.max(1.0E-6, spot.yWeight)) + " " + z + " (" + distance + "m): " + MotionScanner.summary(spot, 3);
        Notifications.push("Motion Scanner", message, Notifications.Type.WARNING);
        if (this.chat.get().booleanValue()) {
            this.info(message, new Object[0]);
        }
    }

    private static String summary(Spot spot, int max) {
        ArrayList<Map.Entry<Reason, Integer>> entries = new ArrayList<Map.Entry<Reason, Integer>>(spot.reasons.entrySet());
        entries.sort((a, b) -> Double.compare((double)((Integer)b.getValue()).intValue() * ((Reason)((Object)((Object)b.getKey()))).weight, (double)((Integer)a.getValue()).intValue() * ((Reason)((Object)((Object)a.getKey()))).weight));
        StringBuilder text = new StringBuilder();
        for (int i = 0; i < entries.size() && i < max; ++i) {
            if (i > 0) {
                text.append(" \u00b7 ");
            }
            text.append(((Map.Entry)entries.get(i)).getValue()).append(' ').append(((Reason)((Object)((Map.Entry)entries.get((int)i)).getKey())).label);
        }
        return text.toString();
    }

    @Override
    public void onRender(Render3D renderer) {
        this.shown.clear();
        if (this.spots.isEmpty() || MotionScanner.mc.field_1724 == null) {
            return;
        }
        int limit = this.threshold.get();
        for (Long2ObjectMap.Entry entry : this.spots.long2ObjectEntrySet()) {
            Spot spot = (Spot)entry.getValue();
            if (spot.score < (double)limit * 0.5) continue;
            class_1923 pos = new class_1923(entry.getLongKey());
            double heat = Math.min(1.0, Math.max(0.0, (spot.score - (double)limit * 0.5) / ((double)limit * 2.5)));
            double y = spot.ySum / Math.max(1.0E-6, spot.yWeight) + 0.05;
            Color c = this.color.get().lerp(this.hotColor.get(), heat);
            ChunkHighlight.draw(renderer, pos.field_9181, pos.field_9180, y, c, this.beams.get() != false && spot.score >= (double)limit);
            if (this.tracers.get().booleanValue() && spot.score >= (double)limit) {
                ChunkHighlight.tracer(renderer, pos.field_9181, pos.field_9180, y, c.scaleAlpha(0.8));
            }
            if (!this.labels.get().booleanValue()) continue;
            this.shown.add(new Label(new class_243((double)(pos.method_8326() + 8), y + 1.5, (double)(pos.method_8328() + 8)), "Activity " + Math.round(spot.score), MotionScanner.summary(spot, 3)));
        }
    }

    @Override
    public boolean isHudOverlayEnabled() {
        return this.isActive() && this.labels.get() != false && !this.shown.isEmpty();
    }

    @Override
    public void renderHudOverlay(OverlayCanvas canvas, float screenW, float screenH) {
        for (Label label : this.shown) {
            float[] screen = WorldLabel.project(mc, label.pos(), screenW, screenH);
            if (screen == null) continue;
            WorldLabel.drawText(canvas, screen[0], screen[1], label.primary(), label.secondary(), 1.0f);
        }
    }

    @Override
    public String getInfoString() {
        int count = 0;
        for (Spot spot : this.spots.values()) {
            if (!(spot.score >= (double)this.threshold.get().intValue())) continue;
            ++count;
        }
        return count == 0 ? null : String.valueOf(count);
    }

    private static enum Reason {
        CONTAINER("containers opened", 6.0),
        DOOR("doors used", 4.0),
        FURNACE("furnaces running", 3.0),
        BUILD("blocks changed", 3.0),
        REDSTONE("redstone", 1.0),
        VEHICLE("minecarts or TNT", 2.0),
        ITEMS("items dropped", 0.5),
        SOUND("block sounds", 1.0);

        final String label;
        final double weight;

        private Reason(String label, double weight) {
            this.label = label;
            this.weight = weight;
        }
    }

    private record Event(Reason reason, double x, double y, double z) {
    }

    private static final class Spot {
        double score;
        double ySum;
        double yWeight;
        long last;
        final EnumMap<Reason, Integer> reasons = new EnumMap(Reason.class);

        private Spot() {
        }
    }

    private record Label(class_243 pos, String primary, String secondary) {
    }
}

