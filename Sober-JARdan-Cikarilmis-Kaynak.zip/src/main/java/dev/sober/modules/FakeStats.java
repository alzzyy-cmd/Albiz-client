/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_124
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 *  net.minecraft.class_5250
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import dev.sober.util.DonutUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;

public class FakeStats
extends Module {
    private static volatile FakeStats instance;
    private static final String SMALL = "\u1d00\u0299\u1d04\u1d05\u1d07\ua730\u0262\u029c\u026a\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18\u01eb\u0280\ua731\u1d1b\u1d1c\u1d20\u1d21x\u028f\u1d22";
    private static final int LINES = 15;
    private final Setting<String> money;
    private final Setting<String> shards;
    private final Setting<String> kills;
    private final Setting<String> deaths;
    private final Setting<String> playtime;
    private final Setting<Boolean> lineNumbers;
    private final Setting<Integer> moneyLine;
    private final Setting<Integer> shardsLine;
    private final Setting<Integer> killsLine;
    private final Setting<Integer> deathsLine;
    private final Setting<Integer> playtimeLine;
    private final List<Stat> stats;
    private final String[] scoreValues;

    public FakeStats() {
        super("Fake Stats", "Changes your money, shards, kills, deaths and playtime on the scoreboard. Only you see it.", Category.DONUT);
        this.group("Values");
        this.money = this.add(new StringSetting("Money", "Money shown on the scoreboard, for example 25.4B. Empty keeps your real money.", "")).onChanged(this::changed);
        this.shards = this.add(new StringSetting("Shards", "Shards shown on the scoreboard. Empty keeps your real shards.", "")).onChanged(this::changed);
        this.kills = this.add(new StringSetting("Kills", "Kills shown on the scoreboard. Empty keeps your real kills.", "")).onChanged(this::changed);
        this.deaths = this.add(new StringSetting("Deaths", "Deaths shown on the scoreboard. Empty keeps your real deaths.", "")).onChanged(this::changed);
        this.playtime = this.add(new StringSetting("Playtime", "Playtime shown on the scoreboard, for example 30d 4h. Empty keeps your real playtime.", "")).onChanged(this::changed);
        this.group("Lines");
        this.lineNumbers = this.add(new BoolSetting("Show Line Numbers", "Writes the line number in front of every scoreboard line, so you know which number to pick below. Turn it off again afterwards.", false));
        this.moneyLine = this.add(FakeStats.line("Money Line", "money"));
        this.shardsLine = this.add(FakeStats.line("Shards Line", "shards"));
        this.killsLine = this.add(FakeStats.line("Kills Line", "kills"));
        this.deathsLine = this.add(FakeStats.line("Deaths Line", "deaths"));
        this.playtimeLine = this.add(FakeStats.line("Playtime Line", "playtime"));
        this.stats = List.of(new Stat(this.money, this.moneyLine, new String[]{"money", "balance", "bal", "coins"}, 1), new Stat(this.shards, this.shardsLine, new String[]{"shards", "shard"}, 2), new Stat(this.kills, this.killsLine, new String[]{"kills", "kill"}, 3), new Stat(this.deaths, this.deathsLine, new String[]{"deaths", "death"}, 4), new Stat(this.playtime, this.playtimeLine, new String[]{"playtime", "play time", "time played"}, 5));
        this.scoreValues = new String[17];
        instance = this;
    }

    private static IntSetting line(String name, String what) {
        return new IntSetting(name, "Scoreboard line (counted from the top) that shows your " + what + ". Auto finds it by its name, and on DonutSMP it uses the usual line. Use Show Line Numbers to see the numbers.", 0, 0, 15){

            @Override
            public String display() {
                return (Integer)this.value == 0 ? "Auto" : String.valueOf(this.value);
            }
        };
    }

    private void changed(String value) {
        if (value != null && !value.isBlank() && !this.isActive()) {
            this.setEnabled(true);
        }
    }

    public static void beginSidebar() {
        FakeStats module = instance;
        if (module == null) {
            return;
        }
        Arrays.fill(module.scoreValues, null);
    }

    public static class_2561 applyLine(int line, class_2561 text) {
        FakeStats module = instance;
        if (module == null || text == null || !module.isActive() || line < 1 || line > 15) {
            return text;
        }
        class_2561 result = text;
        String plain = text.getString();
        String normal = FakeStats.normalize(plain);
        boolean donut = DonutUtils.onDonut();
        for (Stat stat : module.stats) {
            int start;
            String value = stat.value().get().trim();
            if (value.isEmpty()) continue;
            int fixed = stat.line().get();
            int labelEnd = -1;
            if (fixed == 0) {
                for (String label : stat.labels()) {
                    int at = FakeStats.indexOfWord(normal, label);
                    if (at < 0) continue;
                    labelEnd = at + label.length();
                    break;
                }
                if (labelEnd < 0) {
                    if (!donut || stat.donutLine() != line) continue;
                    labelEnd = 0;
                }
            } else {
                if (fixed != line) continue;
                labelEnd = FakeStats.labelEnd(normal, stat.labels());
            }
            if ((start = FakeStats.valueStart(plain, Math.max(0, labelEnd))) < 0) {
                module.scoreValues[line] = value;
                break;
            }
            result = FakeStats.replace(text, start, value);
            break;
        }
        if (module.lineNumbers.get().booleanValue()) {
            result = class_2561.method_43473().method_10852((class_2561)class_2561.method_43470((String)(line + " ")).method_27692(class_124.field_1080)).method_10852(result);
        }
        return result;
    }

    public static class_2561 applyScore(int line, class_2561 score) {
        FakeStats module = instance;
        if (module == null || score == null || !module.isActive() || line < 1 || line > 15) {
            return score;
        }
        String value = module.scoreValues[line];
        if (value == null || score.getString().isBlank()) {
            return score;
        }
        class_2583 style = FakeStats.firstStyle(score);
        return class_2561.method_43470((String)value).method_10862(style);
    }

    private static int labelEnd(String normal, String[] labels) {
        for (String label : labels) {
            int at = FakeStats.indexOfWord(normal, label);
            if (at < 0) continue;
            return at + label.length();
        }
        return 0;
    }

    private static int indexOfWord(String text, String word) {
        int from = 0;
        int at;
        while ((at = text.indexOf(word, from)) >= 0) {
            boolean after;
            boolean before = at == 0 || !Character.isLetter(text.charAt(at - 1));
            boolean bl = after = at + word.length() >= text.length() || !Character.isLetter(text.charAt(at + word.length()));
            if (before && after) {
                return at;
            }
            from = at + 1;
        }
        return -1;
    }

    private static String normalize(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); ++i) {
            char c = text.charAt(i);
            int small = SMALL.indexOf(c);
            out.append(small >= 0 ? (char)(97 + small) : Character.toLowerCase(c));
        }
        return out.toString();
    }

    private static int valueStart(String plain, int from) {
        for (int i = from; i < plain.length(); ++i) {
            if (!Character.isDigit(plain.charAt(i))) continue;
            return i;
        }
        int colon = plain.indexOf(58, from);
        if (colon >= 0) {
            for (int i = colon + 1; i < plain.length(); ++i) {
                if (Character.isWhitespace(plain.charAt(i))) continue;
                return i;
            }
        }
        return -1;
    }

    private static class_2583 firstStyle(class_2561 text) {
        class_2583[] found = new class_2583[]{null};
        text.method_27658((style, string) -> {
            if (!string.isEmpty() && found[0] == null) {
                found[0] = style;
            }
            return Optional.empty();
        }, class_2583.field_24360);
        return found[0] == null ? class_2583.field_24360 : found[0];
    }

    private static class_2561 replace(class_2561 line, int start, String value) {
        ArrayList styles = new ArrayList();
        ArrayList parts = new ArrayList();
        line.method_27658((style, string) -> {
            styles.add(style);
            parts.add(string);
            return Optional.empty();
        }, class_2583.field_24360);
        class_5250 out = class_2561.method_43473();
        int position = 0;
        for (int i = 0; i < parts.size(); ++i) {
            String part = (String)parts.get(i);
            class_2583 style2 = (class_2583)styles.get(i);
            int end = position + part.length();
            if (end > start) {
                int cut = Math.max(0, start - position);
                if (cut > 0) {
                    out.method_10852((class_2561)class_2561.method_43470((String)part.substring(0, cut)).method_10862(style2));
                }
                out.method_10852((class_2561)class_2561.method_43470((String)value).method_10862(style2));
                return out;
            }
            out.method_10852((class_2561)class_2561.method_43470((String)part).method_10862(style2));
            position = end;
        }
        return line;
    }

    @Override
    public String getInfoString() {
        int count = 0;
        for (Stat stat : this.stats) {
            if (stat.value().get().isBlank()) continue;
            ++count;
        }
        return count == 0 ? null : String.valueOf(count);
    }

    private record Stat(Setting<String> value, Setting<Integer> line, String[] labels, int donutLine) {
    }
}

