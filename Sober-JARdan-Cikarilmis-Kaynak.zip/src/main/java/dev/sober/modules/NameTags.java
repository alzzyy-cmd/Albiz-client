/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonParser
 *  com.mojang.serialization.DynamicOps
 *  com.mojang.serialization.JsonOps
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_2561
 *  net.minecraft.class_2583
 *  net.minecraft.class_310
 *  net.minecraft.class_481
 *  net.minecraft.class_490
 *  net.minecraft.class_5250
 *  net.minecraft.class_640
 *  net.minecraft.class_8824
 */
package dev.sober.modules;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import dev.sober.SoberClient;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.Hud;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_481;
import net.minecraft.class_490;
import net.minecraft.class_5250;
import net.minecraft.class_640;
import net.minecraft.class_8824;

public class NameTags
extends Module {
    private static volatile NameTags instance;
    private static volatile String cachedFrom;
    private static volatile String cachedTo;
    private static volatile Pattern cachedPattern;
    private static final String DEV_REFERENCE = "ArchivePedro";
    private final Setting<Boolean> showOwn = this.add(new BoolSetting("Show Own", "Shows your own name tag above your head in third person (F5).", true));
    private final Setting<String> customName = this.add(new StringSetting("Custom Name", "Replaces your real name everywhere on your screen: name tag, chat, tab list and scoreboard. Only you see it. Turns the module on automatically.", "")).onChanged(this::nameChanged);
    private final Setting<FakeRole> fakeRole;
    private final Setting<String> copyFrom;
    private final Setting<String> devIcon;
    private final Setting<String> staffIcon;
    private final Setting<String> copyIcon;
    private String decodedFrom;
    private class_2561 decoded;
    private int ticks;
    private boolean warned;

    public NameTags() {
        super("Name Tags", "Shows your own name tag and lets you change the name you see for yourself.", Category.VISUALS);
        this.group("Fake Role");
        this.fakeRole = this.add(new EnumSetting<FakeRole>("Fake Role", "Puts a DonutSMP role icon in front of your own name tag: Developer is the purple icon, Staff the green one. Copy takes the icon of any player in the tab list. Only you see it.", FakeRole.None)).onChanged(v -> {
            if (v != FakeRole.None && !this.isActive()) {
                this.setEnabled(true);
            }
            this.warned = false;
        });
        this.copyFrom = this.add(new StringSetting("Copy From", "Player in the tab list whose role icon gets copied.", "")).visible(() -> this.fakeRole.get() == FakeRole.Copy);
        this.devIcon = this.add(new StringSetting("Dev Icon", "", "", true)).visible(() -> false);
        this.staffIcon = this.add(new StringSetting("Staff Icon", "", "", true)).visible(() -> false);
        this.copyIcon = this.add(new StringSetting("Copy Icon", "", "", true)).visible(() -> false);
        instance = this;
    }

    public static String customName() {
        return instance == null ? "" : NameTags.instance.customName.get();
    }

    public static void setCustomName(String name) {
        if (instance != null) {
            NameTags.instance.customName.set(name == null ? "" : name);
        }
    }

    private void nameChanged(String value) {
        if (value != null && !value.isBlank() && !this.isActive()) {
            this.setEnabled(true);
        }
        NameTags.refreshChat();
    }

    @Override
    public void onEnable() {
        NameTags.refreshChat();
    }

    @Override
    public void onDisable() {
        NameTags.refreshChat();
    }

    private static void refreshChat() {
        class_310 mc = class_310.method_1551();
        if (mc == null) {
            return;
        }
        mc.execute(() -> {
            if (mc.field_1705 != null) {
                mc.field_1705.method_1743().method_1817();
            }
        });
    }

    @Override
    public void onTick() {
        if (++this.ticks % 40 != 0 || mc.method_1562() == null) {
            return;
        }
        this.learn();
        if (this.fakeRole.get() != FakeRole.None && this.icon() == null && !this.warned && this.ticks > 200) {
            this.warned = true;
            String who = switch (this.fakeRole.get().ordinal()) {
                case 1 -> DEV_REFERENCE;
                case 3 -> {
                    if (this.copyFrom.get().isBlank()) {
                        yield "the player in Copy From";
                    }
                    yield this.copyFrom.get().trim();
                }
                default -> "a staff member";
            };
            this.warning("No role icon saved yet. It gets copied from the tab list as soon as %s is online once.", who);
        }
    }

    private void learn() {
        Hud hud = SoberClient.MODULES.get(Hud.class);
        HashSet<Object> staff = new HashSet<Object>();
        if (hud != null) {
            for (String part : hud.staffNames.get().split(",")) {
                String name = part.trim().toLowerCase(Locale.ROOT);
                if (name.isEmpty() || name.equalsIgnoreCase(DEV_REFERENCE)) continue;
                staff.add(name);
            }
        }
        String copyName = this.copyFrom.get().trim();
        HashMap<String, Integer> counts = new HashMap<String, Integer>();
        HashMap<String, class_2561> prefixes = new HashMap<String, class_2561>();
        String devKey = null;
        for (class_640 entry : mc.method_1562().method_2880()) {
            class_2561 prefix;
            String key;
            String name;
            class_2561[] parts;
            class_2561 display = entry.method_2971();
            if (display == null || (parts = NameTags.split(display, name = entry.method_2966().name())) == null || (key = (prefix = parts[0]).getString()).isBlank()) continue;
            if (name.equalsIgnoreCase(DEV_REFERENCE)) {
                devKey = key;
                NameTags.store(this.devIcon, prefix);
            } else if (staff.contains(name.toLowerCase(Locale.ROOT))) {
                counts.merge(key, 1, Integer::sum);
                prefixes.putIfAbsent(key, prefix);
            }
            if (this.fakeRole.get() != FakeRole.Copy || copyName.isEmpty() || !name.equalsIgnoreCase(copyName)) continue;
            NameTags.store(this.copyIcon, prefix);
        }
        String best = null;
        int bestCount = 0;
        for (Map.Entry count : counts.entrySet()) {
            if (((String)count.getKey()).equals(devKey) || (Integer)count.getValue() <= bestCount) continue;
            best = (String)count.getKey();
            bestCount = (Integer)count.getValue();
        }
        if (best != null) {
            NameTags.store(this.staffIcon, (class_2561)prefixes.get(best));
        }
    }

    private static void store(Setting<String> setting, class_2561 prefix) {
        String json = NameTags.encode(prefix);
        if (!json.isEmpty() && !json.equals(setting.get())) {
            setting.set(json);
        }
    }

    private static DynamicOps<JsonElement> ops() {
        class_310 mc = class_310.method_1551();
        return mc.field_1687 != null ? mc.field_1687.method_30349().method_57093((DynamicOps)JsonOps.INSTANCE) : JsonOps.INSTANCE;
    }

    private static String encode(class_2561 text) {
        try {
            return class_8824.field_46597.encodeStart(NameTags.ops(), (Object)text).result().map(JsonElement::toString).orElse("");
        }
        catch (RuntimeException e) {
            return "";
        }
    }

    private class_2561 icon() {
        String json;
        switch (this.fakeRole.get().ordinal()) {
            case 1: {
                String string = this.devIcon.get();
                break;
            }
            case 2: {
                String string = this.staffIcon.get();
                break;
            }
            case 3: {
                String string = this.copyIcon.get();
                break;
            }
            default: {
                String string = json = "";
            }
        }
        if (json.isEmpty()) {
            return null;
        }
        if (json.equals(this.decodedFrom)) {
            return this.decoded;
        }
        this.decodedFrom = json;
        try {
            this.decoded = class_8824.field_46597.parse(NameTags.ops(), (Object)JsonParser.parseString((String)json)).result().orElse(null);
        }
        catch (RuntimeException e) {
            this.decoded = null;
        }
        return this.decoded;
    }

    public static class_2561 decorate(class_1297 entity, class_2561 displayName) {
        class_310 mc = class_310.method_1551();
        if (displayName == null || entity != mc.field_1724) {
            return displayName;
        }
        NameTags module = instance;
        if (module == null || !module.isActive() || module.fakeRole.get() == FakeRole.None) {
            return displayName;
        }
        class_2561 icon = module.icon();
        if (icon == null) {
            return displayName;
        }
        class_2561[] parts = NameTags.split(displayName, mc.field_1724.method_7334().name());
        if (parts == null) {
            return class_2561.method_43473().method_10852((class_2561)icon.method_27661()).method_10852(displayName);
        }
        return NameTags.join(parts, icon);
    }

    public static boolean isOwn(class_640 entry) {
        class_310 mc = class_310.method_1551();
        return entry != null && mc.field_1724 != null && entry.method_2966().id().equals(mc.field_1724.method_5667());
    }

    public static class_2561 decorateText(class_2561 text) {
        NameTags module = instance;
        if (module == null || text == null || !module.isActive() || module.fakeRole.get() == FakeRole.None) {
            return text;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return text;
        }
        String name = mc.field_1724.method_7334().name();
        if (!NameTags.containsName(text.getString(), name)) {
            return text;
        }
        class_2561 icon = module.icon();
        if (icon == null) {
            return text;
        }
        class_2561[] parts = NameTags.split(text, name);
        return parts == null ? text : NameTags.join(parts, icon);
    }

    private static class_2561 join(class_2561[] parts, class_2561 icon) {
        class_5250 out = class_2561.method_43473();
        if (!NameTags.iconOnly(parts[0].getString())) {
            out.method_10852(parts[0]);
        }
        return out.method_10852((class_2561)icon.method_27661()).method_10852(parts[1]);
    }

    private static boolean iconOnly(String text) {
        int cp;
        for (int i = 0; i < text.length(); i += Character.charCount(cp)) {
            boolean icon;
            cp = text.codePointAt(i);
            boolean bl = icon = Character.isWhitespace(cp) || cp >= 57344 && cp <= 63743 || cp >= 983040;
            if (icon) continue;
            return false;
        }
        return true;
    }

    private static boolean containsName(String text, String name) {
        if (name == null || name.isEmpty()) {
            return false;
        }
        int length = name.length();
        int i = 0;
        while (i + length <= text.length()) {
            if (text.regionMatches(true, i, name, 0, length)) {
                boolean after;
                boolean before = i == 0 || !NameTags.isNameChar(text.charAt(i - 1));
                boolean bl = after = i + length == text.length() || !NameTags.isNameChar(text.charAt(i + length));
                if (before && after) {
                    return true;
                }
            }
            ++i;
        }
        return false;
    }

    private static boolean isNameChar(char c) {
        return c == '_' || c >= 'a' && c <= 'z' || c >= 'A' && c <= 'Z' || c >= '0' && c <= '9';
    }

    static class_2561[] split(class_2561 text, String name) {
        class_2561[] class_2561Array;
        if (name == null || name.isEmpty()) {
            return null;
        }
        String lower = name.toLowerCase(Locale.ROOT);
        if (!text.getString().toLowerCase(Locale.ROOT).contains(lower)) {
            return null;
        }
        List siblings = text.method_10855();
        String own = text.method_27662().getString();
        if (!siblings.isEmpty() && !own.toLowerCase(Locale.ROOT).contains(lower)) {
            int index = -1;
            for (int i = 0; i < siblings.size(); ++i) {
                if (!((class_2561)siblings.get(i)).getString().toLowerCase(Locale.ROOT).contains(lower)) continue;
                index = i;
                break;
            }
            if (index >= 0) {
                class_5250 prefix = text.method_27662().method_10862(text.method_10866());
                for (int i = 0; i < index; ++i) {
                    prefix.method_10852((class_2561)((class_2561)siblings.get(i)).method_27661());
                }
                class_5250 rest = class_2561.method_43473().method_10862(text.method_10866());
                class_2561[] inner = NameTags.split((class_2561)siblings.get(index), name);
                if (inner != null && !inner[0].getString().isEmpty()) {
                    prefix.method_10852(inner[0]);
                    rest.method_10852(inner[1]);
                } else {
                    rest.method_10852((class_2561)((class_2561)siblings.get(index)).method_27661());
                }
                for (int i = index + 1; i < siblings.size(); ++i) {
                    rest.method_10852((class_2561)((class_2561)siblings.get(i)).method_27661());
                }
                return new class_2561[]{prefix, rest};
            }
        }
        ArrayList styles = new ArrayList();
        ArrayList strings = new ArrayList();
        text.method_27658((style, string) -> {
            styles.add(style);
            strings.add(string);
            return Optional.empty();
        }, class_2583.field_24360);
        class_5250 prefix = class_2561.method_43473();
        class_5250 rest = class_2561.method_43473();
        boolean found = false;
        for (int i = 0; i < strings.size(); ++i) {
            String s = (String)strings.get(i);
            class_2583 style2 = (class_2583)styles.get(i);
            if (found) {
                rest.method_10852((class_2561)class_2561.method_43470((String)s).method_10862(style2));
                continue;
            }
            int at = s.toLowerCase(Locale.ROOT).indexOf(lower);
            if (at < 0) {
                prefix.method_10852((class_2561)class_2561.method_43470((String)s).method_10862(style2));
                continue;
            }
            if (at > 0) {
                prefix.method_10852((class_2561)class_2561.method_43470((String)s.substring(0, at)).method_10862(style2));
            }
            rest.method_10852((class_2561)class_2561.method_43470((String)s.substring(at)).method_10862(style2));
            found = true;
        }
        if (found) {
            class_2561[] class_2561Array2 = new class_2561[2];
            class_2561Array2[0] = prefix;
            class_2561Array = class_2561Array2;
            class_2561Array2[1] = rest;
        } else {
            class_2561Array = null;
        }
        return class_2561Array;
    }

    public static boolean showOwnTag(class_1297 entity) {
        NameTags module = instance;
        class_310 mc = class_310.method_1551();
        if (module == null || !module.isActive() || !module.showOwn.get().booleanValue() || entity != mc.field_1724) {
            return false;
        }
        if (!class_310.method_1498() || mc.field_1690.method_31044().method_31034()) {
            return false;
        }
        if (mc.field_1755 instanceof class_490 || mc.field_1755 instanceof class_481) {
            return false;
        }
        return !entity.method_5756((class_1657)mc.field_1724);
    }

    private static boolean containsIgnoreCase(String text, String part) {
        int length = part.length();
        int i = 0;
        while (i + length <= text.length()) {
            if (text.regionMatches(true, i, part, 0, length)) {
                return true;
            }
            ++i;
        }
        return false;
    }

    public static String replace(String text) {
        NameTags module = instance;
        if (module == null || text == null || text.isEmpty() || !module.isActive()) {
            return text;
        }
        String to = module.customName.get().trim();
        if (to.isEmpty()) {
            return text;
        }
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_1548() == null) {
            return text;
        }
        String from = mc.method_1548().method_1676();
        if (from == null || from.isEmpty() || from.equals(to) || !NameTags.containsIgnoreCase(text, from)) {
            return text;
        }
        Pattern pattern = cachedPattern;
        if (pattern == null || !from.equals(cachedFrom) || !to.equals(cachedTo)) {
            pattern = Pattern.compile("(?<![A-Za-z0-9_])" + Pattern.quote(from) + "(?![A-Za-z0-9_])", 2);
            cachedFrom = from;
            cachedTo = to;
            cachedPattern = pattern;
        }
        try {
            return pattern.matcher(text).replaceAll(Matcher.quoteReplacement(to));
        }
        catch (RuntimeException e) {
            SoberClient.LOG.debug("Name replace failed", (Throwable)e);
            return text;
        }
    }

    static {
        cachedFrom = "";
        cachedTo = "";
    }

    public static enum FakeRole {
        None,
        Developer,
        Staff,
        Copy;

    }
}

