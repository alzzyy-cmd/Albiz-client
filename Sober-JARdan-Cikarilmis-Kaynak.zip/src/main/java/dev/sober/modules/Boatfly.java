/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10255
 *  net.minecraft.class_1297
 *  net.minecraft.class_1313
 *  net.minecraft.class_243
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.KeySetting;
import dev.sober.setting.Setting;
import net.minecraft.class_10255;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_243;

public class Boatfly
extends Module {
    private final Setting<Integer> speed = this.add(new IntSetting("Speed", "Horizontal flying speed, in blocks per second.", 20, 1, 100));
    private final Setting<Integer> verticalSpeed = this.add(new IntSetting("Vertical Speed", "How fast you rise or sink with the height key, the up key or the down key, in blocks per second.", 10, 1, 60));
    private final Setting<Boolean> phase = this.add(new BoolSetting("Phase", "Flies through blocks with the boat. Only works on servers that do not check vehicle movement, otherwise the boat gets pulled back.", false));
    private final Setting<Boolean> turn = this.add(new BoolSetting("Face Look Direction", "Turns the boat to where you are looking.", true));
    private final Setting<Boolean> allVehicles = this.add(new BoolSetting("All Vehicles", "Also flies with horses, pigs, striders and other rideable mobs, not only boats.", false));
    private final KeySetting forwardKey;
    private final KeySetting backKey;
    private final KeySetting leftKey;
    private final KeySetting rightKey;
    private final KeySetting heightKey;
    private final KeySetting upKey;
    private final KeySetting downKey;
    private final KeySetting exitKey;
    private static boolean moving;
    private static class_1297 phased;

    public Boatfly() {
        super("Boatfly", "Fly with a boat. WASD moves, hold the sprint key (Ctrl) and look up or down to change height, jump (Space) gets you out. All keys can be changed in the settings. Servers that do not allow flying can kick you after a few seconds in the air.", Category.MOVEMENT);
        this.group("Keys");
        this.forwardKey = (KeySetting)this.add(new KeySetting("Forward Key", "Flies forward. Click and press a key. Right click resets it to your Minecraft key.", () -> Boatfly.mc.field_1690.field_1894));
        this.backKey = (KeySetting)this.add(new KeySetting("Back Key", "Flies backwards. Click and press a key. Right click resets it to your Minecraft key.", () -> Boatfly.mc.field_1690.field_1881));
        this.leftKey = (KeySetting)this.add(new KeySetting("Left Key", "Flies to the left. Click and press a key. Right click resets it to your Minecraft key.", () -> Boatfly.mc.field_1690.field_1913));
        this.rightKey = (KeySetting)this.add(new KeySetting("Right Key", "Flies to the right. Click and press a key. Right click resets it to your Minecraft key.", () -> Boatfly.mc.field_1690.field_1849));
        this.heightKey = (KeySetting)this.add(new KeySetting("Height Key", "Hold it and look up to rise or look down to sink. Default is your sprint key (Ctrl).", () -> Boatfly.mc.field_1690.field_1867));
        this.upKey = (KeySetting)this.add(new KeySetting("Up Key", "Optional key that always rises while held. Right click removes it.", () -> null));
        this.downKey = (KeySetting)this.add(new KeySetting("Down Key", "Optional key that always sinks while held. Right click removes it.", () -> null));
        this.exitKey = (KeySetting)this.add(new KeySetting("Exit Key", "Gets you out of the boat. Default is your jump key (Space).", () -> Boatfly.mc.field_1690.field_1903));
    }

    private static Boatfly instance() {
        return SoberClient.MODULES.get(Boatfly.class);
    }

    public static boolean controlling() {
        if (Boatfly.mc.field_1724 == null || Boatfly.mc.field_1724.method_5854() == null) {
            return false;
        }
        Boatfly fly = Boatfly.instance();
        if (fly == null || !fly.isActive()) {
            return false;
        }
        return Boatfly.mc.field_1724.method_5854() instanceof class_10255 || fly.allVehicles.get() != false;
    }

    public static boolean exitPressed() {
        Boatfly fly = Boatfly.instance();
        return fly != null && fly.exitKey.isPressed();
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static boolean move(class_1297 entity, class_1313 type) {
        boolean down;
        boolean up;
        double pitch;
        if (moving || type != class_1313.field_6308 || Boatfly.mc.field_1724 == null || entity != Boatfly.mc.field_1724.method_5854()) {
            return false;
        }
        Boatfly fly = Boatfly.instance();
        if (fly == null || !fly.isActive()) {
            return false;
        }
        if (!(entity instanceof class_10255) && !fly.allVehicles.get().booleanValue()) {
            return false;
        }
        double vertical = 0.0;
        if (fly.heightKey.isPressed() && Math.abs(pitch = Math.sin(Math.toRadians(Boatfly.mc.field_1724.method_36455()))) > 0.15) {
            vertical = -pitch;
        }
        if ((up = fly.upKey.isPressed()) != (down = fly.downKey.isPressed())) {
            vertical = up ? 1.0 : -1.0;
        }
        class_243 velocity = fly.horizontal(Boatfly.mc.field_1724.method_36454(), (double)fly.speed.get().intValue() / 20.0).method_1031(0.0, vertical * (double)fly.verticalSpeed.get().intValue() / 20.0, 0.0);
        if (fly.turn.get().booleanValue()) {
            entity.method_36456(Boatfly.mc.field_1724.method_36454());
        }
        entity.method_18799(velocity);
        if (fly.phase.get().booleanValue()) {
            entity.field_5960 = true;
            phased = entity;
            entity.method_5814(entity.method_23317() + velocity.field_1352, entity.method_23318() + velocity.field_1351, entity.method_23321() + velocity.field_1350);
            return true;
        }
        moving = true;
        try {
            entity.method_5784(type, velocity);
        }
        finally {
            moving = false;
        }
        return true;
    }

    public static boolean phasing() {
        return phased != null && Boatfly.mc.field_1724 != null && phased == Boatfly.mc.field_1724.method_5854();
    }

    private void release(boolean always) {
        if (phased == null) {
            return;
        }
        if (!always && this.phase.get().booleanValue() && Boatfly.phasing()) {
            return;
        }
        Boatfly.phased.field_5960 = false;
        phased = null;
    }

    @Override
    public void onTick() {
        this.release(false);
    }

    @Override
    public void onDisable() {
        this.release(true);
    }

    @Override
    public void onGameLeft() {
        phased = null;
    }

    private class_243 horizontal(float yaw, double speed) {
        double forward = 0.0;
        double side = 0.0;
        if (this.forwardKey.isPressed()) {
            forward += 1.0;
        }
        if (this.backKey.isPressed()) {
            forward -= 1.0;
        }
        if (this.leftKey.isPressed()) {
            side += 1.0;
        }
        if (this.rightKey.isPressed()) {
            side -= 1.0;
        }
        if (forward == 0.0 && side == 0.0) {
            return class_243.field_1353;
        }
        double length = Math.sqrt(forward * forward + side * side);
        double radians = Math.toRadians(yaw);
        double sin = Math.sin(radians);
        double cos = Math.cos(radians);
        return new class_243((-sin * (forward /= length) + cos * (side /= length)) * speed, 0.0, (cos * forward + sin * side) * speed);
    }

    @Override
    public String getInfoString() {
        return this.phase.get() != false ? String.valueOf(this.speed.get()) + " bps, Phase" : String.valueOf(this.speed.get()) + " bps";
    }
}

