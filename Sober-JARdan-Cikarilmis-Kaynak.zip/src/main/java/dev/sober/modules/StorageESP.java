/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.LongOpenHashSet
 *  net.minecraft.class_1923
 *  net.minecraft.class_2248
 *  net.minecraft.class_2260
 *  net.minecraft.class_2281
 *  net.minecraft.class_2315
 *  net.minecraft.class_2336
 *  net.minecraft.class_2338
 *  net.minecraft.class_2350
 *  net.minecraft.class_2363
 *  net.minecraft.class_2377
 *  net.minecraft.class_239
 *  net.minecraft.class_239$class_240
 *  net.minecraft.class_243
 *  net.minecraft.class_2480
 *  net.minecraft.class_2496
 *  net.minecraft.class_2531
 *  net.minecraft.class_2586
 *  net.minecraft.class_2680
 *  net.minecraft.class_2745
 *  net.minecraft.class_2769
 *  net.minecraft.class_2806
 *  net.minecraft.class_2818
 *  net.minecraft.class_3708
 *  net.minecraft.class_3965
 *  net.minecraft.class_465
 *  net.minecraft.class_481
 *  net.minecraft.class_490
 *  net.minecraft.class_746
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.Color;
import dev.sober.render.Render3D;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.util.Locale;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_2260;
import net.minecraft.class_2281;
import net.minecraft.class_2315;
import net.minecraft.class_2336;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2363;
import net.minecraft.class_2377;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2480;
import net.minecraft.class_2496;
import net.minecraft.class_2531;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2745;
import net.minecraft.class_2769;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_3708;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import net.minecraft.class_481;
import net.minecraft.class_490;
import net.minecraft.class_746;

public class StorageESP
extends Module {
    private static final int OPENED_COLOR = 0x646464;
    private static final double INSET = 0.0625;
    private final Setting<Mode> mode = this.add(new EnumSetting<Mode>("Mode", "Box style \u2014 hollow outline or translucent fill", Mode.Outline));
    private final Setting<Integer> range = this.add(new IntSetting("Range", "Max distance a container is highlighted", 128, 16, 256));
    private final Setting<Integer> maxY = this.add(new IntSetting("Max Y Level", "Only scan containers at or below this Y level", 319, -64, 319));
    private final Setting<Integer> alpha = this.add(new IntSetting("Highlight Alpha", "Box opacity (0-255)", 200, 0, 255));
    private final Setting<Boolean> tracers = this.add(new BoolSetting("Tracers", "Thin lines from the crosshair to nearby containers", false));
    private final Setting<Boolean>[] enabled;
    private final Setting<Color>[] colors;
    private final Setting<Boolean> hideOpened;
    private final LongOpenHashSet opened;

    public StorageESP() {
        super("Storage ESP", "Highlights chests, barrels, shulkers", Category.BASE_FINDING);
        this.group("Containers");
        this.enabled = new Setting[Kind.values().length];
        this.colors = new Setting[Kind.values().length];
        for (Kind kind : Kind.values()) {
            Setting<Boolean> on = this.add(new BoolSetting(kind.label, "Highlights every " + kind.label.toLowerCase(Locale.ROOT) + ".", kind.on));
            this.enabled[kind.ordinal()] = on;
            this.colors[kind.ordinal()] = this.add(new ColorSetting(kind.label + " Color", "Color of the " + kind.label.toLowerCase(Locale.ROOT) + " boxes.", Color.fromPacked(kind.color))).visible(on::get);
        }
        this.group("General");
        this.hideOpened = this.add(new BoolSetting("Hide Opened", "Don't highlight containers you've already opened", false));
        this.opened = new LongOpenHashSet();
    }

    @Override
    public void onEnable() {
        this.opened.clear();
    }

    @Override
    public void onTick() {
        if (StorageESP.mc.field_1687 == null || StorageESP.mc.field_1724 == null) {
            return;
        }
        this.rememberOpened();
    }

    private void rememberOpened() {
        class_3965 hit;
        if (!(StorageESP.mc.field_1755 instanceof class_465) || StorageESP.mc.field_1755 instanceof class_490 || StorageESP.mc.field_1755 instanceof class_481) {
            return;
        }
        class_239 class_2392 = StorageESP.mc.field_1765;
        if (!(class_2392 instanceof class_3965) || (hit = (class_3965)class_2392).method_17783() != class_239.class_240.field_1332) {
            return;
        }
        class_2338 pos = hit.method_17777();
        if (this.opened.contains(pos.method_10063())) {
            return;
        }
        class_2680 state = StorageESP.mc.field_1687.method_8320(pos);
        if (StorageESP.kindOf(state.method_26204()) == null) {
            return;
        }
        this.opened.add(pos.method_10063());
        if (state.method_26204() instanceof class_2281 && state.method_11654((class_2769)class_2281.field_10770) != class_2745.field_12569) {
            class_2350 facing = (class_2350)state.method_11654((class_2769)class_2281.field_10768);
            this.opened.add(pos.method_10093(StorageESP.otherHalf(facing, (class_2745)state.method_11654((class_2769)class_2281.field_10770))).method_10063());
        }
    }

    private static class_2350 otherHalf(class_2350 facing, class_2745 type) {
        return type == class_2745.field_12574 ? facing.method_10170() : facing.method_10160();
    }

    private static Kind kindOf(class_2248 block) {
        if (block instanceof class_2531) {
            return Kind.TRAPPED;
        }
        if (block instanceof class_2281) {
            return Kind.CHEST;
        }
        if (block instanceof class_2336) {
            return Kind.ENDER;
        }
        if (block instanceof class_2480) {
            return Kind.SHULKER;
        }
        if (block instanceof class_3708) {
            return Kind.BARREL;
        }
        if (block instanceof class_2496) {
            return Kind.SPAWNER;
        }
        if (block instanceof class_2377) {
            return Kind.HOPPER;
        }
        if (block instanceof class_2363) {
            return Kind.FURNACE;
        }
        if (block instanceof class_2260) {
            return Kind.FURNACE;
        }
        return block instanceof class_2315 ? Kind.HOPPER : null;
    }

    @Override
    public void onRender(Render3D renderer) {
        class_746 player = StorageESP.mc.field_1724;
        if (StorageESP.mc.field_1687 == null || player == null) {
            return;
        }
        boolean full = this.mode.get() == Mode.Full;
        int boxAlpha = Math.max(0, Math.min(255, this.alpha.get()));
        boolean hide = this.hideOpened.get();
        double reach = this.range.get().intValue();
        double reachSq = reach * reach;
        int top = this.maxY.get();
        boolean lines = this.tracers.get();
        class_243 origin = player.method_30950(mc.method_61966().method_60637(true));
        int radius = Math.min((int)Math.ceil(reach / 16.0), (Integer)StorageESP.mc.field_1690.method_42503().method_41753() + 1);
        class_1923 center = player.method_31476();
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dz = -radius; dz <= radius; ++dz) {
                class_2818 class_28182 = StorageESP.mc.field_1687.method_2935().method_2857(center.field_9181 + dx, center.field_9180 + dz, class_2806.field_12803, false);
                if (!(class_28182 instanceof class_2818)) continue;
                class_2818 chunk = class_28182;
                for (class_2586 entity : chunk.method_12214().values()) {
                    class_2680 state;
                    Kind kind;
                    class_2338 pos = entity.method_11016();
                    if (pos.method_10264() > top || origin.method_1028((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5) > reachSq || (kind = StorageESP.kindOf((state = chunk.method_8320(pos)).method_26204())) == null || !this.enabled[kind.ordinal()].get().booleanValue()) continue;
                    this.draw(renderer, pos, state, kind, full, boxAlpha, hide, lines);
                }
            }
        }
    }

    private void draw(Render3D renderer, class_2338 pos, class_2680 state, Kind kind, boolean full, int boxAlpha, boolean hide, boolean lines) {
        boolean wasOpened;
        class_2338 other = null;
        if (state.method_26204() instanceof class_2281 && state.method_11654((class_2769)class_2281.field_10770) != class_2745.field_12569) {
            if (state.method_11654((class_2769)class_2281.field_10770) == class_2745.field_12571) {
                return;
            }
            other = pos.method_10093(StorageESP.otherHalf((class_2350)state.method_11654((class_2769)class_2281.field_10768), (class_2745)state.method_11654((class_2769)class_2281.field_10770)));
        }
        boolean bl = wasOpened = this.opened.contains(pos.method_10063()) || other != null && this.opened.contains(other.method_10063());
        if (wasOpened && hide) {
            return;
        }
        int rgb = wasOpened ? 0x646464 : this.colors[kind.ordinal()].get().packed() & 0xFFFFFF;
        Color color = Color.fromPacked(boxAlpha << 24 | rgb);
        double x1 = pos.method_10263();
        double y1 = pos.method_10264();
        double z1 = pos.method_10260();
        double x2 = x1 + 1.0;
        double y2 = y1 + 1.0;
        double z2 = z1 + 1.0;
        if (other != null) {
            x1 = Math.min(x1, (double)other.method_10263());
            z1 = Math.min(z1, (double)other.method_10260());
            x2 = Math.max(x2, (double)other.method_10263() + 1.0);
            z2 = Math.max(z2, (double)other.method_10260() + 1.0);
        }
        if (kind == Kind.CHEST || kind == Kind.TRAPPED || kind == Kind.ENDER) {
            x1 += 0.0625;
            z1 += 0.0625;
            x2 -= 0.0625;
            z2 -= 0.0625;
            y2 -= 0.125;
        }
        if (full) {
            renderer.boxSides(x1 - 0.002, y1 - 0.002, z1 - 0.002, x2 + 0.002, y2 + 0.002, z2 + 0.002, color);
        } else {
            renderer.boxLines(x1, y1, z1, x2, y2, z2, color);
        }
        if (lines) {
            renderer.tracer((x1 + x2) * 0.5, (y1 + y2) * 0.5, (z1 + z2) * 0.5, Color.fromPacked(0xB4000000 | rgb), 1.0f, false);
        }
    }

    public static enum Mode {
        Outline,
        Full;

    }

    private static enum Kind {
        CHEST("Chest", -22016, true),
        TRAPPED("Trapped Chest", -65536, true),
        ENDER("Ender Chest", -8912641, true),
        SHULKER("Shulker Box", -47873, true),
        BARREL("Barrel", -7842560, true),
        SPAWNER("Spawner", -16711936, true),
        HOPPER("Hopper", -7829368, false),
        FURNACE("Furnace", -7566196, false);

        final String label;
        final int color;
        final boolean on;

        private Kind(String label, int color, boolean on) {
            this.label = label;
            this.color = color;
            this.on = on;
        }
    }
}

