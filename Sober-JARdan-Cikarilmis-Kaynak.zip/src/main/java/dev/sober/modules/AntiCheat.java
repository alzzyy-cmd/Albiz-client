/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1109
 *  net.minecraft.class_1113
 *  net.minecraft.class_1937
 *  net.minecraft.class_3414
 *  net.minecraft.class_3417
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.gui.AcStatusCard;
import dev.sober.gui.Notifications;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.Color;
import dev.sober.render.Render3D;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import dev.sober.util.AcOffFeed;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1109;
import net.minecraft.class_1113;
import net.minecraft.class_1937;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

public class AntiCheat
extends Module {
    private final Setting<String> feedUrl = this.add(new StringSetting("Feed URL", "Address of the anticheat feed.", "https://anticheat.imjules.be/api.json"));
    private final Setting<Integer> feedInterval = this.add(new IntSetting("Check Every", "Seconds between two checks of the feed.", 10, 3, 120));
    private final Setting<MapVersion> regionMap = this.add(new EnumSetting<MapVersion>("Region Map", "Which DonutSMP region map the G# numbers follow.", MapVersion.New));
    private final Setting<Boolean> testAlerts = this.add(new BoolSetting("Test Alerts", "Also shows test entries of the feed.", false));
    private final Setting<Boolean> statusCard = this.add(new BoolSetting("Status Card", "HUD card that shows if the anticheat is on or off and where it is off. Open the chat to drag it, scroll on it to resize it.", true));
    private final Setting<Boolean> beams = this.add(new BoolSetting("Beams", "A beam into the sky at every place where the anticheat is off.", true));
    private final Setting<Boolean> alertSound = this.add(new BoolSetting("Alert Sound", "Plays a sound when the anticheat goes off somewhere.", true));
    private final Setting<Boolean> chat = this.add(new BoolSetting("Chat Message", "Also writes every alert into the chat.", false));
    private final AcOffFeed feed = new AcOffFeed();
    private final Set<String> knownSpots = new HashSet<String>();
    private boolean feedLoaded;

    public AntiCheat() {
        super("Anti Cheat", "Alerts you when and where the DonutSMP anticheat goes off, from the anticheat feed.", Category.CLIENT);
    }

    @Override
    public void onDisable() {
        this.feed.reset();
        this.knownSpots.clear();
        this.feedLoaded = false;
    }

    @Override
    public void onTick() {
        if (AntiCheat.mc.field_1724 != null) {
            this.feed.poll(this.feedUrl.get(), this.feedInterval.get(), this::onFeed);
        }
    }

    private List<AcOffFeed.Spot> visibleSpots() {
        ArrayList<AcOffFeed.Spot> spots = new ArrayList<AcOffFeed.Spot>();
        for (AcOffFeed.Spot spot : this.feed.snapshot().spots()) {
            if (spot.test() && !this.testAlerts.get().booleanValue()) continue;
            spots.add(spot);
        }
        return spots;
    }

    private void onFeed(AcOffFeed.Snapshot snapshot) {
        mc.execute(() -> {
            if (!this.isActive() || snapshot.error() != null) {
                return;
            }
            List<AcOffFeed.Spot> spots = this.visibleSpots();
            HashSet<String> now = new HashSet<String>();
            ArrayList<AcOffFeed.Spot> fresh = new ArrayList<AcOffFeed.Spot>();
            for (AcOffFeed.Spot spot : spots) {
                now.add(spot.key());
                if (this.knownSpots.contains(spot.key())) continue;
                fresh.add(spot);
            }
            boolean wasOff = !this.knownSpots.isEmpty();
            this.knownSpots.clear();
            this.knownSpots.addAll(now);
            boolean first = !this.feedLoaded;
            this.feedLoaded = true;
            if (!fresh.isEmpty()) {
                if (first && fresh.size() > 1) {
                    this.announce("Anticheat OFF", "The anticheat is off at " + fresh.size() + " places right now. Check the status card.");
                } else {
                    for (AcOffFeed.Spot spot : fresh) {
                        this.announce(spot.test() ? "Anticheat OFF (test)" : "Anticheat OFF", this.place(spot) + " \u00b7 " + spot.coords() + this.distance(spot, " \u00b7 "));
                    }
                }
                if (this.alertSound.get().booleanValue() && mc.method_1483() != null) {
                    mc.method_1483().method_4873((class_1113)class_1109.method_4757((class_3414)((class_3414)class_3417.field_14622.comp_349()), (float)1.5f, (float)0.8f));
                }
            } else if (wasOff && spots.isEmpty()) {
                this.announce("Anticheat ON", "The anticheat is back on everywhere.");
            }
        });
    }

    private void announce(String title, String message) {
        Notifications.push(title, message, title.startsWith("Anticheat OFF") ? Notifications.Type.SUCCESS : Notifications.Type.INFO);
        if (this.chat.get().booleanValue()) {
            this.info(title + ": " + message, new Object[0]);
        }
    }

    private String place(AcOffFeed.Spot spot) {
        int number = this.regionMap.get() == MapVersion.New ? spot.goliath() : spot.oldGoliath();
        return spot.region() + (String)(number >= 0 ? " \u00b7 G#" + number : "");
    }

    private String distance(AcOffFeed.Spot spot, String prefix) {
        if (AntiCheat.mc.field_1724 == null || spot.x() == 0.0 && spot.z() == 0.0) {
            return "";
        }
        double dx = AntiCheat.mc.field_1724.method_23317() - spot.x();
        double dz = AntiCheat.mc.field_1724.method_23321() - spot.z();
        return prefix + Math.round(Math.sqrt(dx * dx + dz * dz)) + "m";
    }

    @Override
    public void onRender(Render3D renderer) {
        if (!this.beams.get().booleanValue() || AntiCheat.mc.field_1687 == null || AntiCheat.mc.field_1687.method_27983() != class_1937.field_25179) {
            return;
        }
        for (AcOffFeed.Spot spot : this.visibleSpots()) {
            if (spot.x() == 0.0 && spot.z() == 0.0) continue;
            renderer.beam(spot.x(), spot.z(), spot.y() - 2.0, 320.0, 0.6, new Color(255, 92, 138, 200), 1.0);
        }
    }

    public static AcStatusCard.Model card() {
        AntiCheat module = SoberClient.MODULES.get(AntiCheat.class);
        if (module == null || !module.isActive() || !module.statusCard.get().booleanValue()) {
            return null;
        }
        AcOffFeed.Snapshot snapshot = module.feed.snapshot();
        List<AcOffFeed.Spot> spots = module.visibleSpots();
        ArrayList<AcStatusCard.Row> rows = new ArrayList<AcStatusCard.Row>();
        for (int i = 0; i < spots.size() && i < 4; ++i) {
            rows.add(new AcStatusCard.Row(module.place(spots.get(i)), module.distance(spots.get(i), "")));
        }
        if (spots.size() > 4) {
            rows.add(new AcStatusCard.Row("+" + (spots.size() - 4) + " more", ""));
        }
        if (!snapshot.loaded()) {
            return new AcStatusCard.Model(AcStatusCard.State.UNKNOWN, "Checking...", rows);
        }
        if (!spots.isEmpty()) {
            return new AcStatusCard.Model(AcStatusCard.State.OFF, "AC OFF \u00b7 " + spots.size() + (spots.size() == 1 ? " place" : " places"), rows);
        }
        if (snapshot.error() != null) {
            return new AcStatusCard.Model(AcStatusCard.State.UNKNOWN, snapshot.error(), rows);
        }
        return new AcStatusCard.Model(AcStatusCard.State.ON, "Anticheat on", rows);
    }

    @Override
    public String getInfoString() {
        int off = this.visibleSpots().size();
        return off == 0 ? null : off + " off";
    }

    public static enum MapVersion {
        New,
        Old;

    }
}

