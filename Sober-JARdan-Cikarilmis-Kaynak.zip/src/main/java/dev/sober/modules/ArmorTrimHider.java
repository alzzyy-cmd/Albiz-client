/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;

public class ArmorTrimHider
extends Module {
    private static volatile ArmorTrimHider instance;

    public ArmorTrimHider() {
        super("Armor Trim Hider", "Hides armor trims, so every armor piece looks plain.", Category.VISUALS);
        instance = this;
    }

    public static boolean hides() {
        ArmorTrimHider module = instance;
        return module != null && module.isActive();
    }
}

