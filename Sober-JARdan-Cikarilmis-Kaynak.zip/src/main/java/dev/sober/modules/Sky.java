/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.Color;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import dev.sober.sky.AuraRenderer;
import dev.sober.sky.SkySettings;
import dev.sober.sky.SkyType;

public class Sky
extends Module {
    private boolean syncingAurora;
    private final Setting<SkyMode> skyMode;
    private final Setting<Integer> speed;
    private final Setting<Integer> brightness;
    private final Setting<AuroraColor> auroraPreset;
    private final Setting<Color> auroraColor;
    private final Setting<Boolean> hideClouds;
    private final Setting<Boolean> matchFog;
    private final Setting<Quality> quality;

    public Sky() {
        super("Sky", "Animated aurora, galaxy, anime, storm sea, blood moon, petal dusk, event horizon, frost halo, firefly night, candy clouds, nebula bloom, ashen squall, nightshade, phantom mist, synthwave, black hole, sakura, underwater, cyberpunk and Sober skies. Sober is a black night with the glowing discord.gg/Soberclient around the horizon.", Category.VISUALS);
        this.group("Sky");
        this.skyMode = this.add(new EnumSetting<SkyMode>("Sky Mode", "Look of the sky.", SkyMode.Galaxy)).onChanged(v -> this.apply());
        this.speed = this.add(new IntSetting("Speed", "Animation speed of the sky in percent.", 100, 0, 300)).onChanged(v -> this.apply());
        this.brightness = this.add(new IntSetting("Brightness", "Brightness of the sky in percent.", 100, 50, 150)).onChanged(v -> this.apply());
        this.auroraPreset = this.add(new EnumSetting<AuroraColor>("Aurora Preset", "Ready made northern lights colors.", AuroraColor.Green)).visible(() -> this.skyMode.get() == SkyMode.Aurora).onChanged(this::onAuroraPreset);
        this.auroraColor = this.add(new ColorSetting("Aurora Color", "Pick any color for the northern lights.", AuroraColor.Green.color)).visible(() -> this.skyMode.get() == SkyMode.Aurora).onChanged(v -> this.onAuroraColor());
        this.hideClouds = this.add(new BoolSetting("Hide Clouds", "Hides the vanilla clouds.", true)).onChanged(v -> this.apply());
        this.matchFog = this.add(new BoolSetting("Match Fog", "Tints the fog so far terrain blends into the sky.", true)).onChanged(v -> this.apply());
        this.quality = this.add(new EnumSetting<Quality>("Sky Quality", "Resolution the sky is drawn at. Balanced draws it at half resolution and looks nearly the same, Performance is the fastest, Ultra is full resolution. While the camera does not move, the sky is redrawn at most 30 times a second.", Quality.Balanced)).onChanged(v -> this.apply());
    }

    @Override
    public void onEnable() {
        this.apply();
    }

    @Override
    public void onDisable() {
        SkySettings.sky = SkyType.VANILLA;
    }

    public SkyType previewType() {
        return this.skyMode.get().type;
    }

    public String previewName() {
        return this.skyMode.get().toString();
    }

    public float previewBrightness() {
        return (float)this.brightness.get().intValue() / 100.0f;
    }

    public float previewSpeed() {
        return (float)this.speed.get().intValue() / 100.0f;
    }

    public int previewPalette() {
        return this.auroraPreset.get().ordinal();
    }

    public int previewAuroraColor() {
        return this.auroraColor.get().packed() & 0xFFFFFF;
    }

    public int accentColor() {
        if (!this.isActive()) {
            return -1;
        }
        return switch (this.skyMode.get().ordinal()) {
            default -> throw new MatchException(null, null);
            case 1 -> 10316799;
            case 0 -> {
                if (this.auroraPreset.get() == AuroraColor.Rainbow) {
                    yield AuraRenderer.hsvToRgb((float)(System.currentTimeMillis() % 3600000L) / 1000.0f * 0.05f % 1.0f, 0.7f, 1.0f);
                }
                yield this.auroraColor.get().packed() & 0xFFFFFF;
            }
            case 3 -> 8377599;
            case 2 -> 0xFFFFFF;
            case 4 -> 16726826;
            case 5 -> 16752324;
            case 6 -> 16751164;
            case 7 -> 12576511;
            case 8 -> 13172570;
            case 9 -> 16754904;
            case 10 -> 13134847;
            case 11 -> 16747084;
            case 12 -> 10640639;
            case 13 -> 13949666;
            case 14 -> 14696570;
            case 15 -> 16756816;
            case 16 -> 16095928;
            case 17 -> 6277336;
            case 18 -> 3008255;
            case 19 -> 0xE6E6EC;
        };
    }

    private void apply() {
        if (!this.isActive()) {
            return;
        }
        SkySettings.sky = this.skyMode.get().type;
        SkySettings.speed = this.speed.get();
        SkySettings.brightness = this.brightness.get();
        SkySettings.auroraPalette = this.auroraPreset.get().ordinal();
        SkySettings.auroraColor = this.auroraColor.get().packed() & 0xFFFFFF;
        SkySettings.hideVanillaClouds = this.hideClouds.get();
        SkySettings.matchFog = this.matchFog.get();
        SkySettings.quality = this.quality.get().percent;
    }

    private void onAuroraPreset(AuroraColor preset) {
        if (preset.color != null && !this.syncingAurora) {
            this.syncingAurora = true;
            this.auroraColor.set(preset.color);
            this.syncingAurora = false;
        }
        this.apply();
    }

    private void onAuroraColor() {
        if (!this.syncingAurora && this.auroraPreset.get() != AuroraColor.Custom) {
            this.syncingAurora = true;
            this.auroraPreset.set(AuroraColor.Custom);
            this.syncingAurora = false;
        }
        this.apply();
    }

    public static enum SkyMode {
        Aurora("Aurora", SkyType.AURORA),
        Galaxy("Galaxy", SkyType.GALAXY),
        Anime("Anime", SkyType.ANIME),
        StormSea("Storm Sea", SkyType.STORM),
        BloodMoon("Blood Moon", SkyType.BLOODMOON),
        PetalDusk("Petal Dusk", SkyType.PETALDUSK),
        EventHorizon("Event Horizon", SkyType.EVENTHORIZON),
        FrostHalo("Frost Halo", SkyType.FROSTHALO),
        FireflyNight("Firefly Night", SkyType.FIREFLYNIGHT),
        CandyClouds("Candy Clouds", SkyType.CANDYCLOUDS),
        NebulaBloom("Nebula Bloom", SkyType.NEBULABLOOM),
        AshenSquall("Ashen Squall", SkyType.ASHENSQUALL),
        Nightshade("Nightshade", SkyType.NIGHTSHADE),
        PhantomMist("Phantom Mist", SkyType.PHANTOMMIST),
        Synthwave("Synthwave", SkyType.SYNTHWAVE),
        BlackHole("Black Hole", SkyType.BLACKHOLE),
        Sakura("Sakura", SkyType.SAKURA),
        Underwater("Underwater", SkyType.UNDERWATER),
        Cyberpunk("Cyberpunk", SkyType.CYBERPUNK),
        Sober("Sober", SkyType.SOBER);

        private final String title;
        final SkyType type;

        private SkyMode(String title, SkyType type) {
            this.title = title;
            this.type = type;
        }

        public String toString() {
            return this.title;
        }
    }

    public static enum AuroraColor {
        Green(new Color(26, 255, 107, 255)),
        Pink(new Color(255, 71, 158, 255)),
        Blue(new Color(38, 191, 255, 255)),
        Rainbow(null),
        Custom(null);

        final Color color;

        private AuroraColor(Color color) {
            this.color = color;
        }
    }

    public static enum Quality {
        Ultra("Ultra", 100),
        High("High", 75),
        Balanced("Balanced", 50),
        Performance("Performance", 35);

        private final String title;
        final int percent;

        private Quality(String title, int percent) {
            this.title = title;
            this.percent = percent;
        }

        public String toString() {
            return this.title;
        }
    }
}

