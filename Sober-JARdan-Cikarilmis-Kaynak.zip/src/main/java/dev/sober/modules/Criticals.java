/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_2829
 *  net.minecraft.class_746
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_746;

public class Criticals
extends Module {
    private static volatile Criticals instance;

    public Criticals() {
        super("Criticals", "Every hit on the ground lands as a critical hit.", Category.MOVEMENT);
        instance = this;
    }

    public static void beforeAttack(class_1297 target) {
        Criticals module = instance;
        class_746 player = Criticals.mc.field_1724;
        if (module == null || !module.isActive() || player == null || !(target instanceof class_1309)) {
            return;
        }
        if (!player.method_24828() || player.method_5799() || player.method_5771() || player.method_6101() || player.method_5765()) {
            return;
        }
        double x = player.method_23317();
        double y = player.method_23318();
        double z = player.method_23321();
        player.field_3944.method_52787((class_2596)new class_2828.class_2829(x, y + 0.0625, z, false, player.field_5976));
        player.field_3944.method_52787((class_2596)new class_2828.class_2829(x, y, z, false, player.field_5976));
    }
}

