/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3532
 *  net.minecraft.class_4587
 *  net.minecraft.class_7833
 *  org.joml.Quaternionfc
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Quaternionfc;

public class SwingAnimations
extends Module {
    public final Setting<Style> style = this.add(new EnumSetting<Style>("Style", "How your item swings.", Style.Smooth));
    public final Setting<Integer> speed = this.add(new IntSetting("Swing Speed", "Swing speed in percent. Lower is slower and smoother.", 70, 25, 200));
    public final Setting<Integer> strength = this.add(new IntSetting("Strength", "How big the swing is, in percent.", 100, 20, 200));
    public final Setting<Boolean> noEquip = this.add(new BoolSetting("No Equip Dip", "Items don't dip down when you switch or hit.", true));
    public final Setting<Integer> scale;
    public final Setting<Integer> offsetX;
    public final Setting<Integer> offsetY;
    public final Setting<Integer> offsetZ;

    public SwingAnimations() {
        super("Swing Animations", "Custom swing animations, swing speed and item position.", Category.VISUALS);
        this.group("Item");
        this.scale = this.add(new IntSetting("Scale", "Size of the held item in percent.", 100, 40, 160));
        this.offsetX = this.add(new IntSetting("Offset X", "Moves the item left or right.", 0, -60, 60));
        this.offsetY = this.add(new IntSetting("Offset Y", "Moves the item up or down.", 0, -60, 60));
        this.offsetZ = this.add(new IntSetting("Offset Z", "Moves the item closer or further away.", 0, -60, 60));
    }

    public int duration(int vanilla) {
        return Math.max(1, Math.round((float)vanilla * 100.0f / (float)this.speed.get().intValue()));
    }

    public void offset(class_4587 matrices) {
        matrices.method_46416((float)this.offsetX.get().intValue() * 0.01f, (float)this.offsetY.get().intValue() * 0.01f, (float)this.offsetZ.get().intValue() * 0.01f);
        float s = (float)this.scale.get().intValue() / 100.0f;
        if (s != 1.0f) {
            matrices.method_22905(s, s, s);
        }
    }

    public boolean swing(class_4587 matrices, float progress, int side) {
        Style current = this.style.get();
        if (current == Style.Vanilla) {
            return false;
        }
        float k = (float)this.strength.get().intValue() / 100.0f;
        float root = class_3532.method_15374((double)(class_3532.method_15355((float)progress) * (float)Math.PI));
        float sine = class_3532.method_15374((double)(progress * (float)Math.PI));
        float eased = class_3532.method_15374((double)(progress * progress * (float)Math.PI));
        switch (current.ordinal()) {
            case 1: {
                matrices.method_46416((float)side * -0.25f * root * k, 0.12f * class_3532.method_15374((double)(class_3532.method_15355((float)progress) * ((float)Math.PI * 2))) * k, -0.12f * sine * k);
                matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)side * (45.0f - 14.0f * eased * k)));
                matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees((float)side * root * -14.0f * k));
                matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(root * -58.0f * k));
                matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)side * -45.0f));
                break;
            }
            case 2: {
                matrices.method_46416((float)side * 0.05f, 0.08f * k, -0.04f);
                matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)side * 45.0f));
                matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees((float)side * root * -10.0f * k));
                matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(root * -35.0f * k));
                matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)side * -45.0f));
                matrices.method_46416(0.0f, -0.25f * root * k, 0.0f);
                break;
            }
            case 3: {
                matrices.method_46416((float)side * -0.08f * root * k, 0.04f * root * k, -0.45f * root * k);
                matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-18.0f * root * k));
                break;
            }
            case 4: {
                matrices.method_46416((float)side * -0.1f * root * k, 0.05f * root * k, -0.1f * sine * k);
                matrices.method_22907((Quaternionfc)class_7833.field_40716.rotationDegrees((float)side * -360.0f * progress));
                break;
            }
            case 5: {
                matrices.method_46416((float)side * -0.15f * root * k, 0.08f * root * k, -0.1f * sine * k);
                matrices.method_22907((Quaternionfc)class_7833.field_40718.rotationDegrees((float)side * -360.0f * progress));
                break;
            }
            case 6: {
                matrices.method_46416(0.0f, 0.18f * root * k, -0.08f * sine * k);
                matrices.method_22907((Quaternionfc)class_7833.field_40714.rotationDegrees(-95.0f * root * k));
                break;
            }
            default: {
                return false;
            }
        }
        return true;
    }

    @Override
    public String getInfoString() {
        return this.style.get().name();
    }

    public static enum Style {
        Vanilla,
        Smooth,
        Slide,
        Stab,
        Spin,
        Swirl,
        Chop;

    }
}

