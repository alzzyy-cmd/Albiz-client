/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
 *  net.minecraft.class_310
 *  net.minecraft.class_412
 *  net.minecraft.class_419
 *  net.minecraft.class_437
 *  net.minecraft.class_442
 *  net.minecraft.class_500
 *  net.minecraft.class_639
 *  net.minecraft.class_642
 */
package dev.sober.modules;

import dev.sober.gui.Notifications;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_419;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_639;
import net.minecraft.class_642;

public class AutoReconnect
extends Module {
    private static boolean skip;
    private final Setting<Integer> delay = this.add(new IntSetting("Delay", "Seconds to wait before joining again.", 5, 1, 60));
    private final Setting<Integer> attempts = this.add(new IntSetting(this, "Attempts", "How often it tries in a row before giving up. 0 tries forever.", 5, 0, 50){

        @Override
        public String display() {
            return (Integer)this.value == 0 ? "Forever" : String.valueOf(this.value);
        }
    });
    private class_642 server;
    private class_419 waitingOn;
    private long reconnectAt;
    private int tries;

    public AutoReconnect() {
        super("Auto Reconnect", "Joins the server again a few seconds after you were kicked or lost the connection.", Category.DONUT);
        ClientTickEvents.END_CLIENT_TICK.register(this::tickAlways);
    }

    public static void skipNext() {
        skip = true;
    }

    private void tickAlways(class_310 client) {
        if (client.field_1687 != null) {
            class_642 entry = client.method_1558();
            if (entry != null && !client.method_1542()) {
                this.server = entry;
            }
            if (client.field_1724 != null && client.field_1724.field_6012 > 100) {
                this.tries = 0;
            }
            this.waitingOn = null;
            return;
        }
        class_437 class_4372 = client.field_1755;
        if (!(class_4372 instanceof class_419)) {
            this.waitingOn = null;
            return;
        }
        class_419 screen = (class_419)class_4372;
        if (!this.isActive() || this.server == null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (this.waitingOn != screen) {
            this.waitingOn = screen;
            if (skip) {
                skip = false;
                this.reconnectAt = -1L;
                return;
            }
            if (this.attempts.get() > 0 && this.tries >= this.attempts.get()) {
                Notifications.push("Auto Reconnect", "Gave up after " + this.tries + " tries.", Notifications.Type.WARNING);
                this.reconnectAt = -1L;
                return;
            }
            this.reconnectAt = now + (long)this.delay.get().intValue() * 1000L;
            Notifications.push("Auto Reconnect", "Joining " + this.server.field_3761 + " again in " + String.valueOf(this.delay.get()) + " s.", Notifications.Type.INFO);
            return;
        }
        if (this.reconnectAt < 0L || now < this.reconnectAt) {
            return;
        }
        this.reconnectAt = -1L;
        ++this.tries;
        class_412.method_36877((class_437)new class_500((class_437)new class_442()), (class_310)client, (class_639)class_639.method_2950((String)this.server.field_3761), (class_642)this.server, (boolean)false, null);
    }

    @Override
    public String getInfoString() {
        return String.valueOf(this.delay.get()) + "s";
    }
}

