/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10185
 *  net.minecraft.class_1293
 *  net.minecraft.class_1294
 *  net.minecraft.class_243
 *  net.minecraft.class_746
 */
package dev.sober.modules.speed;

import dev.sober.modules.Speed;
import dev.sober.modules.speed.SpeedMode;
import net.minecraft.class_10185;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_243;
import net.minecraft.class_746;

public final class VanillaSpeedMode
extends SpeedMode {
    private static final double DIAGONAL = 1.0 / Math.sqrt(2.0);

    public VanillaSpeedMode(Speed settings) {
        super(settings);
    }

    @Override
    public class_243 onMove(class_746 player, class_243 movement) {
        class_243 vel = VanillaSpeedMode.horizontalVelocity(player, this.settings.vanillaSpeed());
        double velX = vel.field_1352;
        double velZ = vel.field_1350;
        class_1293 speedEffect = player.method_6112(class_1294.field_5904);
        if (speedEffect != null) {
            double value = (double)(speedEffect.method_5578() + 1) * 0.205;
            velX += velX * value;
            velZ += velZ * value;
        }
        return new class_243(velX, movement.field_1351, velZ);
    }

    private static class_243 horizontalVelocity(class_746 player, double bps) {
        float yaw = player.method_36454();
        class_243 forward = class_243.method_1030((float)0.0f, (float)yaw);
        class_243 right = class_243.method_1030((float)0.0f, (float)(yaw + 90.0f));
        class_10185 keys = player.field_3913.field_54155;
        double velX = 0.0;
        double velZ = 0.0;
        boolean a = false;
        if (keys.comp_3159()) {
            velX += forward.field_1352 / 20.0 * bps;
            velZ += forward.field_1350 / 20.0 * bps;
            a = true;
        }
        if (keys.comp_3160()) {
            velX -= forward.field_1352 / 20.0 * bps;
            velZ -= forward.field_1350 / 20.0 * bps;
            a = true;
        }
        boolean b = false;
        if (keys.comp_3162()) {
            velX += right.field_1352 / 20.0 * bps;
            velZ += right.field_1350 / 20.0 * bps;
            b = true;
        }
        if (keys.comp_3161()) {
            velX -= right.field_1352 / 20.0 * bps;
            velZ -= right.field_1350 / 20.0 * bps;
            b = true;
        }
        if (a && b) {
            velX *= DIAGONAL;
            velZ *= DIAGONAL;
        }
        return new class_243(velX, 0.0, velZ);
    }
}

