/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10017
 *  net.minecraft.class_10055
 *  net.minecraft.class_11659
 *  net.minecraft.class_12249
 *  net.minecraft.class_1921
 *  net.minecraft.class_2960
 *  net.minecraft.class_4587
 *  net.minecraft.class_4608
 *  net.minecraft.class_591
 *  net.minecraft.class_9334
 *  org.joml.Matrix4f
 *  org.joml.Quaternionf
 *  org.joml.Quaternionfc
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.gui.Theme;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.AccessoryMesh;
import dev.sober.render.Color;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_10017;
import net.minecraft.class_10055;
import net.minecraft.class_11659;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_591;
import net.minecraft.class_9334;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;

public class CustomAccessories
extends Module {
    private static final class_1921 LAYER = class_12249.method_75994((class_2960)class_2960.method_60655((String)"sober", (String)"textures/models/white.png"));
    private static final int FULL_BRIGHT = 0xF000F0;
    private final Setting<Boolean> wings = this.add(new BoolSetting("Sober Wings", "Black wings with purple joints and glowing feather tips on your back.", true));
    private final Setting<Boolean> crown = this.add(new BoolSetting("Crown", "A purple crown with glowing gems on your head.", true));
    private final Setting<Color> crownColor = this.add(new ColorSetting("Crown Color", "Color of the crown. Pick any color on the wheel.", new Color(196, 181, 253, 255))).visible(this.crown::get);
    private final Setting<Integer> wingSize = this.add(new IntSetting("Wing Size", "Size of the wings in percent.", 100, 60, 140));
    private final Setting<Boolean> animate = this.add(new BoolSetting("Wing Animation", "The wings breathe slowly up and down.", true));
    private final Setting<GemColor> gemMode = this.add(new EnumSetting<GemColor>("Gem Color", "Theme uses your accent color for the gems and feather tips. Custom uses your own color.", GemColor.Theme));
    private final Setting<Color> gemColor = this.add(new ColorSetting("Custom Gem Color", "Color of the gems and feather tips.", new Color(167, 139, 250, 255))).visible(() -> this.gemMode.get() == GemColor.Custom);
    private final AccessoryMesh mesh = new AccessoryMesh();
    private final Map<Integer, Baked[]> wingCache = new HashMap<Integer, Baked[]>();
    private Baked crownMesh;
    private float bakedSize = -1.0f;
    private int bakedAccent;
    private int crownAccent;
    private int crownMetal;

    public CustomAccessories() {
        super("Custom Accessories", "The Sober Wings and a crown on your player. While you wear an elytra the normal elytra shows instead of the wings. Only you can see them.", Category.VISUALS);
    }

    private static CustomAccessories instance() {
        return SoberClient.MODULES.get(CustomAccessories.class);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    private static boolean self(class_10017 state) {
        if (!(state instanceof class_10055)) return false;
        class_10055 player = (class_10055)state;
        if (CustomAccessories.mc.field_1724 == null) return false;
        if (player.field_53528 != CustomAccessories.mc.field_1724.method_5628()) return false;
        if (player.field_53333) return false;
        if (player.field_53542) return false;
        return true;
    }

    private static boolean wearsElytra(class_10055 state) {
        return state.field_53418 != null && state.field_53418.method_57826(class_9334.field_54197);
    }

    public static void render(class_591 model, class_10055 state, class_4587 matrices, class_11659 queue, int light, float limbAngle, float limbDistance) {
        int accent;
        CustomAccessories module = CustomAccessories.instance();
        if (module == null || !module.isActive() || state.field_53333 || state.field_53542) {
            return;
        }
        boolean me = CustomAccessories.self((class_10017)state);
        if (!me) {
            return;
        }
        boolean showWings = module.wings.get() != false && !CustomAccessories.wearsElytra(state);
        int n = accent = module.gemMode.get() == GemColor.Custom ? 0xFF000000 | module.gemColor.get().packed() : 0xFF000000 | Theme.accent();
        if (showWings) {
            float raw = state.field_53411 ? Math.max(0.0f, Math.min(1.0f, (-state.field_53417 - 0.2618f) / 1.309f)) : 0.0f;
            int step = Math.round(raw * 40.0f);
            float spread = (float)step / 40.0f;
            float size = (float)module.wingSize.get().intValue() / 100.0f;
            if (size != module.bakedSize || accent != module.bakedAccent) {
                module.wingCache.clear();
                module.bakedSize = size;
                module.bakedAccent = accent;
            }
            Baked[] pair = module.wingCache.computeIfAbsent(step, key -> new Baked[]{Baked.of(module.mesh.reset(), mesh -> mesh.wing(new Matrix4f(), 1, spread, 0.0f, size, accent)), Baked.of(module.mesh.reset(), mesh -> mesh.wing(new Matrix4f(), -1, spread, 0.0f, size, accent))});
            float flap = module.animate.get() != false ? (float)Math.sin(state.field_53328 * 0.09f) * 0.05f * (1.0f - spread) : 0.0f;
            matrices.method_22903();
            model.field_3391.method_22703(matrices);
            matrices.method_22905(0.0625f, 0.0625f, 0.0625f);
            for (int side = 1; side >= -1; side -= 2) {
                matrices.method_22903();
                matrices.method_46416((float)side * 1.6f, 2.4f, 2.3f);
                matrices.method_22907((Quaternionfc)new Quaternionf().rotationY(-flap * (float)side));
                matrices.method_46416((float)(-side) * 1.6f, -2.4f, -2.3f);
                pair[side == 1 ? 0 : 1].submit(matrices, queue, light);
                matrices.method_22909();
            }
            matrices.method_22909();
        }
        if (me && module.crown.get().booleanValue()) {
            int metal = 0xFF000000 | module.crownColor.get().packed() & 0xFFFFFF;
            if (module.crownMesh == null || module.crownAccent != accent || module.crownMetal != metal) {
                module.crownMesh = Baked.of(new AccessoryMesh(), mesh -> mesh.crown(new Matrix4f(), accent, metal));
                module.crownAccent = accent;
                module.crownMetal = metal;
            }
            matrices.method_22903();
            model.field_3398.method_22703(matrices);
            matrices.method_22905(0.0625f, 0.0625f, 0.0625f);
            module.crownMesh.submit(matrices, queue, light);
            matrices.method_22909();
        }
    }

    @Override
    public boolean showInHud() {
        return false;
    }

    public static enum GemColor {
        Theme,
        Custom;

    }

    private record Baked(float[] positions, float[] normals, int[] colors, boolean[] glow, int quads) {
        static Baked of(AccessoryMesh mesh, Consumer<AccessoryMesh> build) {
            build.accept(mesh);
            int quads = mesh.quads;
            return new Baked(Arrays.copyOf(mesh.positions, quads * 12), Arrays.copyOf(mesh.normals, quads * 3), Arrays.copyOf(mesh.colors, quads), Arrays.copyOf(mesh.glow, quads), quads);
        }

        void submit(class_4587 matrices, class_11659 queue, int light) {
            queue.method_73483(matrices, LAYER, (entry, consumer) -> {
                for (int q = 0; q < this.quads; ++q) {
                    int packed = this.glow[q] ? 0xF000F0 : light;
                    float nx = this.normals[q * 3];
                    float ny = this.normals[q * 3 + 1];
                    float nz = this.normals[q * 3 + 2];
                    for (int k = 0; k < 4; ++k) {
                        int o = q * 12 + k * 3;
                        consumer.method_56824(entry, this.positions[o], this.positions[o + 1], this.positions[o + 2]).method_39415(this.colors[q]).method_22913(0.5f, 0.5f).method_22922(class_4608.field_21444).method_60803(packed).method_60831(entry, nx, ny, nz);
                    }
                }
            });
        }
    }
}

