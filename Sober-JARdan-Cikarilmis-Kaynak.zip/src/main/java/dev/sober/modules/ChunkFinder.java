/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap
 *  it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap
 *  it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue
 *  it.unimi.dsi.fastutil.longs.LongArrayList
 *  it.unimi.dsi.fastutil.longs.LongCollection
 *  it.unimi.dsi.fastutil.longs.LongIterator
 *  it.unimi.dsi.fastutil.longs.LongOpenHashSet
 *  it.unimi.dsi.fastutil.longs.LongSet
 *  net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents
 *  net.minecraft.class_1923
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2680
 *  net.minecraft.class_2741
 *  net.minecraft.class_2769
 *  net.minecraft.class_2818
 *  net.minecraft.class_2826
 *  net.minecraft.class_2902$class_2903
 */
package dev.sober.modules;

import dev.sober.gui.Notifications;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.Color;
import dev.sober.render.Render3D;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongCollection;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_1923;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2769;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2902;

public class ChunkFinder
extends Module {
    private static final int SETTLE_TICKS = 200;
    private static final int PER_TICK = 8;
    private static final double BASE_Y = 55.0;
    private final Setting<Integer> mergeRadius = this.add(new IntSetting("Merge Radius", "Hives within this many chunks of each other merge to one middle flag", 4, 1, 8));
    private final Setting<Boolean> notify = this.add(new BoolSetting("Notifications", "Pop a notification for every new chunk", true));
    private final Setting<Boolean> beam = this.add(new BoolSetting("Beam", "Light beam above every flag", false));
    private final Setting<Color> color = this.add(new ColorSetting("Color", "Color of the flagged chunks.", new Color(255, 178, 36, 255)));
    private final LongSet hits = new LongOpenHashSet();
    private final LongSet announced = new LongOpenHashSet();
    private final Long2IntOpenHashMap seen = new Long2IntOpenHashMap();
    private final Long2LongOpenHashMap appeared = new Long2LongOpenHashMap();
    private LongSet flags = LongSet.of();
    private int cursor;
    private int ticks;
    private boolean dirty;
    private int builtRadius;

    public ChunkFinder() {
        super("ChunkFinder", "Highlights Donut SMP chunks that match a rare world signal worth checking.", Category.BASE_FINDING);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> this.reset());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> this.reset());
    }

    @Override
    public void onEnable() {
        this.reset();
    }

    @Override
    public void onDisable() {
        this.reset();
    }

    @Override
    public String getInfoString() {
        return this.flags.isEmpty() ? null : String.valueOf(this.flags.size());
    }

    @Override
    public void onTick() {
        if (ChunkFinder.mc.field_1687 == null || ChunkFinder.mc.field_1724 == null) {
            return;
        }
        ++this.ticks;
        int view = (Integer)ChunkFinder.mc.field_1690.method_42503().method_41753();
        class_1923 center = ChunkFinder.mc.field_1724.method_31476();
        int width = view * 2 + 1;
        int area = width * width;
        if (area <= 0) {
            return;
        }
        for (int i = 0; i < 8; ++i) {
            boolean settled;
            int index = this.cursor % area;
            this.cursor = (this.cursor + 1) % area;
            int x = center.field_9181 + index % width - view;
            int z = center.field_9180 + index / width - view;
            class_2818 chunk = ChunkFinder.mc.field_1687.method_2935().method_12126(x, z, false);
            if (chunk == null || chunk.method_12223()) continue;
            long key2 = class_1923.method_8331((int)x, (int)z);
            this.seen.putIfAbsent(key2, this.ticks);
            boolean bl = settled = this.ticks - this.seen.get(key2) >= 200;
            if (settled && ChunkFinder.hasFullHive(chunk)) {
                if (this.hits.add(key2)) {
                    this.dirty = true;
                }
                if (!this.announced.add(key2)) continue;
                this.announce(x, z);
                continue;
            }
            if (!this.hits.remove(key2)) continue;
            this.dirty = true;
        }
        if (this.hits.removeIf(key -> ChunkFinder.outside(key, center, view))) {
            this.dirty = true;
        }
        this.seen.keySet().removeIf(key -> ChunkFinder.outside(key, center, view));
        if (this.dirty || this.mergeRadius.get() != this.builtRadius) {
            this.rebuild();
        }
    }

    private void rebuild() {
        this.dirty = false;
        this.builtRadius = this.mergeRadius.get();
        if (this.hits.size() < 2) {
            this.flags = new LongOpenHashSet((LongCollection)this.hits);
            return;
        }
        int radius = Math.max(1, this.builtRadius);
        LongOpenHashSet out = new LongOpenHashSet();
        LongOpenHashSet visited = new LongOpenHashSet();
        LongIterator longIterator = this.hits.iterator();
        while (longIterator.hasNext()) {
            long start = (Long)longIterator.next();
            if (!visited.add(start)) continue;
            LongArrayList group = new LongArrayList();
            LongArrayFIFOQueue queue = new LongArrayFIFOQueue();
            queue.enqueue(start);
            while (!queue.isEmpty()) {
                long key = queue.dequeueLong();
                group.add(key);
                int cx = class_1923.method_8325((long)key);
                int cz = class_1923.method_8332((long)key);
                for (int dx = -radius; dx <= radius; ++dx) {
                    for (int dz = -radius; dz <= radius; ++dz) {
                        long next;
                        if (dx == 0 && dz == 0 || !this.hits.contains(next = class_1923.method_8331((int)(cx + dx), (int)(cz + dz))) || !visited.add(next)) continue;
                        queue.enqueue(next);
                    }
                }
            }
            out.add(group.size() == 1 ? group.getLong(0) : ChunkFinder.middle(group));
        }
        this.flags = out;
    }

    private static long middle(LongArrayList group) {
        long sx = 0L;
        long sz = 0L;
        for (int i = 0; i < group.size(); ++i) {
            sx += (long)class_1923.method_8325((long)group.getLong(i));
            sz += (long)class_1923.method_8332((long)group.getLong(i));
        }
        return class_1923.method_8331((int)((int)Math.round((double)sx / (double)group.size())), (int)((int)Math.round((double)sz / (double)group.size())));
    }

    private static boolean hasFullHive(class_2818 chunk) {
        for (class_2826 section : chunk.method_12006()) {
            if (section == null || section.method_38292() || !section.method_12265().method_19526(ChunkFinder::fullHive)) continue;
            for (int x = 0; x < 16; ++x) {
                for (int y = 0; y < 16; ++y) {
                    for (int z = 0; z < 16; ++z) {
                        if (!ChunkFinder.fullHive(section.method_12254(x, y, z))) continue;
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean fullHive(class_2680 state) {
        return (state.method_27852(class_2246.field_20422) || state.method_27852(class_2246.field_20421)) && state.method_28498((class_2769)class_2741.field_20432) && (Integer)state.method_11654((class_2769)class_2741.field_20432) == 5;
    }

    private static boolean outside(long key, class_1923 center, int view) {
        return Math.abs(class_1923.method_8325((long)key) - center.field_9181) > view || Math.abs(class_1923.method_8332((long)key) - center.field_9180) > view;
    }

    private void announce(int x, int z) {
        if (!this.notify.get().booleanValue()) {
            return;
        }
        Notifications.push("Chunk Finder", "X " + (x * 16 + 8) + "  Z " + (z * 16 + 8), Notifications.Type.INFO);
    }

    private void reset() {
        this.hits.clear();
        this.announced.clear();
        this.seen.clear();
        this.appeared.clear();
        this.flags = LongSet.of();
        this.cursor = 0;
        this.ticks = 0;
        this.dirty = false;
        this.builtRadius = this.mergeRadius.get();
    }

    @Override
    public void onRender(Render3D renderer) {
        LongSet current = this.flags;
        this.appeared.keySet().removeIf(key -> !current.contains(key));
        if (current.isEmpty()) {
            return;
        }
        long now = System.currentTimeMillis();
        Color base = this.color.get();
        double pulse = 0.82 + 0.18 * Math.sin((double)now / 420.0);
        double spin = (double)now / 2600.0;
        LongIterator longIterator = current.iterator();
        while (longIterator.hasNext()) {
            long key2 = (Long)longIterator.next();
            long since = this.appeared.computeIfAbsent(key2, k -> now);
            double fade = Math.min(1.0, (double)(now - since) / 350.0);
            double ease = 1.0 - Math.pow(1.0 - fade, 3.0);
            double x1 = (double)class_1923.method_8325((long)key2) * 16.0;
            double z1 = (double)class_1923.method_8332((long)key2) * 16.0;
            double x2 = x1 + 16.0;
            double z2 = z1 + 16.0;
            double cx = x1 + 8.0;
            double cz = z1 + 8.0;
            double y = this.surface(55.0, cx, cz);
            if (!renderer.inView(x1, y - 1.0, z1, x2, y + 1.0, z2)) continue;
            renderer.quad(x1, y, z1, x1, y, z2, x2, y, z2, x2, y, z1, base.withAlpha((int)(34.0 * ease)));
            renderer.disc(cx, y + 0.01, cz, 0.0, 8.0 * (0.6 + 0.4 * ease), base.withAlpha((int)(120.0 * pulse * ease)), base.withAlpha(0), 40);
            renderer.setLineWidth(2.5f);
            Color edge = base.withAlpha((int)(235.0 * ease));
            double arm = 4.0;
            ChunkFinder.corner(renderer, x1, z1, arm, arm, y, edge);
            ChunkFinder.corner(renderer, x2, z1, -arm, arm, y, edge);
            ChunkFinder.corner(renderer, x2, z2, -arm, -arm, y, edge);
            ChunkFinder.corner(renderer, x1, z2, arm, -arm, y, edge);
            renderer.setLineWidth(2.0f);
            ChunkFinder.hexagon(renderer, cx, cz, y + 0.02, 2.4 * ease, spin, base.withAlpha((int)(255.0 * ease)));
            ChunkFinder.hexagon(renderer, cx, cz, y + 0.02, 1.2 * ease, -spin, Color.WHITE.withAlpha((int)(170.0 * pulse * ease)));
            if (!this.beam.get().booleanValue()) continue;
            renderer.beam(cx, cz, y, y + 80.0, 0.28, base.withAlpha((int)(200.0 * ease)), pulse);
        }
        renderer.setLineWidth(2.0f);
    }

    private static void corner(Render3D renderer, double x, double z, double ax, double az, double y, Color color) {
        renderer.line(x, y, z, x + ax, y, z, color);
        renderer.line(x, y, z, x, y, z + az, color);
    }

    private static void hexagon(Render3D renderer, double cx, double cz, double y, double radius, double rotation, Color color) {
        if (radius <= 0.01) {
            return;
        }
        for (int i = 0; i < 6; ++i) {
            double a0 = rotation + 1.0471975511965976 * (double)i;
            double a1 = a0 + 1.0471975511965976;
            renderer.line(cx + Math.cos(a0) * radius, y, cz + Math.sin(a0) * radius, cx + Math.cos(a1) * radius, y, cz + Math.sin(a1) * radius, color);
        }
    }

    private double surface(double base, double x, double z) {
        int bz;
        if (ChunkFinder.mc.field_1687 == null) {
            return base;
        }
        int bx = (int)Math.floor(x);
        int top = ChunkFinder.mc.field_1687.method_8624(class_2902.class_2903.field_13202, bx, bz = (int)Math.floor(z));
        if (top <= ChunkFinder.mc.field_1687.method_31607()) {
            return base;
        }
        return ChunkFinder.mc.field_1687.method_8316(new class_2338(bx, top - 1, bz)).method_15769() ? base : Math.max(base, (double)top + 0.04);
    }

    public LongSet radarChunks() {
        return this.isActive() ? this.flags : LongSet.of();
    }

    public int radarColor() {
        return 0x99000000 | this.color.get().packed() & 0xFFFFFF;
    }
}

