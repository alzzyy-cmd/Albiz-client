/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.ClickGui;
import dev.sober.render.Color;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.Setting;

public class ColorSync
extends Module {
    private final Setting<Boolean> accent = this.add(new BoolSetting("Menu Accent Too", "Also changes the accent color of the menu and the HUD.", false));
    public final Setting<Color> color = this.add(new ColorSetting("All Colors", "Move this one color wheel and every module color follows: ESP, Sus Chunk, tracers, Player Xray, glows and more. Each color keeps its own transparency.", new Color(176, 140, 240, 255))).onChanged(this::apply);

    public ColorSync() {
        super("Color Sync", "One color wheel for every module color at once.", Category.CLIENT);
    }

    private void apply(Color picked) {
        ClickGui gui;
        if (picked == null) {
            return;
        }
        for (Module module : SoberClient.MODULES.all()) {
            if (module == this || module instanceof ClickGui) continue;
            for (Setting<?> setting : module.getSettings()) {
                ColorSetting target;
                if (!(setting instanceof ColorSetting) || (target = (ColorSetting)setting).get() == null) continue;
                target.set(new Color(picked.r(), picked.g(), picked.b(), ((Color)((Object)target.get())).a()));
            }
        }
        if (this.accent.get().booleanValue() && (gui = SoberClient.MODULES.get(ClickGui.class)) != null) {
            gui.accentMode.set(ClickGui.AccentMode.Static);
            gui.accent.set(new Color(picked.r(), picked.g(), picked.b(), 255));
        }
    }

    @Override
    public boolean bindable() {
        return false;
    }

    @Override
    public boolean showInHud() {
        return false;
    }
}

