/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_746
 */
package dev.sober.modules;

import dev.sober.event.Stage;
import dev.sober.event.impl.TickEvent;
import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;
import dev.sober.setting.lite.ModeSetting;
import dev.sober.setting.lite.NumberSetting;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class AutoJump
extends BusModule {
    private final ModeSetting mode = this.addSetting("mode", new ModeSetting("Mode", "Jump", "Jump", "LowHop"));
    private final ModeSetting jumpIf = this.addSetting("jump-if", new ModeSetting("Jump If", "Always", "Sprinting", "Walking", "Always"));
    private final NumberSetting velocityHeight = this.addSetting("velocity-height", new NumberSetting("Velocity Height", 0.25f, 0.0f, 2.0f).step(0.05f));

    public AutoJump() {
        super("auto-jump", "Auto Jump", "Automatically jumps.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEnable() {
        this.on(TickEvent.TYPE, Stage.PRE, this::onPreTick);
    }

    private void onPreTick(TickEvent event) {
        class_746 player = class_310.method_1551().field_1724;
        if (player != null && player.method_24828() && !player.method_5715() && this.shouldJump(player)) {
            if (this.mode.is("Jump")) {
                player.method_6043();
            } else {
                class_243 velocity = player.method_18798();
                player.method_18800(velocity.field_1352, (double)this.velocityHeight.get(), velocity.field_1350);
            }
        }
    }

    private boolean shouldJump(class_746 player) {
        String var3;
        boolean moving = player.field_6250 != 0.0f || player.field_6212 != 0.0f;
        return switch (var3 = this.jumpIf.get()) {
            case "Sprinting" -> {
                if (player.method_5624() && moving) {
                    yield true;
                }
                yield false;
            }
            case "Walking" -> moving;
            default -> true;
        };
    }
}

