/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules.elytrafly;

import dev.sober.modules.ElytraFly;
import dev.sober.modules.elytrafly.ElytraFlightMode;

public final class VanillaMode
extends ElytraFlightMode {
    public VanillaMode(ElytraFly elytraFly) {
        super(elytraFly);
    }
}

