/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules.elytrafly;

public enum ElytraFlightModes {
    Vanilla,
    Pitch40,
    Bounce;

}

