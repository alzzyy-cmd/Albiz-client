/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1657
 *  net.minecraft.class_1661
 *  net.minecraft.class_1713
 *  net.minecraft.class_1802
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1802;

public class AutoTotem
extends Module {
    private final Setting<Integer> health = this.add(new IntSetting(this, "Health", "Only puts a totem in your offhand at or below this many hearts. 0 always keeps one there.", 0, 0, 20){

        @Override
        public String display() {
            return (Integer)this.value == 0 ? "Always" : String.valueOf(this.value) + " hearts";
        }
    });
    private final Setting<Integer> delay = this.add(new IntSetting("Delay", "Ticks to wait between two swaps.", 0, 0, 20));
    private final Setting<Boolean> hotbar = this.add(new BoolSetting("Use Hotbar", "Also takes totems from your hotbar when your inventory has none.", true));
    private int timer;

    public AutoTotem() {
        super("Auto Totem", "Keeps a totem of undying in your offhand.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (AutoTotem.mc.field_1724 == null || AutoTotem.mc.field_1761 == null || AutoTotem.mc.field_1724.method_68878() || AutoTotem.mc.field_1724.method_7325()) {
            return;
        }
        if (AutoTotem.mc.field_1724.field_7512 != AutoTotem.mc.field_1724.field_7498) {
            return;
        }
        if (AutoTotem.mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
            return;
        }
        if (this.health.get() > 0 && AutoTotem.mc.field_1724.method_6032() + AutoTotem.mc.field_1724.method_6067() > (float)this.health.get().intValue() * 2.0f) {
            return;
        }
        if (this.timer > 0) {
            --this.timer;
            return;
        }
        int slot = AutoTotem.totemSlot(this.hotbar.get());
        if (slot < 0) {
            return;
        }
        AutoTotem.mc.field_1761.method_2906(AutoTotem.mc.field_1724.field_7498.field_7763, slot, 40, class_1713.field_7791, (class_1657)AutoTotem.mc.field_1724);
        this.timer = this.delay.get();
    }

    private static int totemSlot(boolean hotbar) {
        int i;
        class_1661 inventory = AutoTotem.mc.field_1724.method_31548();
        for (i = 9; i < 36; ++i) {
            if (!inventory.method_5438(i).method_31574(class_1802.field_8288)) continue;
            return i;
        }
        if (hotbar) {
            for (i = 0; i < 9; ++i) {
                if (!inventory.method_5438(i).method_31574(class_1802.field_8288)) continue;
                return 36 + i;
            }
        }
        return -1;
    }

    @Override
    public String getInfoString() {
        if (AutoTotem.mc.field_1724 == null) {
            return null;
        }
        int count = 0;
        class_1661 inventory = AutoTotem.mc.field_1724.method_31548();
        for (int i = 0; i < 36; ++i) {
            if (!inventory.method_5438(i).method_31574(class_1802.field_8288)) continue;
            count += inventory.method_5438(i).method_7947();
        }
        if (AutoTotem.mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
            ++count;
        }
        return String.valueOf(count);
    }
}

