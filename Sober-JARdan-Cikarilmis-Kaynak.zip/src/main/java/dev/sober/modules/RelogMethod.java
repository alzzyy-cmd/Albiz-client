/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
 *  net.minecraft.class_2561
 *  net.minecraft.class_310
 *  net.minecraft.class_412
 *  net.minecraft.class_437
 *  net.minecraft.class_442
 *  net.minecraft.class_500
 *  net.minecraft.class_639
 *  net.minecraft.class_642
 */
package dev.sober.modules;

import dev.sober.SoberClient;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.KeySetting;
import dev.sober.setting.Setting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_412;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_639;
import net.minecraft.class_642;

public class RelogMethod
extends Module {
    private final Setting<Mode> mode = this.add(new EnumSetting<Mode>("Mode", "Height relogs when you pass a Y level. Keybind relogs when you press your relog key.", Mode.Height));
    private final KeySetting relogKey = (KeySetting)this.add(new KeySetting("Relog Key", "Relogs when you press it. Click and press a key. Right click removes it.", () -> null)).visible(() -> this.mode.get() == Mode.Keybind);
    private final Setting<Integer> height = this.add(new IntSetting("Height", "Y level that triggers the relog.", 0, -64, 320)).visible(() -> this.mode.get() == Mode.Height);
    private final Setting<Trigger> trigger = this.add(new EnumSetting<Trigger>("Trigger", "Relog when you go below or above the height.", Trigger.Below)).visible(() -> this.mode.get() == Mode.Height);
    private final Setting<Boolean> rejoin = this.add(new BoolSetting("Rejoin", "Joins the server again right after the logout.", true));
    private final Setting<Integer> delay = this.add(new IntSetting("Rejoin Delay", "Milliseconds to wait before joining again.", 1000, 0, 10000)).visible(this.rejoin::get);
    private final Setting<Boolean> autoOff = this.add(new BoolSetting("Auto Off", "Turns Relog Method off after one relog. Off keeps it running for the next relog.", false));
    private boolean armed;
    private boolean joinChecked;
    private boolean keyDown;
    private class_642 server;
    private long rejoinAt = -1L;
    private int triggeredY;
    private boolean byKey;

    public RelogMethod() {
        super("Relog Method", "Logs out when you reach a set height or press your relog key, and joins again right away.", Category.DONUT);
        ClientTickEvents.END_CLIENT_TICK.register(this::tickAlways);
    }

    @Override
    public void onEnable() {
        this.armed = RelogMethod.mc.field_1724 == null || !this.past(RelogMethod.mc.field_1724.method_23318());
        this.keyDown = this.relogKey.isPressed();
        this.rejoinAt = -1L;
    }

    @Override
    public void onDisable() {
        this.rejoinAt = -1L;
    }

    @Override
    public void onGameLeft() {
        this.joinChecked = false;
    }

    private boolean past(double y) {
        return this.trigger.get() == Trigger.Below ? y <= (double)this.height.get().intValue() : y >= (double)this.height.get().intValue();
    }

    @Override
    public void onTick() {
        if (this.mode.get() == Mode.Keybind) {
            boolean down = this.relogKey.isPressed();
            boolean pressed = down && !this.keyDown;
            this.keyDown = down;
            if (pressed && RelogMethod.mc.field_1724 != null && !mc.method_1542() && RelogMethod.mc.field_1724.field_6012 >= 40) {
                this.relog(RelogMethod.mc.field_1724.method_23318(), true);
            }
            return;
        }
        if (RelogMethod.mc.field_1724 == null || mc.method_1542() || RelogMethod.mc.field_1724.field_6012 < 40) {
            return;
        }
        double y = RelogMethod.mc.field_1724.method_23318();
        if (!this.joinChecked) {
            this.joinChecked = true;
            if (this.past(y)) {
                this.armed = false;
            }
        }
        if (!this.armed) {
            if (!this.past(y)) {
                this.armed = true;
            }
            return;
        }
        if (!this.past(y)) {
            return;
        }
        this.relog(y, false);
    }

    private void relog(double y, boolean key) {
        class_642 info = mc.method_1558();
        if (info == null) {
            return;
        }
        this.armed = false;
        this.server = info;
        this.byKey = key;
        this.triggeredY = (int)Math.floor(y);
        long l = this.rejoinAt = this.rejoin.get() != false ? System.currentTimeMillis() + (long)this.delay.get().intValue() : -1L;
        if (this.autoOff.get().booleanValue()) {
            this.setEnabledSilently(false);
            SoberClient.CONFIG.save();
        }
        mc.execute(() -> mc.method_73360((class_2561)class_2561.method_43470((String)"SoberClient Relog Method")));
    }

    private void tickAlways(class_310 client) {
        if (this.rejoinAt < 0L || this.server == null || System.currentTimeMillis() < this.rejoinAt) {
            return;
        }
        if (client.field_1687 != null || client.method_1562() != null) {
            return;
        }
        this.rejoinAt = -1L;
        class_642 info = this.server;
        class_412.method_36877((class_437)new class_500((class_437)new class_442()), (class_310)client, (class_639)class_639.method_2950((String)info.field_3761), (class_642)info, (boolean)false, null);
        if (this.autoOff.get().booleanValue()) {
            this.info("Relogged at Y %d. Relog Method is now off.", this.triggeredY);
        } else if (this.byKey) {
            this.info("Relogged at Y %d. Press %s to relog again.", this.triggeredY, this.relogKey.display());
        } else {
            this.info("Relogged at Y %d. Relog Method stays on and triggers again after you went back past Y %d.", this.triggeredY, this.height.get());
        }
    }

    @Override
    public String getInfoString() {
        if (this.mode.get() == Mode.Keybind) {
            return this.relogKey.display();
        }
        return (this.trigger.get() == Trigger.Below ? "< " : "> ") + String.valueOf(this.height.get());
    }

    public static enum Mode {
        Height,
        Keybind;

    }

    public static enum Trigger {
        Below,
        Above;

    }
}

