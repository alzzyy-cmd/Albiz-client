/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  net.minecraft.class_1703
 *  net.minecraft.class_1707
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_1802
 *  net.minecraft.class_2960
 *  net.minecraft.class_7923
 *  net.minecraft.class_9304
 *  net.minecraft.class_9334
 */
package dev.sober.modules;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.ItemSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import dev.sober.util.DonutUtils;
import dev.sober.util.InvUtil;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public class AuctionSniper
extends Module {
    private static final String API_URL = "https://api.donutsmp.net/v1/auction/list/1";
    private final Setting<class_1792> item = this.add(new ItemSetting("Item", "Item to snipe (item id, e.g. elytra).", class_1802.field_8162));
    private final Setting<String> enchantments = this.add(new StringSetting("Enchantments", "Enchantments the item must have, comma separated (e.g. mending, unbreaking).", ""));
    private final Setting<String> blacklist = this.add(new StringSetting("Blacklist", "Enchantments the item must not have, comma separated (e.g. binding_curse).", ""));
    private final Setting<String> maxPrice = this.add(new StringSetting("Max Price", "Maximum price per item, e.g. 500, 1.5k, 2m.", "1k"));
    private final Setting<Mode> mode = this.add(new EnumSetting<Mode>("Mode", "Manual keeps refreshing the /ah GUI. Api polls the DonutSMP API and only opens /ah on a hit.", Mode.Manual));
    private final Setting<Boolean> quickBuy = this.add(new BoolSetting("Quick Buy", "Shift-click to skip the confirm screen (Donut+ rank). Risky.", false));
    private final Setting<Integer> refreshDelay = this.add(new IntSetting("Refresh Delay", "Ticks between /ah refreshes.", 2, 0, 100)).visible(() -> this.mode.get() == Mode.Manual);
    private final Setting<Integer> buyDelay = this.add(new IntSetting("Buy Delay", "Ticks to wait before clicking a found item.", 2, 0, 100));
    private final Setting<String> apiKey;
    private final Setting<Integer> apiRefreshRate;
    private final Setting<Boolean> apiNotifications;
    private final Setting<Boolean> autoResell;
    private final Setting<String> resellPrice;
    private final Setting<String> webhook;
    private final HttpClient http;
    private int wait;
    private boolean readyToBuy;
    private volatile boolean apiQuerying;
    private long lastApiQuery;
    private String apiSeller;
    private int apiStep;
    private Purchase purchase;
    private boolean resellQueued;
    private int resellTimeout;

    public AuctionSniper() {
        super("Auction Sniper", "Snipes cheap items from the auction house.", Category.DONUT);
        this.group("API");
        this.apiKey = this.add(new StringSetting("Api Key", "Get it with /api in game.", "", true)).visible(() -> this.mode.get() == Mode.Api);
        this.apiRefreshRate = this.add(new IntSetting("Api Refresh Rate", "Milliseconds between API requests.", 250, 10, 5000)).visible(() -> this.mode.get() == Mode.Api);
        this.apiNotifications = this.add(new BoolSetting("Api Notifications", "Show API hits and errors as notifications.", true)).visible(() -> this.mode.get() == Mode.Api);
        this.group("Resell");
        this.autoResell = this.add(new BoolSetting("Auto Resell", "Puts sniped items back on the auction house.", false));
        this.resellPrice = this.add(new StringSetting("Resell Price", "Resell price per item.", "1k")).visible(this.autoResell::get);
        this.group("Webhook");
        this.webhook = this.add(new StringSetting("Webhook Url", "Discord webhook that gets a message for every sniped item (empty = off).", "", true));
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5L)).build();
    }

    @Override
    public void onEnable() {
        this.wait = 0;
        this.readyToBuy = false;
        this.apiQuerying = false;
        this.lastApiQuery = 0L;
        this.apiSeller = null;
        this.apiStep = -1;
        this.purchase = null;
        this.resellQueued = false;
        if (this.item.get() == class_1802.field_8162) {
            this.error("Select an item first.", new Object[0]);
            this.setEnabled(false);
            return;
        }
        if (DonutUtils.parsePrice(this.maxPrice.get()) < 0.0) {
            this.error("Invalid max price.", new Object[0]);
            this.setEnabled(false);
        }
    }

    @Override
    public void onTick() {
        this.trackPurchase();
        if (this.resellQueued && this.handleResell()) {
            return;
        }
        if (this.wait > 0) {
            --this.wait;
            return;
        }
        if (this.mode.get() == Mode.Api) {
            this.tickApi();
        } else {
            this.tickManual();
        }
    }

    private void tickManual() {
        class_1703 class_17032 = AuctionSniper.mc.field_1724.field_7512;
        if (class_17032 instanceof class_1707) {
            class_1707 container = (class_1707)class_17032;
            if (container.method_17388() == 6) {
                this.handleAuctionList(container);
            } else if (container.method_17388() == 3) {
                this.handleConfirm(container);
            }
            return;
        }
        StringBuilder query = new StringBuilder(this.item.get().method_63680().getString());
        for (class_2960 id : AuctionSniper.enchantmentIds(this.enchantments.get())) {
            query.append(' ').append(id.method_12832().replace('_', ' '));
        }
        DonutUtils.command("ah " + String.valueOf(query));
        this.wait = 20;
    }

    private void tickApi() {
        if (this.apiSeller != null) {
            class_1703 class_17032 = AuctionSniper.mc.field_1724.field_7512;
            if (class_17032 instanceof class_1707) {
                class_1707 container = (class_1707)class_17032;
                this.apiStep = -1;
                if (container.method_17388() == 6) {
                    this.handleAuctionList(container);
                } else if (container.method_17388() == 3) {
                    this.handleConfirm(container);
                }
                return;
            }
            if (this.apiStep == -1) {
                DonutUtils.command("ah " + this.apiSeller);
                this.apiStep = 0;
            } else if (++this.apiStep > 40) {
                this.apiSeller = null;
            }
            return;
        }
        if (AuctionSniper.mc.field_1724.field_7512 instanceof class_1707 && AuctionSniper.mc.field_1755 != null && AuctionSniper.mc.field_1755.method_25440().getString().contains("Page")) {
            AuctionSniper.mc.field_1724.method_7346();
            this.wait = 20;
            return;
        }
        if (this.apiQuerying) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now - this.lastApiQuery < (long)this.apiRefreshRate.get().intValue()) {
            return;
        }
        this.lastApiQuery = now;
        if (this.apiKey.get().isBlank()) {
            this.error("API key is not set. Get one with /api.", new Object[0]);
            this.setEnabled(false);
            return;
        }
        this.apiQuerying = true;
        String key = this.apiKey.get().trim();
        String targetId = class_7923.field_41178.method_10221((Object)this.item.get()).method_12832();
        double limit = DonutUtils.parsePrice(this.maxPrice.get());
        this.http.sendAsync(HttpRequest.newBuilder(URI.create(API_URL)).timeout(Duration.ofSeconds(10L)).header("Authorization", "Bearer " + key).header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString("{\"sort\": \"recently_listed\"}")).build(), HttpResponse.BodyHandlers.ofString()).whenComplete((response, throwable) -> mc.execute(() -> {
            this.apiQuerying = false;
            if (!this.isActive()) {
                return;
            }
            if (throwable != null) {
                if (this.apiNotifications.get().booleanValue()) {
                    this.warning("API error: %s", throwable.getMessage());
                }
                return;
            }
            if (response.statusCode() != 200) {
                if (this.apiNotifications.get().booleanValue()) {
                    this.warning("API error: %d", response.statusCode());
                }
                return;
            }
            this.handleApiResponse((String)response.body(), targetId, limit);
        }));
    }

    private void handleApiResponse(String body, String targetId, double limit) {
        block5: {
            try {
                JsonArray results = JsonParser.parseString((String)body).getAsJsonObject().getAsJsonArray("result");
                if (results == null) {
                    return;
                }
                for (JsonElement element : results) {
                    String path;
                    JsonObject auction = element.getAsJsonObject();
                    JsonObject auctionItem = auction.getAsJsonObject("item");
                    String id = auctionItem.get("id").getAsString();
                    if (id.contains("shulker_box") || !(path = id.contains(":") ? id.substring(id.indexOf(58) + 1) : id).equals(targetId)) continue;
                    int count = auctionItem.has("count") ? Math.max(1, auctionItem.get("count").getAsInt()) : 1;
                    double price = auction.get("price").getAsDouble();
                    if (price / (double)count > limit) continue;
                    String seller = auction.getAsJsonObject("seller").get("name").getAsString();
                    if (this.apiNotifications.get().booleanValue()) {
                        this.info("Found %s x%d for %s from %s", path, count, DonutUtils.formatPrice(price), seller);
                    }
                    this.apiSeller = seller;
                    this.apiStep = -1;
                    return;
                }
            }
            catch (Exception e) {
                if (!this.apiNotifications.get().booleanValue()) break block5;
                this.warning("Could not read API response: %s", e.getMessage());
            }
        }
    }

    private void handleAuctionList(class_1707 container) {
        class_1799 sortButton = container.method_7611(47).method_7677();
        if (sortButton.method_7960()) {
            this.wait = 2;
            return;
        }
        if (!DonutUtils.isSortActive(sortButton, "Recently Listed")) {
            DonutUtils.click(container.field_7763, 47, 1, class_1713.field_7794);
            this.wait = 5;
            return;
        }
        for (int slot = 0; slot < 45; ++slot) {
            class_1799 stack = container.method_7611(slot).method_7677();
            if (!stack.method_31574(this.item.get()) || DonutUtils.isShulkerBox(stack) || !this.matches(stack)) continue;
            if (!this.readyToBuy) {
                this.readyToBuy = true;
                this.wait = this.buyDelay.get();
                return;
            }
            this.readyToBuy = false;
            if (this.quickBuy.get().booleanValue()) {
                this.startPurchase(stack, DonutUtils.extractPrice(stack));
                DonutUtils.click(container.field_7763, slot, 1, class_1713.field_7794);
            } else {
                DonutUtils.click(container.field_7763, slot, 0, class_1713.field_7790);
            }
            this.wait = 5;
            return;
        }
        this.readyToBuy = false;
        if (this.apiSeller != null) {
            this.apiSeller = null;
            AuctionSniper.mc.field_1724.method_7346();
            return;
        }
        DonutUtils.click(container.field_7763, 49, 1, class_1713.field_7794);
        this.wait = this.refreshDelay.get();
    }

    private void handleConfirm(class_1707 container) {
        class_1799 stack = container.method_7611(13).method_7677();
        if (!DonutUtils.isShulkerBox(stack) && stack.method_31574(this.item.get()) && this.matches(stack)) {
            this.startPurchase(stack, DonutUtils.extractPrice(stack));
            DonutUtils.click(container.field_7763, 15, 1, class_1713.field_7794);
            this.wait = 20;
        } else {
            AuctionSniper.mc.field_1724.method_7346();
            this.wait = 10;
        }
        this.apiSeller = null;
    }

    private boolean matches(class_1799 stack) {
        for (class_2960 id : AuctionSniper.enchantmentIds(this.enchantments.get())) {
            if (AuctionSniper.hasEnchantment(stack, id)) continue;
            return false;
        }
        for (class_2960 id : AuctionSniper.enchantmentIds(this.blacklist.get())) {
            if (!AuctionSniper.hasEnchantment(stack, id)) continue;
            return false;
        }
        double price = DonutUtils.extractPrice(stack);
        double limit = DonutUtils.parsePrice(this.maxPrice.get());
        if (price < 0.0 || limit < 0.0) {
            return false;
        }
        return price / (double)stack.method_7947() <= limit;
    }

    private static List<class_2960> enchantmentIds(String text) {
        ArrayList<class_2960> ids = new ArrayList<class_2960>();
        for (String part : text.split(",")) {
            class_2960 id;
            String name = part.trim().toLowerCase().replace(' ', '_');
            if (name.isEmpty() || (id = class_2960.method_12829((String)(name.contains(":") ? name : "minecraft:" + name))) == null) continue;
            ids.add(id);
        }
        return ids;
    }

    private static boolean hasEnchantment(class_1799 stack, class_2960 id) {
        class_9304 enchants = (class_9304)stack.method_58695(class_9334.field_49633, (Object)class_9304.field_49385);
        class_9304 stored = (class_9304)stack.method_58695(class_9334.field_49643, (Object)class_9304.field_49385);
        return enchants.method_57534().stream().anyMatch(e -> e.method_40226(id)) || stored.method_57534().stream().anyMatch(e -> e.method_40226(id));
    }

    private void startPurchase(class_1799 stack, double price) {
        this.purchase = new Purchase(stack.method_7909(), stack.method_7964().getString(), stack.method_7947(), price, InvUtil.count(stack.method_7909()), 100);
    }

    private void trackPurchase() {
        if (this.purchase == null) {
            return;
        }
        if (InvUtil.count(this.purchase.item) > this.purchase.countBefore) {
            this.sendWebhook(this.purchase);
            if (this.autoResell.get().booleanValue()) {
                this.resellQueued = true;
                this.resellTimeout = 100;
            }
            this.purchase = null;
        } else if (--this.purchase.timeout <= 0) {
            this.purchase = null;
        }
    }

    private boolean handleResell() {
        if (--this.resellTimeout <= 0 || AuctionSniper.mc.field_1724.field_7512 instanceof class_1707) {
            if (this.resellTimeout <= 0) {
                this.resellQueued = false;
            }
            return false;
        }
        double perItem = DonutUtils.parsePrice(this.resellPrice.get());
        if (perItem < 0.0) {
            this.error("Invalid resell price.", new Object[0]);
            this.resellQueued = false;
            return false;
        }
        int hotbar = InvUtil.findHotbar(this.item.get());
        if (hotbar == -1) {
            int main = InvUtil.findMain(this.item.get());
            if (main == -1) {
                this.resellQueued = false;
                return false;
            }
            InvUtil.moveToHotbar(main, AuctionSniper.mc.field_1724.method_31548().method_67532());
            return true;
        }
        InvUtil.select(hotbar);
        int count = AuctionSniper.mc.field_1724.method_31548().method_5438(hotbar).method_7947();
        DonutUtils.command("ah sell " + (long)(perItem * (double)count));
        this.resellQueued = false;
        this.wait = 20;
        return true;
    }

    private void sendWebhook(Purchase p) {
        String url = this.webhook.get().trim();
        if (url.isEmpty()) {
            return;
        }
        JsonObject embed = new JsonObject();
        embed.addProperty("title", "Item Sniped");
        embed.addProperty("color", (Number)16766720);
        JsonArray fields = new JsonArray();
        fields.add((JsonElement)AuctionSniper.field("Item", p.name + (String)(p.count > 1 ? " x" + p.count : "")));
        fields.add((JsonElement)AuctionSniper.field("Price", p.price > 0.0 ? DonutUtils.formatPrice(p.price) : "Unknown"));
        embed.add("fields", (JsonElement)fields);
        JsonArray embeds = new JsonArray();
        embeds.add((JsonElement)embed);
        JsonObject payload = new JsonObject();
        payload.addProperty("username", "Auction Sniper");
        payload.add("embeds", (JsonElement)embeds);
        try {
            this.http.sendAsync(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(10L)).header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(payload.toString())).build(), HttpResponse.BodyHandlers.discarding());
        }
        catch (IllegalArgumentException e) {
            this.warning("Invalid webhook URL.", new Object[0]);
        }
    }

    private static JsonObject field(String name, String value) {
        JsonObject field = new JsonObject();
        field.addProperty("name", name);
        field.addProperty("value", value);
        field.addProperty("inline", Boolean.valueOf(true));
        return field;
    }

    public static enum Mode {
        Manual,
        Api;

    }

    private static final class Purchase {
        final class_1792 item;
        final String name;
        final int count;
        final double price;
        final int countBefore;
        int timeout;

        Purchase(class_1792 item, String name, int count, double price, int countBefore, int timeout) {
            this.item = item;
            this.name = name;
            this.count = count;
            this.price = price;
            this.countBefore = countBefore;
            this.timeout = timeout;
        }
    }
}

