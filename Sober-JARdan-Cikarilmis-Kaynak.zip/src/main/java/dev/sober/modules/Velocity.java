/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_243;

public class Velocity
extends Module {
    private static volatile Velocity instance;
    private final Setting<Integer> horizontal = this.add(new IntSetting("Horizontal", "How much of the sideways knockback you still take, in percent.", 0, 0, 100));
    private final Setting<Integer> vertical = this.add(new IntSetting("Vertical", "How much of the upward knockback you still take, in percent.", 0, 0, 100));
    private final Setting<Boolean> explosions = this.add(new BoolSetting("Explosions", "Also takes away the push of explosions.", true));

    public Velocity() {
        super("Velocity", "Takes away the knockback you get from hits and explosions.", Category.MOVEMENT);
        instance = this;
    }

    private static Velocity active() {
        Velocity module = instance;
        return module != null && module.isActive() && Velocity.mc.field_1724 != null ? module : null;
    }

    public static void onKnockback(int entityId, class_243 velocity) {
        Velocity module = Velocity.active();
        if (module == null || entityId != Velocity.mc.field_1724.method_5628()) {
            return;
        }
        double h = (double)module.horizontal.get().intValue() / 100.0;
        double v = (double)module.vertical.get().intValue() / 100.0;
        Velocity.mc.field_1724.method_18800(velocity.field_1352 * h, velocity.field_1351 * v, velocity.field_1350 * h);
    }

    public static class_243 onExplosion(class_243 before, class_243 after) {
        Velocity module = Velocity.active();
        if (module == null || !module.explosions.get().booleanValue()) {
            return after;
        }
        double h = (double)module.horizontal.get().intValue() / 100.0;
        double v = (double)module.vertical.get().intValue() / 100.0;
        class_243 push = after.method_1020(before);
        return before.method_1031(push.field_1352 * h, push.field_1351 * v, push.field_1350 * h);
    }

    @Override
    public String getInfoString() {
        return String.valueOf(this.horizontal.get()) + "% " + String.valueOf(this.vertical.get()) + "%";
    }
}

