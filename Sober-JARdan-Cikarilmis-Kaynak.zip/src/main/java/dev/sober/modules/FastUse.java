/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1802
 */
package dev.sober.modules;

import dev.sober.mixin.MinecraftClientAccessor;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1802;

public class FastUse
extends Module {
    private final Setting<Mode> mode = this.add(new EnumSetting<Mode>("Mode", "All places and throws every item as fast as possible. Xp Bottles only speeds up throwing experience bottles.", Mode.All));

    public FastUse() {
        super("Fast Use", "Removes the delay between placing blocks and throwing items while you hold right click.", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (FastUse.mc.field_1724 == null) {
            return;
        }
        MinecraftClientAccessor client = (MinecraftClientAccessor)mc;
        if (client.sober$getItemUseCooldown() <= 0) {
            return;
        }
        if (this.mode.get() == Mode.XpBottles && !FastUse.mc.field_1724.method_6047().method_31574(class_1802.field_8287) && !FastUse.mc.field_1724.method_6079().method_31574(class_1802.field_8287)) {
            return;
        }
        client.sober$setItemUseCooldown(0);
    }

    @Override
    public String getInfoString() {
        return this.mode.get().toString();
    }

    public static enum Mode {
        All("All"),
        XpBottles("Xp Bottles");

        private final String title;

        private Mode(String title) {
            this.title = title;
        }

        public String toString() {
            return this.title;
        }
    }
}

