/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.modules;

import dev.sober.module.BusModule;
import dev.sober.module.ModuleCategory;
import dev.sober.setting.lite.BooleanSetting;
import dev.sober.setting.lite.NumberSetting;

public final class TridentBoost
extends BusModule {
    public static volatile TridentBoost active;
    private final NumberSetting boost = this.addSetting("boost", new NumberSetting("Boost", 2.0f, 0.1f, 10.0f).step(0.1f));
    private final BooleanSetting outOfWater = this.addSetting("out-of-water", new BooleanSetting("Out Of Water", true));

    public TridentBoost() {
        super("trident-boost", "Trident Boost", "Boosts you when using riptide with a trident.", ModuleCategory.MOVEMENT);
    }

    @Override
    public void onEnable() {
        active = this;
    }

    @Override
    public void onDisable() {
        active = null;
    }

    public static double riptideMultiplier() {
        TridentBoost module = active;
        return module != null ? (double)module.boost.get() : 1.0;
    }

    public static boolean allowOutOfWater() {
        TridentBoost module = active;
        return module != null && module.outOfWater.get();
    }
}

