/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1268
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_1531
 *  net.minecraft.class_1569
 *  net.minecraft.class_1657
 *  net.minecraft.class_238
 *  net.minecraft.class_243
 *  net.minecraft.class_2596
 *  net.minecraft.class_2828$class_2831
 *  net.minecraft.class_3532
 *  net.minecraft.class_746
 */
package dev.sober.modules;

import dev.sober.config.FriendStore;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.CombatItems;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1531;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import net.minecraft.class_746;

public class KillAura
extends Module {
    private final Setting<Integer> range = this.add(new IntSetting("Range", "Players and mobs within this many blocks get hit.", 4, 2, 6));
    private final Setting<Integer> charge = this.add(new IntSetting("Charge", "Hits once your attack is charged this many percent. 100 gives full damage.", 100, 10, 100));
    private final Setting<Boolean> players;
    private final Setting<Boolean> friends;
    private final Setting<Boolean> mobs;
    private final Setting<Boolean> animals;
    private final Setting<Boolean> walls;
    private final Setting<Boolean> rotate;
    private final Setting<Boolean> weaponOnly;
    private class_1309 target;

    public KillAura() {
        super("Kill Aura", "Hits the closest player or mob around you on its own.", Category.MOVEMENT);
        this.group("Targets");
        this.players = this.add(new BoolSetting("Players", "Hits players.", true));
        this.friends = this.add(new BoolSetting("Ignore Friends", "Never hits players on your friend list.", true)).visible(this.players::get);
        this.mobs = this.add(new BoolSetting("Mobs", "Hits hostile mobs.", true));
        this.animals = this.add(new BoolSetting("Animals", "Hits animals and other peaceful mobs.", false));
        this.walls = this.add(new BoolSetting("Through Walls", "Also hits what you cannot see.", false));
        this.group("Behaviour");
        this.rotate = this.add(new BoolSetting("Rotate", "Turns your view to the target before every hit.", true));
        this.weaponOnly = this.add(new BoolSetting("Weapons Only", "Only hits while you hold a sword, axe, mace or trident.", false));
    }

    @Override
    public void onDisable() {
        this.target = null;
    }

    @Override
    public void onTick() {
        this.target = null;
        class_746 player = KillAura.mc.field_1724;
        if (player == null || KillAura.mc.field_1687 == null || KillAura.mc.field_1761 == null || KillAura.mc.field_1755 != null || player.method_7325() || player.method_6115()) {
            return;
        }
        if (this.weaponOnly.get().booleanValue() && !CombatItems.isWeapon(player.method_6047())) {
            return;
        }
        this.target = this.find(player);
        if (this.target == null || player.method_7261(0.5f) * 100.0f < (float)this.charge.get().intValue()) {
            return;
        }
        if (this.rotate.get().booleanValue()) {
            KillAura.face(player, this.target);
        }
        KillAura.mc.field_1761.method_2918((class_1657)player, (class_1297)this.target);
        player.method_6104(class_1268.field_5808);
    }

    private class_1309 find(class_746 player) {
        class_243 eye = player.method_33571();
        double max = (double)this.range.get().intValue() * (double)this.range.get().intValue();
        class_1309 best = null;
        double bestDistance = Double.MAX_VALUE;
        for (class_1297 entity : KillAura.mc.field_1687.method_18112()) {
            double distance;
            class_1309 living;
            if (!(entity instanceof class_1309) || !this.wanted(living = (class_1309)entity) || (distance = eye.method_1025(KillAura.closest(living.method_5829(), eye))) > max || distance >= bestDistance || !this.walls.get().booleanValue() && !player.method_6057((class_1297)living)) continue;
            best = living;
            bestDistance = distance;
        }
        return best;
    }

    private boolean wanted(class_1309 entity) {
        if (entity == KillAura.mc.field_1724 || !entity.method_5805() || entity.method_7325() || entity instanceof class_1531) {
            return false;
        }
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            return this.players.get() != false && (this.friends.get() == false || !FriendStore.getInstance().isFriend(player.method_7334().name()));
        }
        return entity instanceof class_1569 ? this.mobs.get() : this.animals.get();
    }

    private static class_243 closest(class_238 box, class_243 eye) {
        return new class_243(class_3532.method_15350((double)eye.field_1352, (double)box.field_1323, (double)box.field_1320), class_3532.method_15350((double)eye.field_1351, (double)box.field_1322, (double)box.field_1325), class_3532.method_15350((double)eye.field_1350, (double)box.field_1321, (double)box.field_1324));
    }

    private static void face(class_746 player, class_1309 target) {
        class_243 eye = player.method_33571();
        class_243 aim = target.method_5829().method_1005();
        double dx = aim.field_1352 - eye.field_1352;
        double dy = aim.field_1351 - eye.field_1351;
        double dz = aim.field_1350 - eye.field_1350;
        float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
        player.method_36456(player.method_36454() + class_3532.method_15393((float)(yaw - player.method_36454())));
        player.method_36457(class_3532.method_15363((float)pitch, (float)-90.0f, (float)90.0f));
        player.field_3944.method_52787((class_2596)new class_2828.class_2831(player.method_36454(), player.method_36455(), player.method_24828(), player.field_5976));
    }

    @Override
    public String getInfoString() {
        return this.target == null ? null : this.target.method_5477().getString();
    }
}

