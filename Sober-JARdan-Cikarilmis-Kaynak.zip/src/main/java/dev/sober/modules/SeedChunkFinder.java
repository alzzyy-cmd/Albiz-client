/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1923
 *  net.minecraft.class_1937
 *  net.minecraft.class_2246
 *  net.minecraft.class_2338
 *  net.minecraft.class_2338$class_2339
 *  net.minecraft.class_2818
 *  net.minecraft.class_6574
 *  net.minecraft.class_6677
 */
package dev.sober.modules;

import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.render.Color;
import dev.sober.render.Render3D;
import dev.sober.render.ShapeMode;
import dev.sober.setting.BoolSetting;
import dev.sober.setting.ColorSetting;
import dev.sober.setting.EnumSetting;
import dev.sober.setting.IntSetting;
import dev.sober.setting.Setting;
import dev.sober.setting.StringSetting;
import dev.sober.util.ChunkScanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_6574;
import net.minecraft.class_6677;

public class SeedChunkFinder
extends Module {
    private final Setting<String> seed = this.add(new StringSetting("Server Seed", "The numeric world seed of the server. Re-enable after changing it.", ""));
    private final Setting<Boolean> notify = this.add(new BoolSetting("Notify", "Shows a notification with the coordinates of new suspicious chunks.", true));
    private final Setting<ShapeMode> shapeMode;
    private final Setting<Color> color;
    private final Setting<Integer> renderY;
    private final Set<class_1923> suspiciousChunks;
    private final ChunkScanner scanner;
    private volatile class_6574 deepslateRandom;

    public SeedChunkFinder() {
        super("Seed Chunk Finder", "Finds player placed deepslate using the server seed.", Category.BASE_FINDING);
        this.group("Render");
        this.shapeMode = this.add(new EnumSetting<ShapeMode>("Shape Mode", "How chunks are drawn.", ShapeMode.Both));
        this.color = this.add(new ColorSetting("Color", "Color of suspicious chunks.", new Color(0, 255, 0, 150)));
        this.renderY = this.add(new IntSetting("Render Y", "Y level the chunk markers are drawn at.", 63, -64, 320));
        this.suspiciousChunks = ConcurrentHashMap.newKeySet();
        this.scanner = new ChunkScanner("SeedChunkFinder", this::analyzeChunk);
    }

    @Override
    public void onEnable() {
        long worldSeed;
        try {
            worldSeed = Long.parseLong(this.seed.get().trim());
        }
        catch (NumberFormatException e) {
            this.error("Set a valid numeric server seed first.", new Object[0]);
            this.setEnabled(false);
            return;
        }
        this.deepslateRandom = new class_6677(worldSeed).method_38421().method_38995("minecraft:deepslate").method_38421();
        this.suspiciousChunks.clear();
        this.scanner.start();
        if (SeedChunkFinder.mc.field_1687 != null) {
            this.scanner.submitLoaded();
        }
    }

    @Override
    public void onDisable() {
        this.scanner.stop();
        this.suspiciousChunks.clear();
    }

    @Override
    public void onGameLeft() {
        this.suspiciousChunks.clear();
    }

    @Override
    public void onChunkLoad(class_2818 chunk) {
        this.scanner.submit(chunk);
    }

    private boolean shouldBeDeepslate(int x, int y, int z) {
        if (y <= 0) {
            return true;
        }
        if (y >= 8) {
            return false;
        }
        double chance = 1.0 - (double)y / 8.0;
        return (double)this.deepslateRandom.method_38418(x, y, z).method_43057() < chance;
    }

    private void analyzeChunk(class_2818 chunk) {
        if (SeedChunkFinder.mc.field_1687 == null || SeedChunkFinder.mc.field_1687.method_27983() != class_1937.field_25179) {
            return;
        }
        class_1923 chunkPos = chunk.method_12004();
        class_2338.class_2339 pos = new class_2338.class_2339();
        for (int x = chunkPos.method_8326(); x < chunkPos.method_8326() + 16; ++x) {
            for (int z = chunkPos.method_8328(); z < chunkPos.method_8328() + 16; ++z) {
                for (int y = 1; y < 8; ++y) {
                    pos.method_10103(x, y, z);
                    if (!chunk.method_8320((class_2338)pos).method_27852(class_2246.field_28888) || this.shouldBeDeepslate(x, y, z)) continue;
                    if (this.suspiciousChunks.add(chunkPos) && this.notify.get().booleanValue()) {
                        this.info("Suspicious chunk at X: %d Z: %d", chunkPos.method_8326(), chunkPos.method_8328());
                    }
                    return;
                }
            }
        }
    }

    @Override
    public void onRender(Render3D renderer) {
        if (SeedChunkFinder.mc.field_1687 == null) {
            return;
        }
        this.suspiciousChunks.removeIf(p -> !SeedChunkFinder.mc.field_1687.method_2935().method_12123(p.field_9181, p.field_9180));
        double y = this.renderY.get().intValue();
        for (class_1923 pos : this.suspiciousChunks) {
            renderer.box(pos.method_8326(), y, pos.method_8328(), pos.method_8326() + 16, y + 0.1, pos.method_8328() + 16, this.color.get(), this.color.get(), this.shapeMode.get());
        }
    }
}

