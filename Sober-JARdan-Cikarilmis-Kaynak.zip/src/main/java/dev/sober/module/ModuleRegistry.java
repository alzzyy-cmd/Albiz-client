/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.module;

import dev.sober.SoberClient;
import dev.sober.module.BusModule;
import dev.sober.module.Module;
import java.util.ArrayList;
import java.util.List;

public final class ModuleRegistry {
    private ModuleRegistry() {
    }

    public static <T extends Module> T get(Class<T> type) {
        return SoberClient.MODULES.get(type);
    }

    public static List<BusModule> all() {
        ArrayList<BusModule> out = new ArrayList<BusModule>();
        for (Module module : SoberClient.MODULES.all()) {
            if (!(module instanceof BusModule)) continue;
            BusModule bus = (BusModule)module;
            out.add(bus);
        }
        return out;
    }
}

