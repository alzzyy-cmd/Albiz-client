/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.module;

import java.util.List;

public interface Status {
    public String statusTitle();

    public List<Row> statusRows();

    public String statusDescription();

    public record Row(String title, String detail, String badge, int badgeColor, String link) {
    }
}

