/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.module;

import dev.sober.gui.OverlayCanvas;

public interface HudOverlayProvider {
    public boolean isHudOverlayEnabled();

    public void renderHudOverlay(OverlayCanvas var1, float var2, float var3);
}

