/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.module;

import dev.sober.module.BusModule;

public final class CombatMacroLock {
    private static Object holder;

    private CombatMacroLock() {
    }

    public static boolean tryAcquire(Object owner) {
        BusModule module;
        Object object = holder;
        if (object instanceof BusModule && !(module = (BusModule)object).isEnabled()) {
            holder = null;
        }
        if (holder != null && holder != owner) {
            return false;
        }
        holder = owner;
        return true;
    }

    public static void release(Object owner) {
        if (holder == owner) {
            holder = null;
        }
    }

    public static boolean heldByOther(Object owner) {
        BusModule module;
        Object object = holder;
        if (object instanceof BusModule && !(module = (BusModule)object).isEnabled()) {
            holder = null;
        }
        return holder != null && holder != owner;
    }
}

