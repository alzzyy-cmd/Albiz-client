/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1041
 *  net.minecraft.class_2338
 *  net.minecraft.class_2604
 *  net.minecraft.class_2680
 *  net.minecraft.class_2818
 *  net.minecraft.class_310
 *  net.minecraft.class_3675
 */
package dev.sober.module;

import dev.sober.SoberClient;
import dev.sober.gui.UiSounds;
import dev.sober.module.Category;
import dev.sober.module.Module;
import dev.sober.modules.ClickGui;
import dev.sober.render.Render3D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1041;
import net.minecraft.class_2338;
import net.minecraft.class_2604;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public final class ModuleManager {
    private final List<Module> modules = new ArrayList<Module>();
    private final Set<Integer> heldKeys = new HashSet<Integer>();

    public void add(Module module) {
        this.modules.add(module);
    }

    public List<Module> all() {
        return Collections.unmodifiableList(this.modules);
    }

    public List<Module> inCategory(Category category) {
        ArrayList<Module> list = new ArrayList<Module>();
        for (Module module : this.modules) {
            if (module.category != category) continue;
            list.add(module);
        }
        return list;
    }

    public <T extends Module> T get(Class<T> type) {
        for (Module module : this.modules) {
            if (module.getClass() != type) continue;
            return (T)module;
        }
        return null;
    }

    public Module byName(String name) {
        for (Module module : this.modules) {
            if (!module.name.equals(name)) continue;
            return module;
        }
        return null;
    }

    public boolean isBound(int key) {
        if (key < 0) {
            return false;
        }
        for (Module module : this.modules) {
            if (module.getKey() != key) continue;
            return true;
        }
        return false;
    }

    public void pollKeybinds(class_310 mc) {
        if (mc.method_22683() == null) {
            return;
        }
        HashSet<Integer> checked = new HashSet<Integer>();
        HashSet<Integer> fresh = new HashSet<Integer>();
        for (Module module : this.modules) {
            int key = module.getKey();
            if (key < 0 || !checked.add(key)) continue;
            boolean pressed = class_3675.method_15987((class_1041)mc.method_22683(), (int)key);
            if (pressed && this.heldKeys.add(key)) {
                fresh.add(key);
                continue;
            }
            if (pressed) continue;
            this.heldKeys.remove(key);
        }
        if (fresh.isEmpty() || mc.field_1755 != null) {
            return;
        }
        boolean changed = false;
        for (Module module : this.modules) {
            if (!fresh.contains(module.getKey())) continue;
            module.toggle();
            if (!(module instanceof ClickGui)) {
                UiSounds.moduleToggle(module.isActive());
            }
            changed = true;
        }
        if (changed) {
            SoberClient.CONFIG.save();
        }
    }

    public void onTick() {
        for (Module module : this.modules) {
            if (!module.isActive()) continue;
            ModuleManager.safely(module, module::onTick);
        }
    }

    public void onRender(Render3D renderer) {
        for (Module module : this.modules) {
            if (!module.isActive()) continue;
            renderer.setAlpha(module.fadeIn());
            ModuleManager.safely(module, () -> module.onRender(renderer));
        }
        renderer.setAlpha(1.0f);
    }

    public void onChunkLoad(class_2818 chunk) {
        for (Module module : this.modules) {
            if (!module.isActive()) continue;
            ModuleManager.safely(module, () -> module.onChunkLoad(chunk));
        }
    }

    public void onBlockUpdate(class_2338 pos, class_2680 oldState, class_2680 newState) {
        for (Module module : this.modules) {
            if (!module.isActive()) continue;
            ModuleManager.safely(module, () -> module.onBlockUpdate(pos, oldState, newState));
        }
    }

    public void onGameLeft() {
        for (Module module : this.modules) {
            if (!module.isActive()) continue;
            ModuleManager.safely(module, module::onGameLeft);
        }
    }

    public boolean onEntitySpawn(class_2604 packet) {
        for (Module module : this.modules) {
            if (!module.isActive()) continue;
            try {
                if (!module.onEntitySpawn(packet)) continue;
                return true;
            }
            catch (Exception e) {
                SoberClient.LOG.error("Module {} threw an exception", (Object)module.name, (Object)e);
            }
        }
        return false;
    }

    private static void safely(Module module, Runnable action) {
        try {
            action.run();
        }
        catch (Exception e) {
            SoberClient.LOG.error("Module {} threw an exception", (Object)module.name, (Object)e);
        }
    }
}

