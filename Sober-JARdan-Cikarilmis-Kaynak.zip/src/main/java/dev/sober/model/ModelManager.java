/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.loader.api.FabricLoader
 */
package dev.sober.model;

import dev.sober.SoberClient;
import dev.sober.model.ModelLibrary;
import dev.sober.model.ModelLoader;
import dev.sober.model.ModelMesh;
import dev.sober.model.SpriteModel;
import dev.sober.model.WaterModels;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.lang.invoke.CallSite;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;

public final class ModelManager {
    private static final Map<String, ModelMesh> CACHE = new HashMap<String, ModelMesh>();
    private static final Map<String, String> FAILED = new HashMap<String, String>();
    private static final Map<String, SpriteModel> SPRITES = new HashMap<String, SpriteModel>();
    private static final Map<String, CompletableFuture<SpriteModel.Prepared>> PENDING = new HashMap<String, CompletableFuture<SpriteModel.Prepared>>();
    private static final ExecutorService LOADER = Executors.newSingleThreadExecutor(runnable -> {
        Thread thread = new Thread(runnable, "Sober Sprite Loader");
        thread.setDaemon(true);
        thread.setPriority(1);
        return thread;
    });
    public static final String WATERY = "Watery/";
    private static final Map<String, String> BUILTIN_PACKS = Map.of("Fortnite Pack/", "/assets/sober/models/fortnite_pack/");
    private static final Map<String, Set<String>> BUILTIN_ITEMS = ModelManager.builtinItems();
    private static volatile List<String> files = ModelManager.initial();
    private static volatile Map<String, Set<String>> packs = Map.of();
    private static volatile long lastScan;
    private static volatile boolean scanning;
    private static Path folder;

    private ModelManager() {
    }

    private static List<String> initial() {
        ArrayList<String> list = new ArrayList<String>(ModelLibrary.names());
        list.addAll(BUILTIN_PACKS.keySet());
        list.add(WATERY);
        return List.copyOf(list);
    }

    private static Map<String, Set<String>> builtinItems() {
        HashMap result = new HashMap();
        for (Map.Entry<String, String> pack : BUILTIN_PACKS.entrySet()) {
            HashSet<String> items = new HashSet<String>();
            try (InputStream in = ModelManager.class.getResourceAsStream(pack.getValue() + "items.txt");){
                if (in != null) {
                    for (String line : new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\\R")) {
                        if (line.isBlank()) continue;
                        items.add(line.trim().toLowerCase(Locale.ROOT));
                    }
                }
            }
            catch (IOException iOException) {
                // empty catch block
            }
            result.put(pack.getKey(), Set.copyOf(items));
        }
        return Map.copyOf(result);
    }

    public static Path folder() {
        if (folder != null) {
            return folder;
        }
        Path path = FabricLoader.getInstance().getConfigDir().resolve("sober").resolve("models");
        try {
            Files.createDirectories(path, new FileAttribute[0]);
        }
        catch (IOException iOException) {
            // empty catch block
        }
        folder = path;
        return path;
    }

    public static List<String> files() {
        long now = System.currentTimeMillis();
        if (now - lastScan > 5000L && !scanning) {
            lastScan = now;
            scanning = true;
            CompletableFuture.runAsync(() -> {
                try {
                    ModelManager.rescan();
                }
                finally {
                    scanning = false;
                }
            });
        }
        return files;
    }

    public static void rescan() {
        lastScan = System.currentTimeMillis();
        ArrayList<String> found = new ArrayList<String>(ModelManager.initial());
        ArrayList<Object> local = new ArrayList<Object>();
        HashMap<CallSite, Set<String>> foundPacks = new HashMap<CallSite, Set<String>>();
        try (Stream<Path> stream = Files.list(ModelManager.folder());){
            for (Path path : stream::iterator) {
                String name = path.getFileName().toString();
                if (Files.isDirectory(path, new LinkOption[0])) {
                    Set<String> items;
                    if (BUILTIN_PACKS.containsKey(name + "/") || WATERY.equals(name + "/") || (items = ModelManager.packItems(path)).isEmpty()) continue;
                    foundPacks.put((CallSite)((Object)(name + "/")), items);
                    local.add(name + "/");
                    continue;
                }
                if (!Files.isRegularFile(path, new LinkOption[0]) || !ModelManager.supported(name)) continue;
                local.add(name);
            }
        }
        catch (IOException iOException) {
            // empty catch block
        }
        local.sort(String.CASE_INSENSITIVE_ORDER);
        found.addAll(local);
        packs = Map.copyOf(foundPacks);
        files = List.copyOf(found);
    }

    private static Set<String> packItems(Path directory) {
        HashSet<String> items = new HashSet<String>();
        try (Stream<Path> stream = Files.list(directory);){
            stream.filter(x$0 -> Files.isRegularFile(x$0, new LinkOption[0])).map(p -> p.getFileName().toString()).filter(n -> n.toLowerCase(Locale.ROOT).endsWith(".png")).forEach(n -> items.add(n.substring(0, n.length() - 4).toLowerCase(Locale.ROOT)));
        }
        catch (IOException iOException) {
            // empty catch block
        }
        return items;
    }

    public static void reload() {
        CACHE.clear();
        FAILED.clear();
        for (SpriteModel sprite : SPRITES.values()) {
            if (sprite == null) continue;
            sprite.release();
        }
        SPRITES.clear();
        PENDING.clear();
        ModelManager.rescan();
    }

    private static boolean supported(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".stl") || lower.endsWith(".obj") || lower.endsWith(".png");
    }

    public static boolean isPack(String name) {
        return name != null && name.endsWith("/");
    }

    public static boolean isSprite(String name) {
        return name != null && name.toLowerCase(Locale.ROOT).endsWith(".png");
    }

    public static boolean isWatery(String name) {
        return WATERY.equals(name);
    }

    public static boolean packHas(String pack, String item) {
        if (WATERY.equals(pack)) {
            return WaterModels.kind(item) != null;
        }
        Set<String> builtin = BUILTIN_ITEMS.get(pack);
        if (builtin != null) {
            return builtin.contains(item);
        }
        Set<String> items = packs.get(pack);
        return items != null && items.contains(item);
    }

    public static SpriteModel sprite(String name) {
        return ModelManager.loadSprite(name, ModelManager.folder().resolve(name), null);
    }

    public static SpriteModel packSprite(String pack, String item) {
        if (WATERY.equals(pack) || !ModelManager.packHas(pack, item)) {
            return null;
        }
        String resource = BUILTIN_PACKS.get(pack);
        if (resource != null) {
            return ModelManager.loadSprite(pack + item, null, resource + item + ".png");
        }
        return ModelManager.loadSprite(pack + item, ModelManager.folder().resolve(pack.substring(0, pack.length() - 1)).resolve(item + ".png"), null);
    }

    private static SpriteModel loadSprite(String key, Path file, String resource) {
        if (FAILED.containsKey(key)) {
            return null;
        }
        SpriteModel sprite = SPRITES.get(key);
        if (sprite != null) {
            return sprite;
        }
        CompletableFuture<SpriteModel.Prepared> pending = PENDING.get(key);
        if (pending == null) {
            PENDING.put(key, CompletableFuture.supplyAsync(() -> ModelManager.prepare(file, resource), LOADER));
            return null;
        }
        if (!pending.isDone()) {
            return null;
        }
        PENDING.remove(key);
        try {
            sprite = SpriteModel.upload(pending.join());
            SPRITES.put(key, sprite);
            return sprite;
        }
        catch (RuntimeException e) {
            RuntimeException cause = e instanceof CompletionException && e.getCause() != null ? e.getCause() : e;
            FAILED.put(key, String.valueOf(cause.getMessage()));
            SoberClient.LOG.error("Could not load sprite {}", (Object)key, (Object)cause);
            return null;
        }
    }

    private static SpriteModel.Prepared prepare(Path file, String resource) {
        SpriteModel.Prepared prepared;
        block10: {
            if (resource == null) {
                return SpriteModel.prepare(file);
            }
            InputStream in = ModelManager.class.getResourceAsStream(resource);
            try {
                if (in == null) {
                    throw new IOException("missing " + resource);
                }
                prepared = SpriteModel.prepare(in);
                if (in == null) break block10;
            }
            catch (Throwable throwable) {
                try {
                    if (in != null) {
                        try {
                            in.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (IOException e) {
                    throw new UncheckedIOException(e);
                }
            }
            in.close();
        }
        return prepared;
    }

    public static ModelMesh get(String name) {
        if (name == null || name.isEmpty() || ModelManager.isPack(name) || ModelManager.isSprite(name) || FAILED.containsKey(name)) {
            return null;
        }
        ModelMesh mesh = CACHE.get(name);
        if (mesh != null) {
            return mesh;
        }
        if (ModelLibrary.has(name)) {
            try {
                mesh = ModelLibrary.build(name);
                CACHE.put(name, mesh);
                return mesh;
            }
            catch (RuntimeException e) {
                FAILED.put(name, String.valueOf(e.getMessage()));
                SoberClient.LOG.error("Could not build model {}", (Object)name, (Object)e);
                return null;
            }
        }
        Path file = ModelManager.folder().resolve(name);
        if (!Files.isRegularFile(file, new LinkOption[0])) {
            FAILED.put(name, "file not found");
            return null;
        }
        try {
            mesh = ModelLoader.load(file);
            CACHE.put(name, mesh);
            return mesh;
        }
        catch (IOException | RuntimeException e) {
            FAILED.put(name, String.valueOf(e.getMessage()));
            SoberClient.LOG.error("Could not load model {}", (Object)name, (Object)e);
            return null;
        }
    }

    public static String error(String name) {
        return FAILED.get(name);
    }

    public static String title(String file) {
        if (ModelLibrary.has(file)) {
            return ModelLibrary.title(file);
        }
        if (ModelManager.isPack(file)) {
            return file.substring(0, file.length() - 1);
        }
        int dot = file.lastIndexOf(46);
        String base = dot > 0 ? file.substring(0, dot) : file;
        return base.replace('_', ' ').replace('-', ' ');
    }
}

