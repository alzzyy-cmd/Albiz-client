/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1131
 *  net.minecraft.class_4267$class_4269
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package dev.sober.mixin;

import net.minecraft.class_1131;
import net.minecraft.class_4267;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_4267.class_4269.class})
public interface LanServerEntryAccessor {
    @Accessor(value="field_19114")
    public class_1131 sober$server();
}

