/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3556
 *  net.minecraft.class_3560
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package dev.sober.mixin;

import net.minecraft.class_3556;
import net.minecraft.class_3560;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_3560.class})
public interface LightStorageAccessor {
    @Accessor(value="field_15796")
    public class_3556<?> sober$getStorage();
}

