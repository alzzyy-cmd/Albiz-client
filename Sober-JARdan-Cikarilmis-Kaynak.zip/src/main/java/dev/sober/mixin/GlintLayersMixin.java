/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_12249
 *  net.minecraft.class_1921
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import dev.sober.sky.GlintCover;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_12249.class})
public abstract class GlintLayersMixin {
    @Inject(method={"method_75995"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private static void sober$glint(CallbackInfoReturnable<class_1921> cir) {
        class_1921 layer = GlintCover.glint();
        if (layer != null) {
            cir.setReturnValue((Object)layer);
        }
    }

    @Inject(method={"method_75993"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private static void sober$glintTranslucent(CallbackInfoReturnable<class_1921> cir) {
        class_1921 layer = GlintCover.translucent();
        if (layer != null) {
            cir.setReturnValue((Object)layer);
        }
    }

    @Inject(method={"method_75997"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private static void sober$entityGlint(CallbackInfoReturnable<class_1921> cir) {
        class_1921 layer = GlintCover.entity();
        if (layer != null) {
            cir.setReturnValue((Object)layer);
        }
    }

    @Inject(method={"method_75989"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private static void sober$armorEntityGlint(CallbackInfoReturnable<class_1921> cir) {
        class_1921 layer = GlintCover.armor();
        if (layer != null) {
            cir.setReturnValue((Object)layer);
        }
    }
}

