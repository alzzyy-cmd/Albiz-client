/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1011
 *  net.minecraft.class_1043
 *  net.minecraft.class_4608
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_4608;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_4608.class})
public abstract class OverlayTextureMixin {
    @Shadow
    @Final
    private class_1043 field_21013;

    @Inject(method={"<init>"}, at={@At(value="TAIL")}, require=0)
    private void sober$violetHurt(CallbackInfo ci) {
        class_1011 image = this.field_21013.method_4525();
        if (image == null) {
            return;
        }
        for (int y = 0; y < 8; ++y) {
            for (int x = 0; x < 16; ++x) {
                image.method_61941(x, y, -1766564609);
            }
        }
        this.field_21013.method_4524();
    }
}

