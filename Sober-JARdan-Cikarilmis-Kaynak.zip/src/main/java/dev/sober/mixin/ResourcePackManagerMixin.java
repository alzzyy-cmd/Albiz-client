/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_3262
 *  net.minecraft.class_3283
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import dev.sober.gui.SystemFontPack;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_3262;
import net.minecraft.class_3283;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_3283.class})
public abstract class ResourcePackManagerMixin {
    @Inject(method={"method_29211"}, at={@At(value="RETURN")}, cancellable=true, require=0)
    private void sober$systemFonts(CallbackInfoReturnable<List<class_3262>> cir) {
        try {
            SystemFontPack pack = new SystemFontPack();
            if (pack.isEmpty()) {
                return;
            }
            ArrayList<SystemFontPack> packs = new ArrayList<SystemFontPack>(((List)cir.getReturnValue()).size() + 1);
            packs.add(pack);
            packs.addAll((Collection)cir.getReturnValue());
            cir.setReturnValue(packs);
        }
        catch (RuntimeException runtimeException) {
            // empty catch block
        }
    }
}

