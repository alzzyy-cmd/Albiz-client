/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11908
 *  net.minecraft.class_309
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.modules.CreamyKeys;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_309.class})
public abstract class KeyboardMixin {
    @Inject(method={"method_1466"}, at={@At(value="HEAD")}, require=0)
    private void sober$creamyKeys(long window, int action, class_11908 input, CallbackInfo ci) {
        if (window != class_310.method_1551().method_22683().method_4490()) {
            return;
        }
        try {
            CreamyKeys keys = SoberClient.MODULES.get(CreamyKeys.class);
            if (keys != null && keys.isActive()) {
                keys.onKey(input.comp_4795(), action);
            }
        }
        catch (RuntimeException e) {
            SoberClient.LOG.error("Creamy Keys failed", (Throwable)e);
        }
    }
}

