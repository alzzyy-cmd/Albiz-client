/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11684
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.sky.ItemAuraRenderer;
import net.minecraft.class_11684;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_11684.class})
public abstract class RenderDispatcherMixin {
    @Inject(method={"method_73002"}, at={@At(value="TAIL")})
    private void sober$afterFeatures(CallbackInfo ci) {
        try {
            ItemAuraRenderer.afterFeatures();
        }
        catch (RuntimeException runtimeException) {
            // empty catch block
        }
    }
}

