/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  io.netty.channel.ChannelFutureListener
 *  io.netty.channel.ChannelHandlerContext
 *  net.minecraft.class_2535
 *  net.minecraft.class_2596
 *  net.minecraft.class_2598
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin.feature;

import dev.sober.event.impl.PacketReceiveEvent;
import dev.sober.event.impl.PacketReceiveNettyEvent;
import dev.sober.event.impl.PacketSendEvent;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import java.util.function.BooleanSupplier;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_2535.class})
public abstract class PacketEventsMixin {
    @Unique
    private final BooleanSupplier sober$connectionActive = this::method_10758;

    @Shadow
    public abstract boolean method_10758();

    @Shadow
    public abstract class_2598 method_36121();

    @Inject(method={"method_10770(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/class_2596;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$onPacketReceive(ChannelHandlerContext ctx, class_2596<?> packet, CallbackInfo ci) {
        if (this.method_36121() == class_2598.field_11942) {
            if (PacketReceiveNettyEvent.dispatchSync(packet)) {
                ci.cancel();
            } else {
                PacketReceiveEvent.dispatchAsync(packet, this.sober$connectionActive);
            }
        }
    }

    @Inject(method={"method_52906(Lnet/minecraft/class_2596;Lio/netty/channel/ChannelFutureListener;Z)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$onPacketSend(class_2596<?> packet, ChannelFutureListener listener, boolean flush, CallbackInfo ci) {
        if (this.method_36121() == class_2598.field_11942 && PacketSendEvent.dispatchSync(packet)) {
            ci.cancel();
        }
    }
}

