/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  net.minecraft.class_1308
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.sober.modules.EntityControl;
import net.minecraft.class_1308;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_1308.class})
public abstract class EntityControlMobMixin {
    @ModifyReturnValue(method={"method_66672"}, at={@At(value="RETURN")})
    private boolean sober$entityControlSpoofSaddle(boolean original) {
        return original || EntityControl.spoofSaddle();
    }
}

