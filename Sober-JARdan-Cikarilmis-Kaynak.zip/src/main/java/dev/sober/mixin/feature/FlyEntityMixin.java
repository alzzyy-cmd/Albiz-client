/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  net.minecraft.class_1297
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.sober.modules.Fly;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_1297.class})
public abstract class FlyEntityMixin {
    @ModifyReturnValue(method={"method_5799"}, at={@At(value="RETURN")})
    private boolean sober$flyIsInWater(boolean original) {
        return original && !this.sober$flyAffects();
    }

    @ModifyReturnValue(method={"method_5771"}, at={@At(value="RETURN")})
    private boolean sober$flyIsInLava(boolean original) {
        return original && !this.sober$flyAffects();
    }

    @ModifyExpressionValue(method={"method_5790"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_1297;method_5869()Z")})
    private boolean sober$flyIsUnderWater(boolean original) {
        return original && !this.sober$flyAffects();
    }

    @Unique
    private boolean sober$flyAffects() {
        return Fly.active != null && this == class_310.method_1551().field_1724;
    }
}

