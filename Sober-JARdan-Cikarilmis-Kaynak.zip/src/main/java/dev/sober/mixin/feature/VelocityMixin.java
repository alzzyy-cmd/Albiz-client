/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_2664
 *  net.minecraft.class_2743
 *  net.minecraft.class_310
 *  net.minecraft.class_634
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin.feature;

import dev.sober.modules.Velocity;
import net.minecraft.class_243;
import net.minecraft.class_2664;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_634.class})
public abstract class VelocityMixin {
    @Unique
    private class_243 sober$velocityBefore;

    @Inject(method={"method_11132"}, at={@At(value="TAIL")})
    private void sober$scaleKnockback(class_2743 packet, CallbackInfo ci) {
        Velocity.onKnockback(packet.method_11818(), packet.method_73085());
    }

    @Inject(method={"method_11124"}, at={@At(value="HEAD")})
    private void sober$beforeExplosion(class_2664 packet, CallbackInfo ci) {
        class_746 player = class_310.method_1551().field_1724;
        this.sober$velocityBefore = player == null ? null : player.method_18798();
    }

    @Inject(method={"method_11124"}, at={@At(value="TAIL")})
    private void sober$afterExplosion(class_2664 packet, CallbackInfo ci) {
        class_746 player = class_310.method_1551().field_1724;
        if (player == null || this.sober$velocityBefore == null || packet.comp_2884().isEmpty()) {
            return;
        }
        player.method_18799(Velocity.onExplosion(this.sober$velocityBefore, player.method_18798()));
        this.sober$velocityBefore = null;
    }
}

