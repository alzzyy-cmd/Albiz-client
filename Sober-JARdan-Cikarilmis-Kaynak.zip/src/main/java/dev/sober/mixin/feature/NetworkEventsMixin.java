/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2626
 *  net.minecraft.class_2637
 *  net.minecraft.class_2672
 *  net.minecraft.class_2676
 *  net.minecraft.class_2678
 *  net.minecraft.class_2743
 *  net.minecraft.class_634
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin.feature;

import dev.sober.event.impl.ChatSendEvent;
import dev.sober.event.impl.PacketAppliedEvent;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2672;
import net.minecraft.class_2676;
import net.minecraft.class_2678;
import net.minecraft.class_2743;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_634.class})
public abstract class NetworkEventsMixin {
    @Inject(method={"method_45729"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$onSendChat(String message, CallbackInfo ci) {
        if (ChatSendEvent.dispatch(message)) {
            ci.cancel();
        }
    }

    @Inject(method={"method_11120"}, at={@At(value="TAIL")})
    private void sober$afterLogin(class_2678 packet, CallbackInfo ci) {
        PacketAppliedEvent.dispatch(packet);
    }

    @Inject(method={"method_11128"}, at={@At(value="TAIL")})
    private void sober$afterChunkData(class_2672 packet, CallbackInfo ci) {
        PacketAppliedEvent.dispatch(packet);
    }

    @Inject(method={"method_11136"}, at={@At(value="TAIL")})
    private void sober$afterBlockUpdate(class_2626 packet, CallbackInfo ci) {
        PacketAppliedEvent.dispatch(packet);
    }

    @Inject(method={"method_11100"}, at={@At(value="TAIL")})
    private void sober$afterSectionUpdate(class_2637 packet, CallbackInfo ci) {
        PacketAppliedEvent.dispatch(packet);
    }

    @Inject(method={"method_11143"}, at={@At(value="TAIL")})
    private void sober$afterLightUpdate(class_2676 packet, CallbackInfo ci) {
        PacketAppliedEvent.dispatch(packet);
    }

    @Inject(method={"method_11132"}, at={@At(value="TAIL")})
    private void sober$afterEntityMotion(class_2743 packet, CallbackInfo ci) {
        PacketAppliedEvent.dispatch(packet);
    }
}

