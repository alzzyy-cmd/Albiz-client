/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10185
 *  net.minecraft.class_743
 *  net.minecraft.class_744
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin.feature;

import dev.sober.modules.Sneak;
import net.minecraft.class_10185;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_743.class})
public abstract class SneakInputMixin {
    @Inject(method={"method_3129"}, at={@At(value="TAIL")})
    private void sober$forceSneak(CallbackInfo ci) {
        Sneak sneak = Sneak.active;
        if (sneak != null && sneak.doVanilla()) {
            class_744 input = (class_744)this;
            class_10185 keys = input.field_54155;
            if (!keys.comp_3164()) {
                input.field_54155 = new class_10185(keys.comp_3159(), keys.comp_3160(), keys.comp_3161(), keys.comp_3162(), keys.comp_3163(), true, keys.comp_3165());
            }
        }
    }
}

