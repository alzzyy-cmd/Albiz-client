/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  net.minecraft.class_10255
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import dev.sober.modules.entitycontrol.EntityControlVehicleHook;
import net.minecraft.class_10255;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_10255.class})
public abstract class EntityControlBoatMixin {
    @ModifyExpressionValue(method={"method_64482"}, at={@At(value="FIELD", target="Lnet/minecraft/class_10255;field_54444:Z", opcode=180)})
    private boolean sober$entityControlInputLeft(boolean original) {
        return original && !EntityControlVehicleHook.locksBoatTurning((class_10255)this);
    }

    @ModifyExpressionValue(method={"method_64482"}, at={@At(value="FIELD", target="Lnet/minecraft/class_10255;field_54428:Z", opcode=180)})
    private boolean sober$entityControlInputRight(boolean original) {
        return original && !EntityControlVehicleHook.locksBoatTurning((class_10255)this);
    }
}

