/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin.feature;

import dev.sober.modules.Jesus;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1297.class})
public abstract class JesusEntityMixin {
    @Inject(method={"method_5700"}, at={@At(value="HEAD")})
    private void sober$jesusAboveBubbleColumn(CallbackInfo ci) {
        this.sober$jesusMarkBubbleColumn();
    }

    @Inject(method={"method_5764"}, at={@At(value="HEAD")})
    private void sober$jesusInsideBubbleColumn(CallbackInfo ci) {
        this.sober$jesusMarkBubbleColumn();
    }

    @Unique
    private void sober$jesusMarkBubbleColumn() {
        Jesus jesus = Jesus.active;
        if (jesus != null && this == class_310.method_1551().field_1724) {
            jesus.markInBubbleColumn();
        }
    }
}

