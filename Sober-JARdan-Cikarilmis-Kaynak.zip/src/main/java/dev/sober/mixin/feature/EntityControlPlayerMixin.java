/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.sober.modules.EntityControl;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_746.class})
public abstract class EntityControlPlayerMixin {
    @ModifyReturnValue(method={"method_3151"}, at={@At(value="RETURN")})
    private float sober$maxMountJump(float original) {
        return EntityControl.maxJump() ? 1.0f : original;
    }
}

