/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10197
 *  net.minecraft.class_1799
 *  net.minecraft.class_9331
 *  net.minecraft.class_9334
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Redirect
 */
package dev.sober.mixin.feature;

import dev.sober.modules.ArmorTrimHider;
import net.minecraft.class_10197;
import net.minecraft.class_1799;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(value={class_10197.class})
public abstract class ArmorTrimHiderMixin {
    @Redirect(method={"method_64078(Lnet/minecraft/class_10186$class_10190;Lnet/minecraft/class_5321;Lnet/minecraft/class_3879;Ljava/lang/Object;Lnet/minecraft/class_1799;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;ILnet/minecraft/class_2960;II)V"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_1799;method_58694(Lnet/minecraft/class_9331;)Ljava/lang/Object;"))
    private Object sober$hideTrim(class_1799 stack, class_9331<?> type) {
        if (type == class_9334.field_49607 && ArmorTrimHider.hides()) {
            return null;
        }
        return stack.method_58694(type);
    }
}

