/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  net.minecraft.class_1297
 *  net.minecraft.class_310
 *  net.minecraft.class_5635
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.sober.modules.Jesus;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_5635;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_5635.class})
public abstract class JesusPowderSnowMixin {
    @ModifyReturnValue(method={"method_32355"}, at={@At(value="RETURN")})
    private static boolean sober$jesusWalkOnPowderSnow(boolean original, class_1297 entity) {
        if (original) {
            return true;
        }
        Jesus jesus = Jesus.active;
        return jesus != null && entity == class_310.method_1551().field_1724 && jesus.canWalkOnPowderSnow();
    }
}

