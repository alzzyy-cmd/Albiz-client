/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2824
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package dev.sober.mixin.feature;

import dev.sober.modules.Sneak;
import net.minecraft.class_2824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={class_2824.class})
public abstract class SneakInteractMixin {
    @ModifyVariable(method={"<init>(IZLnet/minecraft/class_2824$class_5906;)V"}, at=@At(value="HEAD"), ordinal=0, argsOnly=true)
    private static boolean sober$packetSneak(boolean usingSecondaryAction) {
        if (usingSecondaryAction) {
            return true;
        }
        Sneak sneak = Sneak.active;
        return sneak != null && sneak.doPacket();
    }
}

