/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1313
 *  net.minecraft.class_243
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package dev.sober.mixin.feature;

import dev.sober.modules.entitycontrol.EntityControlVehicleHook;
import net.minecraft.class_1297;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={class_1297.class})
public abstract class EntityControlEntityMixin {
    @ModifyVariable(method={"method_5784"}, at=@At(value="HEAD"), argsOnly=true)
    private class_243 sober$entityControlVehicleMove(class_243 movement, class_1313 type) {
        return !EntityControlVehicleHook.anyActive ? movement : EntityControlVehicleHook.onEntityMove((class_1297)this, type, movement);
    }
}

