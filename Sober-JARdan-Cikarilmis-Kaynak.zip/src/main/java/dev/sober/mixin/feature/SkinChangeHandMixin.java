/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.class_1007
 *  net.minecraft.class_11659
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_4587
 *  net.minecraft.class_742
 *  net.minecraft.class_746
 *  net.minecraft.class_759
 *  net.minecraft.class_8685
 *  net.minecraft.class_898
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.sober.mixin.EntityRenderManagerAccessor;
import dev.sober.module.ModuleRegistry;
import dev.sober.modules.SkinChange;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import net.minecraft.class_8685;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_759.class}, priority=500)
public abstract class SkinChangeHandMixin {
    @Shadow
    @Final
    private class_310 field_4050;
    @Shadow
    @Final
    private class_898 field_4046;

    @WrapOperation(method={"method_3219", "method_3216"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_1007;method_4220(Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;ILnet/minecraft/class_2960;Z)V"), @At(value="INVOKE", target="Lnet/minecraft/class_1007;method_4221(Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;ILnet/minecraft/class_2960;Z)V")})
    private void sober$skinChangeArm(class_1007<?> renderer, class_4587 poseStack, class_11659 collector, int light, class_2960 texture, boolean sleeve, Operation<Void> original) {
        SkinChange mod = ModuleRegistry.get(SkinChange.class);
        class_746 player = this.field_4050.field_1724;
        if (mod != null && mod.isEnabled() && player != null) {
            class_8685 own = player.method_52814();
            class_8685 skin = mod.skinFor(player.method_5628(), own);
            if (skin != own) {
                texture = skin.comp_1626().comp_3627();
                class_1007<class_742> byModel = ((EntityRenderManagerAccessor)this.field_4046).sober$skinChangePlayerRenderers().get(skin.comp_1629());
                if (byModel != null) {
                    renderer = byModel;
                }
            }
        }
        original.call(new Object[]{renderer, poseStack, collector, light, texture, sleeve});
    }
}

