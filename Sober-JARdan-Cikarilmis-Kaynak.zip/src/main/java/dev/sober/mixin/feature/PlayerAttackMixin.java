/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  net.minecraft.class_1297
 *  net.minecraft.class_1657
 *  net.minecraft.class_310
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.sober.event.impl.PlayerAttackEntityEvent;
import dev.sober.modules.Fly;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1657.class})
public abstract class PlayerAttackMixin {
    @Inject(method={"method_7324"}, at={@At(value="HEAD")})
    private void sober$onAttack(class_1297 target, CallbackInfo ci) {
        if (this == class_310.method_1551().field_1724) {
            PlayerAttackEntityEvent.dispatch(target);
        }
    }

    @ModifyReturnValue(method={"method_49484"}, at={@At(value="RETURN")})
    private float sober$flySpeed(float original) {
        Fly fly = Fly.active;
        if (fly == null) {
            return original;
        }
        class_746 player = class_310.method_1551().field_1724;
        if (player != null && this == player) {
            float override = fly.getOffGroundSpeed(player);
            return override != -1.0f ? override : original;
        }
        return original;
    }
}

