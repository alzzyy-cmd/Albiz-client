/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.minecraft.class_1313
 *  net.minecraft.class_243
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.sugar.Local;
import dev.sober.modules.Speed;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={class_746.class})
public abstract class SpeedMixin {
    @ModifyVariable(method={"method_5784"}, at=@At(value="HEAD"), argsOnly=true)
    private class_243 sober$speedMove(class_243 movement, @Local(argsOnly=true) class_1313 type) {
        Speed speed = Speed.active;
        return speed != null && type == class_1313.field_6308 ? speed.onSelfMove((class_746)this, movement) : movement;
    }
}

