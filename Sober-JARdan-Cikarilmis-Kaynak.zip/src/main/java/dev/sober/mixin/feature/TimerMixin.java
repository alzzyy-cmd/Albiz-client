/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_9779$class_9781
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin.feature;

import dev.sober.modules.Speed;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_9779.class_9781.class})
public abstract class TimerMixin {
    @Shadow
    private float field_51958;

    @Inject(method={"method_60639(J)I"}, at={@At(value="FIELD", target="Lnet/minecraft/class_9779$class_9781;field_51962:J", opcode=181)})
    private void sober$speedTimer(long time, CallbackInfoReturnable<Integer> cir) {
        float multiplier = Speed.timerMultiplier;
        if (multiplier != 1.0f) {
            this.field_51958 *= multiplier;
        }
    }
}

