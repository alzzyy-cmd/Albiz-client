/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.sober.modules.Fly;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_746.class})
public abstract class FlyPlayerMixin {
    @ModifyReturnValue(method={"method_5715"}, at={@At(value="RETURN")})
    private boolean sober$flyNoSneak(boolean original) {
        if (!original) {
            return false;
        }
        Fly fly = Fly.active;
        return fly == null || !fly.noSneak();
    }

    @ModifyExpressionValue(method={"method_6007"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_1656;method_7252()F")})
    private float sober$flyFreecamVertical(float original) {
        Fly fly = Fly.active;
        return fly != null && fly.suppressFlightVerticalInput() ? 0.0f : original;
    }
}

