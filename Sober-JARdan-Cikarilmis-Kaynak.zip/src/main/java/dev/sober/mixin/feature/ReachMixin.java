/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1657
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin.feature;

import dev.sober.modules.Reach;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1657.class})
public abstract class ReachMixin {
    @Inject(method={"method_55755"}, at={@At(value="RETURN")}, cancellable=true)
    private void sober$entityReach(CallbackInfoReturnable<Double> cir) {
        double extra = Reach.entityExtra((class_1657)this);
        if (extra > 0.0) {
            cir.setReturnValue((Object)(cir.getReturnValueD() + extra));
        }
    }

    @Inject(method={"method_55754"}, at={@At(value="RETURN")}, cancellable=true)
    private void sober$blockReach(CallbackInfoReturnable<Double> cir) {
        double extra = Reach.blockExtra((class_1657)this);
        if (extra > 0.0) {
            cir.setReturnValue((Object)(cir.getReturnValueD() + extra));
        }
    }
}

