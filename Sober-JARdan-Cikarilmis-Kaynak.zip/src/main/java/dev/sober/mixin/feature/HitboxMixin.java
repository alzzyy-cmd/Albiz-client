/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin.feature;

import dev.sober.modules.Hitbox;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1297.class})
public abstract class HitboxMixin {
    @Inject(method={"method_5871"}, at={@At(value="RETURN")}, cancellable=true)
    private void sober$growHitbox(CallbackInfoReturnable<Float> cir) {
        float extra = Hitbox.extra((class_1297)this);
        if (extra > 0.0f) {
            cir.setReturnValue((Object)Float.valueOf(cir.getReturnValueF() + extra));
        }
    }
}

