/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10055
 *  net.minecraft.class_1007
 *  net.minecraft.class_11890
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin.feature;

import dev.sober.module.ModuleRegistry;
import dev.sober.modules.SkinChange;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1007.class}, priority=1500)
public abstract class SkinChangeRendererMixin {
    @Inject(method={"method_62604"}, at={@At(value="TAIL")})
    private void sober$applySkin(class_11890 entity, class_10055 state, float partialTick, CallbackInfo ci) {
        SkinChange module = ModuleRegistry.get(SkinChange.class);
        if (module != null && module.isEnabled()) {
            state.field_53520 = module.skinFor(state.field_53528, state.field_53520);
        }
    }
}

