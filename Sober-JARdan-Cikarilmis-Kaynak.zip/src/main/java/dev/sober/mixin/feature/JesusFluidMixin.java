/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyReturnValue
 *  net.minecraft.class_1309
 *  net.minecraft.class_310
 *  net.minecraft.class_3610
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin.feature;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.sober.modules.Jesus;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_1309.class})
public abstract class JesusFluidMixin {
    @ModifyReturnValue(method={"method_26319"}, at={@At(value="RETURN")})
    private boolean sober$jesusCanStandOnFluid(boolean original, class_3610 fluidState) {
        if (original) {
            return true;
        }
        Jesus jesus = Jesus.active;
        return jesus != null && this == class_310.method_1551().field_1724 ? jesus.canWalkOnFluid(fluidState) : false;
    }
}

