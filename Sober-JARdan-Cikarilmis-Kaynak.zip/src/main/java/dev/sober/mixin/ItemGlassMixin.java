/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.minecraft.class_1921
 *  net.minecraft.class_811
 *  net.minecraft.class_918
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package dev.sober.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import dev.sober.modules.Glass;
import net.minecraft.class_1921;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={class_918.class})
public abstract class ItemGlassMixin {
    @ModifyVariable(method={"method_62476"}, at=@At(value="HEAD"), argsOnly=true, require=0)
    private static class_1921 sober$glass(class_1921 layer, @Local(argsOnly=true) class_811 displayContext) {
        return Glass.item(layer, displayContext);
    }
}

