/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11719
 *  net.minecraft.class_327
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.ModifyVariable
 */
package dev.sober.mixin;

import dev.sober.gui.Theme;
import net.minecraft.class_11719;
import net.minecraft.class_327;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={class_327.class})
public abstract class TextRendererMixin {
    @ModifyVariable(method={"method_72732"}, at=@At(value="HEAD"), argsOnly=true)
    private class_11719 sober$gameFont(class_11719 source) {
        return Theme.gameFont(source);
    }
}

