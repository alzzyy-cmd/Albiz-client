/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  net.minecraft.class_437
 *  net.minecraft.class_442
 *  net.minecraft.class_500
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.gui.HomeScreen;
import dev.sober.gui.MenuScreen;
import dev.sober.gui.MultiplayerGridScreen;
import dev.sober.gui.ScreenStyle;
import dev.sober.gui.SoberScreen;
import dev.sober.gui.VanillaPlusScreen;
import dev.sober.modules.MainMenu;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_310.class})
public class MinecraftClientMixin {
    @Inject(method={"method_1507"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$customMenu(class_437 screen, CallbackInfo ci) {
        try {
            MainMenu.Style style;
            boolean title;
            class_310 client = (class_310)this;
            boolean bl = title = screen instanceof class_442 || screen == null && client.field_1687 == null;
            if (!title || !MenuScreen.enabled()) {
                return;
            }
            MainMenu settings = SoberClient.MODULES.get(MainMenu.class);
            MainMenu.Style style2 = style = settings == null ? MainMenu.Style.Sober : settings.style.get();
            SoberScreen menu = style == MainMenu.Style.Sober ? new SoberScreen() : (style == MainMenu.Style.VanillaPlus ? new VanillaPlusScreen() : (style == MainMenu.Style.Home ? new HomeScreen() : new MenuScreen()));
            ci.cancel();
            client.method_1507((class_437)menu);
        }
        catch (RuntimeException e) {
            SoberClient.LOG.error("Custom menu failed", (Throwable)e);
        }
    }

    @Inject(method={"method_1507"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$multiplayer(class_437 screen, CallbackInfo ci) {
        if (screen == null || screen.getClass() != class_500.class || !ScreenStyle.screens() || !ScreenStyle.home()) {
            return;
        }
        try {
            class_437 grid = MultiplayerGridScreen.replace((class_500)screen);
            ci.cancel();
            ((class_310)this).method_1507(grid);
        }
        catch (RuntimeException e) {
            SoberClient.LOG.error("Custom multiplayer screen failed", (Throwable)e);
        }
    }
}

