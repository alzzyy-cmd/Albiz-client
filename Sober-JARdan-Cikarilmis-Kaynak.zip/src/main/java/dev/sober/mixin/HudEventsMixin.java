/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_329
 *  net.minecraft.class_332
 *  net.minecraft.class_9779
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.event.impl.Render2DEvent;
import dev.sober.gui.OverlayCanvas;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_329.class})
public abstract class HudEventsMixin {
    @Inject(method={"method_1753"}, at={@At(value="TAIL")}, require=0)
    private void sober$renderHudEvent(class_332 context, class_9779 counter, CallbackInfo ci) {
        Render2DEvent.dispatch(context, counter.method_60637(false));
        OverlayCanvas.renderProviders(context);
    }
}

