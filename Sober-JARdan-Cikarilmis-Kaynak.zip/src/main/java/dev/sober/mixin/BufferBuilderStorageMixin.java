/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.util.SequencedMap
 *  net.minecraft.class_1921
 *  net.minecraft.class_4597$class_4598
 *  net.minecraft.class_4599
 *  net.minecraft.class_9799
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.mixin.ImmediateAccessor;
import dev.sober.sky.GlintCover;
import java.util.SequencedMap;
import net.minecraft.class_1921;
import net.minecraft.class_4597;
import net.minecraft.class_4599;
import net.minecraft.class_9799;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_4599.class})
public abstract class BufferBuilderStorageMixin {
    @Shadow
    @Final
    private class_4597.class_4598 field_46901;

    @Inject(method={"<init>"}, at={@At(value="TAIL")}, require=0)
    private void sober$glintBuffers(int threads, CallbackInfo ci) {
        try {
            SequencedMap<class_1921, class_9799> buffers = ((ImmediateAccessor)this.field_46901).sober$layerBuffers();
            for (class_1921 layer : GlintCover.layers()) {
                buffers.putIfAbsent((Object)layer, (Object)new class_9799(layer.method_22722()));
            }
        }
        catch (RuntimeException e) {
            SoberClient.LOG.warn("Could not reserve buffers for the covering glint", (Throwable)e);
        }
    }
}

