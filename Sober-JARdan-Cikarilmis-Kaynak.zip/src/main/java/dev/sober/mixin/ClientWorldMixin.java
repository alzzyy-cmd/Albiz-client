/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_2680
 *  net.minecraft.class_638
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_638.class})
public abstract class ClientWorldMixin {
    @Inject(method={"method_41928"}, at={@At(value="HEAD")})
    private void sober$onBlockUpdate(class_2338 pos, class_2680 state, int flags, CallbackInfo ci) {
        class_2680 old = ((class_638)this).method_8320(pos);
        if (old != state) {
            SoberClient.MODULES.onBlockUpdate(pos.method_10062(), old, state);
        }
    }
}

