/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_9975
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.sky.SkyRenderer;
import net.minecraft.class_9975;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_9975.class})
public abstract class SkyRenderingMixin {
    @Inject(method={"method_62302"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$renderSky(CallbackInfo ci) {
        try {
            if (SkyRenderer.renderSky()) {
                ci.cancel();
            }
        }
        catch (RuntimeException runtimeException) {
            // empty catch block
        }
    }

    @Inject(method={"method_62306"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$skipSunrise(CallbackInfo ci) {
        if (SkyRenderer.drewThisFrame()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_62307"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$skipCelestials(CallbackInfo ci) {
        if (SkyRenderer.drewThisFrame()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_62305"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$skipDarkDisc(CallbackInfo ci) {
        if (SkyRenderer.drewThisFrame()) {
            ci.cancel();
        }
    }
}

