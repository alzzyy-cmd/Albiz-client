/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_12077
 *  net.minecraft.class_1937
 *  net.minecraft.class_243
 *  net.minecraft.class_9976
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.modules.ClearView;
import net.minecraft.class_12077;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_9976;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_9976.class})
public abstract class WeatherRenderingMixin {
    @Inject(method={"method_62315"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$noRain(class_1937 world, int ticks, float tickProgress, class_243 cameraPos, class_12077 state, CallbackInfo ci) {
        try {
            if (!ClearView.noRain()) {
                return;
            }
        }
        catch (RuntimeException e) {
            return;
        }
        state.method_74938();
        ci.cancel();
    }

    @Inject(method={"method_62319"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$noRainSound(CallbackInfo ci) {
        try {
            if (ClearView.noRain()) {
                ci.cancel();
            }
        }
        catch (RuntimeException runtimeException) {
            // empty catch block
        }
    }
}

