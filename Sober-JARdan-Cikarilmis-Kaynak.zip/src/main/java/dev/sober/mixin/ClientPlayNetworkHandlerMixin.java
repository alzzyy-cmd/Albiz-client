/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2604
 *  net.minecraft.class_2676
 *  net.minecraft.class_2761
 *  net.minecraft.class_2767
 *  net.minecraft.class_310
 *  net.minecraft.class_634
 *  net.minecraft.class_8143
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.fx.CombatFx;
import dev.sober.gui.HudMetrics;
import dev.sober.modules.ActivityInspector;
import net.minecraft.class_2604;
import net.minecraft.class_2676;
import net.minecraft.class_2761;
import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_8143;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_634.class})
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method={"method_11112"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$onEntitySpawn(class_2604 packet, CallbackInfo ci) {
        if (SoberClient.MODULES.onEntitySpawn(packet)) {
            ci.cancel();
        }
    }

    @Inject(method={"method_11079"}, at={@At(value="HEAD")}, require=0)
    private void sober$onTime(class_2761 packet, CallbackInfo ci) {
        HudMetrics.onWorldTimeUpdate(packet);
    }

    @Inject(method={"method_11143"}, at={@At(value="HEAD")}, require=0)
    private void sober$onLight(class_2676 packet, CallbackInfo ci) {
        if (!class_310.method_1551().method_18854()) {
            return;
        }
        ActivityInspector activity = SoberClient.MODULES.get(ActivityInspector.class);
        if (activity != null) {
            activity.onLightUpdate(packet.method_11558(), packet.method_11554(), packet.method_38600());
        }
    }

    @Inject(method={"method_49034"}, at={@At(value="TAIL")}, require=0)
    private void sober$onDamage(class_8143 packet, CallbackInfo ci) {
        if (!class_310.method_1551().method_18854()) {
            return;
        }
        try {
            CombatFx.onDamage(packet);
        }
        catch (RuntimeException e) {
            SoberClient.LOG.error("Hit effect failed", (Throwable)e);
        }
    }

    @Inject(method={"method_11146"}, at={@At(value="TAIL")}, require=0)
    private void sober$onSound(class_2767 packet, CallbackInfo ci) {
        if (!class_310.method_1551().method_18854()) {
            return;
        }
        try {
            CombatFx.onSound(packet);
        }
        catch (RuntimeException e) {
            SoberClient.LOG.error("Shield effect failed", (Throwable)e);
        }
    }
}

