/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.class_11228
 *  net.minecraft.class_757
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.sober.gui.Backdrop;
import net.minecraft.class_11228;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_11228.class})
public abstract class GuiRendererMixin {
    @WrapOperation(method={"method_71291"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_757;method_57796()V")}, require=0)
    private void sober$menuGlass(class_757 renderer, Operation<Void> original) {
        if (Backdrop.captureMenu()) {
            return;
        }
        original.call(new Object[]{renderer});
    }
}

