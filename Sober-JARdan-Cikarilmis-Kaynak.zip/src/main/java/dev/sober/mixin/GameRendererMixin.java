/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.class_310
 *  net.minecraft.class_4184
 *  net.minecraft.class_4587
 *  net.minecraft.class_5498
 *  net.minecraft.class_757
 *  net.minecraft.class_9920
 *  net.minecraft.class_9922
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.sober.SoberClient;
import dev.sober.modules.Freecam;
import dev.sober.modules.MotionBlur;
import dev.sober.modules.Zoom;
import dev.sober.render.Render3D;
import dev.sober.sky.ItemAuraRenderer;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5498;
import net.minecraft.class_757;
import net.minecraft.class_9920;
import net.minecraft.class_9922;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_757.class})
public abstract class GameRendererMixin {
    @Shadow
    @Final
    private class_9920 field_53066;

    @Inject(method={"method_3192"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_761;method_3254()V", shift=At.Shift.AFTER)}, require=0)
    private void sober$motionBlur(CallbackInfo ci) {
        MotionBlur.apply((class_9922)this.field_53066);
    }

    @Inject(method={"method_3172"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_759;method_22976(FLnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_746;I)V", shift=At.Shift.AFTER)})
    private void sober$handSubmitted(CallbackInfo ci) {
        ItemAuraRenderer.onHandSubmitted(class_310.method_1551().field_1724);
    }

    @Inject(method={"method_3196"}, at={@At(value="RETURN")}, cancellable=true, require=0)
    private void sober$zoom(class_4184 camera, float tickProgress, boolean changingFov, CallbackInfoReturnable<Float> cir) {
        if (!changingFov) {
            return;
        }
        Zoom zoom = SoberClient.MODULES.get(Zoom.class);
        if (zoom == null) {
            return;
        }
        double divisor = zoom.fovDivisor();
        if (divisor > 1.0001) {
            cir.setReturnValue((Object)Float.valueOf((float)((double)cir.getReturnValueF() / divisor)));
        }
    }

    @WrapOperation(method={"method_3172"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_5498;method_31034()Z")}, require=0)
    private boolean sober$freecamHands(class_5498 perspective, Operation<Boolean> original) {
        if (((Boolean)original.call(new Object[]{perspective})).booleanValue()) {
            return true;
        }
        Freecam freecam = SoberClient.MODULES.get(Freecam.class);
        return freecam != null && freecam.showsHands();
    }

    @WrapOperation(method={"method_3188"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_757;method_3186(Lnet/minecraft/class_4587;F)V")}, require=0)
    private void sober$steadyTracers(class_757 renderer, class_4587 matrices, float tickProgress, Operation<Void> original) {
        if (Render3D.tracersActive()) {
            return;
        }
        original.call(new Object[]{renderer, matrices, Float.valueOf(tickProgress)});
    }
}

