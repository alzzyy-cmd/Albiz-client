/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10055
 *  net.minecraft.class_1007
 *  net.minecraft.class_11890
 *  net.minecraft.class_1297
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import dev.sober.modules.Capes;
import dev.sober.modules.NameTags;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11890;
import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1007.class})
public abstract class PlayerEntityRendererMixin {
    @Inject(method={"method_74935(Lnet/minecraft/class_11890;D)Z"}, at={@At(value="RETURN")}, cancellable=true, require=0)
    private void sober$ownTag(class_11890 entity, double distance, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValueZ() && NameTags.showOwnTag((class_1297)entity)) {
            cir.setReturnValue((Object)true);
        }
    }

    @Inject(method={"method_62604(Lnet/minecraft/class_11890;Lnet/minecraft/class_10055;F)V"}, at={@At(value="TAIL")})
    private void sober$fakeRole(class_11890 entity, class_10055 state, float tickProgress, CallbackInfo ci) {
        state.field_53337 = NameTags.decorate((class_1297)entity, state.field_53337);
        Capes.apply(entity, state);
    }
}

