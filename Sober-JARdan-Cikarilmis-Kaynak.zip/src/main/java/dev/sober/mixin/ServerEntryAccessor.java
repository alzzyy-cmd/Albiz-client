/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_4267$class_4270
 *  net.minecraft.class_8573
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package dev.sober.mixin;

import net.minecraft.class_4267;
import net.minecraft.class_8573;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_4267.class_4270.class})
public interface ServerEntryAccessor {
    @Accessor(value="field_19123")
    public class_8573 sober$icon();

    @Accessor(value="field_42874")
    public byte[] sober$favicon();
}

