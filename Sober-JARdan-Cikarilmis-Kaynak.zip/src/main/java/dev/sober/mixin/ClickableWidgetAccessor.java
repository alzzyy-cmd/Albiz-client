/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_339
 *  net.minecraft.class_9110
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package dev.sober.mixin;

import net.minecraft.class_339;
import net.minecraft.class_9110;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_339.class})
public interface ClickableWidgetAccessor {
    @Accessor(value="field_41095")
    public class_9110 sober$tooltip();
}

