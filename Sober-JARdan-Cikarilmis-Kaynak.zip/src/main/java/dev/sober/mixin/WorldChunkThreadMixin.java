/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_2586
 *  net.minecraft.class_2818
 *  net.minecraft.class_2818$class_2819
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import dev.sober.util.ChunkThreadGuard;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_2818.class})
public abstract class WorldChunkThreadMixin {
    @Inject(method={"method_12201(Lnet/minecraft/class_2338;Lnet/minecraft/class_2818$class_2819;)Lnet/minecraft/class_2586;"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$readOffThread(class_2338 pos, class_2818.class_2819 type, CallbackInfoReturnable<class_2586> cir) {
        class_2818 self = (class_2818)this;
        if (!ChunkThreadGuard.offThread(self.method_12200())) {
            return;
        }
        class_2586 blockEntity = (class_2586)self.method_12214().get(pos);
        cir.setReturnValue(blockEntity == null || blockEntity.method_11015() ? null : blockEntity);
    }

    @Inject(method={"method_12007(Lnet/minecraft/class_2586;)V"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$setOffThread(class_2586 blockEntity, CallbackInfo ci) {
        class_2818 self = (class_2818)this;
        if (!ChunkThreadGuard.offThread(self.method_12200())) {
            return;
        }
        ChunkThreadGuard.defer("setBlockEntity", () -> self.method_12007(blockEntity));
        ci.cancel();
    }

    @Inject(method={"method_12216(Lnet/minecraft/class_2586;)V"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$addOffThread(class_2586 blockEntity, CallbackInfo ci) {
        class_2818 self = (class_2818)this;
        if (!ChunkThreadGuard.offThread(self.method_12200())) {
            return;
        }
        ChunkThreadGuard.defer("addBlockEntity", () -> self.method_12216(blockEntity));
        ci.cancel();
    }

    @Inject(method={"method_12041(Lnet/minecraft/class_2338;)V"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$removeOffThread(class_2338 pos, CallbackInfo ci) {
        class_2818 self = (class_2818)this;
        if (!ChunkThreadGuard.offThread(self.method_12200())) {
            return;
        }
        class_2338 copy = pos.method_10062();
        ChunkThreadGuard.defer("removeBlockEntity", () -> self.method_12041(copy));
        ci.cancel();
    }
}

