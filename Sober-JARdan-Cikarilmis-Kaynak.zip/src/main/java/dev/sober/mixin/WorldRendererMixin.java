/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_761
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.sky.SkyRenderer;
import dev.sober.sky.SkySettings;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_761.class})
public abstract class WorldRendererMixin {
    @Inject(method={"method_62204"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$hideClouds(CallbackInfo ci) {
        if (SkySettings.hideVanillaClouds && SkyRenderer.isCustomSkySelected()) {
            ci.cancel();
        }
    }
}

