/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11398
 *  net.minecraft.class_12206
 *  net.minecraft.class_310
 *  net.minecraft.class_4184
 *  net.minecraft.class_638
 *  net.minecraft.class_7285
 *  net.minecraft.class_9779
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.modules.ClearView;
import net.minecraft.class_11398;
import net.minecraft.class_12206;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_11398.class})
public abstract class AtmosphericFogModifierMixin {
    @Inject(method={"method_42591"}, at={@At(value="RETURN")}, require=0)
    private void sober$noRainFog(class_7285 data, class_4184 camera, class_638 world, float viewDistance, class_9779 counter, CallbackInfo ci) {
        try {
            if (!ClearView.noRain() || world.method_8430(1.0f) <= 0.0f) {
                return;
            }
            if (class_310.method_1551().field_1705.method_1740().method_1800()) {
                return;
            }
            float tick = counter.method_60637(false);
            data.field_60582 = ((Float)camera.method_75756().method_75689(class_12206.field_64120, tick)).floatValue();
            data.field_60584 = ((Float)camera.method_75756().method_75689(class_12206.field_64121, tick)).floatValue();
        }
        catch (RuntimeException runtimeException) {
            // empty catch block
        }
    }
}

