/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.class_310
 *  net.minecraft.class_312
 *  net.minecraft.class_746
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.sober.SoberClient;
import dev.sober.modules.Freecam;
import dev.sober.modules.Freelook;
import dev.sober.modules.Zoom;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_312.class})
public abstract class MouseMixin {
    @WrapOperation(method={"method_1606"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_746;method_5872(DD)V")}, require=0)
    private void sober$look(class_746 player, double dx, double dy, Operation<Void> original) {
        Freecam freecam;
        Zoom zoom = SoberClient.MODULES.get(Zoom.class);
        if (zoom != null) {
            double slow = zoom.sensitivityScale();
            dx *= slow;
            dy *= slow;
        }
        if ((freecam = SoberClient.MODULES.get(Freecam.class)) != null && freecam.isActive()) {
            freecam.turn(dx, dy);
            return;
        }
        Freelook freelook = SoberClient.MODULES.get(Freelook.class);
        if (freelook != null && freelook.isActive()) {
            freelook.turn(dx, dy);
            return;
        }
        original.call(new Object[]{player, dx, dy});
    }

    @Inject(method={"method_1598"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$scroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != null || mc.field_1724 == null || vertical == 0.0) {
            return;
        }
        Zoom zoom = SoberClient.MODULES.get(Zoom.class);
        if (zoom != null && zoom.scroll(vertical)) {
            ci.cancel();
            return;
        }
        Freecam freecam = SoberClient.MODULES.get(Freecam.class);
        if (freecam != null && freecam.isActive()) {
            if (freecam.scroll(vertical)) {
                ci.cancel();
            }
            return;
        }
        Freelook freelook = SoberClient.MODULES.get(Freelook.class);
        if (freelook != null && freelook.isActive()) {
            freelook.scroll(vertical);
            ci.cancel();
        }
    }
}

