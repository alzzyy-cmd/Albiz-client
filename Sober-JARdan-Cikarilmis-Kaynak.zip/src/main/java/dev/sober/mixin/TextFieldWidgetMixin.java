/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  com.mojang.blaze3d.pipeline.RenderPipeline
 *  net.minecraft.class_156
 *  net.minecraft.class_2960
 *  net.minecraft.class_327
 *  net.minecraft.class_332
 *  net.minecraft.class_342
 *  net.minecraft.class_5481
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import dev.sober.gui.ScreenStyle;
import dev.sober.modules.AnimatedTyping;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_342.class})
public abstract class TextFieldWidgetMixin {
    @Shadow
    private String field_2092;
    @Shadow
    private int field_2103;
    @Shadow
    private int field_2102;
    @Unique
    private String sober$lastText;
    @Unique
    private long[] sober$times;
    @Unique
    private float sober$caret = Float.NaN;
    @Unique
    private long sober$caretFrame;

    @WrapOperation(method={"method_48579"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_332;method_52706(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/class_2960;IIII)V")}, require=0)
    private void sober$field(class_332 context, RenderPipeline pipeline, class_2960 sprite, int x, int y, int width, int height, Operation<Void> original) {
        if (!ScreenStyle.widgets()) {
            original.call(new Object[]{context, pipeline, sprite, x, y, width, height});
            return;
        }
        ScreenStyle.textField(context, this, x, y, width, height, ((class_342)this).method_25370());
    }

    @Inject(method={"method_48579"}, at={@At(value="HEAD")}, require=0)
    private void sober$trackTyping(class_332 context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        this.sober$times = AnimatedTyping.track(this.sober$lastText, this.field_2092, this.sober$times, AnimatedTyping.applies((class_342)this));
        this.sober$lastText = this.field_2092;
    }

    @WrapOperation(method={"method_48579"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_332;method_51430(Lnet/minecraft/class_327;Lnet/minecraft/class_5481;IIIZ)V", ordinal=0)}, require=0)
    private void sober$typedBefore(class_332 context, class_327 renderer, class_5481 value, int x, int y, int color, boolean shadow, Operation<Void> original) {
        if (this.sober$times == null || !AnimatedTyping.applies((class_342)this)) {
            original.call(new Object[]{context, renderer, value, x, y, color, shadow});
            return;
        }
        AnimatedTyping.draw(context, renderer, value, x, y, color, shadow, this.sober$times, this.field_2103);
    }

    @WrapOperation(method={"method_48579"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_332;method_51430(Lnet/minecraft/class_327;Lnet/minecraft/class_5481;IIIZ)V", ordinal=1)}, require=0)
    private void sober$typedAfter(class_332 context, class_327 renderer, class_5481 value, int x, int y, int color, boolean shadow, Operation<Void> original) {
        if (this.sober$times == null || !AnimatedTyping.applies((class_342)this)) {
            original.call(new Object[]{context, renderer, value, x, y, color, shadow});
            return;
        }
        AnimatedTyping.draw(context, renderer, value, x, y, color, shadow, this.sober$times, this.field_2102);
    }

    @WrapOperation(method={"method_48579"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_332;method_25294(IIIII)V")}, require=0)
    private void sober$cursorBar(class_332 context, int x1, int y1, int x2, int y2, int color, Operation<Void> original) {
        float offset = this.sober$glide(x1);
        if (offset == 0.0f) {
            original.call(new Object[]{context, x1, y1, x2, y2, color});
            return;
        }
        context.method_51448().pushMatrix();
        context.method_51448().translate(offset, 0.0f);
        original.call(new Object[]{context, x1, y1, x2, y2, color});
        context.method_51448().popMatrix();
    }

    @WrapOperation(method={"method_48579"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_332;method_51433(Lnet/minecraft/class_327;Ljava/lang/String;IIIZ)V", ordinal=1)}, require=0)
    private void sober$cursorEnd(class_332 context, class_327 renderer, String value, int x, int y, int color, boolean shadow, Operation<Void> original) {
        float offset = this.sober$glide(x);
        if (offset == 0.0f) {
            original.call(new Object[]{context, renderer, value, x, y, color, shadow});
            return;
        }
        context.method_51448().pushMatrix();
        context.method_51448().translate(offset, 0.0f);
        original.call(new Object[]{context, renderer, value, x, y, color, shadow});
        context.method_51448().popMatrix();
    }

    @Unique
    private float sober$glide(int target) {
        if (!AnimatedTyping.applies((class_342)this) || !AnimatedTyping.smoothCursor()) {
            this.sober$caret = Float.NaN;
            return 0.0f;
        }
        long now = class_156.method_658();
        this.sober$caret = AnimatedTyping.glide(this.sober$caret, target, this.sober$caretFrame, now);
        this.sober$caretFrame = now;
        return this.sober$caret - (float)target;
    }
}

