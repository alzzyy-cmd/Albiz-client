/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.ModifyExpressionValue
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  com.llamalad7.mixinextras.sugar.Local
 *  net.minecraft.class_10017
 *  net.minecraft.class_10042
 *  net.minecraft.class_10055
 *  net.minecraft.class_1058
 *  net.minecraft.class_11659
 *  net.minecraft.class_11683$class_11792
 *  net.minecraft.class_1921
 *  net.minecraft.class_3879
 *  net.minecraft.class_3887
 *  net.minecraft.class_4587
 *  net.minecraft.class_922
 *  net.minecraft.class_979
 *  net.minecraft.class_989
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import dev.sober.fx.CombatFx;
import dev.sober.modules.CustomSkin;
import dev.sober.modules.Glass;
import net.minecraft.class_10017;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1058;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_1921;
import net.minecraft.class_3879;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_922;
import net.minecraft.class_979;
import net.minecraft.class_989;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_922.class})
public abstract class LivingEntityRendererMixin {
    @ModifyExpressionValue(method={"method_4058"}, at={@At(value="FIELD", target="Lnet/minecraft/class_10042;field_53449:F")}, require=0)
    private float sober$uprightDeath(float deathTime, @Local(argsOnly=true) class_10042 state) {
        return CombatFx.dissolves(state) ? 0.0f : deathTime;
    }

    @Inject(method={"method_4058"}, at={@At(value="TAIL")}, require=0)
    private void sober$dissolve(class_10042 state, class_4587 matrices, float bodyYaw, float baseHeight, CallbackInfo ci) {
        CombatFx.dissolve(state, matrices);
    }

    @WrapOperation(method={"method_4054(Lnet/minecraft/class_10042;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_12075;)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_11659;method_73490(Lnet/minecraft/class_3879;Ljava/lang/Object;Lnet/minecraft/class_4587;Lnet/minecraft/class_1921;IIILnet/minecraft/class_1058;ILnet/minecraft/class_11683$class_11792;)V")})
    private void sober$customSkin(class_11659 queue, class_3879<?> model, Object state, class_4587 matrices, class_1921 layer, int light, int overlay, int tint, class_1058 sprite, int outline, class_11683.class_11792 crumbling, Operation<Void> original) {
        class_10055 player;
        if (state instanceof class_10055 && Glass.applies(player = (class_10055)state)) {
            original.call(new Object[]{queue, model, state, matrices, Glass.layer(player), light, overlay, Glass.tint(), sprite, outline, crumbling});
            return;
        }
        if (state instanceof class_10055 && CustomSkin.render(player = (class_10055)state, matrices, queue, overlay)) {
            return;
        }
        original.call(new Object[]{queue, model, state, matrices, layer, light, overlay, tint, sprite, outline, crumbling});
    }

    @WrapOperation(method={"method_4054(Lnet/minecraft/class_10042;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_12075;)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_922;method_62483(Lnet/minecraft/class_10042;)Z")})
    private boolean sober$skinFeatures(class_922<?, ?, ?> renderer, class_10042 state, Operation<Boolean> original) {
        if (CustomSkin.hidesFeatures(state) && !CustomSkin.showsElytra()) {
            return false;
        }
        return (Boolean)original.call(new Object[]{renderer, state});
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    @WrapOperation(method={"method_4054(Lnet/minecraft/class_10042;Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;Lnet/minecraft/class_12075;)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_3887;method_4199(Lnet/minecraft/class_4587;Lnet/minecraft/class_11659;ILnet/minecraft/class_10017;FF)V")})
    private void sober$skinFeature(class_3887<?, ?> feature, class_4587 matrices, class_11659 queue, int light, class_10017 state, float limbAngle, float limbDistance, Operation<Void> original) {
        boolean glass = !(feature instanceof class_989) && Glass.glassGear(state);
        Glass.gear(glass);
        try {
            if (!CustomSkin.hidesFeatures(state)) {
                original.call(new Object[]{feature, matrices, queue, light, state, Float.valueOf(limbAngle), Float.valueOf(limbDistance)});
                return;
            }
            if (!(feature instanceof class_979) || !CustomSkin.showsElytra()) {
                return;
            }
            matrices.method_22903();
            CustomSkin.elytraOffset(matrices);
            original.call(new Object[]{feature, matrices, queue, light, state, Float.valueOf(limbAngle), Float.valueOf(limbDistance)});
            matrices.method_22909();
        }
        finally {
            if (glass) {
                Glass.gear(false);
            }
        }
    }
}

