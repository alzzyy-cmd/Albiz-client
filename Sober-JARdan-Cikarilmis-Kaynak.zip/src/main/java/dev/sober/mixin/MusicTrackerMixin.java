/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1142
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.gui.MenuAudio;
import net.minecraft.class_1142;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1142.class})
public class MusicTrackerMixin {
    @Inject(method={"method_18669"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$menuAudio(CallbackInfo ci) {
        if (MenuAudio.playing()) {
            ci.cancel();
        }
    }
}

