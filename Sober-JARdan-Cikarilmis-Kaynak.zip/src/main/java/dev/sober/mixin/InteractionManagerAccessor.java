/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_2338
 *  net.minecraft.class_636
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 *  org.spongepowered.asm.mixin.gen.Invoker
 */
package dev.sober.mixin;

import net.minecraft.class_2338;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_636.class})
public interface InteractionManagerAccessor {
    @Invoker(value="method_2911")
    public void sober$elytraFlySyncSelected();

    @Accessor(value="field_3715")
    public float sober$breakingProgress();

    @Accessor(value="field_3715")
    public void sober$setBreakingProgress(float var1);

    @Accessor(value="field_3716")
    public void sober$setBreakingCooldown(int var1);

    @Accessor(value="field_3714")
    public class_2338 sober$breakingPos();

    @Accessor(value="field_3717")
    public boolean sober$breaking();
}

