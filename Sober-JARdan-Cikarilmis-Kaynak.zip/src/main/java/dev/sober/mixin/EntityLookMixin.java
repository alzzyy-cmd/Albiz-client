/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.modules.Freecam;
import dev.sober.modules.Freelook;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1297.class})
public abstract class EntityLookMixin {
    @Inject(method={"method_5872"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$cameraLook(double dx, double dy, CallbackInfo ci) {
        if (this != class_310.method_1551().field_1724) {
            return;
        }
        Freecam freecam = SoberClient.MODULES.get(Freecam.class);
        if (freecam != null && freecam.isActive()) {
            freecam.turn(dx, dy);
            ci.cancel();
            return;
        }
        Freelook freelook = SoberClient.MODULES.get(Freelook.class);
        if (freelook != null && freelook.isActive()) {
            freelook.turn(dx, dy);
            ci.cancel();
        }
    }
}

