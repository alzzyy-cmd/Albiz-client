/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11228
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Invoker
 */
package dev.sober.mixin;

import net.minecraft.class_11228;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_11228.class})
public interface GuiRendererAccessor {
    @Invoker(value="method_70896")
    public void sober$resetItemAtlas();

    @Invoker(value="method_72109")
    public void sober$clearOversizedItems();
}

