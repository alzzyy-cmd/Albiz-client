/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import dev.sober.gui.BrandWindow;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_310.class})
public abstract class WindowTitleMixin {
    @Inject(method={"method_24287"}, at={@At(value="RETURN")}, cancellable=true, require=0)
    private void sober$title(CallbackInfoReturnable<String> cir) {
        cir.setReturnValue((Object)BrandWindow.title((String)cir.getReturnValue()));
    }
}

