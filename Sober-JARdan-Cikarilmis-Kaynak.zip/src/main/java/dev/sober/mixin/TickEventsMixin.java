/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.event.EventBus;
import dev.sober.event.impl.TickEvent;
import dev.sober.util.PerformanceBudget;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_310.class})
public abstract class TickEventsMixin {
    @Inject(method={"method_1574"}, at={@At(value="HEAD")}, require=0)
    private void sober$tickStart(CallbackInfo ci) {
        EventBus.INSTANCE.drainAsync();
        PerformanceBudget.beginTick();
        TickEvent.dispatch();
    }

    @Inject(method={"method_1574"}, at={@At(value="RETURN")}, require=0)
    private void sober$tickEnd(CallbackInfo ci) {
        TickEvent.dispatchPost();
    }
}

