/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_304
 *  net.minecraft.class_310
 *  net.minecraft.class_3675$class_306
 *  net.minecraft.class_3675$class_307
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.modules.ClickGui;
import dev.sober.modules.CsPickaxe;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_304.class})
public abstract class KeyBindingMixin {
    @Inject(method={"method_1420"}, at={@At(value="HEAD")}, cancellable=true)
    private static void sober$overridePress(class_3675.class_306 key, CallbackInfo ci) {
        if (KeyBindingMixin.sober$blocks(key)) {
            ci.cancel();
        }
    }

    @Inject(method={"method_1416"}, at={@At(value="HEAD")}, cancellable=true)
    private static void sober$overrideHold(class_3675.class_306 key, boolean pressed, CallbackInfo ci) {
        if (pressed && KeyBindingMixin.sober$blocks(key)) {
            ci.cancel();
        }
    }

    private static boolean sober$blocks(class_3675.class_306 key) {
        if (key == null || key.method_1442() != class_3675.class_307.field_1668) {
            return false;
        }
        if (class_310.method_1551().field_1755 != null) {
            return false;
        }
        if (CsPickaxe.blocks(key.method_1444())) {
            return true;
        }
        ClickGui gui = SoberClient.MODULES.get(ClickGui.class);
        if (gui == null || !gui.overrideKeys.get().booleanValue()) {
            return false;
        }
        return SoberClient.MODULES.isBound(key.method_1444());
    }
}

