/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1703
 *  net.minecraft.class_2561
 *  net.minecraft.class_332
 *  net.minecraft.class_437
 *  net.minecraft.class_465
 *  net.minecraft.class_481
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.At$Shift
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.gui.InventoryStyle;
import dev.sober.modules.MediaHider;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_481;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_465.class})
public abstract class HandledScreenMixin<T extends class_1703>
extends class_437 {
    @Shadow
    protected int field_2776;
    @Shadow
    protected int field_2800;
    @Shadow
    protected int field_2792;
    @Shadow
    protected int field_2779;
    @Shadow
    @Final
    protected T field_2797;

    protected HandledScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method={"method_25420"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_465;method_2389(Lnet/minecraft/class_332;FII)V")}, require=0)
    private void sober$behind(class_332 context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        try {
            InventoryStyle.behind(context, this.field_22789, this.field_22790, this.field_2776, this.field_2800, this.field_2792, this.field_2779, this instanceof class_481);
        }
        catch (RuntimeException e) {
            SoberClient.LOG.error("Inventory style failed", (Throwable)e);
        }
    }

    @Inject(method={"method_25420"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_465;method_2389(Lnet/minecraft/class_332;FII)V", shift=At.Shift.AFTER)}, require=0)
    private void sober$over(class_332 context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        try {
            InventoryStyle.over(context, this.field_2776, this.field_2800, this.field_2792, this.field_2779, this.field_2797, this instanceof class_481);
        }
        catch (RuntimeException e) {
            SoberClient.LOG.error("Inventory style failed", (Throwable)e);
        }
    }

    @Inject(method={"method_71085"}, at={@At(value="TAIL")})
    private void sober$mediaHider(class_332 context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        try {
            MediaHider.coverScreen(context, this, this.field_2776, this.field_2800, this.field_2792, this.field_2779, this.field_2797);
        }
        catch (RuntimeException e) {
            SoberClient.LOG.error("Media hider failed", (Throwable)e);
        }
    }

    @Inject(method={"method_2380"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$hideTooltip(class_332 context, int mouseX, int mouseY, CallbackInfo ci) {
        if (MediaHider.hidesTooltips(this)) {
            ci.cancel();
        }
    }

    @Inject(method={"method_71083"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$hideCursorStack(class_332 context, int mouseX, int mouseY, CallbackInfo ci) {
        if (MediaHider.hidesTooltips(this)) {
            ci.cancel();
        }
    }

    @ModifyArg(method={"method_2388"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_332;method_51439(Lnet/minecraft/class_327;Lnet/minecraft/class_2561;IIIZ)V"), index=4, require=0)
    private int sober$titleColor(int color) {
        return InventoryStyle.titleColor(color);
    }
}

