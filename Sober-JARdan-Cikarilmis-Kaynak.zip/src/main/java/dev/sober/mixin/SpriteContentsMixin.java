/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1011
 *  net.minecraft.class_2960
 *  net.minecraft.class_7764
 *  org.spongepowered.asm.mixin.Final
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.fx.LowFire;
import net.minecraft.class_1011;
import net.minecraft.class_2960;
import net.minecraft.class_7764;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_7764.class})
public abstract class SpriteContentsMixin {
    @Shadow
    @Final
    class_2960 field_40536;
    @Shadow
    @Final
    private class_1011 field_40539;

    @Inject(method={"<init>(Lnet/minecraft/class_2960;Lnet/minecraft/class_7771;Lnet/minecraft/class_1011;Ljava/util/Optional;Ljava/util/List;Ljava/util/Optional;)V"}, at={@At(value="TAIL")}, require=0)
    private void sober$violetFire(CallbackInfo ci) {
        LowFire.recolor(this.field_40536, this.field_40539);
    }
}

