/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11419
 *  net.minecraft.class_11473
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 */
package dev.sober.mixin;

import net.minecraft.class_11419;
import net.minecraft.class_11473;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_11473.class})
public interface DialogScreenAccessor {
    @Accessor(value="field_60761")
    public class_11419 sober$dialog();
}

