/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11910
 *  net.minecraft.class_310
 *  net.minecraft.class_312
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.event.impl.MouseInputEvent;
import dev.sober.modules.CreamyKeys;
import net.minecraft.class_11910;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_312.class})
public abstract class MouseEventsMixin {
    @Inject(method={"method_1601"}, at={@At(value="HEAD")}, require=0)
    private void sober$mouseClickSound(long window, class_11910 input, int action, CallbackInfo ci) {
        if (window != class_310.method_1551().method_22683().method_4490()) {
            return;
        }
        try {
            CreamyKeys keys = SoberClient.MODULES.get(CreamyKeys.class);
            if (keys != null && keys.isActive()) {
                keys.onMouse(input.comp_4801(), action);
            }
        }
        catch (RuntimeException e) {
            SoberClient.LOG.error("Creamy Keys failed", (Throwable)e);
        }
    }

    @Inject(method={"method_1601"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$mouseButtonEvent(long window, class_11910 input, int action, CallbackInfo ci) {
        if (MouseInputEvent.dispatch(window, input.comp_4801(), action, input.comp_4797())) {
            ci.cancel();
        }
    }
}

