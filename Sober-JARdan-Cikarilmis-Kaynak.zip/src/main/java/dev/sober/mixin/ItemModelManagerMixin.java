/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  net.minecraft.class_10442
 *  net.minecraft.class_1799
 *  net.minecraft.class_2960
 *  net.minecraft.class_9331
 *  net.minecraft.class_9334
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 */
package dev.sober.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.sober.modules.CustomTotems;
import net.minecraft.class_10442;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(value={class_10442.class})
public abstract class ItemModelManagerMixin {
    @WrapOperation(method={"method_65596"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_1799;method_58694(Lnet/minecraft/class_9331;)Ljava/lang/Object;")}, require=0)
    private Object sober$totemStyle(class_1799 stack, class_9331<?> type, Operation<Object> original) {
        Object object;
        Object value = original.call(new Object[]{stack, type});
        if (type == class_9334.field_54199 && value instanceof class_2960) {
            class_2960 model = (class_2960)value;
            object = CustomTotems.model(stack, model);
        } else {
            object = value;
        }
        return object;
    }
}

