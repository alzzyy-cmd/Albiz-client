/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1294
 *  net.minecraft.class_1297
 *  net.minecraft.class_1309
 *  net.minecraft.class_310
 *  net.minecraft.class_4184
 *  net.minecraft.class_5636
 *  net.minecraft.class_758
 *  org.joml.Vector4f
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import dev.sober.sky.SkyRenderer;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_758;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_758.class})
public abstract class FogRendererMixin {
    @Inject(method={"method_62185"}, at={@At(value="RETURN")})
    private void sober$matchSkyFog(CallbackInfoReturnable<Vector4f> cir) {
        class_1309 living;
        float[] fog;
        try {
            fog = SkyRenderer.fogColor();
        }
        catch (RuntimeException e) {
            return;
        }
        if (fog == null) {
            return;
        }
        class_4184 camera = class_310.method_1551().field_1773.method_19418();
        class_5636 fluid = camera.method_19334();
        if (fluid == class_5636.field_27886 || fluid == class_5636.field_27885 || fluid == class_5636.field_27887) {
            return;
        }
        class_1297 class_12972 = camera.method_19331();
        if (class_12972 instanceof class_1309 && ((living = (class_1309)class_12972).method_6059(class_1294.field_5919) || living.method_6059(class_1294.field_38092))) {
            return;
        }
        Vector4f color = (Vector4f)cir.getReturnValue();
        color.set(fog[0], fog[1], fog[2], color.w);
    }
}

