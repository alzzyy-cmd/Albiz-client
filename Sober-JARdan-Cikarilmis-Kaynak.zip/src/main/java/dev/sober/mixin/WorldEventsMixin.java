/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.sugar.Local
 *  com.mojang.blaze3d.buffers.GpuBufferSlice
 *  net.minecraft.class_12180$class_12181
 *  net.minecraft.class_310
 *  net.minecraft.class_4184
 *  net.minecraft.class_4604
 *  net.minecraft.class_5636
 *  net.minecraft.class_758$class_4596
 *  net.minecraft.class_761
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyArg
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import dev.sober.event.impl.Render3DEvent;
import dev.sober.mixin.GameRendererAccessor;
import dev.sober.util.ShaderOverlay;
import dev.sober.util.TracerEngine;
import net.minecraft.class_12180;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_5636;
import net.minecraft.class_758;
import net.minecraft.class_761;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_761.class})
public abstract class WorldEventsMixin {
    @ModifyArg(method={"method_22710"}, at=@At(value="INVOKE", target="Lnet/minecraft/class_863;method_23099(Lnet/minecraft/class_4604;DDDF)V"), index=0, require=0)
    private class_4604 sober$renderWorldEvent(class_4604 frustum, @Local(argsOnly=true, ordinal=0) Matrix4f viewRotation, @Local(argsOnly=true, ordinal=1) Matrix4f projection) {
        TracerEngine.beginFrame((Matrix4fc)viewRotation, (Matrix4fc)projection);
        try (class_12180.class_12181 capture = ShaderOverlay.capture();){
            Render3DEvent.dispatch(class_310.method_1551().method_61966().method_60637(false), frustum);
        }
        return frustum;
    }

    @Inject(method={"method_22710"}, at={@At(value="TAIL")}, require=0)
    private void sober$overlayAfterShaderPack(CallbackInfo ci, @Local(argsOnly=true) GpuBufferSlice fog, @Local(argsOnly=true) class_4184 camera, @Local(argsOnly=true, ordinal=0) Matrix4f viewRotation, @Local(argsOnly=true, ordinal=1) Matrix4f projection) {
        if (ShaderOverlay.pending()) {
            ShaderOverlay.render(camera, viewRotation, projection, fog, WorldEventsMixin.sober$onTopFog(fog, camera));
        }
    }

    @Unique
    private static GpuBufferSlice sober$onTopFog(GpuBufferSlice fog, class_4184 camera) {
        if (camera.method_19334() == class_5636.field_27888) {
            return fog;
        }
        return ((GameRendererAccessor)class_310.method_1551().field_1773).sober$getFogRenderer().method_71109(class_758.class_4596.field_60101);
    }
}

