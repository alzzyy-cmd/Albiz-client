/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_12250
 *  org.joml.Matrix4f
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import dev.sober.sky.GlintManager;
import net.minecraft.class_12250;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_12250.class})
public abstract class TextureTransformMixin {
    @Inject(method={"method_76031"}, at={@At(value="HEAD")}, cancellable=true)
    private static void sober$glintScale(float scale, CallbackInfoReturnable<Matrix4f> cir) {
        Matrix4f fitted = GlintManager.transform(scale);
        if (fitted != null) {
            cir.setReturnValue((Object)fitted);
        }
    }
}

