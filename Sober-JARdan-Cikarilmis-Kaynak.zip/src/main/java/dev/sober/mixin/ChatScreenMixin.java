/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11909
 *  net.minecraft.class_408
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import dev.sober.gui.HudRenderer;
import net.minecraft.class_11909;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_408.class})
public abstract class ChatScreenMixin {
    @Inject(method={"method_25402"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_437;method_25402(Lnet/minecraft/class_11909;Z)Z")}, cancellable=true)
    private void sober$dragHud(class_11909 click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        if (HudRenderer.chatPress(click.comp_4798(), click.comp_4799(), click.method_74245())) {
            cir.setReturnValue((Object)true);
        }
    }

    @Inject(method={"method_25401"}, at={@At(value="HEAD")}, cancellable=true)
    private void sober$scaleHud(double mouseX, double mouseY, double horizontalAmount, double verticalAmount, CallbackInfoReturnable<Boolean> cir) {
        if (HudRenderer.chatScroll(mouseX, mouseY, verticalAmount)) {
            cir.setReturnValue((Object)true);
        }
    }
}

