/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11228
 *  net.minecraft.class_4184
 *  net.minecraft.class_757
 *  net.minecraft.class_758
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.gen.Accessor
 *  org.spongepowered.asm.mixin.gen.Invoker
 */
package dev.sober.mixin;

import net.minecraft.class_11228;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_757.class})
public interface GameRendererAccessor {
    @Invoker(value="method_3196")
    public float sober$getFov(class_4184 var1, float var2, boolean var3);

    @Accessor(value="field_60793")
    public class_758 sober$getFogRenderer();

    @Invoker(value="method_3202")
    public boolean sober$shouldRenderBlockOutline();

    @Accessor(value="field_59965")
    public class_11228 sober$getGuiRenderer();
}

