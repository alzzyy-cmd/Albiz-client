/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10185
 *  net.minecraft.class_241
 *  net.minecraft.class_743
 *  net.minecraft.class_744
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.modules.Boatfly;
import dev.sober.modules.Freecam;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_743.class})
public abstract class KeyboardInputMixin
extends class_744 {
    @Inject(method={"method_3129"}, at={@At(value="TAIL")})
    private void sober$boatControls(CallbackInfo ci) {
        if (!Boatfly.controlling()) {
            return;
        }
        class_10185 input = this.field_54155;
        this.field_54155 = new class_10185(input.comp_3159(), input.comp_3160(), input.comp_3161(), input.comp_3162(), false, Boatfly.exitPressed(), false);
    }

    @Inject(method={"method_3129"}, at={@At(value="TAIL")})
    private void sober$freezePlayer(CallbackInfo ci) {
        Freecam freecam = SoberClient.MODULES.get(Freecam.class);
        if (!freecam.isActive()) {
            return;
        }
        this.field_54155 = freecam.frozenInput();
        this.field_55868 = class_241.field_1340;
    }
}

