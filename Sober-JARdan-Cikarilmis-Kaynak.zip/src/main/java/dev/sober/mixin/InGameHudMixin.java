/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.llamalad7.mixinextras.injector.wrapoperation.Operation
 *  com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation
 *  com.mojang.blaze3d.pipeline.RenderPipeline
 *  net.minecraft.class_2561
 *  net.minecraft.class_266
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_327
 *  net.minecraft.class_329
 *  net.minecraft.class_332
 *  net.minecraft.class_5348
 *  net.minecraft.class_9779
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import dev.sober.modules.CustomCrosshair;
import dev.sober.modules.FakeStats;
import dev.sober.modules.MediaHider;
import dev.sober.modules.NameTags;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_5348;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_329.class})
public abstract class InGameHudMixin {
    @Unique
    private int sober$drawIndex;
    @Unique
    private int sober$widthIndex;

    @WrapOperation(method={"method_1736"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_332;method_52706(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/class_2960;IIII)V")}, require=0)
    private void sober$crosshair(class_332 context, RenderPipeline pipeline, class_2960 sprite, int x, int y, int width, int height, Operation<Void> original) {
        if (sprite.method_12832().equals("hud/crosshair") && CustomCrosshair.render(context)) {
            return;
        }
        if (sprite.method_12832().startsWith("hud/crosshair_attack_indicator") && CustomCrosshair.hidesVanillaIndicator()) {
            return;
        }
        original.call(new Object[]{context, pipeline, sprite, x, y, width, height});
    }

    @WrapOperation(method={"method_1736"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_332;method_70846(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/class_2960;IIIIIIII)V")}, require=0)
    private void sober$crosshairProgress(class_332 context, RenderPipeline pipeline, class_2960 sprite, int textureWidth, int textureHeight, int u, int v, int x, int y, int width, int height, Operation<Void> original) {
        if (sprite.method_12832().startsWith("hud/crosshair_attack_indicator") && CustomCrosshair.hidesVanillaIndicator()) {
            return;
        }
        original.call(new Object[]{context, pipeline, sprite, textureWidth, textureHeight, u, v, x, y, width, height});
    }

    @Inject(method={"method_1736"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$freeCameraCrosshair(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1690.method_31044().method_31034() || !CustomCrosshair.showsInFreeCamera()) {
            return;
        }
        if (CustomCrosshair.render(context)) {
            ci.cancel();
        }
    }

    @Inject(method={"method_1749"}, at={@At(value="HEAD")}, cancellable=true, require=0)
    private void sober$hideHeldName(class_332 context, CallbackInfo ci) {
        if (MediaHider.hidesHeldName()) {
            ci.cancel();
        }
    }

    @Inject(method={"method_1757(Lnet/minecraft/class_332;Lnet/minecraft/class_266;)V"}, at={@At(value="HEAD")})
    private void sober$sidebarStart(class_332 context, class_266 objective, CallbackInfo ci) {
        this.sober$drawIndex = 0;
        this.sober$widthIndex = 0;
        FakeStats.beginSidebar();
    }

    @WrapOperation(method={"method_1757(Lnet/minecraft/class_332;Lnet/minecraft/class_266;)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_332;method_51439(Lnet/minecraft/class_327;Lnet/minecraft/class_2561;IIIZ)V")})
    private void sober$sidebarRole(class_332 context, class_327 renderer, class_2561 text, int x, int y, int color, boolean shadow, Operation<Void> original) {
        int index;
        if ((index = this.sober$drawIndex++) == 0) {
            original.call(new Object[]{context, renderer, NameTags.decorateText(text), x, y, color, shadow});
            return;
        }
        int line = (index - 1) / 2 + 1;
        if ((index - 1) % 2 == 1) {
            class_2561 score = FakeStats.applyScore(line, text);
            int shift = score == text ? 0 : renderer.method_27525((class_5348)text) - renderer.method_27525((class_5348)score);
            original.call(new Object[]{context, renderer, score, x + shift, y, color, shadow});
            return;
        }
        original.call(new Object[]{context, renderer, NameTags.decorateText(FakeStats.applyLine(line, text)), x, y, color, shadow});
    }

    @WrapOperation(method={"method_1757(Lnet/minecraft/class_332;Lnet/minecraft/class_266;)V"}, at={@At(value="INVOKE", target="Lnet/minecraft/class_327;method_27525(Lnet/minecraft/class_5348;)I")})
    private int sober$sidebarWidth(class_327 renderer, class_5348 text, Operation<Integer> original) {
        int index = this.sober$widthIndex++;
        if (!(text instanceof class_2561)) {
            return (Integer)original.call(new Object[]{renderer, text});
        }
        class_2561 value = (class_2561)text;
        if (index == 0) {
            return (Integer)original.call(new Object[]{renderer, NameTags.decorateText(value)});
        }
        return (Integer)original.call(new Object[]{renderer, NameTags.decorateText(FakeStats.applyLine(index, value))});
    }
}

