/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1297
 *  net.minecraft.class_1937
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_3532
 *  net.minecraft.class_4184
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Shadow
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.modules.Freecam;
import dev.sober.modules.Freelook;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_4184.class})
public abstract class CameraMixin {
    @Shadow
    private float field_18722;
    @Shadow
    private float field_18721;

    @Shadow
    protected abstract void method_19325(float var1, float var2);

    @Shadow
    protected abstract void method_19322(class_243 var1);

    @Shadow
    protected abstract void method_19324(float var1, float var2, float var3);

    @Shadow
    private float method_19318(float distance) {
        throw new AssertionError();
    }

    @Inject(method={"method_19321"}, at={@At(value="TAIL")})
    private void sober$moveCamera(class_1937 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickProgress, CallbackInfo ci) {
        if (focusedEntity != class_310.method_1551().field_1724) {
            return;
        }
        Freecam freecam = SoberClient.MODULES.get(Freecam.class);
        if (freecam.isActive()) {
            this.method_19325(freecam.yaw(), freecam.pitch());
            this.method_19322(freecam.update());
            return;
        }
        Freelook freelook = SoberClient.MODULES.get(Freelook.class);
        if (freelook.isActive() || freelook.exiting()) {
            this.method_19325(freelook.yaw(), freelook.pitch());
            this.method_19322(new class_243(class_3532.method_16436((double)tickProgress, (double)focusedEntity.field_6014, (double)focusedEntity.method_23317()), class_3532.method_16436((double)tickProgress, (double)focusedEntity.field_6036, (double)focusedEntity.method_23318()) + (double)class_3532.method_16439((float)tickProgress, (float)this.field_18722, (float)this.field_18721), class_3532.method_16436((double)tickProgress, (double)focusedEntity.field_5969, (double)focusedEntity.method_23321())));
            float distance = (float)freelook.distance();
            this.method_19324(-(freelook.throughWalls() ? distance : this.method_19318(distance)), 0.0f, 0.0f);
        }
    }
}

