/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1309
 *  net.minecraft.class_310
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package dev.sober.mixin;

import dev.sober.SoberClient;
import dev.sober.modules.SwingAnimations;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1309.class})
public abstract class LivingEntityMixin {
    @Inject(method={"method_6028"}, at={@At(value="RETURN")}, cancellable=true, require=0)
    private void sober$swingDuration(CallbackInfoReturnable<Integer> cir) {
        if (this != class_310.method_1551().field_1724) {
            return;
        }
        SwingAnimations module = SoberClient.MODULES.get(SwingAnimations.class);
        if (module != null && module.isActive()) {
            cir.setReturnValue((Object)module.duration(cir.getReturnValueI()));
        }
    }
}

