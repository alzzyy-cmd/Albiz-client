/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_11401
 *  net.minecraft.class_4184
 *  net.minecraft.class_638
 *  net.minecraft.class_7285
 *  net.minecraft.class_9779
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 */
package dev.sober.mixin;

import dev.sober.modules.ClearView;
import net.minecraft.class_11401;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_11401.class})
public abstract class LavaFogModifierMixin {
    @Inject(method={"method_42591"}, at={@At(value="RETURN")}, require=0)
    private void sober$clearLava(class_7285 data, class_4184 camera, class_638 world, float viewDistance, class_9779 counter, CallbackInfo ci) {
        try {
            if (!ClearView.clearLava()) {
                return;
            }
        }
        catch (RuntimeException e) {
            return;
        }
        data.field_60582 = viewDistance * 0.5f;
        data.field_60584 = viewDistance;
        data.field_60099 = viewDistance;
        data.field_60100 = viewDistance;
    }
}

