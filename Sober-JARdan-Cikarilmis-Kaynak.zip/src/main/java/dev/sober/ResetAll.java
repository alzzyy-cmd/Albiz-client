/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonObject
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_310
 */
package dev.sober;

import com.google.gson.JsonObject;
import dev.sober.ConfigSlots;
import dev.sober.SoberClient;
import dev.sober.config.FriendStore;
import dev.sober.gui.DropdownScreen;
import dev.sober.gui.HudLayout;
import dev.sober.gui.Notifications;
import dev.sober.modules.CustomGlint;
import dev.sober.util.OwnAreas;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;

public final class ResetAll {
    private static final String[] FILES = new String[]{"soberclient.json", "soberclient-configs.json", "soberclient-dropdown.json", "soberclient-hud-layout.json", "soberclient-areas.json", "sober"};
    private static JsonObject defaults;

    private ResetAll() {
    }

    static void capture() {
        defaults = SoberClient.CONFIG.toJson();
    }

    public static void run() {
        class_310 mc = class_310.method_1551();
        if (defaults == null) {
            return;
        }
        mc.method_1507(null);
        Path backup = ResetAll.moveFiles();
        SoberClient.CONFIG.resetTo(defaults);
        SoberClient.migrate();
        HudLayout.reset();
        DropdownScreen.resetLayout();
        ConfigSlots.reset();
        FriendStore.getInstance().reset();
        OwnAreas.reset();
        SoberClient.MODULES.get(CustomGlint.class).sync();
        SoberClient.CONFIG.save();
        HudLayout.save();
        String where = backup == null ? "" : " Your old files are in config/sober-backups/" + String.valueOf(backup.getFileName()) + ".";
        Notifications.push("Reset All", "SoberClient is reset like on the first start." + where, Notifications.Type.SUCCESS);
    }

    private static Path moveFiles() {
        Path dir = FabricLoader.getInstance().getConfigDir();
        Path backup = dir.resolve("sober-backups").resolve("reset_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss")));
        boolean moved = false;
        for (String name : FILES) {
            Path from = dir.resolve(name);
            if (!Files.exists(from, new LinkOption[0])) continue;
            try {
                Files.createDirectories(backup, new FileAttribute[0]);
                Files.move(from, backup.resolve(name), new CopyOption[0]);
                moved = true;
            }
            catch (IOException e) {
                SoberClient.LOG.warn("Could not move {} out of the way", (Object)name, (Object)e);
            }
        }
        return moved ? backup : null;
    }
}

