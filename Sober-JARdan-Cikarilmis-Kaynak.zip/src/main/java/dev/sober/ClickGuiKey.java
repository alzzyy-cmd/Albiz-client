/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper
 *  net.minecraft.class_2960
 *  net.minecraft.class_304
 *  net.minecraft.class_304$class_11900
 *  net.minecraft.class_310
 *  net.minecraft.class_3675
 *  net.minecraft.class_3675$class_306
 *  net.minecraft.class_3675$class_307
 */
package dev.sober;

import dev.sober.SoberClient;
import dev.sober.modules.ClickGui;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public final class ClickGuiKey {
    private static class_304 binding;
    private static class_3675.class_306 lastBound;
    private static int lastModuleKey;

    private ClickGuiKey() {
    }

    public static void register() {
        binding = KeyBindingHelper.registerKeyBinding((class_304)new class_304("key.sober.clickgui", class_3675.class_307.field_1668, 344, class_304.class_11900.method_74698((class_2960)class_2960.method_60655((String)"sober", (String)"main"))));
    }

    public static void sync(class_310 mc) {
        ClickGui gui = SoberClient.MODULES.get(ClickGui.class);
        if (binding == null || gui == null) {
            return;
        }
        ClickGuiKey.push(mc, gui.getKey());
    }

    public static void tick(class_310 mc) {
        boolean mouse;
        ClickGui gui = SoberClient.MODULES.get(ClickGui.class);
        if (binding == null || gui == null) {
            return;
        }
        if (lastBound == null) {
            ClickGuiKey.push(mc, gui.getKey());
            return;
        }
        class_3675.class_306 bound = KeyBindingHelper.getBoundKeyOf((class_304)binding);
        if (!bound.equals((Object)lastBound)) {
            lastBound = bound;
            int n = lastModuleKey = bound.method_1442() == class_3675.class_307.field_1668 ? bound.method_1444() : -1;
            if (gui.getKey() != lastModuleKey) {
                gui.setKey(lastModuleKey);
                SoberClient.CONFIG.save();
            }
        } else if (gui.getKey() != lastModuleKey) {
            ClickGuiKey.push(mc, gui.getKey());
        }
        boolean bl = mouse = lastBound.method_1442() == class_3675.class_307.field_1672;
        while (binding.method_1436()) {
            if (!mouse || mc.field_1755 != null) continue;
            gui.toggle();
        }
    }

    private static void push(class_310 mc, int code) {
        class_3675.class_306 key = code < 0 ? class_3675.field_16237 : class_3675.class_307.field_1668.method_1447(code);
        lastModuleKey = code;
        lastBound = key;
        if (KeyBindingHelper.getBoundKeyOf((class_304)binding).equals((Object)key)) {
            return;
        }
        binding.method_1422(key);
        class_304.method_1426();
        if (mc.field_1690 != null) {
            mc.field_1690.method_1640();
        }
    }
}

