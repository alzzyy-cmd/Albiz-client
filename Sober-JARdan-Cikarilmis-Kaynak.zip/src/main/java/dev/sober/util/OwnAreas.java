/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_1923
 *  net.minecraft.class_310
 */
package dev.sober.util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.sober.SoberClient;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1923;
import net.minecraft.class_310;

public final class OwnAreas {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("soberclient-areas.json");
    private static final Gson GSON = new Gson();
    private static final Map<String, Set<Long>> AREAS = new HashMap<String, Set<Long>>();
    private static boolean loaded;

    private OwnAreas() {
    }

    public static String currentKey() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            return null;
        }
        Object server = mc.method_1558() != null ? mc.method_1558().field_3761.toLowerCase() : (mc.method_1576() != null ? "singleplayer:" + mc.method_1576().method_27728().method_150() : "unknown");
        return (String)server + "|" + String.valueOf(mc.field_1687.method_27983().method_29177());
    }

    public static synchronized Set<Long> get(String key) {
        OwnAreas.load();
        return AREAS.computeIfAbsent(key, k -> new HashSet());
    }

    public static synchronized void add(String key, class_1923 pos) {
        if (OwnAreas.get(key).add(pos.method_8324())) {
            OwnAreas.save();
        }
    }

    public static synchronized void clear(String key) {
        if (OwnAreas.get(key).isEmpty()) {
            return;
        }
        AREAS.get(key).clear();
        OwnAreas.save();
    }

    public static synchronized void reset() {
        AREAS.clear();
        loaded = false;
    }

    public static synchronized boolean isNear(String key, class_1923 pos, int radius) {
        for (long packed : OwnAreas.get(key)) {
            int x = class_1923.method_8325((long)packed);
            int z = class_1923.method_8332((long)packed);
            if (Math.abs(x - pos.field_9181) > radius || Math.abs(z - pos.field_9180) > radius) continue;
            return true;
        }
        return false;
    }

    private static void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        if (!Files.exists(FILE, new LinkOption[0])) {
            return;
        }
        try {
            JsonObject root = JsonParser.parseString((String)Files.readString(FILE, StandardCharsets.UTF_8)).getAsJsonObject();
            for (Map.Entry entry : root.entrySet()) {
                HashSet<Long> set = new HashSet<Long>();
                for (JsonElement element : ((JsonElement)entry.getValue()).getAsJsonArray()) {
                    set.add(element.getAsLong());
                }
                AREAS.put((String)entry.getKey(), set);
            }
        }
        catch (Exception e) {
            SoberClient.LOG.error("Could not load own areas", (Throwable)e);
        }
    }

    private static void save() {
        JsonObject root = new JsonObject();
        for (Map.Entry<String, Set<Long>> entry : AREAS.entrySet()) {
            if (entry.getValue().isEmpty()) continue;
            JsonArray array = new JsonArray();
            for (long packed : entry.getValue()) {
                array.add((Number)packed);
            }
            root.add(entry.getKey(), (JsonElement)array);
        }
        try {
            Files.createDirectories(FILE.getParent(), new FileAttribute[0]);
            Files.writeString(FILE, (CharSequence)GSON.toJson((JsonElement)root), StandardCharsets.UTF_8, new OpenOption[0]);
        }
        catch (Exception e) {
            SoberClient.LOG.error("Could not save own areas", (Throwable)e);
        }
    }
}

