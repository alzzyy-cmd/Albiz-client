/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_310
 *  net.minecraft.class_408
 */
package dev.sober.util;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_310;
import net.minecraft.class_408;

public final class FractionalGuiScale {
    private static final MethodHandle SCALE_FOR = FractionalGuiScale.find();
    private static boolean failed;

    private FractionalGuiScale() {
    }

    private static MethodHandle find() {
        if (!FabricLoader.getInstance().isModLoaded("precise-gui-scale")) {
            return null;
        }
        try {
            Class<?> controller = Class.forName("com.scale.preciseguiscale.ScaleController");
            return MethodHandles.publicLookup().findStatic(controller, "scaleFor", MethodType.methodType(Double.TYPE, class_310.class));
        }
        catch (LinkageError | ReflectiveOperationException e) {
            return null;
        }
    }

    public static double uncorrectedScale(class_310 mc) {
        double scale;
        if (SCALE_FOR == null || failed) {
            return 0.0;
        }
        if (mc.field_1755 != null && !(mc.field_1755 instanceof class_408)) {
            return 0.0;
        }
        try {
            scale = SCALE_FOR.invokeExact(mc);
        }
        catch (Throwable e) {
            failed = true;
            return 0.0;
        }
        if (!(scale > 0.0)) {
            return 0.0;
        }
        return Math.abs((scale = Math.max(0.5, Math.min(8.0, scale))) - (double)mc.method_22683().method_4495()) > 0.001 ? scale : 0.0;
    }
}

