/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 *  net.minecraft.class_1922
 *  net.minecraft.class_1923
 *  net.minecraft.class_1937
 *  net.minecraft.class_2338
 *  net.minecraft.class_2338$class_2339
 */
package dev.sober.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

public final class Shafts {
    private Shafts() {
    }

    public static List<Shaft> find(class_1937 world, class_1923 chunkPos, int minDepth, boolean oneByOne, boolean threeByOne) {
        ArrayList<Shaft> found = new ArrayList<Shaft>();
        if (!oneByOne && !threeByOne) {
            return found;
        }
        int bottomY = world.method_31607();
        int topY = world.method_31600();
        class_2338.class_2339 m = new class_2338.class_2339();
        for (int x = chunkPos.method_8326(); x < chunkPos.method_8326() + 16; ++x) {
            for (int z = chunkPos.method_8328(); z < chunkPos.method_8328() + 16; ++z) {
                if (oneByOne) {
                    Shafts.scanColumn(world, found, m, x, z, bottomY, topY, minDepth, Shape.ONE);
                }
                if (!threeByOne) continue;
                Shafts.scanColumn(world, found, m, x, z, bottomY, topY, minDepth, Shape.THREE_X);
                Shafts.scanColumn(world, found, m, x, z, bottomY, topY, minDepth, Shape.THREE_Z);
            }
        }
        return found;
    }

    private static void scanColumn(class_1937 world, List<Shaft> out, class_2338.class_2339 m, int x, int z, int bottomY, int topY, int depth, Shape shape) {
        int run = 0;
        for (int y = bottomY; y <= topY + 1; ++y) {
            if (y <= topY && Shafts.matches(world, m, x, y, z, shape)) {
                ++run;
                continue;
            }
            if (run >= depth) {
                out.add(new Shaft(x, y - run, z, y, shape));
            }
            run = 0;
        }
    }

    private static boolean matches(class_1937 w, class_2338.class_2339 m, int x, int y, int z, Shape shape) {
        return switch (shape.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> {
                if (!(!Shafts.open(w, m, x, y, z) || Shafts.open(w, m, x - 1, y, z) || Shafts.open(w, m, x + 1, y, z) || Shafts.open(w, m, x, y, z - 1) || Shafts.open(w, m, x, y, z + 1))) {
                    yield true;
                }
                yield false;
            }
            case 1 -> {
                if (!(!Shafts.open(w, m, x, y, z) || !Shafts.open(w, m, x + 1, y, z) || !Shafts.open(w, m, x + 2, y, z) || Shafts.open(w, m, x - 1, y, z) || Shafts.open(w, m, x + 3, y, z) || Shafts.open(w, m, x, y, z - 1) || Shafts.open(w, m, x, y, z + 1) || Shafts.open(w, m, x + 1, y, z - 1) || Shafts.open(w, m, x + 1, y, z + 1) || Shafts.open(w, m, x + 2, y, z - 1) || Shafts.open(w, m, x + 2, y, z + 1))) {
                    yield true;
                }
                yield false;
            }
            case 2 -> Shafts.open(w, m, x, y, z) && Shafts.open(w, m, x, y, z + 1) && Shafts.open(w, m, x, y, z + 2) && !Shafts.open(w, m, x, y, z - 1) && !Shafts.open(w, m, x, y, z + 3) && !Shafts.open(w, m, x - 1, y, z) && !Shafts.open(w, m, x + 1, y, z) && !Shafts.open(w, m, x - 1, y, z + 1) && !Shafts.open(w, m, x + 1, y, z + 1) && !Shafts.open(w, m, x - 1, y, z + 2) && !Shafts.open(w, m, x + 1, y, z + 2);
        };
    }

    private static boolean open(class_1937 world, class_2338.class_2339 m, int x, int y, int z) {
        m.method_10103(x, y, z);
        return world.method_8320((class_2338)m).method_26220((class_1922)world, (class_2338)m).method_1110();
    }

    public static enum Shape {
        ONE(1, 1),
        THREE_X(3, 1),
        THREE_Z(1, 3);

        public final int sizeX;
        public final int sizeZ;

        private Shape(int sizeX, int sizeZ) {
            this.sizeX = sizeX;
            this.sizeZ = sizeZ;
        }
    }

    public record Shaft(int x, int minY, int z, int maxY, Shape shape) {
    }
}

