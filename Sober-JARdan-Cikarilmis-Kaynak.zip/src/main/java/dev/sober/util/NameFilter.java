/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.util;

import java.util.function.UnaryOperator;

public final class NameFilter {
    private static volatile UnaryOperator<String> filter = UnaryOperator.identity();

    private NameFilter() {
    }

    public static String apply(String name) {
        if (name == null) {
            return null;
        }
        String shown = (String)filter.apply(name);
        return shown != null ? shown : name;
    }

    public static void set(UnaryOperator<String> newFilter) {
        filter = newFilter != null ? newFilter : UnaryOperator.identity();
    }
}

