/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1657
 *  net.minecraft.class_1713
 *  net.minecraft.class_1792
 *  net.minecraft.class_1799
 *  net.minecraft.class_310
 */
package dev.sober.util;

import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public final class InvUtil {
    private static final class_310 mc = class_310.method_1551();

    private InvUtil() {
    }

    public static int count(class_1792 item) {
        if (InvUtil.mc.field_1724 == null) {
            return 0;
        }
        int count = 0;
        for (int i = 0; i < 36; ++i) {
            class_1799 stack = InvUtil.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_31574(item)) continue;
            count += stack.method_7947();
        }
        return count;
    }

    public static boolean has(class_1792 item) {
        return InvUtil.find(item, 0, 35) != -1;
    }

    public static int findHotbar(class_1792 item) {
        return InvUtil.find(item, 0, 8);
    }

    public static int findMain(class_1792 item) {
        return InvUtil.find(item, 9, 35);
    }

    private static int find(class_1792 item, int from, int to) {
        if (InvUtil.mc.field_1724 == null) {
            return -1;
        }
        for (int i = from; i <= to; ++i) {
            if (!InvUtil.mc.field_1724.method_31548().method_5438(i).method_31574(item)) continue;
            return i;
        }
        return -1;
    }

    public static void select(int hotbarSlot) {
        if (InvUtil.mc.field_1724 != null) {
            InvUtil.mc.field_1724.method_31548().method_61496(hotbarSlot);
        }
    }

    public static void moveToHotbar(int inventorySlot, int hotbarSlot) {
        if (InvUtil.mc.field_1724 == null || InvUtil.mc.field_1761 == null) {
            return;
        }
        int screenSlot = inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;
        InvUtil.mc.field_1761.method_2906(InvUtil.mc.field_1724.field_7498.field_7763, screenSlot, hotbarSlot, class_1713.field_7791, (class_1657)InvUtil.mc.field_1724);
    }
}

