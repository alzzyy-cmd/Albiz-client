/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonArray
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 */
package dev.sober.util;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public final class AcOffFeed {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8L)).build();
    private volatile Snapshot snapshot = Snapshot.EMPTY;
    private volatile boolean polling;
    private long lastPoll;

    public Snapshot snapshot() {
        return this.snapshot;
    }

    public void reset() {
        this.snapshot = Snapshot.EMPTY;
        this.lastPoll = 0L;
    }

    public void poll(String url, int intervalSeconds, Consumer<Snapshot> onResult) {
        HttpRequest request;
        long now = System.currentTimeMillis();
        if (this.polling || now - this.lastPoll < (long)intervalSeconds * 1000L) {
            return;
        }
        this.lastPoll = now;
        try {
            request = HttpRequest.newBuilder(URI.create(url.trim())).timeout(Duration.ofSeconds(8L)).header("User-Agent", "SoberClient").GET().build();
        }
        catch (IllegalArgumentException e) {
            this.finish(this.failed("Invalid feed URL", now), onResult);
            return;
        }
        this.polling = true;
        HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString()).whenComplete((response, error) -> {
            Snapshot next;
            if (error != null) {
                next = this.failed("Feed not reachable", now);
            } else if (response.statusCode() != 200) {
                next = this.failed("Feed answered " + response.statusCode(), now);
            } else {
                try {
                    next = AcOffFeed.parse((String)response.body(), now);
                }
                catch (RuntimeException e) {
                    next = this.failed("Feed sent unreadable data", now);
                }
            }
            this.polling = false;
            this.finish(next, onResult);
        });
    }

    private void finish(Snapshot next, Consumer<Snapshot> onResult) {
        this.snapshot = next;
        onResult.accept(next);
    }

    private Snapshot failed(String error, long now) {
        Snapshot last = this.snapshot;
        return new Snapshot(last.updatedAt(), last.spots(), error, now);
    }

    static Snapshot parse(String body, long now) {
        JsonObject root = JsonParser.parseString((String)body).getAsJsonObject();
        String updatedAt = root.has("updatedAt") ? root.get("updatedAt").getAsString() : "";
        ArrayList<Spot> spots = new ArrayList<Spot>();
        if (root.has("alerts") && root.get("alerts").isJsonArray()) {
            JsonArray alerts = root.getAsJsonArray("alerts");
            for (JsonElement element : alerts) {
                if (!element.isJsonObject()) continue;
                JsonObject o = element.getAsJsonObject();
                boolean test = o.has("test") && o.get("test").getAsBoolean();
                int goliath = o.has("goliath") ? o.get("goliath").getAsInt() : -1;
                int newGoliath = o.has("newGoliath") ? o.get("newGoliath").getAsInt() : goliath;
                int oldGoliath = o.has("oldGoliath") ? o.get("oldGoliath").getAsInt() : goliath;
                String region = o.has("region") ? o.get("region").getAsString() : "Unknown";
                String coords = o.has("coords") ? o.get("coords").getAsString() : "";
                double x = 0.0;
                double y = 0.0;
                double z = 0.0;
                if (o.has("position") && o.get("position").isJsonObject()) {
                    JsonObject p = o.getAsJsonObject("position");
                    x = p.has("x") ? p.get("x").getAsDouble() : 0.0;
                    y = p.has("y") ? p.get("y").getAsDouble() : 0.0;
                    z = p.has("z") ? p.get("z").getAsDouble() : 0.0;
                } else {
                    String[] parts = coords.trim().split("\\s+");
                    if (parts.length >= 3) {
                        try {
                            x = Double.parseDouble(parts[0]);
                            y = Double.parseDouble(parts[1]);
                            z = Double.parseDouble(parts[2]);
                        }
                        catch (NumberFormatException numberFormatException) {
                            // empty catch block
                        }
                    }
                }
                spots.add(new Spot(test, newGoliath, oldGoliath, region, coords, x, y, z));
            }
        }
        return new Snapshot(updatedAt, List.copyOf(spots), null, now);
    }

    public record Snapshot(String updatedAt, List<Spot> spots, String error, long fetchedAt) {
        public static final Snapshot EMPTY = new Snapshot("", List.of(), null, 0L);

        public boolean loaded() {
            return this.fetchedAt != 0L;
        }
    }

    public record Spot(boolean test, int goliath, int oldGoliath, String region, String coords, double x, double y, double z) {
        public String key() {
            return this.region + "|" + this.coords + "|" + this.goliath + "|" + this.test;
        }
    }
}

