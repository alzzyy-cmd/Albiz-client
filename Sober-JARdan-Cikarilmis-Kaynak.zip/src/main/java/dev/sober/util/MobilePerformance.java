/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.util;

public final class MobilePerformance {
    private static final boolean ANDROID = false;

    private MobilePerformance() {
    }

    public static boolean isAndroid() {
        return false;
    }

    public static boolean active() {
        return false;
    }

    public static int segments(int original, int minimum) {
        return MobilePerformance.reduce(original, minimum);
    }

    public static int particles(int original, int minimum) {
        return MobilePerformance.reduce(original, minimum);
    }

    public static int trailSamples(int original, int minimum) {
        return MobilePerformance.reduce(original, minimum);
    }

    public static int uiSegments(int original, float radiusPixels) {
        if (MobilePerformance.active() && original > 12 && Float.isFinite(radiusPixels) && !(radiusPixels <= 0.0f)) {
            double angle = Math.acos(Math.max(-1.0, 1.0 - 0.35 / (double)radiusPixels));
            if (angle <= 0.0) {
                return original;
            }
            int needed = (int)Math.ceil(Math.PI / angle);
            return needed >= original ? original : Math.min(original, Math.max(12, (needed + 3) / 4 * 4));
        }
        return original;
    }

    private static int reduce(int original, int minimum) {
        return MobilePerformance.active() && original > 0 ? Math.min(original, Math.max(minimum, original / 2 + original % 2)) : original;
    }
}

