/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1011
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  org.lwjgl.glfw.GLFW
 *  org.lwjgl.glfw.GLFWImage
 *  org.lwjgl.glfw.GLFWImage$Buffer
 *  org.lwjgl.system.MemoryStack
 *  org.lwjgl.system.MemoryUtil
 */
package dev.sober.gui;

import dev.sober.SoberClient;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import net.minecraft.class_1011;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

public final class BrandWindow {
    private static final int[] SIZES = new int[]{16, 32, 48, 64, 128, 256};

    private BrandWindow() {
    }

    public static String title(String vanilla) {
        return vanilla == null ? "Minecraft | SoberClient" : vanilla + " | SoberClient";
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void apply(class_310 client) {
        int platform = GLFW.glfwGetPlatform();
        if (platform != 393217 && platform != 393220) {
            client.method_24288();
            return;
        }
        ArrayList<ByteBuffer> buffers = new ArrayList<ByteBuffer>();
        try (MemoryStack stack = MemoryStack.stackPush();){
            GLFWImage.Buffer images = GLFWImage.malloc((int)SIZES.length, (MemoryStack)stack);
            int count = 0;
            for (int size : SIZES) {
                try (InputStream stream = client.method_1478().open(class_2960.method_60655((String)"sober", (String)("textures/brand/icon_" + size + ".png")));
                     class_1011 image = class_1011.method_4309((InputStream)stream);){
                    ByteBuffer pixels = MemoryUtil.memAlloc((int)(image.method_4307() * image.method_4323() * 4));
                    buffers.add(pixels);
                    pixels.asIntBuffer().put(image.method_48463());
                    images.position(count);
                    images.width(image.method_4307());
                    images.height(image.method_4323());
                    images.pixels(pixels);
                    ++count;
                }
            }
            if (count > 0) {
                images.position(0);
                images.limit(count);
                GLFW.glfwSetWindowIcon((long)client.method_22683().method_4490(), (GLFWImage.Buffer)images);
            }
        }
        catch (Exception e) {
            SoberClient.LOG.warn("Could not set the SoberClient window icon", (Throwable)e);
        }
        finally {
            buffers.forEach(MemoryUtil::memFree);
        }
        client.method_24288();
    }
}

