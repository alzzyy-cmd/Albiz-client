/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 *  net.minecraft.class_1102
 *  net.minecraft.class_1111
 *  net.minecraft.class_1111$class_1112
 *  net.minecraft.class_1113
 *  net.minecraft.class_1113$class_1114
 *  net.minecraft.class_1144
 *  net.minecraft.class_1146
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3419
 *  net.minecraft.class_4231
 */
package dev.sober.gui;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import javax.sound.sampled.AudioFormat;
import net.minecraft.class_1102;
import net.minecraft.class_1111;
import net.minecraft.class_1113;
import net.minecraft.class_1144;
import net.minecraft.class_1146;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3419;
import net.minecraft.class_4231;

public final class KeySynth {
    private static final int RATE = 44100;
    private static final AudioFormat FORMAT;
    private static final AudioFormat RECORDED_FORMAT;
    private static final Map<String, Integer> COUNTS;
    private static final Random RANDOM;
    private static final String PREFIX = "sounds/keys/";
    private static final class_1146 SET;
    private static final Map<Integer, Double> COLUMNS;

    private KeySynth() {
    }

    public static boolean handles(class_2960 location) {
        return location.method_12836().equals("sober") && location.method_12832().startsWith(PREFIX);
    }

    public static void play(Profile profile, int key, boolean release, float volume, boolean stereo) {
        float pitch;
        int variants;
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_1483() == null || volume <= 0.0f) {
            return;
        }
        Kind kind = KeySynth.kind(key, release);
        boolean recorded = KeySynth.recorded(profile);
        Kind slot = recorded ? KeySynth.recordedSlot(profile, kind) : kind;
        int n = variants = recorded ? KeySynth.count(profile, slot) : kind.variants;
        if (variants <= 0) {
            return;
        }
        boolean realSpace = recorded && (slot == Kind.SPACE || slot == Kind.SPACE_RELEASE);
        int hash = KeySynth.mixKey(key);
        int variant = realSpace ? RANDOM.nextInt(variants) : Math.floorMod(hash, variants);
        double pan = stereo && !recorded ? KeySynth.pan(key) : 0.0;
        float f = pitch = realSpace ? 1.0f : 1.0f + ((float)Math.floorMod(hash >>> 8, 1000) / 1000.0f - 0.5f) * 0.07f;
        if (recorded && !realSpace && (kind == Kind.SPACE || kind == Kind.SPACE_RELEASE)) {
            pitch *= 0.9f;
        } else if (recorded && (kind == Kind.STAB || kind == Kind.STAB_RELEASE)) {
            pitch *= 0.95f;
        }
        class_2960 id = class_2960.method_60655((String)"sober", (String)("keys/" + profile.name().toLowerCase() + "_" + slot.name().toLowerCase() + "_" + variant));
        mc.method_1483().method_4873((class_1113)new KeySound(id, Math.min(1.0f, volume), pitch, pan));
    }

    public static void playMouse(float volume) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_1483() == null || volume <= 0.0f) {
            return;
        }
        mc.method_1483().method_4873((class_1113)new KeySound(class_2960.method_60655((String)"sober", (String)"keys/mouse_click_0"), Math.min(1.0f, volume), 1.0f, 0.0));
    }

    private static int mixKey(int key) {
        int h = key * -1640531535;
        h ^= h >>> 15;
        h *= -2048144789;
        h ^= h >>> 13;
        return h;
    }

    private static Kind kind(int key, boolean release) {
        boolean stab;
        if (key == 32) {
            return release ? Kind.SPACE_RELEASE : Kind.SPACE;
        }
        boolean bl = stab = key == 257 || key == 335 || key == 259 || key == 340 || key == 344 || key == 258 || key == 280;
        if (stab) {
            return release ? Kind.STAB_RELEASE : Kind.STAB;
        }
        return release ? Kind.RELEASE : Kind.PRESS;
    }

    private static double pan(int key) {
        double column = COLUMNS.getOrDefault(key, 7.0);
        return Math.max(-1.0, Math.min(1.0, column / 14.5 * 2.0 - 1.0)) * 0.55;
    }

    public static class_4231 create(class_2960 location) {
        ByteBuffer mouse;
        String name = location.method_12832().substring(PREFIX.length());
        if (name.endsWith(".ogg")) {
            name = name.substring(0, name.length() - 4);
        }
        if (name.startsWith("mouse_") && (mouse = KeySynth.recorded("mouse/" + name.substring(6, name.lastIndexOf(95) + 1), 0)) != null) {
            return new class_4231(mouse, RECORDED_FORMAT);
        }
        String[] parts = name.split("_");
        Profile profile = Profile.Creamy;
        for (Profile profile2 : Profile.values()) {
            if (!profile2.name().equalsIgnoreCase(parts[0])) continue;
            profile = profile2;
        }
        int variant = 0;
        try {
            variant = Integer.parseInt(parts[parts.length - 1]);
        }
        catch (NumberFormatException numberFormatException) {
            // empty catch block
        }
        String kindName = name.substring(parts[0].length() + 1, name.length() - parts[parts.length - 1].length() - 1).toUpperCase();
        Kind kind = Kind.PRESS;
        for (Kind k : Kind.values()) {
            if (!k.name().equals(kindName)) continue;
            kind = k;
        }
        if (KeySynth.recorded(profile)) {
            ByteBuffer byteBuffer = KeySynth.recorded(KeySynth.folder(profile) + KeySynth.prefix(KeySynth.recordedSlot(profile, kind)), variant);
            if (byteBuffer != null) {
                return new class_4231(byteBuffer, RECORDED_FORMAT);
            }
            profile = Profile.Creamy;
        }
        short[] sArray = KeySynth.render(profile, kind, variant);
        ByteBuffer buffer = ByteBuffer.allocateDirect(sArray.length * 2).order(ByteOrder.LITTLE_ENDIAN);
        for (short sample : sArray) {
            buffer.putShort(sample);
        }
        buffer.flip();
        return new class_4231(buffer, FORMAT);
    }

    private static boolean recorded(Profile profile) {
        return profile == Profile.Recorded || profile == Profile.Fb67 || profile == Profile.He60v2 || profile == Profile.Frost65;
    }

    private static String folder(Profile profile) {
        return switch (profile.ordinal()) {
            case 1 -> "fb67/";
            case 2 -> "60he_v2/";
            case 3 -> "frost65/";
            default -> "";
        };
    }

    private static Kind recordedSlot(Profile profile, Kind kind) {
        if ((kind == Kind.SPACE || kind == Kind.SPACE_RELEASE) && KeySynth.count(profile, kind) > 0) {
            return kind;
        }
        return kind.release() ? Kind.RELEASE : Kind.PRESS;
    }

    private static String prefix(Kind slot) {
        return slot.name().toLowerCase() + "_";
    }

    private static int count(Profile profile, Kind slot) {
        return COUNTS.computeIfAbsent(KeySynth.folder(profile) + KeySynth.prefix(slot), path -> {
            int n;
            for (n = 0; n < 64 && KeySynth.class.getResource("/assets/sober/keysamples/" + path + n + ".pcm") != null; ++n) {
            }
            return n;
        });
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private static ByteBuffer recorded(String prefix, int variant) {
        try (InputStream in = KeySynth.class.getResourceAsStream("/assets/sober/keysamples/" + prefix + variant + ".pcm");){
            if (in == null) {
                ByteBuffer byteBuffer2 = null;
                return byteBuffer2;
            }
            byte[] data = in.readAllBytes();
            ByteBuffer buffer = ByteBuffer.allocateDirect(data.length).order(ByteOrder.LITTLE_ENDIAN);
            buffer.put(data);
            buffer.flip();
            ByteBuffer byteBuffer = buffer;
            return byteBuffer;
        }
        catch (IOException e) {
            return null;
        }
    }

    private static Mode[] modes(Profile profile) {
        Mode[] modeArray;
        switch (profile.ordinal()) {
            default: {
                throw new MatchException(null, null);
            }
            case 0: 
            case 1: 
            case 2: 
            case 3: 
            case 4: {
                Mode[] modeArray2 = new Mode[4];
                modeArray2[0] = new Mode(205.0, 0.02, 1.0);
                modeArray2[1] = new Mode(520.0, 0.011, 0.55);
                modeArray2[2] = new Mode(1240.0, 0.0055, 0.24);
                modeArray = modeArray2;
                modeArray2[3] = new Mode(2550.0, 0.0028, 0.09);
                break;
            }
            case 5: {
                Mode[] modeArray3 = new Mode[4];
                modeArray3[0] = new Mode(150.0, 0.028, 1.0);
                modeArray3[1] = new Mode(370.0, 0.015, 0.62);
                modeArray3[2] = new Mode(880.0, 0.0075, 0.2);
                modeArray = modeArray3;
                modeArray3[3] = new Mode(1900.0, 0.003, 0.06);
                break;
            }
            case 6: {
                Mode[] modeArray4 = new Mode[4];
                modeArray4[0] = new Mode(620.0, 0.009, 0.45);
                modeArray4[1] = new Mode(2900.0, 0.0032, 0.75);
                modeArray4[2] = new Mode(4300.0, 0.0022, 0.5);
                modeArray = modeArray4;
                modeArray4[3] = new Mode(6100.0, 0.0014, 0.25);
                break;
            }
            case 7: {
                Mode[] modeArray5 = new Mode[4];
                modeArray5[0] = new Mode(330.0, 0.014, 0.8);
                modeArray5[1] = new Mode(1050.0, 0.0085, 0.75);
                modeArray5[2] = new Mode(2150.0, 0.0045, 0.4);
                modeArray = modeArray5;
                modeArray5[3] = new Mode(3600.0, 0.0025, 0.18);
            }
        }
        return modeArray;
    }

    private static double noiseLevel(Profile profile) {
        return switch (profile.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0, 1, 2, 3, 4 -> 0.28;
            case 5 -> 0.22;
            case 6 -> 0.55;
            case 7 -> 0.35;
        };
    }

    private static double cutoff(Profile profile) {
        return switch (profile.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0, 1, 2, 3, 4 -> 4200.0;
            case 5 -> 3200.0;
            case 6 -> 9500.0;
            case 7 -> 6500.0;
        };
    }

    private static short[] render(Profile profile, Kind kind, int variant) {
        int delay;
        double decayScale;
        Random random = new Random((long)profile.ordinal() * 7919L + (long)kind.ordinal() * 104729L + (long)variant * 15485863L + 17L);
        boolean release = kind.release();
        boolean space = kind == Kind.SPACE || kind == Kind.SPACE_RELEASE;
        boolean stab = kind == Kind.STAB || kind == Kind.STAB_RELEASE;
        double freqScale = release ? 1.45 : 1.0;
        double d = decayScale = release ? 0.6 : 1.0;
        if (space) {
            freqScale *= 0.74;
            decayScale *= 1.65;
        } else if (stab) {
            freqScale *= 0.86;
            decayScale *= 1.3;
        }
        double duration = (release ? 0.055 : 0.085) * (space ? 1.6 : (stab ? 1.3 : 1.0));
        int n = (int)(44100.0 * duration);
        double[] out = new double[n];
        Mode[] modes = KeySynth.modes(profile);
        KeySynth.hit(out, 0, modes, freqScale, decayScale, 1.0, random, profile, release);
        if (space || stab) {
            delay = (int)(44100.0 * (space ? 0.009 + random.nextDouble() * 0.005 : 0.006 + random.nextDouble() * 0.003));
            KeySynth.hit(out, delay, modes, freqScale * 1.12, decayScale * 0.7, space ? 0.28 : 0.16, random, profile, release);
        }
        if (profile == Profile.Clicky && !release) {
            delay = (int)(44100.0 * (0.0045 + random.nextDouble() * 0.0015));
            KeySynth.hit(out, delay, modes, 1.08, 0.8, 0.6, random, profile, false);
        }
        double alpha = 1.0 - Math.exp(Math.PI * -2 * KeySynth.cutoff(profile) * (release ? 1.15 : 1.0) / 44100.0);
        double low = 0.0;
        double dc = 0.0;
        double peak = 1.0E-9;
        for (int i = 0; i < n; ++i) {
            low += alpha * (out[i] - low);
            dc += 0.0025 * (low - dc);
            out[i] = low - dc;
            peak = Math.max(peak, Math.abs(out[i]));
        }
        double target = release ? 0.5 : (space ? 0.95 : 0.9);
        int fade = Math.min(n, 176);
        short[] samples = new short[n];
        for (int i = 0; i < n; ++i) {
            double v = out[i] / peak * target;
            if (i >= n - fade) {
                v *= (double)(n - i) / (double)fade;
            }
            samples[i] = (short)Math.round(Math.max(-1.0, Math.min(1.0, v)) * 32767.0);
        }
        return samples;
    }

    private static void hit(double[] out, int start, Mode[] modes, double freqScale, double decayScale, double gain, Random random, Profile profile, boolean release) {
        double t;
        double env;
        int n = out.length;
        for (Mode mode : modes) {
            double t2;
            double env2;
            double freq = mode.freq() * freqScale * (1.0 + random.nextGaussian() * 0.05);
            double decay = mode.decay() * decayScale * (1.0 + random.nextGaussian() * 0.12);
            double amp = mode.amp() * gain * (1.0 + random.nextGaussian() * 0.08) * (release ? 0.7 : 1.0);
            double phase = random.nextDouble() * Math.PI * 2.0;
            double chirp = 0.06 + random.nextDouble() * 0.05;
            int i = start;
            while (!(i >= n || (env2 = Math.exp(-(t2 = (double)(i - start) / 44100.0) / Math.max(8.0E-4, decay)) * (1.0 - Math.exp(-t2 / 3.5E-4))) < 1.0E-5 && t2 > 0.003)) {
                double f = freq * (1.0 + chirp * Math.exp(-t2 / 0.004));
                int n2 = i++;
                out[n2] = out[n2] + amp * env2 * Math.sin(phase += Math.PI * 2 * f / 44100.0);
            }
        }
        double noise = KeySynth.noiseLevel(profile) * gain * (release ? 0.6 : 1.0);
        double noiseDecay = profile == Profile.Clicky ? 0.0022 : 0.0016;
        double filtered = 0.0;
        int i = start;
        while (i < n && !((env = Math.exp(-(t = (double)(i - start) / 44100.0) / noiseDecay)) < 1.0E-4)) {
            filtered += 0.45 * (random.nextGaussian() - filtered);
            int n3 = i++;
            out[n3] = out[n3] + noise * env * filtered;
        }
    }

    static {
        int i;
        FORMAT = new AudioFormat(44100.0f, 16, 1, true, false);
        RECORDED_FORMAT = new AudioFormat(48000.0f, 16, 2, true, false);
        COUNTS = new ConcurrentHashMap<String, Integer>();
        RANDOM = new Random();
        SET = new class_1146(class_2960.method_60655((String)"sober", (String)"keys"), null);
        COLUMNS = new HashMap<Integer, Double>();
        String digits = "1234567890";
        for (int i2 = 0; i2 < digits.length(); ++i2) {
            COLUMNS.put(Integer.valueOf(digits.charAt(i2)), 1.0 + (double)i2);
        }
        String top = "QWERTYUIOP";
        String middle = "ASDFGHJKL";
        String bottom = "ZXCVBNM";
        for (i = 0; i < top.length(); ++i) {
            COLUMNS.put(Integer.valueOf(top.charAt(i)), 1.5 + (double)i);
        }
        for (i = 0; i < middle.length(); ++i) {
            COLUMNS.put(Integer.valueOf(middle.charAt(i)), 1.75 + (double)i);
        }
        for (i = 0; i < bottom.length(); ++i) {
            COLUMNS.put(Integer.valueOf(bottom.charAt(i)), 2.25 + (double)i);
        }
        COLUMNS.put(96, 0.0);
        COLUMNS.put(256, 0.0);
        COLUMNS.put(258, 0.5);
        COLUMNS.put(280, 0.8);
        COLUMNS.put(340, 1.0);
        COLUMNS.put(341, 0.6);
        COLUMNS.put(342, 2.4);
        COLUMNS.put(32, 6.5);
        COLUMNS.put(346, 9.5);
        COLUMNS.put(345, 13.0);
        COLUMNS.put(45, 11.0);
        COLUMNS.put(61, 12.0);
        COLUMNS.put(259, 13.5);
        COLUMNS.put(91, 11.5);
        COLUMNS.put(93, 12.5);
        COLUMNS.put(92, 13.75);
        COLUMNS.put(59, 10.75);
        COLUMNS.put(39, 11.75);
        COLUMNS.put(257, 13.4);
        COLUMNS.put(44, 9.25);
        COLUMNS.put(46, 10.25);
        COLUMNS.put(47, 11.25);
        COLUMNS.put(344, 13.2);
        COLUMNS.put(263, 15.5);
        COLUMNS.put(264, 16.5);
        COLUMNS.put(265, 16.5);
        COLUMNS.put(262, 17.5);
        for (i = 0; i < 12; ++i) {
            COLUMNS.put(290 + i, 1.0 + (double)i * 1.05);
        }
    }

    public static enum Kind {
        PRESS(8),
        RELEASE(6),
        SPACE(4),
        SPACE_RELEASE(3),
        STAB(4),
        STAB_RELEASE(3);

        final int variants;

        private Kind(int variants) {
            this.variants = variants;
        }

        boolean release() {
            return this == RELEASE || this == SPACE_RELEASE || this == STAB_RELEASE;
        }
    }

    public static enum Profile {
        Recorded,
        Fb67,
        He60v2,
        Frost65,
        Creamy,
        Thocky,
        Clicky,
        Marble;

    }

    private static final class KeySound
    extends class_1102 {
        KeySound(class_2960 id, float volume, float pitch, double pan) {
            super(id, class_3419.field_61058, class_1113.method_43221());
            this.field_5442 = volume;
            this.field_5441 = pitch;
            this.field_18936 = true;
            this.field_5440 = class_1113.class_1114.field_5478;
            this.field_5439 = pan;
            this.field_5450 = 0.0;
            this.field_5449 = pan == 0.0 ? 0.0 : -1.0;
        }

        public class_1146 method_4783(class_1144 soundManager) {
            this.field_5444 = new class_1111(this.field_5448, random -> 1.0f, random -> 1.0f, 1, class_1111.class_1112.field_5474, false, false, 16);
            return SET;
        }
    }

    private record Mode(double freq, double decay, double amp) {
    }
}

