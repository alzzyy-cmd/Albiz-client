/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 */
package dev.sober.gui;

import dev.sober.gui.BrandTextures;
import dev.sober.gui.CrispText;
import dev.sober.gui.MenuKit;
import dev.sober.gui.Smooth;
import dev.sober.gui.SoberScreen;
import dev.sober.util.NameFilter;
import java.util.Locale;
import java.util.UUID;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class VanishAlert {
    private static final float IN = 0.35f;
    private static final float STAY = 3.6f;
    private static final float OUT = 1.1f;
    private static final String BOLD = "montserrat-bold.ttf";
    private static final String BLACK = "montserrat-black.ttf";
    private static String title;
    private static long startNanos;
    private static boolean active;

    private VanishAlert() {
    }

    public static void watching(UUID id, String name, int others) {
        if (class_310.method_1551().field_1687 == null || name == null) {
            return;
        }
        String shown = NameFilter.apply(name);
        title = ((String)(others > 0 ? shown + " +" + others : shown)).toUpperCase(Locale.ROOT) + " IS WATCHING YOU";
        startNanos = System.nanoTime();
        active = true;
    }

    public static void render(class_332 context) {
        if (!active) {
            return;
        }
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            active = false;
            return;
        }
        float t = (float)(System.nanoTime() - startNanos) / 1.0E9f;
        if (t > 5.0499997f) {
            active = false;
            return;
        }
        float fade = t < 0.35f ? MenuKit.quint(t / 0.35f) : (t > 3.9499998f ? 1.0f - MenuKit.quint((t - 0.35f - 3.6f) / 1.1f) : 1.0f);
        float pop = t < 0.35f ? 0.82f + 0.18f * MenuKit.quint(t / 0.35f) : 1.0f;
        float pulse = 0.5f + 0.5f * (float)Math.sin((double)t * 5.0);
        int width = context.method_51421();
        int height = context.method_51443();
        int edge = MenuKit.alpha(-723723, fade * (0.1f + 0.06f * pulse));
        context.method_25296(0, 0, width, height / 5, edge, 0xF4F4F5);
        context.method_25296(0, height - height / 5, width, height, 0xF4F4F5, edge);
        float cx = (float)width / 2.0f;
        float cy = (float)height * 0.36f;
        Smooth.glow(context, Math.round(cx), Math.round(cy), Math.round(70.0f * pop), MenuKit.alpha(-723723, fade * (0.18f + 0.1f * pulse)));
        float logo = 64.0f * pop;
        BrandTextures.Sprite orbit = BrandTextures.fit("orbit_glow", logo * 1.6f * Smooth.pixelsPerUnit(context));
        if (orbit != null) {
            float w = logo * 1.6f;
            float h = w * (float)orbit.height() / (float)orbit.width();
            SoberScreen.image(context, orbit, cx - w / 2.0f, cy - h / 2.0f, w, h, MenuKit.alpha(-1, fade));
        }
        float titleEm = 8.5f;
        float luckEm = 22.0f * (0.9f + 0.1f * pop);
        float titleW = CrispText.width(title, BOLD, titleEm, 0.8f);
        float luckW = CrispText.width("Good Luck!", BLACK, luckEm, 0.2f);
        float textTop = cy + logo / 2.0f + 12.0f;
        int panelW = Math.round(Math.max(titleW, luckW) + 40.0f);
        int panelH = Math.round(luckEm + titleEm + 34.0f);
        Smooth.rect(context, Math.round(cx - (float)panelW / 2.0f), Math.round(textTop - 6.0f), panelW, panelH, 3, MenuKit.alpha(-15198181, fade * 0.9f));
        CrispText.draw(context, title, BOLD, cx - titleW / 2.0f, textTop + titleEm + 4.0f, titleEm, 0.8f, MenuKit.alpha(-7434602, fade));
        CrispText.draw(context, "Good Luck!", BLACK, cx - luckW / 2.0f, textTop + titleEm + luckEm + 10.0f, luckEm, 0.2f, MenuKit.alpha(-723723, fade));
        String tag = "SOBERCLIENT  \u00b7  ANTI VANISH";
        float tagW = CrispText.width(tag, BOLD, 5.6f, 1.2f);
        CrispText.draw(context, tag, BOLD, cx - tagW / 2.0f, textTop + (float)panelH + 4.0f, 5.6f, 1.2f, MenuKit.alpha(-10724252, fade));
    }
}

