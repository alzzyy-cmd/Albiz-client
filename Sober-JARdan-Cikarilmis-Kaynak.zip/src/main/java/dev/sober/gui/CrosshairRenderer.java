/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 *  net.minecraft.class_1011
 *  net.minecraft.class_10799
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  org.joml.Matrix3x2fStack
 */
package dev.sober.gui;

import dev.sober.gui.Smooth;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.joml.Matrix3x2fStack;

public final class CrosshairRenderer {
    private static final float[][] BOTTLE_LINES = new float[][]{{-0.18f, -1.16f, 0.18f, -1.16f}, {0.18f, -1.16f, 0.18f, -1.0f}, {0.18f, -1.0f, -0.18f, -1.0f}, {-0.18f, -1.0f, -0.18f, -1.16f}, {-0.14f, -1.0f, -0.14f, -0.72f}, {0.14f, -1.0f, 0.14f, -0.72f}, {-0.14f, -0.72f, -0.3f, -0.62f}, {-0.3f, -0.62f, -0.42f, -0.45f}, {0.14f, -0.72f, 0.3f, -0.62f}, {0.3f, -0.62f, 0.42f, -0.45f}, {-0.42f, -0.45f, -0.42f, 0.75f}, {0.42f, -0.45f, 0.42f, 0.75f}, {-0.42f, 0.75f, -0.3f, 0.88f}, {-0.3f, 0.88f, 0.3f, 0.88f}, {0.3f, 0.88f, 0.42f, 0.75f}, {0.0f, 0.88f, 0.0f, 0.98f}};
    private static final float[][] BOTTLE_LABEL = new float[][]{{-0.27f, -0.28f, 0.27f, -0.28f}, {0.27f, -0.28f, 0.27f, 0.28f}, {0.27f, 0.28f, -0.27f, 0.28f}, {-0.27f, 0.28f, -0.27f, -0.28f}};
    private static final Map<String, Mask> CACHE = new LinkedHashMap<String, Mask>();
    private static final int SUPER = 4;
    private static int counter;

    private CrosshairRenderer() {
    }

    public static void draw(class_332 context, Shape shape, int size, int thickness, int gap, boolean outline, boolean glow, int color, float opacity) {
        class_310 mc = class_310.method_1551();
        int pixelsWide = mc.method_22683().method_4489();
        int pixelsHigh = mc.method_22683().method_4506();
        float scaleX = (float)pixelsWide / (float)Math.max(1, context.method_51421());
        float scaleY = (float)pixelsHigh / (float)Math.max(1, context.method_51443());
        String key = String.valueOf((Object)shape) + "|" + size + "|" + thickness + "|" + gap;
        Mask mask = CACHE.get(key);
        if (mask == null) {
            mask = CrosshairRenderer.create(shape, size, thickness, gap);
            if (mask == null) {
                return;
            }
            CACHE.put(key, mask);
            if (CACHE.size() > 64) {
                Iterator<Map.Entry<String, Mask>> oldest = CACHE.entrySet().iterator();
                Mask old = oldest.next().getValue();
                oldest.remove();
                mc.method_1531().method_4615(old.fill());
                mc.method_1531().method_4615(old.outline());
                mc.method_1531().method_4615(old.glow());
            }
        }
        int n = mask.size();
        int x = pixelsWide / 2 - n / 2;
        int y = pixelsHigh / 2 - n / 2;
        Matrix3x2fStack matrices = context.method_51448();
        matrices.pushMatrix();
        matrices.identity();
        matrices.scale(1.0f / scaleX, 1.0f / scaleY);
        int alpha = Math.round(Math.max(0.0f, Math.min(1.0f, opacity)) * 255.0f);
        int tinted = Math.round((float)(color >>> 24) / 255.0f * (float)alpha) << 24 | color & 0xFFFFFF;
        if (glow) {
            context.method_25293(class_10799.field_56883, mask.glow(), x, y, 0.0f, 0.0f, n, n, n, n, n, n, Math.round((float)alpha * 0.55f) << 24 | color & 0xFFFFFF);
        }
        if (outline) {
            context.method_25293(class_10799.field_56883, mask.outline(), x, y, 0.0f, 0.0f, n, n, n, n, n, n, Math.round((float)alpha * 0.8f) << 24);
        }
        context.method_25293(class_10799.field_56883, mask.fill(), x, y, 0.0f, 0.0f, n, n, n, n, n, n, tinted);
        matrices.popMatrix();
    }

    public static void bar(class_332 context, int offset, int width, int height, float progress, int color, boolean outline, float opacity, float halo) {
        class_310 mc = class_310.method_1551();
        int pixelsWide = mc.method_22683().method_4489();
        int pixelsHigh = mc.method_22683().method_4506();
        float scaleX = (float)pixelsWide / (float)Math.max(1, context.method_51421());
        float scaleY = (float)pixelsHigh / (float)Math.max(1, context.method_51443());
        float alpha = Math.max(0.0f, Math.min(1.0f, opacity));
        if (alpha <= 0.003f) {
            return;
        }
        int x = pixelsWide / 2 - width / 2;
        int y = pixelsHigh / 2 + offset;
        int radius = Math.max(1, height / 2 + height % 2);
        Matrix3x2fStack matrices = context.method_51448();
        matrices.pushMatrix();
        matrices.identity();
        matrices.scale(1.0f / scaleX, 1.0f / scaleY);
        if (halo > 0.01f) {
            Smooth.rect(context, x - 2, y - 2, width + 4, height + 4, radius + 2, CrosshairRenderer.tint(color, 0.22f * halo * alpha));
        }
        if (outline) {
            Smooth.rect(context, x - 1, y - 1, width + 2, height + 2, radius + 1, CrosshairRenderer.tint(-16777216, 0.5f * alpha));
        }
        Smooth.rect(context, x, y, width, height, radius, CrosshairRenderer.tint(-16777216, 0.42f * alpha));
        float filled = Math.max(0.0f, Math.min(1.0f, progress)) * (float)width;
        int full = (int)filled;
        if (full >= radius * 2) {
            Smooth.rect(context, x, y, full, height, radius, CrosshairRenderer.tint(color, alpha));
        } else if (filled > 0.05f) {
            Smooth.rect(context, x, y, radius * 2, height, radius, CrosshairRenderer.tint(color, alpha * filled / ((float)radius * 2.0f)));
        }
        matrices.popMatrix();
    }

    private static int tint(int color, float alpha) {
        int a = Math.round(Math.max(0.0f, Math.min(1.0f, (float)(color >>> 24) / 255.0f * alpha)) * 255.0f);
        return a << 24 | color & 0xFFFFFF;
    }

    private static Mask create(Shape shape, int size, int thickness, int gap) {
        float extent = switch (shape.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> (float)size * 1.6f * 1.16f + (float)thickness + 3.0f;
            case 1 -> 0.6f + (float)size * 0.22f + (float)thickness * 0.5f;
            case 2, 6 -> gap + size + thickness;
            case 3, 5 -> (float)size * 0.8f + (float)gap * 0.5f + (float)size * 0.12f + (float)thickness;
            case 4 -> (float)thickness * 1.2f + 1.5f + (float)gap + (float)size * 0.6f + (float)thickness;
            case 7 -> (float)gap + (float)size * 0.7f + (float)thickness;
            case 8 -> (float)size * 0.95f + (float)thickness;
            case 9 -> size + thickness;
        };
        int pad = 7;
        int n = 2 * ((int)Math.ceil(extent) + pad) + 1;
        float[] fill = new float[n * n];
        float center = (float)n / 2.0f;
        for (int py = 0; py < n; ++py) {
            for (int px = 0; px < n; ++px) {
                int inside = 0;
                for (int sy = 0; sy < 4; ++sy) {
                    for (int sx = 0; sx < 4; ++sx) {
                        float x = (float)px + ((float)sx + 0.5f) / 4.0f - center;
                        float y = (float)py + ((float)sy + 0.5f) / 4.0f - center;
                        if (!(CrosshairRenderer.distance(shape, x, y, size, thickness, gap) <= 0.0f)) continue;
                        ++inside;
                    }
                }
                fill[py * n + px] = (float)inside / 16.0f;
            }
        }
        float[] outline = CrosshairRenderer.dilate(fill, n, 1.25f);
        float[] glow = CrosshairRenderer.blur(fill, n, 3);
        int id = counter++;
        return new Mask(CrosshairRenderer.register("crosshair_fill_" + id, fill, n, 1.0f), CrosshairRenderer.register("crosshair_outline_" + id, outline, n, 1.0f), CrosshairRenderer.register("crosshair_glow_" + id, glow, n, 1.8f), n);
    }

    private static class_2960 register(String name, float[] coverage, int n, float boost) {
        class_1011 image = new class_1011(n, n, false);
        for (int i = 0; i < n * n; ++i) {
            int a = Math.round(Math.max(0.0f, Math.min(1.0f, coverage[i] * boost)) * 255.0f);
            image.method_61941(i % n, i / n, a << 24 | 0xFFFFFF);
        }
        class_2960 id = class_2960.method_60655((String)"sober", (String)("dynamic/" + name));
        Smooth.register(id, image);
        return id;
    }

    private static float capsule(float x, float y, float ax, float ay, float bx, float by, float radius) {
        float dx = bx - ax;
        float dy = by - ay;
        float t = Math.max(0.0f, Math.min(1.0f, ((x - ax) * dx + (y - ay) * dy) / Math.max(1.0E-6f, dx * dx + dy * dy)));
        float qx = ax + dx * t - x;
        float qy = ay + dy * t - y;
        return (float)Math.sqrt(qx * qx + qy * qy) - radius;
    }

    private static float ray(float x, float y, double angle, float from, float to, float radius) {
        float c = (float)Math.cos(angle);
        float s = (float)Math.sin(angle);
        return CrosshairRenderer.capsule(x, y, c * from, s * from, c * to, s * to, radius);
    }

    private static float distance(Shape shape, float x, float y, int size, int thickness, int gap) {
        float r = (float)Math.sqrt(x * x + y * y);
        float half = (float)thickness / 2.0f;
        float dot = Math.max(0.9f, (float)thickness * 0.75f);
        switch (shape.ordinal()) {
            case 1: {
                return r - (0.6f + (float)size * 0.22f + (float)thickness * 0.5f);
            }
            case 0: {
                float s = (float)size * 1.6f;
                float d = r - dot * 0.85f;
                for (float[] line : BOTTLE_LINES) {
                    d = Math.min(d, CrosshairRenderer.capsule(x, y, line[0] * s, line[1] * s, line[2] * s, line[3] * s, half));
                }
                for (float[] line : BOTTLE_LABEL) {
                    d = Math.min(d, CrosshairRenderer.capsule(x, y, line[0] * s, line[1] * s, line[2] * s, line[3] * s, half * 0.8f));
                }
                float dropY = 1.04f * s;
                float dropR = Math.max(half * 1.4f, 0.07f * s);
                return Math.min(d, (float)Math.sqrt(x * x + (y - dropY) * (y - dropY)) - dropR);
            }
            case 2: {
                float d = Float.MAX_VALUE;
                for (int i = 0; i < 4; ++i) {
                    d = Math.min(d, CrosshairRenderer.ray(x, y, (double)i * Math.PI / 2.0, (float)gap + half, gap + size, half));
                }
                return d;
            }
            case 3: {
                float radius = (float)size * 0.8f + (float)gap * 0.5f;
                return Math.min(Math.abs(r - radius) - half, r - dot);
            }
            case 5: {
                float radius = (float)size * 0.8f + (float)gap * 0.5f;
                double theta = Math.atan2(y, x);
                float wave = radius + Math.max(0.8f, (float)size * 0.12f) * (float)Math.sin(theta * 8.0);
                return Math.min(Math.abs(r - wave) - half, r - dot);
            }
            case 4: {
                float core = (float)thickness * 1.2f + 1.0f;
                float d = r - core;
                float start = core + 1.5f + (float)gap;
                float end = start + (float)size * 0.6f;
                for (int i = 0; i < 8; ++i) {
                    d = Math.min(d, CrosshairRenderer.ray(x, y, (double)i * Math.PI / 4.0 - 1.5707963267948966, start, end, half * 0.9f));
                }
                return d;
            }
            case 6: {
                double[] angles;
                float d = r - dot;
                for (double a : angles = new double[]{1.5707963267948966, Math.toRadians(210.0), Math.toRadians(330.0)}) {
                    d = Math.min(d, CrosshairRenderer.ray(x, y, a, (float)gap + half + 1.0f, gap + size, half));
                }
                return d;
            }
            case 7: {
                float corner = (float)gap + (float)size * 0.7f;
                float arm = Math.max(2.0f, (float)size * 0.45f);
                float d = r - dot;
                for (int sx = -1; sx <= 1; sx += 2) {
                    for (int sy = -1; sy <= 1; sy += 2) {
                        float cx = (float)sx * corner;
                        float cy = (float)sy * corner;
                        d = Math.min(d, CrosshairRenderer.capsule(x, y, cx, cy, cx - (float)sx * arm, cy, half));
                        d = Math.min(d, CrosshairRenderer.capsule(x, y, cx, cy, cx, cy - (float)sy * arm, half));
                    }
                }
                return d;
            }
            case 9: {
                double theta = Math.atan2(x, -y);
                if (theta < 0.0) {
                    theta += Math.PI * 2;
                }
                if (theta > (double)gap / 24.0 * Math.PI * 2.0) {
                    return Float.MAX_VALUE;
                }
                return Math.abs(r - (float)size) - half;
            }
            case 8: {
                float d = Float.MAX_VALUE;
                for (int i = 0; i < 4; ++i) {
                    d = Math.min(d, CrosshairRenderer.ray(x, y, 0.7853981633974483 + (double)i * Math.PI / 2.0, (float)size * 0.35f, (float)size * 0.95f, half));
                }
                return d;
            }
        }
        return r - dot;
    }

    private static float[] dilate(float[] source, int n, float radius) {
        float[] out = new float[n * n];
        int r = (int)Math.ceil(radius);
        for (int y = 0; y < n; ++y) {
            for (int x = 0; x < n; ++x) {
                float best = 0.0f;
                for (int dy = -r; dy <= r; ++dy) {
                    for (int dx = -r; dx <= r; ++dx) {
                        int nx = x + dx;
                        int ny = y + dy;
                        if (nx < 0 || ny < 0 || nx >= n || ny >= n) continue;
                        float distance = (float)Math.sqrt(dx * dx + dy * dy);
                        float weight = Math.max(0.0f, Math.min(1.0f, radius + 0.5f - distance));
                        best = Math.max(best, source[ny * n + nx] * weight);
                    }
                }
                out[y * n + x] = best;
            }
        }
        return out;
    }

    private static float[] blur(float[] source, int n, int radius) {
        float[] a = (float[])source.clone();
        for (int pass = 0; pass < 2; ++pass) {
            float[] h = new float[n * n];
            for (int y = 0; y < n; ++y) {
                for (int x = 0; x < n; ++x) {
                    float sum = 0.0f;
                    for (int k = -radius; k <= radius; ++k) {
                        int xx = Math.max(0, Math.min(n - 1, x + k));
                        sum += a[y * n + xx];
                    }
                    h[y * n + x] = sum / (float)(2 * radius + 1);
                }
            }
            float[] v = new float[n * n];
            for (int y = 0; y < n; ++y) {
                for (int x = 0; x < n; ++x) {
                    float sum = 0.0f;
                    for (int k = -radius; k <= radius; ++k) {
                        int yy = Math.max(0, Math.min(n - 1, y + k));
                        sum += h[yy * n + x];
                    }
                    v[y * n + x] = sum / (float)(2 * radius + 1);
                }
            }
            a = v;
        }
        return a;
    }

    private record Mask(class_2960 fill, class_2960 outline, class_2960 glow, int size) {
    }

    public static enum Shape {
        BOTTLE,
        DOT,
        CROSS,
        RING,
        SUN,
        WAVE,
        Y,
        BRACKETS,
        HIT,
        ARC;

    }
}

