/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1011
 *  net.minecraft.class_1041
 *  net.minecraft.class_10799
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  org.joml.Matrix3x2fStack
 *  org.joml.Vector2f
 */
package dev.sober.gui;

import dev.sober.SoberClient;
import dev.sober.gui.SharpTexture;
import dev.sober.gui.Smooth;
import java.io.InputStream;
import net.minecraft.class_1011;
import net.minecraft.class_1041;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.joml.Matrix3x2fStack;
import org.joml.Vector2f;

final class ExactImage {
    private final class_2960 source;
    private final String key;
    private class_1011 image;
    private boolean failed;
    private class_2960 current;
    private int shownW;
    private int texW;
    private int texH;
    private static int instances;

    ExactImage(String path) {
        this.source = class_2960.method_60655((String)"sober", (String)path);
        this.key = path.replace('/', '_').replace(".png", "") + "_" + instances++;
    }

    private boolean load() {
        boolean bl;
        block10: {
            if (this.image != null) {
                return true;
            }
            if (this.failed) {
                return false;
            }
            InputStream stream = class_310.method_1551().method_1478().open(this.source);
            try {
                this.image = class_1011.method_4309((InputStream)stream);
                bl = true;
                if (stream == null) break block10;
            }
            catch (Throwable throwable) {
                try {
                    if (stream != null) {
                        try {
                            stream.close();
                        }
                        catch (Throwable throwable2) {
                            throwable.addSuppressed(throwable2);
                        }
                    }
                    throw throwable;
                }
                catch (Exception e) {
                    this.failed = true;
                    SoberClient.LOG.error("Could not load {}", (Object)this.source, (Object)e);
                    return false;
                }
            }
            stream.close();
        }
        return bl;
    }

    float aspect() {
        return this.load() ? (float)this.image.method_4323() / (float)this.image.method_4307() : 1.0f;
    }

    void draw(class_332 context, float x, float y, float w, int color) {
        if (color >>> 24 == 0 || w <= 0.0f || !this.load()) {
            return;
        }
        Matrix3x2fStack matrices = context.method_51448();
        class_1041 window = class_310.method_1551().method_22683();
        float ratio = (float)window.method_4506() / (float)Math.max(1, window.method_4502());
        float zoom = (float)Math.sqrt(matrices.m00() * matrices.m00() + matrices.m01() * matrices.m01());
        int pw = Math.max(1, Math.round(w * zoom * ratio));
        int ph = Math.max(1, Math.round((float)(pw * this.image.method_4323()) / (float)this.image.method_4307()));
        if (this.current == null || pw != this.shownW) {
            this.rebuild(pw, ph);
        }
        Vector2f origin = matrices.transformPosition(x, y, new Vector2f());
        int px = Math.round(origin.x * ratio);
        int py = Math.round(origin.y * ratio);
        matrices.pushMatrix();
        matrices.identity();
        matrices.scale(1.0f / ratio, 1.0f / ratio);
        context.method_25293(class_10799.field_56883, this.current, px, py, 0.0f, 0.0f, pw, ph, this.texW, this.texH, this.texW, this.texH, color);
        matrices.popMatrix();
    }

    private void rebuild(int pw, int ph) {
        class_1011 scaled;
        if (pw >= this.image.method_4307()) {
            scaled = new class_1011(this.image.method_4307(), this.image.method_4323(), false);
            scaled.method_4317(this.image);
        } else {
            scaled = SharpTexture.downscale(this.image, pw, ph);
        }
        if (this.current != null) {
            class_310.method_1551().method_1531().method_4615(this.current);
        }
        this.current = class_2960.method_60655((String)"sober", (String)("dynamic/exact_" + this.key + "_" + pw));
        Smooth.register(this.current, scaled);
        this.shownW = pw;
        this.texW = scaled.method_4307();
        this.texH = scaled.method_4323();
    }
}

