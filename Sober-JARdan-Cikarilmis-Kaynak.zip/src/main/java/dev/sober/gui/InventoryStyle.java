/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_10799
 *  net.minecraft.class_1703
 *  net.minecraft.class_1735
 *  net.minecraft.class_2960
 *  net.minecraft.class_332
 */
package dev.sober.gui;

import dev.sober.SoberClient;
import dev.sober.gui.Smooth;
import dev.sober.gui.Theme;
import dev.sober.modules.CustomGlint;
import dev.sober.modules.CustomInventory;
import dev.sober.render.Color;
import java.util.Locale;
import net.minecraft.class_10799;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public final class InventoryStyle {
    private static Runnable pendingEntity;
    private static int[] entityBox;

    private InventoryStyle() {
    }

    private static CustomInventory module() {
        CustomInventory module = SoberClient.MODULES.get(CustomInventory.class);
        return module != null && module.styled() ? module : null;
    }

    private static int alpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) & 0xFF) << 24 | color & 0xFFFFFF;
    }

    private static int mix(int a, int b, float t) {
        int ar = a >> 16 & 0xFF;
        int ag = a >> 8 & 0xFF;
        int ab = a & 0xFF;
        int br = b >> 16 & 0xFF;
        int bg = b >> 8 & 0xFF;
        int bb = b & 0xFF;
        return (int)((float)ar + (float)(br - ar) * t) << 16 | (int)((float)ag + (float)(bg - ag) * t) << 8 | (int)((float)ab + (float)(bb - ab) * t);
    }

    private static float hash(int n) {
        int h = n * 374761393 + 668265263;
        h = (h ^ h >>> 13) * 1274126177;
        return (float)((h ^ h >>> 16) & 0xFFFFFF) / 1.6777215E7f;
    }

    private static int hue(int color, float shift) {
        float[] hsv = Color.fromPacked(0xFF000000 | color).toHsv();
        return Color.fromHsv((hsv[0] + shift + 1.0f) % 1.0f, Math.max(0.45f, hsv[1]), Math.max(0.7f, hsv[2]), 255).packed() & 0xFFFFFF;
    }

    public static boolean lightTitles() {
        CustomInventory module = InventoryStyle.module();
        if (module == null) {
            return false;
        }
        return module.style.get() != CustomInventory.Style.Tinted && module.strength.get() >= 35;
    }

    public static int titleColor(int original) {
        if (!InventoryStyle.lightTitles()) {
            return original;
        }
        return -1645840;
    }

    public static boolean deferEntity(int x1, int y1, int x2, int y2, Runnable draw) {
        CustomInventory module = InventoryStyle.module();
        if (module == null || module.style.get() == CustomInventory.Style.Tinted) {
            return false;
        }
        pendingEntity = draw;
        entityBox = new int[]{x1, y1, x2, y2};
        return true;
    }

    public static void behind(class_332 context, int screenWidth, int screenHeight, int x, int y, int w, int h, boolean creative) {
        int size;
        pendingEntity = null;
        CustomInventory module = InventoryStyle.module();
        if (module == null) {
            return;
        }
        int color = module.color();
        double time = (double)System.currentTimeMillis() / 1000.0;
        float pulse = (float)(0.5 + 0.5 * Math.sin(time * 1.6));
        int cx = x + w / 2;
        int cy = y + h / 2;
        if (module.background.get().booleanValue()) {
            context.method_25296(0, 0, screenWidth, screenHeight, InventoryStyle.alpha(InventoryStyle.mix(color, 0, 0.55f), 40), InventoryStyle.alpha(InventoryStyle.mix(color, 328714, 0.85f), 120));
            Smooth.glow(context, cx, cy, Math.round((float)Math.max(w, h) * 1.1f), InventoryStyle.alpha(color, 56));
            size = Math.round((float)Math.min(screenWidth, screenHeight) * 0.9f);
            Smooth.logo(context, cx - size / 2, cy - size / 2, size, 0x8FFFFFF);
        }
        if (module.glow.get().booleanValue()) {
            int[] spread = new int[]{9, 6, 3};
            int[] shade = new int[]{16, 28, 42};
            for (int i = 0; i < spread.length; ++i) {
                int s = spread[i];
                Smooth.rect(context, x - s, y - s + 3, w + s * 2, h + s * 2, 6 + s, shade[i] << 24);
            }
            Smooth.glow(context, cx, y, Math.round((float)w * 0.6f), InventoryStyle.alpha(color, Math.round(48.0f + 32.0f * pulse)));
            Smooth.outline(context, x - 2, y - 2, w + 4, h + 4, 6, InventoryStyle.alpha(color, Math.round(144.0f + 64.0f * pulse)));
        }
        if (module.logo.get().booleanValue() && !creative && y > 30) {
            size = 20;
            int ly = y - size - 8 + Math.round((float)Math.sin(time * 1.2) * 1.5f);
            Smooth.glow(context, cx, ly + size / 2, 22, InventoryStyle.alpha(color, Math.round(96.0f + 48.0f * pulse)));
            Smooth.logo(context, cx - size / 2, ly, size, -1);
        }
        context.method_71048();
    }

    public static void over(class_332 context, int x, int y, int w, int h, class_1703 handler, boolean creative) {
        CustomInventory module = InventoryStyle.module();
        if (module == null) {
            InventoryStyle.flushEntity();
            return;
        }
        int color = module.color();
        float strength = (float)module.strength.get().intValue() / 100.0f;
        context.method_71048();
        int panel = Theme.panelSolid(0) & 0xFFFFFF;
        switch (module.style.get()) {
            case Tinted: {
                Smooth.rect(context, x, y, w, h, 4, InventoryStyle.alpha(color, Math.round(144.0f * strength)));
                break;
            }
            case Glass: {
                Smooth.rect(context, x, y, w, h, 5, InventoryStyle.alpha(InventoryStyle.mix(panel, color, 0.06f), Math.round(244.0f * strength)));
                Smooth.rect(context, x, y, w, h, 5, InventoryStyle.alpha(color, Math.round(18.0f * strength)));
                Smooth.rect(context, x + 5, y + 1, w - 10, 1, 1, InventoryStyle.alpha(0xFFFFFF, Math.round(38.0f * strength)));
                break;
            }
            case Midnight: {
                Smooth.rect(context, x, y, w, h, 5, InventoryStyle.alpha(461071, Math.round(255.0f * strength)));
                Smooth.rect(context, x + 5, y + 1, w - 10, 1, 1, InventoryStyle.alpha(color, Math.round(144.0f * strength)));
                break;
            }
        }
        if (module.style.get() != CustomInventory.Style.Tinted && module.animation.get() != CustomInventory.Animation.None) {
            context.method_44379(x + 2, y + 2, x + w - 2, y + h - 2);
            InventoryStyle.animate(context, module, x, y, w, h, color, strength);
            context.method_44380();
        }
        if (module.slots.get().booleanValue() && module.style.get() != CustomInventory.Style.Tinted && handler != null && strength > 0.05f) {
            float s = Math.min(1.0f, strength * 1.3f);
            int fill = InventoryStyle.alpha(InventoryStyle.mix(1053728, color, 0.12f), Math.round(176.0f * s));
            int edge = InventoryStyle.alpha(InventoryStyle.mix(0xFFFFFF, color, 0.35f), Math.round(52.0f * s));
            for (class_1735 slot : handler.field_7761) {
                if (!slot.method_7682()) continue;
                int sx = x + slot.field_7873 - 1;
                int sy = y + slot.field_7872 - 1;
                Smooth.rect(context, sx, sy, 18, 18, 4, fill);
                Smooth.outline(context, sx, sy, 18, 18, 4, edge);
            }
        }
        if (pendingEntity != null && entityBox != null) {
            int ex = entityBox[0];
            int ey = entityBox[1];
            int ew = entityBox[2] - ex;
            int eh = entityBox[3] - ey;
            Smooth.rect(context, ex, ey, ew, eh, 5, InventoryStyle.alpha(InventoryStyle.mix(1053728, color, 0.18f), 192));
            Smooth.glow(context, ex + ew / 2, ey + eh - 6, Math.max(ew, eh) / 2, InventoryStyle.alpha(color, 64));
            Smooth.outline(context, ex, ey, ew, eh, 5, InventoryStyle.alpha(InventoryStyle.mix(0xFFFFFF, color, 0.4f), 64));
        }
        InventoryStyle.flushEntity();
        if (module.logo.get().booleanValue() && !creative && w >= 120) {
            Smooth.logo(context, x + w - 14, y + 4, 9, InventoryStyle.alpha(0xFFFFFF, InventoryStyle.lightTitles() ? 176 : 128));
        }
    }

    private static void flushEntity() {
        Runnable draw = pendingEntity;
        pendingEntity = null;
        if (draw != null) {
            draw.run();
        }
    }

    private static void animate(class_332 context, CustomInventory module, int x, int y, int w, int h, int color, float strength) {
        double time = (double)System.currentTimeMillis() / 1000.0 * (double)module.animationSpeed.get().intValue() / 100.0;
        float k = Math.max(0.2f, strength);
        switch (module.animation.get()) {
            case Stars: {
                for (int i = 0; i < 40; ++i) {
                    float sx = (float)x + InventoryStyle.hash(i * 3) * (float)w;
                    float speed = 2.0f + InventoryStyle.hash(i * 3 + 1) * 6.0f;
                    float sy = (InventoryStyle.hash(i * 3 + 2) * (float)(h + 10) - (float)(time * (double)speed)) % (float)(h + 10);
                    if (sy < 0.0f) {
                        sy += (float)(h + 10);
                    }
                    float twinkle = 0.3f + 0.7f * (0.5f + 0.5f * (float)Math.sin(time * (0.8 + (double)InventoryStyle.hash(i) * 2.2) + (double)i));
                    int star = InventoryStyle.mix(0xFFFFFF, color, InventoryStyle.hash(i * 7) * 0.6f);
                    float py = (float)(y - 5) + sy;
                    if (InventoryStyle.hash(i * 11) > 0.8f) {
                        Smooth.softDot(context, sx, py, 4.5f, InventoryStyle.alpha(star, Math.round(112.0f * twinkle * k)));
                    }
                    Smooth.softDot(context, sx, py, 1.4f, InventoryStyle.alpha(star, Math.round(224.0f * twinkle * k)));
                }
                break;
            }
            case Aurora: {
                for (int i = 0; i < 4; ++i) {
                    float phase = (float)(time * (0.18 + (double)i * 0.05) + (double)i * 1.7);
                    int gx = x + Math.round((0.5f + 0.45f * (float)Math.sin(phase)) * (float)w);
                    int gy = y + Math.round((0.3f + 0.4f * (float)Math.cos(phase * 0.8f + (float)i)) * (float)h);
                    int tint = InventoryStyle.hue(color, (float)i * 0.08f - 0.08f);
                    Smooth.glow(context, gx, gy, Math.round((float)Math.max(w, h) * (0.45f + 0.1f * (float)i)), InventoryStyle.alpha(tint, Math.round(52.0f * k)));
                }
                break;
            }
            case Glint: {
                CustomGlint glint = SoberClient.MODULES.get(CustomGlint.class);
                String name = glint == null || glint.glint.get() == CustomGlint.Glint.Vanilla ? "galaxy" : glint.glint.get().name().toLowerCase(Locale.ROOT);
                class_2960 texture = class_2960.method_60655((String)"sober", (String)("textures/glint/" + name + ".png"));
                int tile = 128;
                int ox = (int)Math.round(time * 12.0) % tile;
                int oy = (int)Math.round(time * 7.0) % tile;
                int tint = InventoryStyle.alpha(0xFFFFFF, Math.round(80.0f * k));
                for (int tx = x - tile + ox; tx < x + w; tx += tile) {
                    for (int ty = y - tile + oy; ty < y + h; ty += tile) {
                        context.method_25291(class_10799.field_56883, texture, tx, ty, 0.0f, 0.0f, tile, tile, tile, tile, tint);
                    }
                }
                break;
            }
            case Shimmer: {
                float cycle = (float)(time * 0.35 % 1.0);
                int band = Math.round((float)(-w) * 0.4f + cycle * (float)w * 1.8f);
                int shine = InventoryStyle.mix(0xFFFFFF, color, 0.3f);
                int peak = InventoryStyle.alpha(shine, Math.round(40.0f * k));
                int left = Math.max(x, x + band - 12);
                int center = x + band;
                int right = Math.min(x + w, x + band + 12);
                if (center > left) {
                    Smooth.horizontalGradient(context, left, y, Math.min(center, x + w), y + h, InventoryStyle.alpha(shine, 0), peak);
                }
                if (right > center) {
                    Smooth.horizontalGradient(context, Math.max(center, x), y, right, y + h, peak, InventoryStyle.alpha(shine, 0));
                }
                Smooth.glow(context, x + band, y + h / 2, Math.round((float)h * 0.6f), InventoryStyle.alpha(color, Math.round(34.0f * k)));
                break;
            }
        }
    }
}

