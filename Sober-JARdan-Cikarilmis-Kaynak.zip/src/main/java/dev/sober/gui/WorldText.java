/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.gui;

import dev.sober.gui.GuiPalette;
import dev.sober.gui.OverlayCanvas;

public final class WorldText {
    public static final int NAME = -1;
    public static final int LABEL = -4541521;
    private static final float NAME_PX = 17.0f;
    private static final float DETAIL_PX = 14.0f;

    private WorldText() {
    }

    public static int hudAccent() {
        return GuiPalette.accent();
    }

    public static void draw(OverlayCanvas canvas, float cx, float bottom, String name, String[] runs, int[] colors, float alpha) {
        if (alpha <= 0.001f) {
            return;
        }
        boolean detail = runs.length > 0;
        float y = Math.round(bottom - 2.0f - (detail ? 15.0f : 0.0f) - 17.0f);
        float nameWidth = OverlayCanvas.textWidth(name, 17.0f);
        canvas.addText(17.0f, Math.round(cx - nameWidth * 0.5f), y, WorldText.scaleAlpha(-1, alpha), name, true);
        if (!detail) {
            return;
        }
        float detailWidth = 0.0f;
        for (String run : runs) {
            detailWidth += OverlayCanvas.textWidth(run, 14.0f);
        }
        float x = Math.round(cx - detailWidth * 0.5f);
        float detailY = Math.round(y + 17.0f + 1.0f);
        for (int i = 0; i < runs.length; ++i) {
            canvas.addText(14.0f, Math.round(x), detailY, WorldText.scaleAlpha(colors[i], alpha), runs[i], true);
            x += OverlayCanvas.textWidth(runs[i], 14.0f);
        }
    }

    private static int scaleAlpha(int abgr, float alpha) {
        int a = Math.round((float)(abgr >>> 24) * Math.max(0.0f, Math.min(1.0f, alpha)));
        return a << 24 | abgr & 0xFFFFFF;
    }
}

