/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_243
 *  net.minecraft.class_310
 *  net.minecraft.class_4184
 */
package dev.sober.gui;

import dev.sober.gui.OverlayCanvas;
import dev.sober.util.TracerEngine;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;

public final class WorldLabel {
    private static final int PRIMARY = -1;
    private static final int SECONDARY = -1315861;
    private static final float MAIN_PX = 17.0f;
    private static final float SMALL_PX = 14.0f;

    private WorldLabel() {
    }

    public static float[] project(class_310 mc, class_243 world, float screenW, float screenH) {
        class_4184 camera = mc.field_1773.method_19418();
        if (camera == null || !camera.method_19332() || !TracerEngine.isInFront(camera, world)) {
            return null;
        }
        class_243 ndc = mc.field_1773.method_70778(world);
        if (!Double.isFinite(ndc.field_1352) || !Double.isFinite(ndc.field_1351)) {
            return null;
        }
        float x = (float)(ndc.field_1352 + 1.0) * 0.5f * screenW;
        float y = (float)(1.0 - ndc.field_1351) * 0.5f * screenH;
        if (x < -200.0f || x > screenW + 200.0f || y < -100.0f || y > screenH + 100.0f) {
            return null;
        }
        return new float[]{x, y};
    }

    public static void drawText(OverlayCanvas canvas, float cx, float bottom, String primary, String secondary, float alpha) {
        float gap = 6.0f;
        float mainWidth = OverlayCanvas.textWidth(primary, 17.0f);
        float smallWidth = secondary == null ? 0.0f : OverlayCanvas.textWidth(secondary, 14.0f);
        float x = Math.round(cx - (mainWidth + (secondary == null ? 0.0f : gap + smallWidth)) * 0.5f);
        float y = Math.round(bottom - 5.0f - 17.0f);
        canvas.addText(17.0f, x, y, WorldLabel.fade(-1, alpha), primary, true);
        if (secondary != null) {
            canvas.addText(14.0f, Math.round(x + mainWidth + gap), y + 2.4f, WorldLabel.fade(-1315861, alpha), secondary, true);
        }
    }

    private static int fade(int abgr, float alpha) {
        int a = Math.round((float)(abgr >>> 24) * Math.max(0.0f, Math.min(1.0f, alpha)));
        return a << 24 | abgr & 0xFFFFFF;
    }
}

