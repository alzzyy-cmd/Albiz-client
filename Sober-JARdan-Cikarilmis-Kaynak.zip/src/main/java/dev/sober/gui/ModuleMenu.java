/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.gui;

public interface ModuleMenu {
}

