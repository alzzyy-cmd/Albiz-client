/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.gui;

import dev.sober.gui.GuiPalette;

public final class EgyptDraw {
    private EgyptDraw() {
    }

    public static int col(int argb, float alpha) {
        int a = Math.round((float)(argb >>> 24 & 0xFF) * Math.max(0.0f, Math.min(1.0f, alpha)));
        return GuiPalette.abgr(a << 24 | argb & 0xFFFFFF);
    }
}

