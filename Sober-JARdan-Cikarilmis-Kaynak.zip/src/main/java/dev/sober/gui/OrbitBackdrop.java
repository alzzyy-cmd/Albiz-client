/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1011
 *  net.minecraft.class_1041
 *  net.minecraft.class_10799
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  org.joml.Matrix3x2fStack
 */
package dev.sober.gui;

import dev.sober.gui.MenuKit;
import dev.sober.gui.Smooth;
import java.util.Random;
import net.minecraft.class_1011;
import net.minecraft.class_1041;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import org.joml.Matrix3x2fStack;

final class OrbitBackdrop {
    static final OrbitBackdrop START = new OrbitBackdrop("orbit_backdrop", 0.79f, 0.68f, 0.34f, 0.32f, 0.45f, true);
    static final OrbitBackdrop CORNER = new OrbitBackdrop("orbit_backdrop_corner", 0.965f, -0.02f, 0.17f, 0.5f, 0.5f, false);
    static final float RING_RX = 1.95f;
    static final float RING_RY = 0.52f;
    static final float RING_TILT = -22.0f;
    private static final float RING_ALPHA = 0.42f;
    private static final float[][] STARS = OrbitBackdrop.stars(90);
    final float planetX;
    final float planetY;
    final float planetR;
    private final class_2960 id;
    private final float glowX;
    private final float glowY;
    private final boolean moon;
    private final long createdAt = System.nanoTime();
    private int builtW;
    private int builtH;

    private OrbitBackdrop(String name, float planetX, float planetY, float planetR, float glowX, float glowY, boolean moon) {
        this.id = class_2960.method_60655((String)"sober", (String)("dynamic/" + name));
        this.planetX = planetX;
        this.planetY = planetY;
        this.planetR = planetR;
        this.glowX = glowX;
        this.glowY = glowY;
        this.moon = moon;
    }

    void draw(class_332 context, float opacity) {
        if (opacity <= 0.002f) {
            return;
        }
        class_1041 window = class_310.method_1551().method_22683();
        int w = Math.max(1, window.method_4489());
        int h = Math.max(1, window.method_4506());
        if (w != this.builtW || h != this.builtH) {
            this.build(w, h);
        }
        float ratio = (float)h / (float)Math.max(1, window.method_4502());
        Matrix3x2fStack matrices = context.method_51448();
        matrices.pushMatrix();
        matrices.identity();
        matrices.scale(1.0f / ratio, 1.0f / ratio);
        context.method_25293(class_10799.field_56883, this.id, 0, 0, 0.0f, 0.0f, w, h, w, h, w, h, MenuKit.alpha(-1, opacity));
        matrices.popMatrix();
    }

    void sky(class_332 context, int width, int height, int mouseX, int mouseY, float fade) {
        float time = (float)(System.nanoTime() - this.createdAt) / 1.0E9f;
        float pcx = (float)width * this.planetX;
        float pcy = (float)height * this.planetY;
        float pr = (float)height * this.planetR;
        float mx = ((float)mouseX - (float)width / 2.0f) / Math.max(1.0f, (float)width);
        float my = ((float)mouseY - (float)height / 2.0f) / Math.max(1.0f, (float)height);
        for (float[] star : STARS) {
            float depth = star[2];
            float x = star[0] * (float)width - mx * 6.0f * depth;
            float dx = x - pcx;
            float y = star[1] * (float)height - my * 6.0f * depth;
            float dy = y - pcy;
            if (dx * dx + dy * dy < (pr + 3.0f) * (pr + 3.0f)) continue;
            float twinkle = 0.45f + 0.55f * (0.5f + 0.5f * (float)Math.sin(time * star[4] + star[3]));
            int alpha = Math.round(255.0f * twinkle * (0.35f + 0.4f * depth));
            Smooth.softDot(context, x, y, depth * 1.6f, MenuKit.alpha(alpha << 24 | 0xE9E3FF, fade));
        }
        if (!this.moon) {
            return;
        }
        double tilt = Math.toRadians(-22.0);
        double a = (double)time * 0.16;
        float ox = (float)Math.cos(a) * pr * 2.35f;
        float oy = (float)Math.sin(a) * pr * 0.62f;
        float moonX = pcx + ox * (float)Math.cos(tilt) - oy * (float)Math.sin(tilt);
        float moonY = pcy + ox * (float)Math.sin(tilt) + oy * (float)Math.cos(tilt);
        float mdx = moonX - pcx;
        float mdy = moonY - pcy;
        if (Math.sin(a) < 0.0 && mdx * mdx + mdy * mdy < pr * pr) {
            return;
        }
        float r = Math.max(2.5f, pr * 0.04f);
        Smooth.softDot(context, moonX, moonY, r * 3.2f, MenuKit.alpha(1084722170, fade));
        Smooth.circle(context, Math.round(moonX), Math.round(moonY), Math.round(r), MenuKit.alpha(-1448961, fade));
    }

    private static float[][] stars(int count) {
        Random random = new Random(7L);
        float[][] list = new float[count][];
        for (int i = 0; i < count; ++i) {
            float size = 0.35f + (float)Math.pow(random.nextFloat(), 3.0) * 1.1f;
            list[i] = new float[]{random.nextFloat(), random.nextFloat(), size, random.nextFloat() * 6.283f, 0.6f + random.nextFloat() * 1.6f};
        }
        return list;
    }

    private void build(int w, int h) {
        class_1011 image = new class_1011(w, h, false);
        float gx = (float)w * this.glowX;
        float gy = (float)h * this.glowY;
        float sx = 1.0f / ((float)w * 0.75f);
        float sy = 1.0f / ((float)h * 0.9f);
        float pcx = (float)w * this.planetX;
        float pcy = (float)h * this.planetY;
        float pr = (float)h * this.planetR;
        float rx = pr * 1.95f;
        float ry = pr * 0.52f;
        float thick = pr * 0.035f;
        float gap = pr * 0.03f;
        double tilt = Math.toRadians(-22.0);
        float cos = (float)Math.cos(tilt);
        float sin = (float)Math.sin(tilt);
        float[] light = OrbitBackdrop.normalize(-0.55f, -0.6f, 0.58f);
        int seed = -1640531527;
        float[] bg = new float[3];
        float[] c = new float[3];
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                seed ^= seed << 13;
                seed ^= seed >>> 17;
                seed ^= seed << 5;
                float noise = (float)((seed & 0xFFFF) + (seed >>> 16 & 0xFFFF)) / 65535.0f - 1.0f;
                float dx = ((float)x - gx) * sx;
                float dy = ((float)y - gy) * sy;
                float d = Math.min(1.0f, (float)Math.sqrt(dx * dx + dy * dy));
                float t = d * d * (3.0f - 2.0f * d);
                bg[0] = 38.0f - 25.0f * t;
                bg[1] = 27.0f - 17.0f * t;
                bg[2] = 66.0f - 41.0f * t;
                c[0] = bg[0];
                c[1] = bg[1];
                c[2] = bg[2];
                float px = (float)x + 0.5f - pcx;
                float py = (float)y + 0.5f - pcy;
                float dist = (float)Math.sqrt(px * px + py * py);
                float planet = OrbitBackdrop.clamp01(0.5f - (dist - pr));
                float u = px * cos + py * sin;
                float v = -px * sin + py * cos;
                float k = (float)Math.sqrt(u * u / (rx * rx) + v * v / (ry * ry));
                float grad = (float)Math.sqrt(u * u / (rx * rx * rx * rx) + v * v / (ry * ry * ry * ry)) / Math.max(k, 1.0E-4f);
                float ringDist = Math.abs((k - 1.0f) / Math.max(grad, 1.0E-6f));
                float ring = OrbitBackdrop.clamp01(0.5f - (ringDist - thick / 2.0f));
                float front = OrbitBackdrop.clamp01(0.5f + v);
                OrbitBackdrop.mix(c, 237.0f, 231.0f, 255.0f, ring * 0.42f);
                if (planet > 0.0f) {
                    float nx = px / pr;
                    float ny = py / pr;
                    float nz = (float)Math.sqrt(Math.max(0.0f, 1.0f - nx * nx - ny * ny));
                    float lambert = Math.max(0.0f, nx * light[0] + ny * light[1] + nz * light[2]);
                    float shade = 0.1f + 0.75f * (float)Math.pow(lambert, 1.2f);
                    float r = 46.0f + 82.0f * shade;
                    float g = 34.0f + 74.0f * shade;
                    float b = 86.0f + 110.0f * shade;
                    float rim = OrbitBackdrop.clamp01(1.0f - (pr - dist) / (pr * 0.04f)) * lambert;
                    r += (237.0f - r) * rim * 0.5f;
                    g += (231.0f - g) * rim * 0.5f;
                    b += (255.0f - b) * rim * 0.5f;
                    OrbitBackdrop.mix(c, r, g, b, planet);
                    float gapCover = OrbitBackdrop.clamp01(0.5f - (ringDist - thick / 2.0f - gap)) * front * planet;
                    OrbitBackdrop.mix(c, bg[0], bg[1], bg[2], gapCover);
                    OrbitBackdrop.mix(c, 237.0f, 231.0f, 255.0f, ring * 0.42f * front * planet);
                }
                int r = OrbitBackdrop.clamp(Math.round(c[0] + noise));
                int g = OrbitBackdrop.clamp(Math.round(c[1] + noise));
                int b = OrbitBackdrop.clamp(Math.round(c[2] + noise));
                image.method_61941(x, y, 0xFF000000 | r << 16 | g << 8 | b);
            }
        }
        class_310.method_1551().method_1531().method_4615(this.id);
        Smooth.register(this.id, image);
        this.builtW = w;
        this.builtH = h;
    }

    private static void mix(float[] c, float r, float g, float b, float amount) {
        if (amount <= 0.0f) {
            return;
        }
        c[0] = c[0] + (r - c[0]) * amount;
        c[1] = c[1] + (g - c[1]) * amount;
        c[2] = c[2] + (b - c[2]) * amount;
    }

    private static float[] normalize(float x, float y, float z) {
        float l = (float)Math.sqrt(x * x + y * y + z * z);
        return new float[]{x / l, y / l, z / l};
    }

    private static float clamp01(float v) {
        return Math.max(0.0f, Math.min(1.0f, v));
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }
}

