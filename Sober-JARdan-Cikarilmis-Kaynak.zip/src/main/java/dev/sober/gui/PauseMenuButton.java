/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.fabricmc.fabric.api.client.screen.v1.ScreenEvents
 *  net.fabricmc.fabric.api.client.screen.v1.Screens
 *  net.minecraft.class_2561
 *  net.minecraft.class_2588
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 *  net.minecraft.class_339
 *  net.minecraft.class_4185
 *  net.minecraft.class_4185$class_4241
 *  net.minecraft.class_433
 *  net.minecraft.class_437
 *  net.minecraft.class_7417
 *  net.minecraft.class_7919
 */
package dev.sober.gui;

import dev.sober.SoberClient;
import dev.sober.gui.MenuKit;
import dev.sober.gui.Smooth;
import dev.sober.gui.UiSounds;
import dev.sober.modules.ClickGui;
import java.util.List;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import net.minecraft.class_7417;
import net.minecraft.class_7919;

public final class PauseMenuButton {
    private PauseMenuButton() {
    }

    public static void register() {
        ScreenEvents.AFTER_INIT.register(PauseMenuButton::addButton);
    }

    private static void addButton(class_310 client, class_437 screen, int width, int height) {
        class_433 menu;
        if (!(screen instanceof class_433) || !(menu = (class_433)screen).method_53558()) {
            return;
        }
        try {
            List buttons = Screens.getButtons((class_437)screen);
            for (class_339 widget : buttons) {
                class_2588 text;
                class_7417 class_74172 = widget.method_25369().method_10851();
                if (!(class_74172 instanceof class_2588) || !(text = (class_2588)class_74172).method_11022().equals("menu.returnToGame")) continue;
                LogoButton button = new LogoButton(widget.method_46426() + widget.method_25368() + 4, widget.method_46427(), 20, widget.method_25364(), pressed -> PauseMenuButton.open(client));
                button.method_47400(class_7919.method_47407((class_2561)class_2561.method_43470((String)"SoberClient Menu")));
                buttons.add(button);
                return;
            }
        }
        catch (RuntimeException e) {
            SoberClient.LOG.warn("Could not add the Sober button to the pause menu", (Throwable)e);
        }
    }

    private static void open(class_310 client) {
        ClickGui gui = SoberClient.MODULES.get(ClickGui.class);
        if (gui == null) {
            return;
        }
        client.method_1507(MenuKit.menu());
        UiSounds.open();
    }

    private static final class LogoButton
    extends class_4185 {
        LogoButton(int x, int y, int width, int height, class_4185.class_4241 action) {
            super(x, y, width, height, (class_2561)class_2561.method_43470((String)"SoberClient"), action, field_40754);
        }

        protected void method_75752(class_332 context, int mouseX, int mouseY, float deltaTicks) {
            this.method_75794(context);
            int size = Math.min(this.method_25368(), this.method_25364()) - 4;
            Smooth.logo(context, this.method_46426() + (this.method_25368() - size) / 2, this.method_46427() + (this.method_25364() - size) / 2, size, -1);
        }
    }
}

