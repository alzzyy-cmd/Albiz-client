/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.mojang.logging.LogUtils
 *  net.fabricmc.api.ClientModInitializer
 *  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents
 *  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents
 *  net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents
 *  net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents
 *  net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback
 *  net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry
 *  net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents
 *  net.fabricmc.loader.api.FabricLoader
 *  net.minecraft.class_10055
 *  net.minecraft.class_1007
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_3883
 *  net.minecraft.class_3887
 *  net.minecraft.class_4184
 *  net.minecraft.class_591
 *  org.slf4j.Logger
 */
package dev.sober;

import com.mojang.logging.LogUtils;
import dev.sober.ClickGuiKey;
import dev.sober.Config;
import dev.sober.GuiTest;
import dev.sober.ResetAll;
import dev.sober.esp.ChunkScanner;
import dev.sober.event.impl.PacketAppliedEvent;
import dev.sober.fx.CombatFx;
import dev.sober.fx.LowFire;
import dev.sober.gui.BrandWindow;
import dev.sober.gui.HudLayout;
import dev.sober.gui.HudMetrics;
import dev.sober.gui.HudRenderer;
import dev.sober.gui.MenuAudio;
import dev.sober.gui.PauseMenuButton;
import dev.sober.gui.SkyLyrics;
import dev.sober.gui.TargetCard;
import dev.sober.gui.VanishAlert;
import dev.sober.module.Module;
import dev.sober.module.ModuleManager;
import dev.sober.modules.ActivityInspector;
import dev.sober.modules.AimAssist;
import dev.sober.modules.AmethystBypass;
import dev.sober.modules.AnchorMacro;
import dev.sober.modules.AnimatedTyping;
import dev.sober.modules.AntiCheat;
import dev.sober.modules.AntiTrap;
import dev.sober.modules.AntiVanish;
import dev.sober.modules.ArmorTrimHider;
import dev.sober.modules.Aspect;
import dev.sober.modules.AuctionSniper;
import dev.sober.modules.AutoClicker;
import dev.sober.modules.AutoCrystal;
import dev.sober.modules.AutoDoubleHand;
import dev.sober.modules.AutoEat;
import dev.sober.modules.AutoFirework;
import dev.sober.modules.AutoHitCrystal;
import dev.sober.modules.AutoInvTotem;
import dev.sober.modules.AutoJump;
import dev.sober.modules.AutoJumpReset;
import dev.sober.modules.AutoLog;
import dev.sober.modules.AutoReconnect;
import dev.sober.modules.AutoRespawn;
import dev.sober.modules.AutoSell;
import dev.sober.modules.AutoShop;
import dev.sober.modules.AutoTool;
import dev.sober.modules.AutoTotem;
import dev.sober.modules.AutoWalk;
import dev.sober.modules.BedrockVoidESP;
import dev.sober.modules.BlockESP;
import dev.sober.modules.BlockEntityESP;
import dev.sober.modules.BlockNotifier;
import dev.sober.modules.BlockOverlay;
import dev.sober.modules.BoatNoclip;
import dev.sober.modules.Boatfly;
import dev.sober.modules.Capes;
import dev.sober.modules.ChunkFinder;
import dev.sober.modules.ChunkScannerModule;
import dev.sober.modules.ClearView;
import dev.sober.modules.ClickGui;
import dev.sober.modules.ClickTp;
import dev.sober.modules.ColorSync;
import dev.sober.modules.Configs;
import dev.sober.modules.CoordSnapper;
import dev.sober.modules.CreamyKeys;
import dev.sober.modules.Criticals;
import dev.sober.modules.CsPickaxe;
import dev.sober.modules.CustomAccessories;
import dev.sober.modules.CustomCrosshair;
import dev.sober.modules.CustomGlint;
import dev.sober.modules.CustomInventory;
import dev.sober.modules.CustomModels;
import dev.sober.modules.CustomSkin;
import dev.sober.modules.CustomTotems;
import dev.sober.modules.DiscordPresence;
import dev.sober.modules.ElytraFly;
import dev.sober.modules.ElytraSwap;
import dev.sober.modules.EntityControl;
import dev.sober.modules.EntitySpeed;
import dev.sober.modules.FakePay;
import dev.sober.modules.FakeStats;
import dev.sober.modules.FastUse;
import dev.sober.modules.Fly;
import dev.sober.modules.FlySpeed;
import dev.sober.modules.FpsBooster;
import dev.sober.modules.Freecam;
import dev.sober.modules.Freelook;
import dev.sober.modules.Fullbright;
import dev.sober.modules.Glass;
import dev.sober.modules.Hitbox;
import dev.sober.modules.HomeMeta;
import dev.sober.modules.HomeReset;
import dev.sober.modules.Hotkeys;
import dev.sober.modules.Hud;
import dev.sober.modules.InventoryHud;
import dev.sober.modules.Jesus;
import dev.sober.modules.JumpCircles;
import dev.sober.modules.KeyHomesetter;
import dev.sober.modules.KeyPearl;
import dev.sober.modules.KillAura;
import dev.sober.modules.LightEsp;
import dev.sober.modules.LightFinder;
import dev.sober.modules.MainMenu;
import dev.sober.modules.MediaHider;
import dev.sober.modules.MotionBlur;
import dev.sober.modules.MotionScanner;
import dev.sober.modules.NameTags;
import dev.sober.modules.NetheriteFinder;
import dev.sober.modules.NoFall;
import dev.sober.modules.NoJumpDelay;
import dev.sober.modules.PanicPay;
import dev.sober.modules.PlayerESP;
import dev.sober.modules.Reach;
import dev.sober.modules.RegionMap;
import dev.sober.modules.RelogMethod;
import dev.sober.modules.RenderDistanceToggle;
import dev.sober.modules.RtpMethod;
import dev.sober.modules.SeedChunkFinder;
import dev.sober.modules.ShieldBreaker;
import dev.sober.modules.SkeletonESP;
import dev.sober.modules.SkinChange;
import dev.sober.modules.Sky;
import dev.sober.modules.Sneak;
import dev.sober.modules.SpawnerBeam;
import dev.sober.modules.Speed;
import dev.sober.modules.SpeedMine;
import dev.sober.modules.Spider;
import dev.sober.modules.SpotifyPlayer;
import dev.sober.modules.Sprint;
import dev.sober.modules.StaffLive;
import dev.sober.modules.StepTiles;
import dev.sober.modules.StorageESP;
import dev.sober.modules.SusChunk;
import dev.sober.modules.SuspiciousESP;
import dev.sober.modules.SwingAnimations;
import dev.sober.modules.TargetHud;
import dev.sober.modules.Tracers;
import dev.sober.modules.TridentBoost;
import dev.sober.modules.TriggerBot;
import dev.sober.modules.TunnelHoleESP;
import dev.sober.modules.Velocity;
import dev.sober.modules.WeatherNotifier;
import dev.sober.modules.Zoom;
import dev.sober.render.AccessoryFeature;
import dev.sober.render.Render3D;
import dev.sober.render.XrayFeature;
import dev.sober.sky.AuraRenderer;
import dev.sober.sky.GlintManager;
import dev.sober.util.CompletionChannel;
import dev.sober.util.netherite.NetheriteChunkTracker;
import java.io.IOException;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4184;
import net.minecraft.class_591;
import org.slf4j.Logger;

public class SoberClient
implements ClientModInitializer {
    public static final Logger LOG = LogUtils.getLogger();
    public static final ModuleManager MODULES = new ModuleManager();
    public static final Config CONFIG = new Config(MODULES);
    private static final Object NETHERITE_TRACKER_OWNER = new Object();
    private static Render3D renderer;

    static boolean migrate() {
        boolean migrated;
        boolean bl = migrated = CONFIG.loadedCleanly(MODULES.get(ClickGui.class)) && MODULES.get(ClickGui.class).migrate();
        if (CONFIG.loadedCleanly(MODULES.get(Hud.class)) && MODULES.get(Hud.class).migrate()) {
            migrated = true;
        }
        if (CONFIG.loadedCleanly(MODULES.get(MainMenu.class)) && MODULES.get(MainMenu.class).migrate()) {
            migrated = true;
        }
        if (CONFIG.loadedCleanly(MODULES.get(CsPickaxe.class)) && MODULES.get(CsPickaxe.class).migrate()) {
            migrated = true;
        }
        return migrated;
    }

    private static void moveConfigFolder() {
        Path dir = FabricLoader.getInstance().getConfigDir();
        Path from = dir.resolve("violet");
        Path to = dir.resolve("sober");
        if (!Files.isDirectory(from, new LinkOption[0]) || Files.exists(to, new LinkOption[0])) {
            return;
        }
        try {
            Files.move(from, to, new CopyOption[0]);
        }
        catch (IOException e) {
            LOG.warn("Could not move the config folder", (Throwable)e);
        }
    }

    public void onInitializeClient() {
        SoberClient.moveConfigFolder();
        Module.bindClient();
        MODULES.add(new SusChunk());
        MODULES.add(new ChunkFinder());
        MODULES.add(new AmethystBypass());
        MODULES.add(new ChunkScannerModule());
        MODULES.add(new SuspiciousESP());
        MODULES.add(new TunnelHoleESP());
        MODULES.add(new BedrockVoidESP());
        MODULES.add(new LightFinder());
        MODULES.add(new SeedChunkFinder());
        MODULES.add(new SpawnerBeam());
        MODULES.add(new PlayerESP());
        MODULES.add(new SkeletonESP());
        MODULES.add(new BlockESP());
        MODULES.add(new StorageESP());
        MODULES.add(new BlockNotifier());
        MODULES.add(new Tracers());
        MODULES.add(new LightEsp());
        MODULES.add(new HomeMeta());
        MODULES.add(new RenderDistanceToggle());
        MODULES.add(new AntiTrap());
        MODULES.add(new AutoTotem());
        MODULES.add(new AutoInvTotem());
        MODULES.add(new AnchorMacro());
        MODULES.add(new AutoCrystal());
        MODULES.add(new AutoHitCrystal());
        MODULES.add(new AutoDoubleHand());
        MODULES.add(new AimAssist());
        MODULES.add(new TriggerBot());
        MODULES.add(new Hitbox());
        MODULES.add(new AutoClicker());
        MODULES.add(new ShieldBreaker());
        MODULES.add(new AutoJumpReset());
        MODULES.add(new AutoEat());
        MODULES.add(new AutoFirework());
        MODULES.add(new AutoRespawn());
        MODULES.add(new FastUse());
        MODULES.add(new AuctionSniper());
        MODULES.add(new AutoSell());
        MODULES.add(new AutoShop());
        MODULES.add(new AutoTool());
        MODULES.add(new RtpMethod());
        MODULES.add(new RelogMethod());
        MODULES.add(new AutoReconnect());
        MODULES.add(new AutoLog());
        MODULES.add(new FakeStats());
        MODULES.add(new FakePay());
        MODULES.add(new StaffLive());
        MODULES.add(new NetheriteFinder());
        MODULES.add(new PanicPay());
        MODULES.add(new HomeReset());
        MODULES.add(new KeyHomesetter());
        MODULES.add(new KeyPearl());
        MODULES.add(new CustomCrosshair());
        MODULES.add(new MotionBlur());
        MODULES.add(new Sky());
        MODULES.add(new ClearView());
        MODULES.add(new Fullbright());
        MODULES.add(new Capes());
        MODULES.add(new Glass());
        MODULES.add(new Freelook());
        MODULES.add(new Freecam());
        MODULES.add(new Zoom());
        MODULES.add(new WeatherNotifier());
        MODULES.add(new SwingAnimations());
        MODULES.add(new FlySpeed());
        MODULES.add(new Boatfly());
        MODULES.add(new Fly());
        MODULES.add(new Speed());
        MODULES.add(new Sprint());
        MODULES.add(new Jesus());
        MODULES.add(new Spider());
        MODULES.add(new ElytraFly());
        MODULES.add(new ElytraSwap());
        MODULES.add(new BoatNoclip());
        MODULES.add(new EntityControl());
        MODULES.add(new EntitySpeed());
        MODULES.add(new AutoWalk());
        MODULES.add(new AutoJump());
        MODULES.add(new ClickTp());
        MODULES.add(new Sneak());
        MODULES.add(new NoJumpDelay());
        MODULES.add(new TridentBoost());
        MODULES.add(new KillAura());
        MODULES.add(new Criticals());
        MODULES.add(new Velocity());
        MODULES.add(new NoFall());
        MODULES.add(new Reach());
        MODULES.add(new ClickGui());
        MODULES.add(new ColorSync());
        MODULES.add(new Hud());
        MODULES.add(new InventoryHud());
        MODULES.add(new MainMenu());
        MODULES.add(new CreamyKeys());
        MODULES.add(new Aspect());
        MODULES.add(new AnimatedTyping());
        MODULES.add(new MediaHider());
        MODULES.add(new SpotifyPlayer());
        MODULES.add(new FpsBooster());
        MODULES.add(new RegionMap());
        MODULES.add(new Hotkeys());
        MODULES.add(new CoordSnapper());
        MODULES.add(new CustomGlint());
        MODULES.add(new ArmorTrimHider());
        MODULES.add(new BlockOverlay());
        MODULES.add(new CustomInventory());
        MODULES.add(new CustomModels());
        MODULES.add(new CsPickaxe());
        MODULES.add(new CustomAccessories());
        MODULES.add(new CustomSkin());
        MODULES.add(new SkinChange());
        MODULES.add(new NameTags());
        MODULES.add(new TargetHud());
        MODULES.add(new CustomTotems());
        MODULES.add(new StepTiles());
        MODULES.add(new JumpCircles());
        MODULES.add(new BlockEntityESP());
        MODULES.add(new MotionScanner());
        MODULES.add(new SpeedMine());
        MODULES.add(new AntiCheat());
        MODULES.add(new AntiVanish());
        MODULES.add(new ActivityInspector());
        MODULES.add(new Configs());
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, context) -> {
            class_1007 player;
            if (renderer instanceof class_1007) {
                player = (class_1007)renderer;
                helper.register((class_3887)new AccessoryFeature((class_3883<class_10055, class_591>)player));
            }
            if (renderer instanceof class_1007) {
                player = (class_1007)renderer;
                helper.register((class_3887)new XrayFeature((class_3883<class_10055, class_591>)player));
            }
        });
        ClickGuiKey.register();
        DiscordPresence presence = new DiscordPresence();
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
            renderer = new Render3D();
            ResetAll.capture();
            CONFIG.load();
            HudLayout.load();
            if (SoberClient.migrate()) {
                CONFIG.save();
            }
            MODULES.get(CustomGlint.class).sync();
            ClickGuiKey.sync(client);
            presence.setEnabled(true);
            BrandWindow.apply(client);
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            presence.setEnabled(false);
            CONFIG.save();
            HudLayout.save();
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClickGuiKey.tick(client);
            MODULES.pollKeybinds(client);
            HudMetrics.tick(client);
            GlintManager.ensure();
            MenuAudio.tick(client);
            if (client.field_1724 != null && client.field_1687 != null) {
                MODULES.onTick();
                CombatFx.tick(client);
            }
        });
        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> MODULES.onChunkLoad(chunk));
        PauseMenuButton.register();
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            HudMetrics.reset();
            MODULES.get(CustomGlint.class).checkConflicts();
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            MODULES.onGameLeft();
            CombatFx.clear();
        });
        WorldRenderEvents.END_MAIN.register(context -> {
            class_310 mc = class_310.method_1551();
            if (renderer == null || mc.field_1687 == null || mc.field_1724 == null) {
                return;
            }
            class_4184 camera = mc.field_1773.method_19418();
            try {
                renderer.begin(camera.method_71156(), camera.method_19329(), camera.method_19330());
                MODULES.onRender(renderer);
                CombatFx.render(renderer, mc.method_61966().method_60637(true));
                renderer.end();
            }
            catch (RuntimeException e) {
                LOG.error("Render failed", (Throwable)e);
            }
        });
        WorldRenderEvents.BEFORE_BLOCK_OUTLINE.register((context, outline) -> {
            try {
                return AuraRenderer.render(context, outline);
            }
            catch (RuntimeException e) {
                return true;
            }
        });
        HudElementRegistry.addFirst((class_2960)class_2960.method_60655((String)"sober", (String)"sky_lyrics"), (context, tickCounter) -> SkyLyrics.render(context, tickCounter.method_60637(true)));
        HudElementRegistry.addFirst((class_2960)class_2960.method_60655((String)"sober", (String)"low_fire"), (context, tickCounter) -> LowFire.render(context));
        HudElementRegistry.addLast((class_2960)class_2960.method_60655((String)"sober", (String)"target_card"), (context, tickCounter) -> TargetCard.render(context, tickCounter.method_60637(true)));
        HudElementRegistry.addLast((class_2960)class_2960.method_60655((String)"sober", (String)"module_list"), HudRenderer::render);
        HudElementRegistry.addLast((class_2960)class_2960.method_60655((String)"sober", (String)"vanish_alert"), (context, tickCounter) -> VanishAlert.render(context));
        CompletionChannel.install();
        if (Boolean.getBoolean("sober.guitest")) {
            GuiTest.register();
        }
        ChunkScanner.init();
        PacketAppliedEvent.TYPE.listen(NETHERITE_TRACKER_OWNER, event -> NetheriteChunkTracker.onPacketApplied(event.packet));
        LOG.info("SoberClient loaded with {} modules", (Object)MODULES.all().size());
    }
}

