/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  it.unimi.dsi.fastutil.ints.Int2LongMap$Entry
 *  it.unimi.dsi.fastutil.ints.Int2LongOpenHashMap
 *  it.unimi.dsi.fastutil.ints.IntCollection
 *  it.unimi.dsi.fastutil.ints.IntIterator
 *  it.unimi.dsi.fastutil.ints.IntOpenHashSet
 *  net.minecraft.class_10042
 *  net.minecraft.class_1297
 *  net.minecraft.class_1299
 *  net.minecraft.class_1309
 *  net.minecraft.class_1657
 *  net.minecraft.class_243
 *  net.minecraft.class_2767
 *  net.minecraft.class_310
 *  net.minecraft.class_3417
 *  net.minecraft.class_4587
 *  net.minecraft.class_4588
 *  net.minecraft.class_742
 *  net.minecraft.class_8143
 */
package dev.sober.fx;

import dev.sober.modules.TargetHud;
import dev.sober.render.Color;
import dev.sober.render.Render3D;
import it.unimi.dsi.fastutil.ints.Int2LongMap;
import it.unimi.dsi.fastutil.ints.Int2LongOpenHashMap;
import it.unimi.dsi.fastutil.ints.IntCollection;
import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import net.minecraft.class_10042;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2767;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_742;
import net.minecraft.class_8143;

public final class CombatFx {
    public static final float SHIELD_SECONDS = 5.0f;
    private static final Color WHITE = new Color(255, 255, 255, 255);
    private static final Color VIOLET = new Color(168, 85, 247, 255);
    private static final Color LILAC = new Color(216, 180, 254, 255);
    private static final Color PINK = new Color(245, 168, 255, 255);
    private static final Color ROSE = new Color(244, 114, 182, 255);
    private static final List<Ripple> RIPPLES = new ArrayList<Ripple>();
    private static final List<Crack> CRACKS = new ArrayList<Crack>();
    private static final List<Afterglow> AFTERGLOWS = new ArrayList<Afterglow>();
    private static final List<Spark> SPARKS = new ArrayList<Spark>();
    private static final List<Mote> MOTES = new ArrayList<Mote>();
    private static final Int2LongOpenHashMap SHIELDS = new Int2LongOpenHashMap();
    private static final IntOpenHashSet FALLEN = new IntOpenHashSet();
    private static final Random RANDOM = new Random();
    private static int sweep;

    private CombatFx() {
    }

    private static float seconds(long start, long now) {
        return (float)(now - start) / 1.0E9f;
    }

    private static float clamp(float v) {
        return Math.max(0.0f, Math.min(1.0f, v));
    }

    private static float easeOut(float t) {
        float f = 1.0f - CombatFx.clamp(t);
        return 1.0f - f * f * f;
    }

    public static void onDamage(class_8143 packet) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
        }
        int me = mc.field_1724.method_5628();
        int attacker = packet.comp_1269() >= 0 ? packet.comp_1269() : packet.comp_1270();
        TargetHud.onDamage(packet.comp_1267(), attacker);
        if (packet.comp_1267() == me || packet.comp_1269() != me && packet.comp_1270() != me) {
            return;
        }
        class_1297 class_12972 = mc.field_1687.method_8469(packet.comp_1267());
        if (!(class_12972 instanceof class_1309)) {
            return;
        }
        class_1309 target = (class_1309)class_12972;
        CombatFx.ripple(mc, target);
    }

    private static void ripple(class_310 mc, class_1309 target) {
        long now = System.nanoTime();
        class_243 center = target.method_73189().method_1031(0.0, (double)target.method_17682() * 0.62, 0.0);
        class_243 eye = mc.field_1724.method_33571();
        class_243 toward = eye.method_1020(center);
        class_243 flat = new class_243(toward.field_1352, 0.0, toward.field_1350);
        class_243 facing = flat.method_1027() < 1.0E-6 ? class_243.field_1353 : flat.method_1029().method_1021((double)target.method_17681() * 0.55);
        class_243 hit = center.method_1019(facing).method_1031(0.0, Math.max(-0.25, Math.min(0.25, toward.field_1351 * 0.08)), 0.0);
        if (RIPPLES.size() >= 24) {
            RIPPLES.remove(0);
        }
        class_243 base = target.method_73189();
        RIPPLES.add(new Ripple(target.method_5628(), hit.field_1352 - base.field_1352, hit.field_1351 - base.field_1351, hit.field_1350 - base.field_1350, hit.field_1352, hit.field_1351, hit.field_1350, now));
        class_243 out = toward.method_1027() < 1.0E-6 ? new class_243(0.0, 0.0, 1.0) : toward.method_1029();
        for (int i = 0; i < 9; ++i) {
            if (SPARKS.size() >= 300) {
                SPARKS.remove(0);
            }
            double speed = 1.6 + RANDOM.nextDouble() * 2.2;
            double vx = out.field_1352 * 0.9 + RANDOM.nextGaussian() * 0.75;
            double vy = 0.35 + RANDOM.nextDouble() * 1.1;
            double vz = out.field_1350 * 0.9 + RANDOM.nextGaussian() * 0.75;
            double length = Math.sqrt(vx * vx + vy * vy + vz * vz);
            SPARKS.add(new Spark(hit.field_1352, hit.field_1351, hit.field_1350, vx / length * speed, vy / length * speed, vz / length * speed, now, 0.38f + RANDOM.nextFloat() * 0.3f, 0.028f + RANDOM.nextFloat() * 0.03f, RANDOM.nextFloat()));
        }
    }

    public static void onSound(class_2767 packet) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null || !packet.method_11894().method_40225(class_3417.field_15239.method_40237())) {
            return;
        }
        class_742 closest = null;
        double best = 6.25;
        for (class_742 player : mc.field_1687.method_18456()) {
            double d;
            if (player == mc.field_1724 || !((d = player.method_5649(packet.method_11890(), packet.method_11889(), packet.method_11893())) < best)) continue;
            best = d;
            closest = player;
        }
        if (closest == null) {
            return;
        }
        long now = System.nanoTime();
        SHIELDS.put(closest.method_5628(), now);
        if (CRACKS.size() >= 8) {
            CRACKS.remove(0);
        }
        CRACKS.add(new Crack(closest.method_5628(), now, CombatFx.crackLines(new Random(now))));
    }

    private static float[][] crackLines(Random random) {
        ArrayList<float[]> lines = new ArrayList<float[]>();
        int branches = 8 + random.nextInt(3);
        for (int b = 0; b < branches; ++b) {
            double angle = ((double)b + random.nextDouble() * 0.6) / (double)branches * Math.PI * 2.0;
            float x = 0.0f;
            float y = 0.0f;
            float length = 0.07f + random.nextFloat() * 0.035f;
            int steps = 3 + random.nextInt(2);
            for (int s = 0; s < steps; ++s) {
                float nx = x + (float)Math.cos(angle += (random.nextDouble() - 0.5) * 0.9) * length;
                float ny = y + (float)Math.sin(angle) * length;
                lines.add(new float[]{x, y, nx, ny, (float)s / (float)steps});
                if (s == 1 && random.nextFloat() < 0.55f) {
                    double fork = angle + (random.nextBoolean() ? 0.7 : -0.7);
                    lines.add(new float[]{nx, ny, nx + (float)Math.cos(fork) * length * 0.8f, ny + (float)Math.sin(fork) * length * 0.8f, 0.6f});
                }
                x = nx;
                y = ny;
                length *= 0.86f;
            }
        }
        return (float[][])lines.toArray((T[])new float[0][]);
    }

    public static float shieldRemaining(int entity) {
        if (!SHIELDS.containsKey(entity)) {
            return -1.0f;
        }
        return 5.0f - CombatFx.seconds(SHIELDS.get(entity), System.nanoTime());
    }

    public static IntOpenHashSet shieldEntities() {
        return new IntOpenHashSet((IntCollection)SHIELDS.keySet());
    }

    public static void tick(class_310 mc) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return;
        }
        long now = System.nanoTime();
        for (class_742 player : mc.field_1687.method_18456()) {
            boolean dead;
            if (player == mc.field_1724) continue;
            boolean bl = dead = player.method_29504() || player.method_6032() <= 0.0f;
            if (dead && FALLEN.add(player.method_5628())) {
                CombatFx.afterglow((class_1657)player, now);
                continue;
            }
            if (dead || player.field_6012 <= 2) continue;
            FALLEN.remove(player.method_5628());
        }
        if (++sweep % 100 == 0) {
            IntIterator it = FALLEN.iterator();
            while (it.hasNext()) {
                if (mc.field_1687.method_8469(it.nextInt()) != null) continue;
                it.remove();
            }
            it = SHIELDS.int2LongEntrySet().fastIterator();
            while (it.hasNext()) {
                Int2LongMap.Entry entry = (Int2LongMap.Entry)it.next();
                if (!(CombatFx.seconds(entry.getLongValue(), now) > 6.0f) && mc.field_1687.method_8469(entry.getIntKey()) != null) continue;
                it.remove();
            }
        }
    }

    private static void afterglow(class_1657 player, long now) {
        if (AFTERGLOWS.size() >= 6) {
            AFTERGLOWS.remove(0);
        }
        float width = player.method_17681();
        float height = Math.max(0.6f, player.method_17682());
        AFTERGLOWS.add(new Afterglow(player.method_23317(), player.method_23318(), player.method_23321(), width, height, now));
        for (int i = 0; i < 90; ++i) {
            if (MOTES.size() >= 600) {
                MOTES.remove(0);
            }
            float level = RANDOM.nextFloat();
            long delay = (long)((1.0f - level) * 4.2E8f);
            double angle = RANDOM.nextDouble() * Math.PI * 2.0;
            double spread = Math.sqrt(RANDOM.nextDouble()) * (double)width * 0.55;
            double x = player.method_23317() + Math.cos(angle) * spread;
            double z = player.method_23321() + Math.sin(angle) * spread;
            double swirl = 0.12 + RANDOM.nextDouble() * 0.25;
            MOTES.add(new Mote(x, player.method_23318() + (double)(level * height), z, Math.cos(angle + 1.5707963267948966) * swirl, 0.45 + RANDOM.nextDouble() * 0.9, Math.sin(angle + 1.5707963267948966) * swirl, now + delay, 1.3f + RANDOM.nextFloat() * 1.1f, 0.03f + RANDOM.nextFloat() * 0.045f, RANDOM.nextFloat(), RANDOM.nextFloat() * 6.28f));
        }
    }

    public static boolean dissolves(class_10042 state) {
        return state.field_58171 == class_1299.field_6097 && state.field_53449 > 0.0f;
    }

    public static void dissolve(class_10042 state, class_4587 matrices) {
        if (!CombatFx.dissolves(state)) {
            return;
        }
        float p = CombatFx.clamp((state.field_53449 - 1.0f) / 9.0f);
        float shrink = 1.0f - p * p * (3.0f - 2.0f * p);
        float middle = state.field_53330 * 0.5f;
        matrices.method_46416(0.0f, middle + p * 0.35f, 0.0f);
        matrices.method_22905(shrink, shrink, shrink);
        matrices.method_46416(0.0f, -middle, 0.0f);
    }

    public static void clear() {
        RIPPLES.clear();
        CRACKS.clear();
        AFTERGLOWS.clear();
        SPARKS.clear();
        MOTES.clear();
        SHIELDS.clear();
        FALLEN.clear();
    }

    public static void render(Render3D renderer, float tickDelta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null) {
            return;
        }
        if (RIPPLES.isEmpty() && CRACKS.isEmpty() && AFTERGLOWS.isEmpty() && SPARKS.isEmpty() && MOTES.isEmpty()) {
            return;
        }
        long now = System.nanoTime();
        renderer.setDepthTest(true);
        CombatFx.afterglows(renderer, now);
        CombatFx.motes(renderer, now);
        renderer.setDepthTest(false);
        CombatFx.ripples(renderer, mc, now, tickDelta);
        CombatFx.sparks(renderer, now);
        CombatFx.cracks(renderer, mc, now, tickDelta);
        renderer.setLineWidth(2.0f);
        renderer.setDepthTest(false);
    }

    private static void ripples(Render3D renderer, class_310 mc, long now, float tickDelta) {
        Iterator<Ripple> it = RIPPLES.iterator();
        while (it.hasNext()) {
            float flash;
            Ripple ripple = it.next();
            float age = CombatFx.seconds(ripple.start(), now);
            if (age > 0.62f) {
                it.remove();
                continue;
            }
            double x = ripple.x();
            double y = ripple.y();
            double z = ripple.z();
            class_1297 entity = mc.field_1687.method_8469(ripple.entity());
            if (entity != null) {
                class_243 base = entity.method_30950(tickDelta);
                x = base.field_1352 + ripple.dx();
                y = base.field_1351 + ripple.dy();
                z = base.field_1350 + ripple.dz();
            }
            if ((flash = CombatFx.clamp(1.0f - age / 0.16f)) > 0.0f) {
                renderer.billboardGlow(x, y, z, 0.2 + 0.25 * (double)(1.0f - flash), WHITE.withAlpha(Math.round(235.0f * flash)), LILAC.withAlpha(0), 14);
            }
            CombatFx.wave(renderer, x, y, z, age / 0.48f, 1.0f);
            CombatFx.wave(renderer, x, y, z, (age - 0.09f) / 0.5f, 0.55f);
        }
    }

    private static void wave(Render3D renderer, double x, double y, double z, float t, float strength) {
        if (t <= 0.0f || t >= 1.0f) {
            return;
        }
        float grow = CombatFx.easeOut(t);
        double radius = 0.1 + 1.05 * (double)grow;
        double thick = 0.035 + 0.13 * (double)(1.0f - t);
        float fade = (float)Math.pow(1.0f - t, 1.4) * strength;
        CombatFx.band(renderer, x, y, z, Math.max(0.0, radius - thick * 2.2), radius - thick * 0.25, VIOLET.withAlpha(0).packed(), VIOLET.withAlpha(Math.round(120.0f * fade)).packed(), 48);
        CombatFx.band(renderer, x, y, z, radius - thick * 0.25, radius, VIOLET.withAlpha(Math.round(120.0f * fade)).packed(), WHITE.withAlpha(Math.round(250.0f * fade)).packed(), 48);
        CombatFx.band(renderer, x, y, z, radius, radius + thick * 0.55, WHITE.withAlpha(Math.round(250.0f * fade)).packed(), LILAC.withAlpha(0).packed(), 48);
    }

    private static void band(Render3D renderer, double cx, double cy, double cz, double inner, double outer, int innerColor, int outerColor, int segments) {
        if (outer <= inner) {
            return;
        }
        double[] axes = renderer.billboardBasis();
        class_243 camera = renderer.cameraPos();
        float ox = (float)(cx - camera.field_1352);
        float oy = (float)(cy - camera.field_1351);
        float oz = (float)(cz - camera.field_1350);
        int ci = renderer.tint(innerColor);
        int co = renderer.tint(outerColor);
        if (ci >>> 24 == 0 && co >>> 24 == 0) {
            return;
        }
        class_4588 buffer = renderer.relativeQuads();
        double step = Math.PI * 2 / (double)segments;
        for (int i = 0; i < segments; ++i) {
            double c0 = Math.cos((double)i * step);
            double s0 = Math.sin((double)i * step);
            double c1 = Math.cos((double)(i + 1) * step);
            double s1 = Math.sin((double)(i + 1) * step);
            CombatFx.corner(buffer, ox, oy, oz, axes, c0 * inner, s0 * inner, ci);
            CombatFx.corner(buffer, ox, oy, oz, axes, c0 * outer, s0 * outer, co);
            CombatFx.corner(buffer, ox, oy, oz, axes, c1 * outer, s1 * outer, co);
            CombatFx.corner(buffer, ox, oy, oz, axes, c1 * inner, s1 * inner, ci);
        }
    }

    private static void corner(class_4588 buffer, float ox, float oy, float oz, double[] axes, double u, double v, int color) {
        buffer.method_22912((float)((double)ox + axes[0] * u + axes[3] * v), (float)((double)oy + axes[1] * u + axes[4] * v), (float)((double)oz + axes[2] * u + axes[5] * v)).method_39415(color);
    }

    private static void sparks(Render3D renderer, long now) {
        Iterator<Spark> it = SPARKS.iterator();
        while (it.hasNext()) {
            Spark spark = it.next();
            float age = CombatFx.seconds(spark.start(), now);
            float t = age / spark.life();
            if (t >= 1.0f) {
                it.remove();
                continue;
            }
            double drag = (1.0 - Math.exp(-5.5 * (double)age)) / 5.5;
            double x = spark.x() + spark.vx() * drag;
            double y = spark.y() + spark.vy() * drag - 0.9 * (double)age * (double)age;
            double z = spark.z() + spark.vz() * drag;
            float fade = (1.0f - t) * (1.0f - t);
            Color core = WHITE.lerp(LILAC, (double)spark.white() * 0.6);
            renderer.billboardGlow(x, y, z, spark.size() * (1.4f - t * 0.6f), core.withAlpha(Math.round(255.0f * fade)), PINK.withAlpha(0), 8);
        }
    }

    private static void cracks(Render3D renderer, class_310 mc, long now, float tickDelta) {
        Iterator<Crack> it = CRACKS.iterator();
        while (it.hasNext()) {
            class_1297 class_12972;
            Crack crack = it.next();
            float age = CombatFx.seconds(crack.start(), now);
            if (age > 0.8f || !((class_12972 = mc.field_1687.method_8469(crack.entity())) instanceof class_1309)) {
                it.remove();
                continue;
            }
            class_1309 target = (class_1309)class_12972;
            class_243 base = target.method_30950(tickDelta);
            class_243 center = base.method_1031(0.0, (double)target.method_17682() * 0.6, 0.0);
            class_243 toward = renderer.cameraPos().method_1020(center);
            if (toward.method_1027() > 1.0E-6) {
                center = center.method_1019(toward.method_1029().method_1021((double)target.method_17681() * 0.6 + 0.08));
            }
            double[] axes = renderer.billboardBasis();
            float reveal = CombatFx.easeOut(age / 0.14f);
            float fade = age < 0.3f ? 1.0f : CombatFx.clamp(1.0f - (age - 0.3f) / 0.5f);
            float scale = 2.6f;
            float ring = CombatFx.easeOut(age / 0.34f);
            renderer.setLineWidth(1.4f);
            renderer.billboardRing(center.field_1352, center.field_1351, center.field_1350, 0.26 + 0.2 * (double)ring, WHITE.withAlpha(Math.round(220.0f * (1.0f - ring) * fade)), 48);
            for (int pass = 0; pass < 2; ++pass) {
                renderer.setLineWidth(pass == 0 ? 5.0f : 1.5f);
                Color color = pass == 0 ? VIOLET.withAlpha(Math.round(110.0f * fade)) : WHITE.withAlpha(Math.round(245.0f * fade));
                for (float[] line : crack.lines()) {
                    float local = CombatFx.clamp((reveal - line[4] * 0.6f) / 0.4f);
                    if (local <= 0.0f) continue;
                    float ex = line[0] + (line[2] - line[0]) * local;
                    float ey = line[1] + (line[3] - line[1]) * local;
                    renderer.line(center.field_1352 + (axes[0] * (double)line[0] + axes[3] * (double)line[1]) * (double)scale, center.field_1351 + (axes[1] * (double)line[0] + axes[4] * (double)line[1]) * (double)scale, center.field_1350 + (axes[2] * (double)line[0] + axes[5] * (double)line[1]) * (double)scale, center.field_1352 + (axes[0] * (double)ex + axes[3] * (double)ey) * (double)scale, center.field_1351 + (axes[1] * (double)ex + axes[4] * (double)ey) * (double)scale, center.field_1350 + (axes[2] * (double)ex + axes[5] * (double)ey) * (double)scale, color);
                }
            }
            renderer.billboardGlow(center.field_1352, center.field_1351, center.field_1350, 0.16, WHITE.withAlpha(Math.round(200.0f * fade * (1.0f - reveal * 0.6f))), VIOLET.withAlpha(0), 12);
        }
    }

    private static void afterglows(Render3D renderer, long now) {
        Iterator<Afterglow> it = AFTERGLOWS.iterator();
        while (it.hasNext()) {
            float burst;
            Afterglow glow = it.next();
            float age = CombatFx.seconds(glow.start(), now);
            if (age > 2.6f) {
                it.remove();
                continue;
            }
            float beam = age < 0.15f ? age / 0.15f : (age < 0.9f ? 1.0f : CombatFx.clamp(1.0f - (age - 0.9f) / 1.5f));
            double top = glow.y() + (double)(46.0f * CombatFx.easeOut(age / 0.45f));
            renderer.beam(glow.x(), glow.z(), glow.y(), top, 0.16, VIOLET.withAlpha(Math.round(235.0f * beam)), 1.0);
            float t = age / 1.35f;
            if (t < 1.0f) {
                double radius = 0.4 + 3.1 * (double)CombatFx.easeOut(t);
                double width = 0.26 * (double)(1.0f - t) + 0.06;
                int alpha = Math.round(230.0f * (float)Math.pow(1.0f - t, 1.4));
                double y = glow.y() + 0.03;
                renderer.disc(glow.x(), y, glow.z(), Math.max(0.0, radius - width), radius, ROSE.withAlpha(0), ROSE.withAlpha(alpha), 64);
                renderer.disc(glow.x(), y, glow.z(), radius, radius + width * 0.45, ROSE.withAlpha(alpha), PINK.withAlpha(0), 64);
            }
            if (!((burst = CombatFx.clamp(1.0f - age / 0.35f)) > 0.0f)) continue;
            renderer.billboardGlow(glow.x(), glow.y() + (double)glow.height() * 0.55, glow.z(), 0.9 + 0.5 * (double)(1.0f - burst), PINK.withAlpha(Math.round(150.0f * burst)), VIOLET.withAlpha(0), 20);
        }
    }

    private static void motes(Render3D renderer, long now) {
        Iterator<Mote> it = MOTES.iterator();
        while (it.hasNext()) {
            Mote mote = it.next();
            float age = CombatFx.seconds(mote.start(), now);
            if (age < 0.0f) continue;
            float t = age / mote.life();
            if (t >= 1.0f) {
                it.remove();
                continue;
            }
            double sway = Math.sin((double)age * 2.6 + (double)mote.phase()) * 0.06;
            double x = mote.x() + mote.vx() * (double)age + sway;
            double y = mote.y() + mote.vy() * (double)age + 0.18 * (double)age * (double)age;
            double z = mote.z() + mote.vz() * (double)age - sway;
            float in = CombatFx.clamp(age / 0.12f);
            float twinkle = 0.7f + 0.3f * (float)Math.sin(age * 11.0f + mote.phase() * 3.0f);
            float fade = in * (1.0f - t) * twinkle;
            Color core = PINK.lerp(WHITE, mote.white());
            renderer.billboardGlow(x, y, z, mote.size() * (1.0f + 0.4f * (1.0f - t)), core.withAlpha(Math.round(255.0f * fade)), ROSE.withAlpha(0), 8);
        }
    }

    private record Ripple(int entity, double dx, double dy, double dz, double x, double y, double z, long start) {
    }

    private record Spark(double x, double y, double z, double vx, double vy, double vz, long start, float life, float size, float white) {
    }

    private record Crack(int entity, long start, float[][] lines) {
    }

    private record Afterglow(double x, double y, double z, float width, float height, long start) {
    }

    private record Mote(double x, double y, double z, double vx, double vy, double vz, long start, float life, float size, float white, float phase) {
    }
}

