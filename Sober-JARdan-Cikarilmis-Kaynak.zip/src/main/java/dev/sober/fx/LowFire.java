/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1011
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 *  net.minecraft.class_332
 */
package dev.sober.fx;

import dev.sober.gui.Smooth;
import net.minecraft.class_1011;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class LowFire {
    private static final class_2960 FIRE_0 = class_2960.method_60656((String)"block/fire_0");
    private static final class_2960 FIRE_1 = class_2960.method_60656((String)"block/fire_1");
    private static final int[][] RAMP = new int[][]{{0, 36, 18, 110}, {90, 70, 48, 220}, {155, 120, 84, 255}, {205, 178, 146, 255}, {255, 246, 240, 255}};
    private static final int[] TONGUES = new int[]{11758591, 15312639, 0xCF8CFF, 16038143};
    private static float shown;
    private static long last;

    private LowFire() {
    }

    public static void recolor(class_2960 id, class_1011 image) {
        if (image == null || !FIRE_0.equals((Object)id) && !FIRE_1.equals((Object)id)) {
            return;
        }
        for (int y = 0; y < image.method_4323(); ++y) {
            for (int x = 0; x < image.method_4307(); ++x) {
                int k;
                int c = image.method_61940(x, y);
                int a = c >>> 24;
                if (a == 0) continue;
                int light = Math.round((float)(c >> 16 & 0xFF) * 0.299f + (float)(c >> 8 & 0xFF) * 0.587f + (float)(c & 0xFF) * 0.114f);
                light = Math.min(255, Math.round((float)light * 1.08f));
                for (k = 0; k < RAMP.length - 2 && light > RAMP[k + 1][0]; ++k) {
                }
                int[] from = RAMP[k];
                int[] to = RAMP[k + 1];
                float t = Math.max(0.0f, Math.min(1.0f, (float)(light - from[0]) / (float)Math.max(1, to[0] - from[0])));
                int r = Math.round((float)from[1] + (float)(to[1] - from[1]) * t);
                int g = Math.round((float)from[2] + (float)(to[2] - from[2]) * t);
                int b = Math.round((float)from[3] + (float)(to[3] - from[3]) * t);
                image.method_61941(x, y, a << 24 | r << 16 | g << 8 | b);
            }
        }
    }

    private static float hash(int i) {
        int h = i * 374761393 + 668265263;
        h = (h ^ h >>> 13) * 1274126177;
        return (float)((h ^ h >>> 16) & 0xFFFF) / 65535.0f;
    }

    private static int alpha(int rgb, float a) {
        return Math.round(Math.max(0.0f, Math.min(1.0f, a)) * 255.0f) << 24 | rgb & 0xFFFFFF;
    }

    public static void render(class_332 context) {
        int i;
        class_310 mc = class_310.method_1551();
        long now = System.nanoTime();
        float delta = last == 0L ? 0.0f : Math.min(0.1f, (float)(now - last) / 1.0E9f);
        last = now;
        boolean burning = mc.field_1724 != null && mc.method_1560() == mc.field_1724 && mc.field_1690.method_31044().method_31034() && mc.field_1724.method_5862();
        float target = burning ? 1.0f : 0.0f;
        if ((shown += (target - shown) * (1.0f - (float)Math.exp(-(burning ? 9.0f : 4.5f) * delta))) < 0.005f) {
            shown = burning ? shown : 0.0f;
            return;
        }
        int w = context.method_51421();
        int h = context.method_51443();
        float t = (float)(now % 3600000000000L) / 1.0E9f;
        float band = (float)h * 0.15f;
        context.method_25296(0, Math.round((float)h - band * 1.5f), w, h, LowFire.alpha(13208575, 0.0f), LowFire.alpha(14854399, 0.5f * shown));
        int count = Math.max(10, w / 24);
        for (i = 0; i < count; ++i) {
            float x = ((float)i + 0.5f) / (float)count * (float)w + (float)Math.sin(t * 0.8f + (float)i * 1.7f) * 7.0f;
            float flicker = 0.62f + 0.38f * (float)Math.sin(t * (2.4f + (float)(i % 5) * 0.41f) + (float)i * 2.3f);
            float tall = band * (0.75f + 0.55f * LowFire.hash(i)) * flicker;
            int color = TONGUES[i % TONGUES.length];
            for (int k = 0; k < 3; ++k) {
                float y = (float)h - tall * (0.12f + 0.34f * (float)k);
                float radius = tall * (0.58f - 0.14f * (float)k);
                float sway = (float)Math.sin(t * 3.1f + (float)i * 1.3f + (float)k) * (1.5f + (float)k);
                Smooth.softDot(context, x + sway, y, radius, LowFire.alpha(color, (0.42f - 0.1f * (float)k) * shown));
            }
        }
        for (i = 0; i < 28; ++i) {
            float speed = 0.1f + 0.09f * LowFire.hash(i * 13 + 1);
            float p = (t * speed + LowFire.hash(i * 7 + 3)) % 1.0f;
            float x = LowFire.hash(i * 31 + 5) * (float)w + (float)Math.sin(t * 1.3f + (float)i) * 14.0f;
            float y = (float)h - p * (float)h * 0.58f;
            float fade = (1.0f - p) * Math.min(1.0f, p / 0.08f) * shown;
            float twinkle = 0.6f + 0.4f * (float)Math.sin(t * 9.0f + (float)i * 3.1f);
            Smooth.softDot(context, x, y, 1.5f + 1.3f * LowFire.hash(i * 17), LowFire.alpha(i % 2 == 0 ? 0xFFE0FF : 15772668, 0.95f * fade * twinkle));
        }
    }
}

