/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.class_1921
 *  net.minecraft.class_2960
 */
package dev.sober.render;

import dev.sober.render.GlassLayers;
import net.minecraft.class_1921;
import net.minecraft.class_2960;

public final class GlassGear {
    private static boolean active;

    private GlassGear() {
    }

    public static void set(boolean on) {
        active = on;
    }

    public static class_1921 layer(class_2960 texture) {
        return active && texture != null ? GlassLayers.textured(texture) : null;
    }
}

