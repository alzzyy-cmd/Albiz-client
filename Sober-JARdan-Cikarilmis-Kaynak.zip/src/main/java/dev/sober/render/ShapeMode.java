/*
 * Decompiled with CFR 0.152.
 */
package dev.sober.render;

public enum ShapeMode {
    Lines,
    Sides,
    Both;


    public boolean lines() {
        return this != Sides;
    }

    public boolean sides() {
        return this != Lines;
    }
}

