/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 *  net.minecraft.class_1011
 *  net.minecraft.class_1043
 *  net.minecraft.class_1044
 *  net.minecraft.class_12079$class_10726
 *  net.minecraft.class_12079$class_12081
 *  net.minecraft.class_2960
 *  net.minecraft.class_310
 */
package dev.sober.render;

import dev.sober.SoberClient;
import dev.sober.modules.Capes;
import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RadialGradientPaint;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.imageio.ImageIO;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1044;
import net.minecraft.class_12079;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class CapeTexture {
    private static final int S = 10;
    private static final int W = 640;
    private static final int H = 320;
    private static final int FACE_W = 100;
    private static final int FACE_H = 160;
    private static final class_2960 ID = class_2960.method_60655((String)"sober", (String)"cape/sober");
    private static final class_12079.class_12081 ASSET = new class_12079.class_10726(ID, ID);
    private static final long FRAME_MS = 80L;
    private static final String BOTTLE = "textures/brand/sober_bottle.png";
    private static final String WORD = "textures/brand/sober_word.png";
    private static final String BADGE = "textures/effects/jump_badge.png";
    private static final Color SILVER = new Color(222, 224, 230);
    private static final Map<String, BufferedImage> IMAGES = new HashMap<String, BufferedImage>();
    private static class_1043 texture;
    private static Capes.Style built;
    private static boolean builtMoving;
    private static long paintedAt;

    private CapeTexture() {
    }

    public static class_12079.class_12081 asset(Capes.Style style, boolean effects) {
        boolean moving;
        long now = System.currentTimeMillis();
        if (texture == null) {
            texture = new class_1043(() -> "sober cape", new class_1011(640, 320, true));
            class_310.method_1551().method_1531().method_4616(ID, (class_1044)texture);
            built = null;
        }
        boolean bl = moving = effects && style != Capes.Style.Sober && style != Capes.Style.Wordmark;
        if (style != built || moving != builtMoving || moving && now - paintedAt >= 80L) {
            CapeTexture.paint(texture.method_4525(), style, moving ? (double)(now % 3600000L) / 1000.0 : 1.2);
            texture.method_4524();
            built = style;
            builtMoving = moving;
            paintedAt = now;
        }
        return ASSET;
    }

    private static void paint(class_1011 image, Capes.Style style, double time) {
        if (image == null) {
            return;
        }
        BufferedImage face = CapeTexture.face(style, 100, 160, time);
        int edge = CapeTexture.edge(style);
        image.method_4326(0, 0, 640, 320, edge);
        CapeTexture.copy(image, face, 10, 10, 1.0f);
        CapeTexture.copy(image, face, 120, 10, 0.45f);
        BufferedImage wing = new BufferedImage(100, 200, 2);
        Graphics2D g = wing.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(face, 0, 0, wing.getWidth(), wing.getHeight(), null);
        g.dispose();
        CapeTexture.copy(image, wing, 240, 20, 1.0f);
        CapeTexture.copy(image, wing, 360, 20, 0.8f);
    }

    private static void copy(class_1011 image, BufferedImage src, int ox, int oy, float light) {
        int w = src.getWidth();
        int h = src.getHeight();
        int[] pixels = src.getRGB(0, 0, w, h, null, 0, w);
        for (int y = 0; y < h; ++y) {
            for (int x = 0; x < w; ++x) {
                int c = pixels[y * w + x];
                int r = Math.round((float)(c >> 16 & 0xFF) * light);
                int gr = Math.round((float)(c >> 8 & 0xFF) * light);
                int b = Math.round((float)(c & 0xFF) * light);
                image.method_61941(ox + x, oy + y, 0xFF000000 | r << 16 | gr << 8 | b);
            }
        }
    }

    private static int edge(Capes.Style style) {
        return switch (style) {
            default -> throw new MatchException(null, null);
            case Capes.Style.Sober, Capes.Style.Drip, Capes.Style.Badge, Capes.Style.Wordmark -> -15461354;
            case Capes.Style.SoberShine -> -13882318;
            case Capes.Style.NeonBottle, Capes.Style.Lightning -> -16185077;
            case Capes.Style.NightSky -> -15987694;
            case Capes.Style.Smoke -> -15198180;
            case Capes.Style.Chrome -> -4933440;
        };
    }

    private static BufferedImage image(String path) {
        BufferedImage loaded;
        BufferedImage cached = IMAGES.get(path);
        if (cached != null) {
            return cached;
        }
        try (InputStream stream = class_310.method_1551().method_1478().open(class_2960.method_60655((String)"sober", (String)path));){
            loaded = CapeTexture.shrink(ImageIO.read(stream), 192);
        }
        catch (Exception e) {
            SoberClient.LOG.warn("Could not load the cape image {}", (Object)path, (Object)e);
            loaded = new BufferedImage(1, 1, 2);
        }
        IMAGES.put(path, loaded);
        return loaded;
    }

    private static BufferedImage shrink(BufferedImage image, int max) {
        while (Math.max(image.getWidth(), image.getHeight()) > max * 2) {
            BufferedImage half = new BufferedImage(Math.max(1, image.getWidth() / 2), Math.max(1, image.getHeight() / 2), 2);
            Graphics2D g = half.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(image, 0, 0, half.getWidth(), half.getHeight(), null);
            g.dispose();
            image = half;
        }
        return image;
    }

    private static BufferedImage face(Capes.Style style, int w, int h, double t) {
        BufferedImage img = new BufferedImage(w, h, 2);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        Random rnd = new Random(31 + style.ordinal());
        float u = (float)w / 200.0f;
        switch (style) {
            case Sober: {
                CapeTexture.soberBackground(g, w, h);
                CapeTexture.stars(g, rnd, w, h, 30, u, 0.0, 0.6);
                CapeTexture.glow(g, (double)w * 0.5, (double)h * 0.45, (double)w * 0.55, new Color(255, 255, 255, 55));
                CapeTexture.draw(g, BOTTLE, (double)w * 0.5, (double)h * 0.45, (double)h * 0.68, 1.0f);
                CapeTexture.border(g, w, h, CapeTexture.silver(150), u);
                break;
            }
            case SoberShine: {
                g.setPaint(new GradientPaint(0.0f, 0.0f, new Color(74, 74, 82), w, h, new Color(18, 18, 22)));
                g.fillRect(0, 0, w, h);
                CapeTexture.draw(g, BOTTLE, (double)w * 0.5, (double)h * 0.45, (double)h * 0.68, 1.0f);
                double sweep = t / 2.6 % 1.0 * 1.7 - 0.35;
                Polygon band = new Polygon(new int[]{(int)((double)w * (sweep - 0.25)), (int)((double)w * (sweep + 0.05)), (int)((double)w * (sweep + 0.35)), (int)((double)w * (sweep + 0.05))}, new int[]{0, 0, h, h}, 4);
                g.setPaint(new GradientPaint((float)((double)w * (sweep - 0.15)), 0.0f, new Color(255, 255, 255, 0), (float)((double)w * (sweep + 0.1)), 0.0f, new Color(255, 255, 255, 130), true));
                g.fill(band);
                CapeTexture.border(g, w, h, CapeTexture.silver(130), u);
                break;
            }
            case NeonBottle: {
                g.setColor(new Color(9, 9, 11));
                g.fillRect(0, 0, w, h);
                double flicker = 0.7 + 0.3 * Math.sin(t * 3.0) + (Math.sin(t * 23.0) > 0.96 ? -0.3 : 0.0);
                CapeTexture.glow(g, (double)w * 0.5, (double)h * 0.45, (double)w * 0.65, new Color(255, 255, 255, CapeTexture.clamp(80.0 * flicker)));
                CapeTexture.draw(g, BOTTLE, (double)w * 0.5, (double)h * 0.45, (double)h * 0.72, (float)Math.max(0.25, Math.min(1.0, flicker)));
                CapeTexture.neonFrame(g, w, h, u, flicker);
                break;
            }
            case Drip: {
                CapeTexture.soberBackground(g, w, h);
                CapeTexture.drops(g, w, h, u, t);
                CapeTexture.glow(g, (double)w * 0.5, (double)h * 0.3, (double)w * 0.55, new Color(255, 255, 255, 45));
                CapeTexture.draw(g, WORD, (double)w * 0.5, (double)h * 0.3, (double)w * 0.96, 1.0f);
                CapeTexture.draw(g, BOTTLE, (double)w * 0.5, (double)h * 0.66, (double)h * 0.36, 0.9f);
                CapeTexture.border(g, w, h, CapeTexture.silver(140), u);
                break;
            }
            case Badge: {
                CapeTexture.soberBackground(g, w, h);
                CapeTexture.stars(g, rnd, w, h, 30, u, t, 0.5);
                AffineTransform saved = g.getTransform();
                g.rotate(t * 0.35, (double)w * 0.5, (double)h * 0.45);
                g.translate(w, 0);
                g.scale(-1.0, 1.0);
                CapeTexture.draw(g, BADGE, (double)w * 0.5, (double)h * 0.45, (double)w * 0.92, 1.0f);
                g.setTransform(saved);
                CapeTexture.border(g, w, h, CapeTexture.silver(140), u);
                break;
            }
            case Wordmark: {
                CapeTexture.soberBackground(g, w, h);
                CapeTexture.glow(g, (double)w * 0.5, (double)h * 0.4, (double)w * 0.6, new Color(255, 255, 255, 50));
                CapeTexture.draw(g, WORD, (double)w * 0.5, (double)h * 0.4, (double)w * 0.96, 1.0f);
                g.setColor(CapeTexture.silver(120));
                g.setStroke(new BasicStroke(1.4f * u));
                g.drawLine(Math.round((float)w * 0.2f), Math.round((float)h * 0.62f), Math.round((float)w * 0.8f), Math.round((float)h * 0.62f));
                CapeTexture.draw(g, BOTTLE, (double)w * 0.5, (double)h * 0.78, (double)h * 0.22, 0.85f);
                CapeTexture.border(g, w, h, CapeTexture.silver(140), u);
                break;
            }
            case Lightning: {
                double flash;
                g.setColor(new Color(9, 9, 11));
                g.fillRect(0, 0, w, h);
                long strike = (long)Math.floor(t / 1.7);
                double phase = t / 1.7 - (double)strike;
                double d = flash = phase < 0.18 ? 1.0 - phase / 0.18 : 0.0;
                if (flash > 0.0) {
                    g.setColor(new Color(220, 224, 235, (int)Math.round(55.0 * flash)));
                    g.fillRect(0, 0, w, h);
                    CapeTexture.bolt(g, new Random(strike * 7919L), w, h, u, flash);
                }
                CapeTexture.glow(g, (double)w * 0.5, (double)h * 0.45, (double)w * 0.5, new Color(255, 255, 255, CapeTexture.clamp(50.0 + 120.0 * flash)));
                CapeTexture.draw(g, BOTTLE, (double)w * 0.5, (double)h * 0.45, (double)h * 0.66, 1.0f);
                CapeTexture.border(g, w, h, CapeTexture.silver(CapeTexture.clamp(100.0 + 120.0 * flash)), u);
                break;
            }
            case NightSky: {
                g.setPaint(new GradientPaint(0.0f, 0.0f, new Color(6, 6, 9), 0.0f, h, new Color(30, 30, 38)));
                g.fillRect(0, 0, w, h);
                CapeTexture.stars(g, rnd, w, h, 70, u, t, 1.0);
                CapeTexture.glow(g, (double)w * 0.5, (double)h * 0.45, (double)w * 0.55, new Color(255, 255, 255, CapeTexture.clamp(70.0 + 50.0 * Math.sin(t * 1.6))));
                CapeTexture.draw(g, BOTTLE, (double)w * 0.5, (double)h * 0.45, (double)h * 0.66, 1.0f);
                CapeTexture.border(g, w, h, CapeTexture.silver(120), u);
                break;
            }
            case Smoke: {
                g.setColor(new Color(16, 16, 19));
                g.fillRect(0, 0, w, h);
                Color[] smoke = new Color[]{new Color(200, 200, 210, 45), new Color(150, 150, 160, 40), new Color(240, 240, 245, 30)};
                for (int i = 0; i < 26; ++i) {
                    double bx = rnd.nextDouble() * (double)w + Math.sin(t * 0.25 + (double)i) * (double)w * 0.08;
                    double by = rnd.nextDouble() * (double)h - (t * 0.04 * (double)h + (double)(i * 13)) % ((double)h * 1.2) + (double)h * 0.6;
                    CapeTexture.glow(g, bx, by, (double)w * (0.25 + rnd.nextDouble() * 0.35), smoke[i % 3]);
                }
                CapeTexture.stars(g, rnd, w, h, 40, u, 0.0, 0.0);
                CapeTexture.glow(g, (double)w * 0.5, (double)h * 0.45, (double)w * 0.5, new Color(255, 255, 255, 60));
                CapeTexture.draw(g, BOTTLE, (double)w * 0.5, (double)h * 0.45, (double)h * 0.66, 1.0f);
                CapeTexture.border(g, w, h, CapeTexture.silver(120), u);
                break;
            }
            case Chrome: {
                for (int y = 0; y < h; ++y) {
                    for (int x = 0; x < w; ++x) {
                        double v = ((double)x * 0.6 + (double)y) / ((double)w * 0.6 + (double)h) * 2.2 - t * 0.18;
                        double wave = 0.5 + 0.5 * Math.sin(v * Math.PI * 2.0);
                        int c = (int)Math.round(70.0 + 150.0 * Math.pow(wave, 2.2));
                        img.setRGB(x, y, 0xFF000000 | c << 16 | c << 8 | Math.min(255, c + 8));
                    }
                }
                g.setPaint(new GradientPaint(0.0f, 0.0f, new Color(255, 255, 255, 80), w, h, new Color(0, 0, 0, 70)));
                g.fillRect(0, 0, w, h);
                CapeTexture.glow(g, (double)w * 0.5, (double)h * 0.45, (double)w * 0.5, new Color(10, 10, 14, 120));
                CapeTexture.draw(g, BOTTLE, (double)w * 0.5, (double)h * 0.45, (double)h * 0.66, 1.0f);
                CapeTexture.border(g, w, h, new Color(255, 255, 255, 170), u);
            }
        }
        g.dispose();
        return img;
    }

    private static Color silver(int alpha) {
        return new Color(SILVER.getRed(), SILVER.getGreen(), SILVER.getBlue(), CapeTexture.clamp(alpha));
    }

    private static int clamp(double value) {
        return (int)Math.round(Math.max(0.0, Math.min(255.0, value)));
    }

    private static void soberBackground(Graphics2D g, int w, int h) {
        g.setPaint(new RadialGradientPaint(new Point2D.Double((double)w * 0.5, (double)h * 0.4), (float)h * 0.75f, new float[]{0.0f, 1.0f}, new Color[]{new Color(48, 48, 54), new Color(10, 10, 12)}));
        g.fillRect(0, 0, w, h);
    }

    private static void drops(Graphics2D g, int w, int h, float u, double t) {
        Random rnd = new Random(77L);
        for (int i = 0; i < 9; ++i) {
            double x = (double)w * (0.12 + rnd.nextDouble() * 0.76);
            double speed = 0.18 + rnd.nextDouble() * 0.22;
            double phase = (t * speed + rnd.nextDouble()) % 1.0;
            double y = (double)h * (0.38 + phase * 0.62);
            double size = (5.0 + rnd.nextDouble() * 4.0) * (double)u * (0.6 + 0.4 * (1.0 - phase));
            int alpha = CapeTexture.clamp(220.0 * (1.0 - phase * phase));
            g.setColor(CapeTexture.silver(alpha / 3));
            g.setStroke(new BasicStroke((float)(size * 0.35), 1, 1));
            g.draw(new Line2D.Double(x, (double)h * 0.36, x, y - size));
            g.setColor(CapeTexture.silver(alpha));
            g.fill(new Ellipse2D.Double(x - size * 0.5, y - size, size, size * 1.3));
            g.setColor(new Color(255, 255, 255, alpha));
            g.fill(new Ellipse2D.Double(x - size * 0.22, y - size * 0.75, size * 0.28, size * 0.36));
        }
    }

    private static void stars(Graphics2D g, Random rnd, int w, int h, int count, float u, double t, double twinkleAmount) {
        for (int i = 0; i < count; ++i) {
            double sx = rnd.nextDouble() * (double)w;
            double sy = rnd.nextDouble() * (double)h;
            double phase = rnd.nextDouble() * Math.PI * 2.0;
            double speed = 1.2 + rnd.nextDouble() * 2.0;
            float size = (0.6f + rnd.nextFloat() * 2.0f) * u;
            double twinkle = 1.0 - twinkleAmount * (0.5 - 0.5 * Math.sin(t * speed + phase));
            g.setColor(new Color(240, 240, 246, (int)Math.round((double)(90 + rnd.nextInt(165)) * twinkle)));
            g.fill(new Ellipse2D.Double(sx, sy, size, size));
        }
    }

    private static void bolt(Graphics2D g, Random rnd, int w, int h, float u, double flash) {
        Path2D.Double path = new Path2D.Double();
        double x = (double)w * (0.2 + rnd.nextDouble() * 0.6);
        double y = 0.0;
        ((Path2D)path).moveTo(x, y);
        while (y < (double)h) {
            ((Path2D)path).lineTo(x += (double)w * (rnd.nextDouble() - 0.5) * 0.35, y += (double)h * (0.06 + rnd.nextDouble() * 0.08));
        }
        for (int pass = 0; pass < 3; ++pass) {
            float width = (pass == 0 ? 9.0f : (pass == 1 ? 4.0f : 1.5f)) * u;
            int alpha = (int)Math.round((double)(pass == 0 ? 50 : (pass == 1 ? 120 : 255)) * flash);
            g.setColor(pass == 2 ? new Color(255, 255, 255, alpha) : CapeTexture.silver(alpha));
            g.setStroke(new BasicStroke(width, 1, 1));
            g.draw(path);
        }
    }

    private static void neonFrame(Graphics2D g, int w, int h, float u, double flicker) {
        g.setColor(new Color(255, 255, 255, CapeTexture.clamp(55.0 * flicker)));
        g.setStroke(new BasicStroke(6.0f * u));
        g.drawRect(Math.round(8.0f * u), Math.round(8.0f * u), w - 1 - Math.round(16.0f * u), h - 1 - Math.round(16.0f * u));
        g.setColor(new Color(245, 245, 250, CapeTexture.clamp(220.0 * flicker)));
        g.setStroke(new BasicStroke(1.6f * u));
        g.drawRect(Math.round(8.0f * u), Math.round(8.0f * u), w - 1 - Math.round(16.0f * u), h - 1 - Math.round(16.0f * u));
    }

    private static void border(Graphics2D g, int w, int h, Color color, float u) {
        g.setColor(color);
        g.setStroke(new BasicStroke(2.0f * u));
        g.drawRect(Math.round(u), Math.round(u), w - 1 - Math.round(2.0f * u), h - 1 - Math.round(2.0f * u));
    }

    private static void glow(Graphics2D g, double cx, double cy, double r, Color c) {
        g.setPaint(new RadialGradientPaint(new Point2D.Double(cx, cy), (float)r, new float[]{0.0f, 1.0f}, new Color[]{c, new Color(c.getRed(), c.getGreen(), c.getBlue(), 0)}));
        g.fill(new Ellipse2D.Double(cx - r, cy - r, r * 2.0, r * 2.0));
    }

    private static void draw(Graphics2D g, String path, double cx, double cy, double size, float opacity) {
        BufferedImage image = CapeTexture.image(path);
        double scale = Math.min(size / (double)Math.max(image.getWidth(), image.getHeight()), 86.0 / (double)image.getWidth());
        double dw = (double)image.getWidth() * scale;
        double dh = (double)image.getHeight() * scale;
        g.setComposite(AlphaComposite.getInstance(3, Math.max(0.0f, Math.min(1.0f, opacity))));
        g.drawImage(image, (int)Math.round(cx - dw / 2.0), (int)Math.round(cy - dh / 2.0), (int)Math.round(dw), (int)Math.round(dh), null);
        g.setComposite(AlphaComposite.SrcOver);
    }
}

