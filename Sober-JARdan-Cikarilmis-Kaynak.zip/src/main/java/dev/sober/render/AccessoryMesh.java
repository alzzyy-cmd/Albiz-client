/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.joml.Matrix4f
 *  org.joml.Matrix4fc
 *  org.joml.Vector3f
 */
package dev.sober.render;

import java.util.Arrays;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;

public final class AccessoryMesh {
    public static final int GOLD = -3885571;
    public static final int GOLD_DARK = -7639072;
    public static final int FEATHER_A = -14276819;
    public static final int FEATHER_B = -15066336;
    public static final int FEATHER_BACK = -15724267;
    public static final int BONE = -13750216;
    private static final int[][] FACES = new int[][]{{0, 1, 2, 3}, {5, 4, 7, 6}, {4, 0, 3, 7}, {1, 5, 6, 2}, {4, 5, 1, 0}, {3, 2, 6, 7}};
    private static final float[][] NORMALS = new float[][]{{0.0f, 0.0f, -1.0f}, {0.0f, 0.0f, 1.0f}, {-1.0f, 0.0f, 0.0f}, {1.0f, 0.0f, 0.0f}, {0.0f, -1.0f, 0.0f}, {0.0f, 1.0f, 0.0f}};
    private static final float[] LENGTHS = new float[]{8.5f, 10.5f, 12.0f, 13.2f, 13.6f, 12.6f, 10.6f};
    private static final float[] ALONG = new float[]{2.2f, 4.8f, 7.2f, 2.0f, 5.0f, 1.4f, 4.2f};
    public float[] positions = new float[768];
    public float[] normals = new float[192];
    public int[] colors = new int[64];
    public boolean[] glow = new boolean[64];
    public int quads;
    private final Vector3f corner = new Vector3f();
    private final Vector3f normal = new Vector3f();

    public AccessoryMesh reset() {
        this.quads = 0;
        return this;
    }

    private void ensure(int more) {
        if (this.quads + more <= this.colors.length) {
            return;
        }
        int size = Math.max(this.colors.length * 2, this.quads + more);
        this.positions = Arrays.copyOf(this.positions, size * 12);
        this.normals = Arrays.copyOf(this.normals, size * 3);
        this.colors = Arrays.copyOf(this.colors, size);
        this.glow = Arrays.copyOf(this.glow, size);
    }

    public void box(Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, int color, boolean bright) {
        this.ensure(6);
        float[][] c = new float[][]{{x0, y0, z0}, {x1, y0, z0}, {x1, y1, z0}, {x0, y1, z0}, {x0, y0, z1}, {x1, y0, z1}, {x1, y1, z1}, {x0, y1, z1}};
        float[] p = new float[24];
        for (int i = 0; i < 8; ++i) {
            m.transformPosition(this.corner.set(c[i][0], c[i][1], c[i][2]));
            p[i * 3] = this.corner.x;
            p[i * 3 + 1] = this.corner.y;
            p[i * 3 + 2] = this.corner.z;
        }
        for (int f = 0; f < 6; ++f) {
            for (int k = 0; k < 4; ++k) {
                int v = FACES[f][k];
                System.arraycopy(p, v * 3, this.positions, this.quads * 12 + k * 3, 3);
            }
            m.transformDirection(this.normal.set(NORMALS[f][0], NORMALS[f][1], NORMALS[f][2])).normalize();
            this.normals[this.quads * 3] = this.normal.x;
            this.normals[this.quads * 3 + 1] = this.normal.y;
            this.normals[this.quads * 3 + 2] = this.normal.z;
            this.colors[this.quads] = color;
            this.glow[this.quads] = bright;
            ++this.quads;
        }
    }

    public void wing(Matrix4f body, int side, float spread, float flap, float size, int accent) {
        Matrix4f m = new Matrix4f((Matrix4fc)body).scale((float)side, 1.0f, 1.0f).translate(1.6f, 2.4f, 2.3f).scale(size);
        m.rotateY(-(0.5f - 0.42f * spread) - flap).rotateX(0.1f * (1.0f - spread));
        float lift = -(0.6f - 0.32f * spread);
        Matrix4f gem = new Matrix4f((Matrix4fc)m).translate(0.4f, 0.6f, 0.5f);
        this.box(gem, -2.1f, -2.1f, -0.7f, 2.1f, 2.1f, 0.7f, -7639072, false);
        this.box(new Matrix4f((Matrix4fc)gem).rotateZ(0.7853982f), -1.25f, -1.25f, -0.95f, 1.25f, 1.25f, 0.95f, accent, true);
        Matrix4f bar = new Matrix4f((Matrix4fc)m).rotateZ(lift);
        this.box(bar, 1.2f, -1.1f, -0.8f, 8.0f, 1.1f, 0.8f, -13750216, false);
        Matrix4f bar2 = new Matrix4f((Matrix4fc)bar).translate(8.0f, 0.0f, 0.0f).rotateZ(0.2f);
        this.box(bar2, -0.3f, -1.0f, -0.7f, 7.0f, 1.0f, 0.7f, -13750216, false);
        Matrix4f bar3 = new Matrix4f((Matrix4fc)bar2).translate(7.0f, 0.0f, 0.0f).rotateZ(0.28f);
        this.box(bar3, -0.3f, -0.85f, -0.6f, 5.2f, 0.85f, 0.6f, -13750216, false);
        this.box(new Matrix4f((Matrix4fc)bar3).translate(5.2f, 0.0f, 0.0f).rotateZ(-1.2f), -0.4f, -0.7f, -0.55f, 2.6f, 0.7f, 0.55f, -3885571, false);
        Matrix4f[] frames = new Matrix4f[]{bar, bar, bar, bar2, bar2, bar3, bar3};
        Matrix4f inverse = new Matrix4f((Matrix4fc)m).invert();
        for (int i = 0; i < 7; ++i) {
            float fold = (float)Math.toRadians(100.0f - (float)i * 10.5f);
            float open = (float)Math.toRadians(82.0f - (float)i * 10.5f);
            float angle = fold + (open - fold) * spread;
            Vector3f local = inverse.transformPosition(frames[i].transformPosition(new Vector3f(ALONG[i], 0.6f, 0.0f)));
            Matrix4f feather = new Matrix4f((Matrix4fc)m).translate(local.x, local.y, local.z + 0.12f * (float)i).rotateZ(angle);
            float length = LENGTHS[i];
            this.box(feather, 0.0f, -1.3f, -0.35f, length - 2.4f, 1.3f, 0.35f, i % 2 == 0 ? -14276819 : -15066336, false);
            this.box(feather, length - 2.4f, -1.1f, -0.3f, length, 1.1f, 0.3f, accent, true);
            this.box(feather, -0.4f, -1.45f, -0.5f, 1.0f, 1.45f, 0.5f, -3885571, false);
            if (i >= 6) continue;
            Matrix4f back = new Matrix4f((Matrix4fc)m).translate(local.x + 0.6f, local.y + 0.4f, local.z + 0.55f).rotateZ(angle - 0.09f);
            this.box(back, 0.0f, -1.05f, -0.3f, length * 0.6f, 1.05f, 0.3f, -15724267, false);
        }
    }

    public void crown(Matrix4f head, int accent, int metal) {
        int dark = metal == -3885571 ? -7639072 : 0xFF000000 | Math.round((float)(metal >> 16 & 0xFF) * 0.8f) << 16 | Math.round((float)(metal >> 8 & 0xFF) * 0.8f) << 8 | Math.round((float)(metal & 0xFF) * 0.8f);
        Matrix4f m = new Matrix4f((Matrix4fc)head).translate(0.0f, -8.4f, 0.0f).rotateZ(0.05f);
        float r = 4.6f;
        float t = 0.8f;
        float top = -1.2f;
        float bottom = 0.9f;
        this.box(m, -r - t, top, -r - t, r + t, bottom, -r, metal, false);
        this.box(m, -r - t, top, r, r + t, bottom, r + t, metal, false);
        this.box(m, -r - t, top, -r, -r, bottom, r, metal, false);
        this.box(m, r, top, -r, r + t, bottom, r, metal, false);
        for (int side = 0; side < 4; ++side) {
            Matrix4f s = new Matrix4f((Matrix4fc)m).rotateY((float)(1.5707963267948966 * (double)side));
            this.box(s, -0.75f, top - 3.6f, -r - t, 0.75f, top, -r, metal, false);
            this.box(s, -0.6f, top - 4.8f, -r - t + 0.05f, 0.6f, top - 3.6f, -r - 0.05f, accent, true);
            for (int k = -1; k <= 1; k += 2) {
                this.box(s, (float)k * 2.6f - 0.55f, top - 1.9f, -r - t, (float)k * 2.6f + 0.55f, top, -r, dark, false);
            }
            this.box(s, -r - t - 0.2f, top - 2.4f, -r - t - 0.2f, -r + 0.2f, bottom + 0.2f, -r + 0.2f, metal, false);
            this.box(s, -r - t + 0.05f, top - 3.0f, -r - t + 0.05f, -r - 0.05f, top - 2.4f, -r - 0.05f, dark, false);
        }
        Matrix4f gem = new Matrix4f((Matrix4fc)m).translate(0.0f, (top + bottom) / 2.0f, -r - t - 0.2f).rotateZ(0.7853982f);
        this.box(gem, -1.15f, -1.15f, -0.4f, 1.15f, 1.15f, 0.4f, accent, true);
    }
}

