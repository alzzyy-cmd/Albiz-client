/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 *  net.fabricmc.loader.api.FabricLoader
 */
package dev.sober;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.sober.SoberClient;
import dev.sober.module.Module;
import dev.sober.module.ModuleManager;
import dev.sober.setting.Setting;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.fabricmc.loader.api.FabricLoader;

public final class Config {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, String> LEGACY = Map.of("Relog Method", "Y Relog", "SusChunks", "Better Sus Chunk");
    private static final int BACKUPS = 5;
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("soberclient.json");
    private final Path backups = FabricLoader.getInstance().getConfigDir().resolve("sober").resolve("backups");
    private final ModuleManager modules;
    private final Map<String, JsonObject> unread = new HashMap<String, JsonObject>();
    private boolean readable = true;

    public Config(ModuleManager modules) {
        this.modules = modules;
    }

    public void load() {
        JsonObject root;
        if (!Files.exists(this.file, new LinkOption[0])) {
            return;
        }
        try {
            root = JsonParser.parseString((String)Files.readString(this.file, StandardCharsets.UTF_8)).getAsJsonObject();
        }
        catch (Exception e) {
            this.readable = false;
            SoberClient.LOG.error("Could not read config, it will not be overwritten", (Throwable)e);
            return;
        }
        this.backup();
        for (Module module : this.modules.all()) {
            String key = root.has(module.name) ? module.name : LEGACY.get(module.name);
            try {
                if (key == null || !root.has(key)) continue;
                JsonObject data = root.getAsJsonObject(key);
                if (data.has("key")) {
                    module.setKey(data.get("key").getAsInt());
                }
                if (data.has("settings")) {
                    JsonObject settings = data.getAsJsonObject("settings");
                    for (Setting<?> setting : module.getSettings()) {
                        JsonElement value = settings.get(setting.name);
                        if (value == null) continue;
                        try {
                            setting.load(value);
                        }
                        catch (Exception exception) {}
                    }
                }
                if (!data.has("enabled") || !data.get("enabled").getAsBoolean()) continue;
                module.setEnabled(true);
            }
            catch (Exception e) {
                if (key != null && root.has(key) && root.get(key).isJsonObject()) {
                    this.unread.put(module.name, root.getAsJsonObject(key));
                }
                SoberClient.LOG.error("Could not load the config of {}, its saved settings are kept", (Object)module.name, (Object)e);
            }
        }
    }

    public boolean loadedCleanly(Module module) {
        return !this.unread.containsKey(module.name);
    }

    private void backup() {
        try {
            Files.createDirectories(this.backups, new FileAttribute[0]);
            String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
            Files.copy(this.file, this.backups.resolve("soberclient_" + stamp + ".json"), StandardCopyOption.REPLACE_EXISTING);
            try (Stream<Path> stream = Files.list(this.backups);){
                List old = stream.filter(path -> path.getFileName().toString().startsWith("soberclient_")).sorted(Comparator.reverseOrder()).skip(5L).toList();
                for (Path path2 : old) {
                    Files.deleteIfExists(path2);
                }
            }
        }
        catch (IOException e) {
            SoberClient.LOG.warn("Could not back up the config", (Throwable)e);
        }
    }

    public JsonObject toJson() {
        JsonObject root = new JsonObject();
        for (Module module : this.modules.all()) {
            JsonObject kept = this.unread.get(module.name);
            if (kept != null) {
                root.add(module.name, (JsonElement)kept.deepCopy());
                continue;
            }
            JsonObject data = new JsonObject();
            data.addProperty("enabled", Boolean.valueOf(module.isActive()));
            data.addProperty("key", (Number)module.getKey());
            JsonObject settings = new JsonObject();
            for (Setting<?> setting : module.getSettings()) {
                settings.add(setting.name, setting.save());
            }
            data.add("settings", (JsonElement)settings);
            root.add(module.name, (JsonElement)data);
        }
        return root;
    }

    public void apply(JsonObject root, Predicate<Module> skip, Predicate<Module> keepEnabled) {
        for (Module module : this.modules.all()) {
            String key;
            if (skip.test(module) || (key = root.has(module.name) ? module.name : LEGACY.get(module.name)) == null || !root.has(key)) continue;
            try {
                JsonObject data = root.getAsJsonObject(key);
                if (data.has("key")) {
                    module.setKey(data.get("key").getAsInt());
                }
                if (data.has("settings")) {
                    JsonObject settings = data.getAsJsonObject("settings");
                    for (Setting<?> setting : module.getSettings()) {
                        JsonElement value = settings.get(setting.name);
                        if (value == null) continue;
                        try {
                            setting.apply(value);
                        }
                        catch (Exception exception) {}
                    }
                }
                if (!keepEnabled.test(module)) {
                    module.setEnabled(data.has("enabled") && data.get("enabled").getAsBoolean());
                }
                this.unread.remove(module.name);
            }
            catch (Exception e) {
                SoberClient.LOG.error("Could not apply config for {}", (Object)module.name, (Object)e);
            }
        }
    }

    public void resetTo(JsonObject defaults) {
        this.unread.clear();
        this.readable = true;
        this.apply(defaults, module -> false, module -> false);
    }

    public void save() {
        if (!this.readable) {
            return;
        }
        JsonObject root = this.toJson();
        try {
            Files.createDirectories(this.file.getParent(), new FileAttribute[0]);
            Files.writeString(this.file, (CharSequence)GSON.toJson((JsonElement)root), StandardCharsets.UTF_8, new OpenOption[0]);
        }
        catch (IOException e) {
            SoberClient.LOG.error("Could not save config", (Throwable)e);
        }
    }
}

